local Keepwork = NPL.export()
local KeepworkAPI = NPL.load("./KeepworkAPI.lua")
local GitlabAPI = NPL.load("./GitlabAPI.lua")

local userinfo ;
local authorization;
local namespace = "truckstar";
local defaultPlanetPath = "/offline";
local defaultRepository = "/keepworkdatasource"
local defaultdatasource;

local function checkIfLogin()
    if not userinfo then
        error("need log in keepwork.")
    end
end

function Keepwork.login(account, password, callback)
    KeepworkAPI.user.login(account, password, function (data, err)
            if not err and data.error.id == 0 then
                userinfo = data.data.userinfo;
                userinfo.website = KeepworkAPI.getDomain();
                defaultdatasource = userinfo.defaultSiteDataSource;
                authorization = "Bearer " .. data.data.token;
            end

            callback(data, err);
        end,
        1)
end

function Keepwork.logout()
    userinfo = nil;
end

function Keepwork.getUserinfo()
    return userinfo;
end


function Keepwork.register(username, password, callback)
    KeepworkAPI.user.register(username, password, callback)
end

-- oauth
function Keepwork.oauth(callback)
    KeepworkAPI.oauth_app.agreeOauth(userinfo.username, authorization, callback);
end

-- website
function Keepwork.getWebsite(sitename,callback)
    checkIfLogin();
    KeepworkAPI.website.getDetailInfo(userinfo.username, sitename, authorization, callback)
end

function Keepwork.createWebsite(sitename, callback)
    checkIfLogin();
    KeepworkAPI.website.new({displayName = sitename, name = sitename, userId = userinfo._id, username = userinfo.username},authorization, callback);
end

function Keepwork.addPage(sitename, pagename, content, callback)
    checkIfLogin();
    local git = GitlabAPI:new():init(defaultdatasource.apiBaseUrl, defaultdatasource.dataSourceToken);
    local path = string.format("%s/%s/%s.md", defaultdatasource.username, sitename, pagename); 
    git:add(defaultdatasource.projectId, path, content, callback);
end

function Keepwork.getPage(sitename, pagename, callback)
    checkIfLogin();
    local git = GitlabAPI:new():init(defaultdatasource.apiBaseUrl, defaultdatasource.dataSourceToken);
    local path = string.format("%s/%s/%s.md", defaultdatasource.username, sitename, pagename); 
    git:getRaw(defaultdatasource.projectId, path, nil, callback );
end

function Keepwork.updatePage(sitename, pagename, content, callback)
    checkIfLogin();
    local git = GitlabAPI:new():init(defaultdatasource.apiBaseUrl, defaultdatasource.dataSourceToken);
    local path = string.format("%s/%s/%s.md", defaultdatasource.username, sitename, pagename); 
    git:update(defaultdatasource.projectId, path, content, callback);
end


function Keepwork.addTheme(sitename, content, callback)
    checkIfLogin();
    content = content or defaulttheme;
    Keepwork.addPage(sitename, content, callback);
end
