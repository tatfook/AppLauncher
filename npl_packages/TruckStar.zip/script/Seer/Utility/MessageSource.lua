--[[
    Title: MessageSource
    Author(s): Devil
    Date: 2016/04/7
    Desc: Seer Message Source
    use the lib:
    ------------------------------------------------------------
    NPL.load("(gl)script/Seer/Utility/MessageSource.lua");
    local MessageSource=commonlib.gettable("Mod.Seer.Utility.MessageSource");
    local MessageSourceContainer=commonlib.gettable("Mod.Seer.Utility.MessageSourceContainer");
    -------------------------------------------------------
]]
--internal struct
local ListenerList=commonlib.inherit(nil,commonlib.gettable("Mod.Seer.Utility.MessageSource.ListenerList"));
function ListenerList:addListener(instance,callback)
	self:_getList()[instance]=callback;
end
function ListenerList:removeListener(instance)
	self:_getList()[instance]=nil;
end
--return value:if true that skip next others process,if false that go on process
function ListenerList:notify(message,...)
	for instance,callback in pairs(self:_getList()) do
		if callback(instance,message,...) then
			return true;
		end
	end
	return false;
end
function ListenerList:_getList()
	self.mList=self.mList or {};
	return self.mList;
end
--internal struct
local ListenerGroup=commonlib.inherit(nil,commonlib.gettable("Mod.Seer.Utility.MessageSource.ListenerGroups"));
function ListenerGroup:addListenerOrdered(instance,callback,order)
	if not self:_getOrderedList()[order] then
		self:_getOrderedList()[order]=ListenerList:new();
	end
	self:_getOrderedList()[order]:addListener(instance,callback);
	table.sort(self:_getOrderedList());
end
function ListenerGroup:addListenerUnordered(instance,callback)
	self:_getUnorderedList():addListener(instance,callback);
end
function ListenerGroup:removeListenerOrdered(instance)
	if not self:_getOrderedList() then
		return;
	end
	for order,list in pairs(self:_getOrderedList()) do
		list:removeListener(instance);
	end
end
function ListenerGroup:removeListenerUnordered(instance)
	self:_getUnorderedList():removeListener(instance);
end
function ListenerGroup:removeListener(instance)
	self:removeListenerOrdered(instance);
	self:removeListenerUnordered(instance);
end
--return value:if true that skip next others process,if false that go on process
function ListenerGroup:notify(message,...)
	if self:_notifyOrdered(message,...) then
		return true;
	end
	return self:_notifyUnordered(message,...);
end
--return value:if true that skip next others process,if false that go on process
function ListenerGroup:_notifyOrdered(message,...)
	for order,list in pairs(self:_getOrderedList()) do
		if list:notify(message,...) then
			return true;
		end
	end
	return false;
end
function ListenerGroup:_notifyUnordered(message,...)
	return self:_getUnorderedList():notify(message,...);
end
function ListenerGroup:_getOrderedList()
	self.mOrderedList=self.mOrderedList or {};
	return self.mOrderedList;
end
function ListenerGroup:_getUnorderedList()
	self.mUnorderedList=self.mUnorderedList or ListenerList:new();
	return self.mUnorderedList;
end
--MessageSource
local MessageSource=commonlib.inherit(nil,commonlib.gettable("Mod.Seer.Utility.MessageSource"));
function MessageSource:addListenerOrdered(message,instance,callback,order)
	self:_getListenerList(message):addListenerOrdered(instance,callback,order);
end
function MessageSource:addListenerUnordered(message,instance,callback)
	self:_getListenerList(message):addListenerUnordered(instance,callback);
end
function MessageSource:removeListenerUnordered(message,instance)
	if not self:_hasListenerList(message) then
		return;
	end
	self:_getListenerList(message):removeListenerUnordered(instance);
end
function MessageSource:removeListenerOrdered(message,instance)
	if not self:_hasListenerList(message) then
		return;
	end
	self:_getListenerList(message):removeListenerOrdered(instance);
end
function MessageSource:removeListener(message,instance)
	if not self:_hasListenerList(message) then
		return;
	end
	self:_getListenerList(message):removeListener(instance);
end
function MessageSource:notify(message,...)
	if self:_hasListenerList(message) then
		self:_getListenerGroups()[message]:notify(message,...);
	end
end
function MessageSource:_hasListenerGroups()
	return nil~=self.mListenerGroups;
end
function MessageSource:_hasListenerList(message)
	return self:_hasListenerGroups() and nil~=self.mListenerGroups[message];
end
function MessageSource:_getListenerGroups()
	self.mListenerGroups=self.mListenerGroups or {};
	return self.mListenerGroups;
end
function MessageSource:_getListenerList(message)
	self:_getListenerGroups()[message]=self:_getListenerGroups()[message] or ListenerGroup:new();
	return self:_getListenerGroups()[message];
end

local MessageSourceContainer=commonlib.inherit(nil,commonlib.gettable("Mod.Seer.Utility.MessageSourceContainer"));
function MessageSourceContainer:ctor()
end
function MessageSourceContainer:getMessageSource()
	self.mMessageSource=self.mMessageSource or MessageSource:new();
	return self.mMessageSource;
end