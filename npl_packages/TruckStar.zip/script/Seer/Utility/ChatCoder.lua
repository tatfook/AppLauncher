NPL.load("(gl)script/Seer/NetWork/YcProfile.lua");
local YcProfile = commonlib.gettable("Mod.Seer.Network.YcProfile");
local ChatCoder=commonlib.gettable("Seer.Utility.ChatCoder");
local lMark="6$$6";
local function _processPair(pair)
  local splite_pos=string.find(pair,":");
  local key=string.sub(pair,1,splite_pos-1);
  local value=string.sub(pair,splite_pos+1);
  local need_to_number_keys={"FromUserID","FromUserAvatarID"};
  for i=1,#need_to_number_keys do
    if need_to_number_keys[i]==key then
      value=tonumber(value);
      break;
    end
  end
  return key,value;
end

function ChatCoder.encode(chatText)
  local ret=lMark;
  ret=ret.."FromUserID:"..tostring(YcProfile.GetUID())..";";
  ret=ret.."FromUserNickName:"..tostring(YcProfile.GetMyNickname())..";";
  ret=ret.."FromUserAvatarID:"..tostring(YcProfile.GetMyCharacterAssetID())..";";
  ret=ret..lMark;
  ret=ret..chatText;
  return ret;
end

function ChatCoder.encode2(chatText,fromName)
  return lMark.."FromName:"..tostring(fromName)..";"..lMark..chatText;
end

function ChatCoder.decode(text)
  local ret;
  local start_pos,end_pos=string.find(text,lMark);
  if start_pos and end_pos then
    local words=string.sub(text,1,start_pos-1);
    local str=string.sub(text,end_pos+1);
    start_pos,end_pos=string.find(str,lMark);
    words=words..string.sub(str,end_pos+1);
    str=string.sub(str,1,start_pos-1);
    if start_pos and end_pos then
      ret={mText=words};
      while string.find(str,';') do
        local pair=string.sub(str,1,string.find(str,';')-1);
        local key,value=_processPair(pair);
        ret["m"..key]=value;
        str=string.sub(str,string.find(str,';')+1);
        if string.sub(str,1,1)==lMark then
          break;
        end
      end
    end
  end
  return ret;
end