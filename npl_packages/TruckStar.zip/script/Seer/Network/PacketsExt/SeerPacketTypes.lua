--[[
    Title: SeerPacketTypes.lua
    Author(s): Cellfy
    Date Created: Jul 9, 2016
    Date Updated: Jul 9, 2016
    Desc: packets extension for TruckStar
    Usage:
    ------------------------------------------------------------
    NPL.load("(gl)script/Seer/Network/PacketsExt/SeerPacketTypes.lua");
    local SeerPacketTypes = commonlib.gettable("Mod.Seer.Network.PacketsExt.SeerPacketTypes");
    ------------------------------------------------------------
]]

local Packet_Types = commonlib.gettable("MyCompany.Aries.Game.Network.Packets.Packet_Types");
local Packets = commonlib.gettable("Mod.Seer.Network.PacketsExt");
local SeerPacketTypes = commonlib.gettable("Mod.Seer.Network.PacketsExt.SeerPacketTypes");

SeerPacketTypes.inited = false;

function SeerPacketTypes:StaticInit()
    if(self.inited) then
        return;
    end
    self.inited = true;
    self.callbacks = {};
    self.callback_sequence = 1;
    
    LOG.std(nil, "debug", "SeerPacketTypes", "initialized");

    NPL.load("(gl)script/Seer/Network/PacketsExt/PacketPlayerPositionReq.lua");
    Packet_Types:AddIdClassMapping(10001, true, false, Packets.PacketPlayerPositionReq);
    NPL.load("(gl)script/Seer/Network/PacketsExt/PacketPlayerPosition.lua");
    Packet_Types:AddIdClassMapping(10002, false, true, Packets.PacketPlayerPosition);
    NPL.load("(gl)script/Seer/Game/Lock/LockPackets.lua");
    local LockResponse=commonlib.gettable("Seer.Game.Lock.Server.Packets.Response");
    local CreateMutexReq=commonlib.gettable("Seer.Game.Lock.Server.Packets.CreateMutexReq");
    local RetrieveMutexReq=commonlib.gettable("Seer.Game.Lock.Server.Packets.RetrieveMutexReq");
    local LockReq=commonlib.gettable("Seer.Game.Lock.Server.Packets.LockReq");
    local UnlockReq=commonlib.gettable("Seer.Game.Lock.Server.Packets.UnlockReq");
    Packet_Types:AddIdClassMapping(10003, false, true, LockResponse);
    Packet_Types:AddIdClassMapping(10004, false, true, CreateMutexReq);
    Packet_Types:AddIdClassMapping(10005, false, true, RetrieveMutexReq);
    Packet_Types:AddIdClassMapping(10006, false, true, LockReq);
    Packet_Types:AddIdClassMapping(10007, false, true, UnlockReq);
    NPL.load("(gl)script/Seer/Game/Furniture/FurniturePackets.lua");
    local FurnitureResponse=commonlib.gettable("Seer.Game.Furniture.Packets.Response");
    local PlayFurnitureAnimationReq=commonlib.gettable("Seer.Game.Furniture.Packets.PlayFurnitureAnimationReq");
    Packet_Types:AddIdClassMapping(10008, false, true, FurnitureResponse);
    Packet_Types:AddIdClassMapping(10009, false, true, PlayFurnitureAnimationReq);
    NPL.load("script/Seer/Network/PacketsExt/PacketSyncResourceTable.lua");
    Packet_Types:AddIdClassMapping(10010, true, true, Packets.PacketSyncResourceTable);
    
end

function SeerPacketTypes:RegisterCallback(packet)
    if packet.callback then
        self.callbacks[self.callback_sequence] = packet.callback;
        packet.sequence = self.callback_sequence
        self.callback_sequence = self.callback_sequence + 1;
        packet.callback = nil;
    end
end

function SeerPacketTypes:RunCallback(packet)
    if packet.sequence and type(packet.sequence)=="number" and packet.sequence>0 then
        local callback_func = self.callbacks[packet.sequence];
        if callback_func and type(callback_func)=="function" then
            callback_func(packet);
        end
        self.callbacks[packet.sequence] = nil;
    end
end

function SeerPacketTypes:CheckCallback(packet)
    if packet.sequence and type(packet.sequence)=="number" and packet.sequence>0 then
        local callback_func = self.callbacks[packet.sequence];
        if callback_func and type(callback_func)=="function" then
            return true;
        end
    end
    return false;
end
