--[[
    Title: Node
    Author(s): Devil
    Date: 2017/10/10
    Desc: Seer Node
    use the lib:
    ------------------------------------------------------------
    NPL.load("(gl)script/Seer/Utility/Node.lua");
    local Node=commonlib.gettable("Mod.Seer.Utility.Node");
    -------------------------------------------------------
]]
NPL.load("(gl)script/Seer/Utility/CommonUtility.lua");
NPL.load("(gl)script/Seer/Utility/BaseDestructionObject.lua");
local BaseDestructionObject=commonlib.gettable("Mod.Seer.Utility.BaseDestructionObject");
local CommonUtility = commonlib.gettable("Mod.Seer.Utility.CommonUtility");
local Node=commonlib.inherit(BaseDestructionObject,commonlib.gettable("Mod.Seer.Utility.Node"));
Node.ClassName="Mod.Seer.Utility.Node";
function Node:createChild(name,parent,value)
  local datas={mValue=value};
  local ret=Node:new({mName=name,mParent=parent,mDatas=datas});
  return ret;
end

function Node:ctor()
  self.mDatas=self.mDatas or {};
  self.mChildren=self.mChildren or {};
  self.mChildIterator=self.mChildIterator or 1;
  self.mDataChange=self.mDataChange or false;
end

function Node:_delete()
  for i,child in pairs(self.mChildren) do
    child:delete();
  end
  self.mChildren={};
end

function Node:_dataChange()
  if not self.mDataChange then
    self.mDataChange=true;
    if self.mParent then
      self.mParent:_childDataChange(self);
    end
  end
end

function Node:_childDataChange(child)
end

function Node:getName()
  return self.mName;
end

function Node:getParent()
  return self.mParent;
end

function Node:getChildren()
  return self.mChildren;
end

function Node:setValue(value)
  local datas={mValue=value};
  if not CommonUtility.isTableEqual(datas,self.mDatas) then
    self.mDatas=datas;
    self:_dataChange();
  end
end

function Node:getValue()
  return self.mDatas.mValue;
end

function Node:setChild(name,child)
  self.mChildren[name]=child;
end

function Node:getChild(name)
  return self:getChildren()[name];
end

function Node:deleteChild(name)
  local child=self:getChild(name);
  if child then
    child:delete();
    self:setChild(name,nil);
  end
end

function Node:setChildValue(name,value)
  local child=self:getChild(name);
  if not child then
    self:setChild(name,self:createChild(name,self,value));
  else
    self:getChild(name):setValue(value);
  end
end
function Node:getChildValue(name)
  local child=self:getChild(name);
  if child then
    return child:getValue();
  end
end

function Node:findFirstChild()
  self.mChildIterator=1;
  for key,value in pairs(self.getChildren()) do
    return value;
  end
end

function Node:findNextChild()
  self.mChildIterator=self.mChildIterator+1;
  local iter=1;
  for key,value in pairs(self.getChildren()) do
    if iter==self.mChildIterator then
      return value;
    end
    iter=iter+1;
  end
end

function Node:findClose()
  self.mChildIterator=1;
end
