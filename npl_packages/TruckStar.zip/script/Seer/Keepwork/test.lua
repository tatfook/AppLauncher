local KeepworkAPI = NPL.load("./KeepworkAPI.lua");
local GitlabAPI = NPL.load("./GitlabAPI.lua")
local PlanetManager = NPL.load("script/Seer/Game/Offline/PlanetManager.lua")

return function ()
    KeepworkAPI.login("issacxu", "taomee@123", function (data, err)
        if not err and data.error.id == 0 then
            userinfo = data.data.userinfo;
            local datasource = userinfo.defaultSiteDataSource;
            PlanetManager.connectToDataSource(datasource, function ()
                local planets = PlanetManager.listPlanets();
                for k,v in pairs(planets) do
                    v:sync(nil, function (err)
                        echo(err)
                    end);
                end
                
            end);

            
        end
    end)

end
