﻿--[[
	NPL.load("(gl)script/Seer/Config/ConfigPaser.lua");
	local ConfigPaser = commonlib.gettable("Mod.Seer.Config.ConfigPaser");
]]

local ConfigPaser = commonlib.gettable("Mod.Seer.Config.ConfigPaser");

local function get(self, index)
	return self._VEC[index]
end

local function size(self, index)
	return #self._VEC;
end

local function find(self, key)
	return self._MAP[tostring(key)]
end

--get all nodes without sorting
local function content(self)
	return self._CONTENT
end

local function name(self)
	return self._NAME
end

local function parseTable(cfg)
	if (type(cfg) == "string") then
		commonlib.log("error: " .. cfg .. "\n");
		return;
	end

	local tbl = {content=content, name=name, _CONTENT={}};
	tbl._NAME = cfg.name;
	local _,key, value ;
	--attr
	if (cfg.attr) then
		for key, value in pairs(cfg.attr) do
			tbl[key] = value
		end
	end

	for _,value in ipairs(cfg) do
		local sub = parseTable(value);
		tbl._CONTENT[#tbl._CONTENT + 1] = sub;

		local node = tbl[sub._NAME];
		if (not node) then
			node = {}
			node.get = get
			node.size= size;
			node.find= find; 

			tbl[sub._NAME] = node

		end

		local vec = node._VEC;
		if (not vec) then
			vec = {}
			node._VEC = vec
		end

		local map = node._MAP;
		if not map then
			map = {}
			node._MAP = map ;
		end

		vec[#vec + 1] = sub;

		if sub._KEY then
			local k = sub[sub._KEY];
			if (k) then
				if (map[k]) then
					commonlib.log("error: item('".. sub._KEY.."' = '"..k.."') is existed!\n");
					commonlib.log("old:\n")
					echotable(map[k]);
					commonlib.log("new:\n")
					echotable(sub);
				end
				map[k] = sub;
			end
		end
	end

	return tbl;
end

function ConfigPaser.parse(path, name)
	local cfg = ParaXML.LuaXML_ParseFile(path);
	if (not cfg or not next(cfg)) then 
		commonlib.log("error:parse config " .. path .. " failed.\n")
		return;
	end
	local tbl = parseTable(cfg);
	return  tbl:content()[1];
end
