--[[
    Title: CommonUtility
    Author(s): Cellfy, Issac
    Date: 2016/02/14
    Desc: Seer common utilities
    use the lib:
    ------------------------------------------------------------
    NPL.load("(gl)script/Seer/Utility/CommonUtility.lua");
    local CommonUtility = commonlib.gettable("Mod.Seer.Utility.CommonUtility");
    -------------------------------------------------------
]]

local CommonUtility = commonlib.gettable("Mod.Seer.Utility.CommonUtility");

function CommonUtility:CheckIntegrity()
    LOG.std(nil, "debug", "truckstar", "checking integrity");

    --cellfy: NPL.GetNPLID() may return: "Seer" "Seer_Dev"
    local integrityCheck = false;
    if NPL.GetNPLID then
        if type(NPL.GetNPLID)=="function" then
            if string.match(NPL.GetNPLID(), "Seer") then
                integrityCheck = true;
            end
        end
    end

    --dev warning
    if CommonUtility:IsDevVersion() then
        _guihelper.MessageBox("DEV version, NEVER release me", nil, _guihelper.MessageBoxButtons.OK);
    end

    return integrityCheck;
end

function CommonUtility:IsDevVersion()
    local isDev = false;
    if NPL.GetNPLID then
        if type(NPL.GetNPLID)=="function" then
            if string.match(NPL.GetNPLID(), "Dev") then
                isDev = true;
            end
        end
    end
    return isDev;
end

CommonUtility.DebugMobile = false;
CommonUtility.Android = "android";
CommonUtility.IOS = "ios"
CommonUtility.PC = "pc"

function CommonUtility:IsMobilePlatform() 
    local platform = CommonUtility:GetPlatform();
    return platform == CommonUtility.Android or platform == CommonUtility.IOS or CommonUtility.DebugMobile;
end

function CommonUtility:GetPlatform()
    if(System.options.IsMobilePlatform) then
        return CommonUtility.Android
    else
        return CommonUtility.PC
    end
end

--print all content of the table
--@author Issac
--@param tbl: Table to print
--@param simple: true: do not print the key if it's a number; false: show both key and value on no contition
--@return nil
function echotable(tbl, simple, blank)
   local output = commonlib.log;
   
   if (type(tbl) ~= "table") then
      if (type(tbl) == "string") then
         output('"' .. tbl .. '"\n')
      else
         output(tbl);
         output("\n")
      end
      return
   end

   if (not blank) then
      blank = ""
   end
   output(blank .. "{\n");

   local subblank = blank.."  "

   local key, value;
   for key, value in pairs(tbl) do
      output(subblank)
      if simple ~= true or type(key)~="number" then
         output("[")
         if type(key) == "string" then
            output('"'..key..'"')
         else
            output(key)
         end
         output("] = ")
      end
      if (type(value) == "table" ) then output("\n") end
      
      echotable(value, simple, subblank);

   end
   output(blank .."},");
   output("\n")

end


function CommonUtility:ListAllCommands()
   echo("----------------------------------listing all commands currently available----------------------------------");
   local Commands = commonlib.gettable("MyCompany.Aries.Game.Commands");
   local CommandList = {};
   for k,v in pairs(Commands) do
      table.insert(CommandList, k);
   end
   table.sort(CommandList);
   echotable(CommandList, true);
end

function CommonUtility.getChineseCharacterCount(text)
	local ret=0;
    local char_index=1;
    while char_index<=#text do
        local current_bytes=string.byte(text,char_index);
        local byte_count=1;
        if current_bytes>0 and current_bytes<=127 then
            byte_count = 1;
        elseif current_bytes>=192 and current_bytes< 223 then
            byte_count = 2;
        elseif current_bytes>=224 and current_bytes< 239 then
            byte_count = 3;
        elseif current_bytes>=240 and current_bytes<=247 then
            byte_count = 4;
        end
		if 1<byte_count then
			ret=ret+1;
		end
        char_index=char_index+byte_count;
    end
	return ret;
end

function CommonUtility.getNotChineseCharacterCount(text)
	local ret=0;
    local char_index=1;
    while char_index<=#text do
        local current_bytes=string.byte(text,char_index);
        local byte_count=1;
        if current_bytes>0 and current_bytes<=127 then
            byte_count = 1;
        elseif current_bytes>=192 and current_bytes< 223 then
            byte_count = 2;
        elseif current_bytes>=224 and current_bytes< 239 then
            byte_count = 3;
        elseif current_bytes>=240 and current_bytes<=247 then
            byte_count = 4;
        end
		if 1==byte_count then
			ret=ret+1;
		end
        char_index=char_index+byte_count;
    end
	return ret;
end

function CommonUtility.IsCoinSupported()
	return true;
end

function CommonUtility.isTableEqual(table1,table2)
  local test_func=function(t1,t2)
    for key,value in pairs(t1) do
      local test_value=t2[key];
      if not test_value or type(test_value)~=type(value) then
        return;
      end
      if type(value)==type({}) and not CommonUtility.isTableEqual(value,test_value) then
        return;
      end
      if type(value)~=type({}) and value~=test_value then
        return;
      end
    end
    return true;
  end;
  if type(table1)==type(table2) and type(table1)==type({}) then
    if test_func(table1,table2) and test_func(table2,table1) then
      return true;
    end
  end
end