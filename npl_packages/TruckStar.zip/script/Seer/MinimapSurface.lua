--[[
Title: Minimap Surface
Author(s): LiXizhi
Date: 2015/5/05
Desc: paint minimap around the current player location in a spiral pattern. 
	- click to close. 
	- mouse wheel to zoom in/out
use the lib:
------------------------------------------------------------
NPL.load("(gl)script/Seer/MinimapSurface.lua");
local MinimapSurface = commonlib.gettable("Mod.Seer.UI.MinimapSurface");

-- it is important for the parent window to enable self paint and disable auto clear background. 
window:EnableSelfPaint(true);
window:SetAutoClearBackground(false);
-------------------------------------------------------
]]
local EntityManager = commonlib.gettable("MyCompany.Aries.Game.EntityManager");
local BlockEngine = commonlib.gettable("MyCompany.Aries.Game.BlockEngine");
local MinimapSurface = commonlib.inherit(commonlib.gettable("System.Windows.UIElement"), commonlib.gettable("Mod.Seer.UI.MinimapSurface"));

NPL.load("(gl)script/Seer/MinimapWnd.lua");
local MinimapWnd = commonlib.gettable("MyCompany.Aries.Game.Items.ItemMinimap.MinimapWnd");

local GameLogic = commonlib.gettable("MyCompany.Aries.Game.GameLogic");

NPL.load("(gl)script/ide/timer.lua");

MinimapSurface:Property({"CenterX", nil, desc="map center in block position"});
MinimapSurface:Property({"CenterY", nil, desc="map center in block position"});
MinimapSurface:Property({"MapRadius", 32, "GetMapRadius", "SetMapRadius", desc="map radius in block coordinate"});
MinimapSurface:Property({"BlocksPerFrame", 128 * 128, desc = "how many blocks to render per frame. "});

MinimapSurface:Signal("mapChanged");

-- mapping from block_id to block color like "#ff0000"
local color_table = nil;

local refreshTimer = nil;
local paintDone = nil;

function MinimapSurface:ctor()
	self:ResetDrawProgress();
	self:BuildBlockColorTable();

	if(not refreshTimer) then
		refreshTimer = commonlib.Timer:new({callbackFunc = function(timer)
			local UIManager = commonlib.gettable("Mod.Seer.Game.UI.UIManager");
			local Minimap = UIManager.getUI("Minimap");
	 		if(paintDone and Minimap) then
				Minimap.surface = self;
	 			paintDone = false;
	 			x, _, y = EntityManager.GetPlayer():GetBlockPos();
	 			self.CenterX = x;
	 			self.CenterY = y;
	 			self:ResetDrawProgress();
	 			self:repaint();

	 			-- refresh minimap window
	 			local playerX, playerZ, playerY = EntityManager.GetPlayer():GetBlockPos();
	 			--Minimap.location = string.format("X:%d Z:%d Y: %d",playerX, playerY, playerZ);
	 			--Minimap.refresh();
	 			if(not self.aries_map_avatar) then
					self.aries_map_avatar = Map3DSystem.mcml.PageCtrl:new({url="script/Seer/MinimapAvatar.html"});
					self.aries_map_avatar_pagectrl = self.aries_map_avatar;
					self.aries_map_avatar = self.aries_map_avatar:Create("test_ariesMap", nil, "_rt", -100, 133, 1, 1).name;
				else

	 			end
	 		end
		end})
	end
end

function MinimapSurface:Close()

	if(self.aries_map_avatar) then
		ParaUI.Destroy(self.aries_map_avatar);
		self.aries_map_avatar = nil;
	end

	local window = self:GetWindow();
	if(window) then
		window:hide();

	end	

	refreshTimer:Change();
	refreshTimer = nil;
end

function MinimapSurface:BuildBlockColorTable()
	if(color_table) then
		return
	end
	color_table = {};
	NPL.load("(gl)script/apps/Aries/Creator/Game/blocks/block_types.lua");
	local block_types = commonlib.gettable("MyCompany.Aries.Game.block_types");

	--------------------------------------------------------------------------------
	local blocks_id = {};
	local count = 1;
	local filename = "config/Aries/creator/block_list.xml";
	local xmlRoot = ParaXML.LuaXML_ParseFile(filename);
	if(xmlRoot) then
		local node, category_node;
		for node in commonlib.XPath.eachNode(xmlRoot, "/blocklist/category") do
			local category_name = node.attr.name;
			category_node = node;
			-- add blocks
			
			for node in commonlib.XPath.eachNode(category_node, "/block") do
				local attr = node.attr;
				local from_id = tonumber(attr.id);
				blocks_id[count] = from_id;
				count = count + 1;
			end
		end
	end
	--------------------------------------------------------------------------------

	local tttt = block_types.get(20012);
	if(not tttt) then
		echo("Test_ not find 20012 type  ");	
	end

	-- some random color used
	local default_colors = {"#ff0000", "#ffff00", "#ff00ff", "#00ff00", "#0000cc", "#00ffff"};
	default_colors_count = #default_colors;
	for i=1, #blocks_id do
		local id = blocks_id[i];
		local block_template = block_types.get(id);
		
		if(block_template) then
			local color = block_template.mapcolor;
			if(not color) then
				color = default_colors[(id%default_colors_count)+1];
			end
			color_table[id] = color;			
		end
	end


	-- 	-- some random color used
	-- local default_colors = {"#ff0000", "#ffff00", "#ff00ff", "#00ff00", "#0000cc", "#00ffff"};
	-- default_colors_count = #default_colors;
	-- for id=1, 256 do
	-- 	local block_template = block_types.get(id);
	-- 	if(block_template) then
	-- 		local color = block_template.mapcolor;
	-- 		if(not color) then
	-- 			color = default_colors[(id%default_colors_count)+1];
	-- 		end
	-- 		color_table[id] = color;
	-- 	end
	-- end
	-- for id=1, 256 do		
	-- 	echo("Test_ color_table id  color: "..id.."  "..color_table[id]);
	-- end
end

-- set center of the map in block coordinate system.
-- @param x,y: if nil, it will be current player's position. 
function MinimapSurface:SetMapCenter(x, y)
	if(not x or not y) then
		local _;
		x, _, y = EntityManager.GetPlayer():GetBlockPos();
	end
	if(self.CenterX~=x or self.CenterY~=y) then
		self.CenterX = x;
		self.CenterY = y;
		self:Invalidate();
		-- signal
		self:mapChanged();
	end
end

-- in block coordinate
function MinimapSurface:GetMapRadius()
	return self.MapRadius;
end

-- in block coordinate
function MinimapSurface:SetMapRadius(radius)
	local radius = math.max(16, math.min(radius, 512));
	if(self.MapRadius~=radius) then
		self.MapRadius = radius;
		self:Invalidate();
		-- signal
		self:mapChanged();
	end
end

function MinimapSurface:paintEvent(painter)
	if(self:width() <= 0) then
		return;
	end
	self:DrawBackground(painter);
	self:DrawSome(painter);
	self:DrawPlayerPos(painter)
	self:ScheduleNextPaint();
end

function MinimapSurface:ResetDrawProgress()
	self.backgroundPainted = false;
	self.last_x, self.last_y = 0,0;
	if(not self.CenterX) then
		self:SetMapCenter(nil, nil);
		return;
	end
	self.map_left = self.CenterX - self.MapRadius;
	self.map_top = self.CenterY - self.MapRadius;
	self.map_width = self.MapRadius * 2;
	self.map_height = self.MapRadius * 2;
	if(self:width() > 0) then
		self.step_size = self.map_width / self:width();
		self.block_size = 1 / self.step_size;
		if(self.step_size <= 1) then
			self.step_size = 1;
			self.block_count = self.map_width;
			self.block_size = self:width()/self.block_count;
		else
			self.block_count = math.floor(self:width()/self.block_size);
		end
	end
end

function MinimapSurface:Invalidate()
	self:ResetDrawProgress();
	self:ScheduleNextPaint();
end


function MinimapSurface:showEvent()
	-- always Invalidate when page become visible. 	
	refreshTimer:Change(100, 500);
	self:SetMapCenter(nil, nil)
	self:Invalidate();
end

function MinimapSurface:hideEvent()
	echo("Test_ call hideEvent() func!");
end

function MinimapSurface:DrawBackground(painter)
	if(not self.backgroundPainted) then
		self.backgroundPainted = true;
		painter:SetPen("#ffffff00");
		painter:DrawRect(self:x(), self:y(), self:width(), self:height());
	end
end


function MinimapSurface:GetHighmapColor(x,z)
	local block_id, y = BlockEngine:GetNextBlockOfTypeInColumn(x,255,z, 4, 255);
	if(block_id and block_id > 0) then
    NPL.load("(gl)script/apps/Aries/Creator/Game/blocks/block_types.lua");
    local block_types = commonlib.gettable("MyCompany.Aries.Game.block_types");
    color_table[block_id]=color_table[block_id] or block_types.get(block_id).mapcolor;
		return color_table[block_id] or "#0000ff";
	else
		return "#000000"
	end
end


function MinimapSurface:DrawSome(painter)
	local step_size = self.step_size;
	local block_size = self.block_size;
	local block_count = self.block_count;

	local from_x, from_y = self.map_left, self.map_top;
	local count = 0;

	while (true) do
		local color = self:GetHighmapColor(from_x+self.last_x*step_size, from_y+(block_count-self.last_y)*step_size);
		-- echo({color,from_x+self.last_x*step_size, from_y+self.last_y*step_size})
		painter:SetPen(color);
		painter:DrawRect(self.last_x*block_size, self.last_y*block_size, block_size, block_size);
		count = count + 1;
		
		if(self.last_y >= block_count) then
			self.last_y = 0;
			self.last_x = self.last_x + 1;
		else
			self.last_y = self.last_y + 1;
		end
		if(count >= self.BlocksPerFrame or self.last_x > block_count) then			
			break;
		end
	end
end

function MinimapSurface:DrawPlayerPos(painter)
	if(self.last_x > self.block_count) then
            --draw a red cross for player info
            --echo("----------------------------------draw player----------------------------------");
		local playerX, playerZ, playerY = EntityManager.GetPlayer():GetBlockPos();
		local x = (playerX+0.5 - self.map_left) / self.map_width;
		local y = (playerY+0.5 - self.map_top) / self.map_height;
		x = math.min(0.99, math.max(x, 0.01));
		y = math.min(0.99, math.max(y, 0.01));
		x, y = x*self:width(), y*self:height();

---------------------------------------------------------------------------------------------
		-- -- draw player avatar
		local dist, upangle, roty = ParaCamera.GetEyePos();
		
		--local angleA = roty * 180 / 3.14 + 30;
                local angleA = roty * 180 / 3.14 + 90;
		local angleB = -60;

		painter:SetPen("#ffffff");
		painter:Save();
		painter:Translate(x, y);
		painter:Rotate(angleA);
		--painter:DrawRect(-10, -5, 10, 5);
		-- painter:Rotate(angleB);
		-- painter:DrawRect(-10, -2, 10, 3);
                --NPL.load("(gl)script/ide/System/Scene/Overlays/ShapesDrawer.lua");
                --local ShapesDrawer = commonlib.gettable("System.Scene.Overlays.ShapesDrawer");
                --ShapesDrawer.DrawCube(painter, 0,0,0, 100, true);
                painter:DrawTexture(-10, -10,16, 19, "gameassets/textures/ui_16_minimap/MiniMapUI.png", 99, 462, 16, 19);
                --ShapesDrawer.DrawLine(painter, 0, 0, 0, 10, 10, 10);
                --ShapesDrawer.DrawCircle(painter, 0,0,0, 20, "y", true);
		painter:Restore();


		
---------------------------------------------------------------------------------------------


	end
end

function MinimapSurface:ScheduleNextPaint()
	if(self.block_count) then
		if(self.last_x > self.block_count) then
			-- LOG.std(nil, "debug", "MinimapSurface", "refreshed finished");

			-- NPL.load("(gl)script/Seer/Minimap.lua");
			-- local Minimap = commonlib.gettable("Mod.Seer.UI.Minimap");
			-- Minimap.RefreshAvatar();
			

			paintDone = true;
			self:ResetDrawProgress();
		else
			self:repaint();
		end
	end
end

-- -- virtual: 
-- function MinimapSurface:mousePressEvent(mouse_event)
-- 	if(mouse_event:button() == "right" or mouse_event:button() == "left") then
-- 		mouse_event:accept();
-- 	end
-- end

-- -- virtual: 
-- function MinimapSurface:mouseReleaseEvent(mouse_event)
-- 	-- if(mouse_event:button() == "right" or mouse_event:button() == "left") then
-- 	-- 	mouse_event:accept();
-- 	-- 	-- click to close 
-- 	-- 	local window = self:GetWindow();
-- 	-- 	if(window) then
-- 	-- 		window:hide();
-- 	-- 		refreshTimer:Change();
-- 	-- 	end
-- 	-- end
-- end

-- virtual: 
function MinimapSurface:mouseWheelEvent(mouse_event)
  --暂时搞掉
	--[[local radius = self:GetMapRadius() - 0.1*mouse_event:GetDelta()*self:GetMapRadius();
	self:SetMapRadius(math.floor(radius));]]
end
