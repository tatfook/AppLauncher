--[[
Title: Seer Mod Settings
Author(s): ZhouXing
Date: 2015/6/18
Desc: Seer Mod Settings
use the lib:
------------------------------------------------------------
NPL.load("(gl)script/Seer/Theme.lua");
local Settings = commonlib.gettable("Mod.Seer.Settings");
------------------------------------------------------------
]]
NPL.load("(gl)script/Seer/Seer_aries_window.lua");

local UITheme = commonlib.gettable("Mod.Seer.UI.Theme");

function UITheme.Init()	
	-- update screen resolution when use default {1020,680,}
	local systemAttr = ParaEngine.GetAttributeObject();
	local resolution = systemAttr:GetField("ScreenResolution", {1020,680,});
	if(resolution[1] < 1280 or resolution[2] < 720) then
		systemAttr:SetField("ScreenResolution", {1280, 720}); 
		systemAttr:CallField("UpdateScreenMode");
	end

	NPL.load("(gl)script/ide/AudioEngine/AudioEngine.lua");
	local AudioEngine = commonlib.gettable("AudioEngine");
	AudioEngine.LoadSoundWaveBank("config/audio/UISound.bank.xml");
	-- change default texture path
	if(not ParaIO.CreateDirectory("worlds")) then
		echo("create path failed: ".."worlds");
	end
	if(not ParaIO.CreateDirectory("worlds/BlockTextures")) then
		echo("create path failed: ".."worlds/BlockTextures");
	end
	if(not ParaIO.CopyFile("TS/BlockTextures/local/SeerCraft32x_r1.zip", "worlds/BlockTextures/SeerCraft32x_r1.zip", true)) then
		echo("create file failed: ".."worlds/BlockTextures/SeerCraft32x_r1.zip");
	end
	NPL.load("(gl)script/apps/Aries/Creator/Game/Materials/TexturePackage.lua");
	local TexturePackage = commonlib.gettable("MyCompany.Aries.Creator.Game.Desktop.TexturePackage");
	NPL.load("(gl)script/Seer/Settings.lua");
	local Settings = commonlib.gettable("Mod.Seer.Settings");
	TexturePackage.default_texture_path = Settings.default_texture_path;
	TexturePackage.default_texture_name = Settings.default_texture_name;
	echo("change default_texture_path");

	UITheme.InitMessageBox();
	UITheme.InitScrollbar();
	UITheme.InitPeCheckboxButton();
	UITheme.InitSliderBar();
	UITheme.InitSelect();
 
	UITheme.InitServerHallFriendSliderBar();
	UITheme.InitInGameScrollBar();
	UITheme.InitInGameSliderBar();

	NPL.load("(gl)script/kids/3DMapSystemUI/MiniGames/SwfLoadingBarPage.lua");
	Map3DSystem.App.MiniGames.SwfLoadingBarPage.url="script/apps/Aries/Creator/Game/Login/SwfLoadingBarPage.yoocraft.html";

end

function UITheme.InitMessageBox()
	Map3DSystem.mcml_controls.RegisterUserControl("aries:window", Mod.Seer.Seer_aries_window);

	NPL.load("(gl)script/seer/Utility/CommonUtility.lua");
	local CommonUtility = commonlib.gettable("Mod.Seer.Utility.CommonUtility");
	if CommonUtility:IsMobilePlatform() then
		_guihelper.SetDefaultMsgBoxMCMLTemplate("script/Seer/MessageBox.html");
	else
		_guihelper.SetDefaultMsgBoxMCMLTemplate("script/Seer/MessageBox.PC.html");
	end
end

function UITheme.InitScrollbar()
	_guihelper.UpdateScrollBar(ParaUI.GetDefaultObject("scrollbar")
		, "gameassets/textures/gameassets/textures/ui_14_others/toolsUI512x512_32bits.png;85 215 15 74"
		, "gameassets/textures/ui_14_others/toolsUI512x512_32bits.png;55 215 13 17"
		, "gameassets/textures/ui_14_others/toolsUI512x512_32bits.png;40 215 13 17"
		, "gameassets/textures/ui_14_others/toolsUI512x512_32bits.png;70 215 13 29");
end

function UITheme.InitPeCheckboxButton()
    NPL.load("(gl)script/apps/Aries/Creator/Game/mcml/pe_checkbox_button.lua");
	local pe_checkbox_button = commonlib.gettable("MyCompany.Aries.Game.mcml.pe_checkbox_button");
	pe_checkbox_button.checked_bg = "gameassets/textures/ui_11_esc/EscUI_32bits.png;546 1230 46 26";
	pe_checkbox_button.unchecked_bg = "gameassets/textures/ui_11_esc/EscUI_32bits.png;546 1230 46 26";
	pe_checkbox_button.unchecked_bg_color = "#cccccc"
	pe_checkbox_button.checked_bg_color = "#cccccc";
	pe_checkbox_button.checked_text = "ON";
	pe_checkbox_button.unchecked_text = "OFF";
end

function UITheme.InitSliderBar()
    NPL.load("(gl)script/ide/SliderBar.lua");
	CommonCtrl.SliderBar.background = "gameassets/textures/ui_14_others/toolsUI512x512_32bits.png;295 215 115 20";
	CommonCtrl.SliderBar.button_bg = "gameassets/textures/ui_14_others/toolsUI512x512_32bits.png;415 210 10 28";
	CommonCtrl.SliderBar.button_width = 10;
	CommonCtrl.SliderBar.button_height = 25;
	CommonCtrl.SliderBar.background_margin_top = 6;
	CommonCtrl.SliderBar.background_margin_bottom = 6;
end

function UITheme.InitSelect()
	local pe_select = commonlib.gettable("Map3DSystem.mcml_controls.pe_select");
	pe_select.dropdownBtn_bg = "gameassets/textures/ui_11_esc/EscUI_32bits.png;732 1230 26 25:1 1 1 1";
	pe_select.editbox_bg = "gameassets/textures/ui_11_esc/EscUI_32bits.png;594 1230 136 25";
	pe_select.container_bg = "gameassets/textures/ui_11_esc/EscUI_32bits.png;594 1230 136 25:5 5 5 5";
	pe_select.listbox_bg = "gameassets/textures/ui_11_esc/EscUI_32bits.png;594 1230 136 25:5 5 5 5";
	pe_select.dropdownbutton_width = 20;
	pe_select.dropdownbutton_height = 20;
end

function UITheme.InitServerHallFriendSliderBar()
	_guihelper.UpdateScrollBar(ParaUI.GetDefaultObject("scrollbar")
		, "gameassets/textures/ui_04_friend/friend_32bits.png;856 584 19 526;"
		, ""
		, ""
		, "gameassets/textures/ui_04_friend/friend_32bits.png;1218 2 38 38");
end

function UITheme.InitInGameScrollBar() -- should call when entering game
	NPL.load("(gl)script/seer/Utility/CommonUtility.lua");
	local CommonUtility = commonlib.gettable("Mod.Seer.Utility.CommonUtility");
	if CommonUtility:IsMobilePlatform() then

	_guihelper.UpdateScrollBar(ParaUI.GetDefaultObject("scrollbar")
		, "gameassets/textures/ui_04_friend/friend_32bits.png;856 584 19 526;"
		, ""
		, ""
		, "gameassets/textures/ui_04_friend/friend_32bits.png;1218 2 38 38");
	else
	_guihelper.UpdateScrollBar(ParaUI.GetDefaultObject("scrollbar")
		, "gameassets_pc/textures/ui_common/scrollbar_vertical.png;"
		, ""
		, ""
		, "gameassets_pc/textures/ui_common/slider_vertical.png");
	end

end

function UITheme.InitInGameSliderBar()
    NPL.load("(gl)script/ide/SliderBar.lua");
	CommonCtrl.SliderBar.background = "gameassets/textures/ui_11_esc/EscUI_32bits.png;776 1230 139 16";
	CommonCtrl.SliderBar.button_bg = "gameassets/textures/ui_11_esc/EscUI_32bits.png;760 1230 14 24";
	CommonCtrl.SliderBar.button_width = 10;
	CommonCtrl.SliderBar.button_height = 25;
	CommonCtrl.SliderBar.background_margin_top = 6;
	CommonCtrl.SliderBar.background_margin_bottom = 6;
end
