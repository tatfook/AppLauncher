local FileCaches = NPL.export()

NPL.load("(gl)script/ide/System/Encoding/sha1.lua");
local Encoding = commonlib.gettable("System.Encoding");

function FileCaches.getFilePath(hash)
    return "temp/cache/" .. commonlib.tolower(hash:sub(1,1)) .."/" .. hash;
end

function FileCaches.cacheFile(path, hash)
    if not hash then
        local f = ParaIO.open(path, "r");
        
        if f:IsValid() then
            local data = f:ReadBytes(f:GetFileSize(),nil);
            FileCaches.cacheData(data);
            f:close();
        end
    else
        local filename = FileCaches.getFilePath(hash);
        ParaIO.CreateDirectory(filename);
        ParaIO.CopyFile(path, filename, false);
    end
end

function FileCaches.cacheData(data, hash)
    hash = hash or Encoding.sha1(data,"hex");
    local filename = FileCaches.getFilePath(hash);
    ParaIO.CreateDirectory(filename);
    if ParaIO.DoesFileExist(filename) then
        return
    end
    local f = ParaIO.open(filename, "w");
    
    if f:IsValid() then
        f:write( data, data:len());
        f:close();
    end
end

function FileCaches.getFile(hash)
    local filename = FileCaches.getFilePath(hash);
    if ParaIO.DoesFileExist(filename) then
        return filename;
    end
end
