--[[
    Title: CreateRolePage.html code-behind script
    Author(s): WangXiXi
    Date: 2015/7/14
    Desc: Create new world based on predefined template and open existing world. 
    use the lib:
    -------------------------------------------------------
    NPL.load("(gl)script/Seer/CreateRolePage.lua");
    local CreateRolePage = commonlib.gettable("MyCompany.Aries.Game.MainLogin.CreateRolePage")
    CreateRolePage.ShowPage()
    -------------------------------------------------------
]]
NPL.load("(gl)script/apps/Aries/Creator/WorldCommon.lua");
NPL.load("(gl)script/Seer/Utility/CommonUtility.lua");
NPL.load("(gl)script/Seer/Settings.lua");
NPL.load("(gl)script/apps/Aries/Creator/Game/Entity/PlayerSkins.lua");
NPL.load("(gl)script/Seer/NetWork/YcProfile.lua");
NPL.load("(gl)script/Seer/Config/CharacterAssetsReader.lua");
NPL.load("(gl)script/Seer/Network/Packets/PacketPbHelper.lua");
NPL.load("(gl)script/apps/Aries/Creator/Game/Sound/BackgroundMusic.lua");
local BackgroundMusic = commonlib.gettable("MyCompany.Aries.Game.Sound.BackgroundMusic");
local Settings = commonlib.gettable("Mod.Seer.Settings");
local PlayerSkins = commonlib.gettable("MyCompany.Aries.Game.EntityManager.PlayerSkins")
local YcProfile = commonlib.gettable("Mod.Seer.Network.YcProfile");
local CommonUtility = commonlib.gettable("Mod.Seer.Utility.CommonUtility");
local CharacterAssetsReader = commonlib.gettable("Mod.Seer.Config.CharacterAssetsReader");
local PacketPbHelper = commonlib.gettable("Mod.Seer.Network.Packets.PacketPbHelper");

local CreateRolePage = commonlib.gettable("MyCompany.Aries.Game.MainLogin.CreateRolePage")

--key is the value in CreateRolePage.html->gender
local GenderMap = {
    ["1"] = "male",
    ["2"] = "female"
};

local page;

CreateRolePage.inited = false;
CreateRolePage.isWritting = false;
CreateRolePage.role_index = 1;
CreateRolePage.current_gender = "1";
CreateRolePage.isClickBoy = true
-- init function. page script fresh is set to false.
function CreateRolePage.OnInit()
    page = document:GetPageCtrl();
    if(not CreateRolePage.inited) then
        CreateRolePage.inited = true;
    end
end

function CreateRolePage.IsOnScreen()
    return CreateRolePage.inited;
end
-- show page
function CreateRolePage.ShowPage(bShow)
    --Cellfy:
    --Here is the reason why these codes for initing is here, instead of being in OnInit:
    --The button for faking nickname textbox need page:Refresh(0) to make itself disappear
    --and page:Refresh(0) will refresh everything by re-init the page
    --so the real init code can not be put in OnInit
    CreateRolePage.current_gender = "1"; --change this to "2" if you want default gender to be female
    CreateRolePage.role_index = 1;
    if CommonUtility:IsMobilePlatform() then
        _url = "script/Seer/CreateRolePage.html"
    else
        _url = "script/Seer/CreateRolePage.PC.html"
    end
    System.App.Commands.Call("File.MCMLWindowFrame", {
        url = _url, 
        name = "CreateRolePage", 
        isShowTitleBar = false,
        DestroyOnClose = true, -- prevent many ViewProfile pages staying in memory
        style = CommonCtrl.WindowFrame.ContainerStyle,
        zorder = 0,
        allowDrag = false,
        bShow = bShow,
        directPosition = true,
        align = "_fi",
        x = 0,
        y = 0,
        width = 0,
        height = 0,
        cancelShowAnimation = true,
    });

    local sound = BackgroundMusic:GetMusic("gameassets/audios/game_bgms/offline_bgm.mp3");
    BackgroundMusic:PlayBackgroundSound(sound);
end

function CreateRolePage.OnClose()
    CreateRolePage.isWritting = false;
    CreateRolePage.role_index = 1;
    CreateRolePage.inited = false;
    CreateRolePage.page:CloseWindow();
end

function CreateRolePage.UpdatePreviewInfo(obj_params)
    if obj_params then
        CurrentAssetList = CharacterAssetsReader.GetAssetInfoList(GenderMap[CreateRolePage.current_gender]);
        local assetInfo = CurrentAssetList[(CreateRolePage.role_index-1) % #CurrentAssetList + 1];
        obj_params.AssetFile = assetInfo.model;
        if (assetInfo.texture and type(assetInfo.texture)=="string" and string.len(assetInfo.texture)>0) then
            obj_params.ReplaceableTextures = {[2] = assetInfo.texture};
        else
            obj_params.ReplaceableTextures = {[2] = nil};
        end        
    end
end

function CreateRolePage.PreviewSkin()
    local player_node = CreateRolePage.page:GetNode("MyPlayer");
    local obj_params = player_node.obj_params;
    CreateRolePage.UpdatePreviewInfo(obj_params);
    local canvasCtl = player_node.Canvas3D_ctl;
    if(canvasCtl) then
        canvasCtl:ShowModel(obj_params);
    end

    --[[
    PlayerSkins:Init();
    local filename = PlayerSkins:GetSkinByID(tonumber(CreateRolePage.role_index));
    cur_skin = filename;
    local player_node = CreateRolePage.page:GetNode("MyPlayer");
    local obj_params = player_node.obj_params;
    obj_params.ReplaceableTextures = {[2] = filename};
    local canvasCtl = player_node.Canvas3D_ctl;
    if(canvasCtl) then
        canvasCtl:ShowModel(obj_params);
    end
    ]]
end

function CreateRolePage.OnClickRadioGender(value)
    CreateRolePage.current_gender = page:GetValue("gender", "1");
    CreateRolePage.role_index = 1;
    CreateRolePage.PreviewSkin();
end
function CreateRolePage.OnClickBoy()
    if CreateRolePage.isClickBoy == true then
        return
    end
    CreateRolePage.isClickBoy = true
    page:Refresh(0)
end
function CreateRolePage.OnClickGirl()
    if CreateRolePage.isClickBoy == false then
        return
    end
    CreateRolePage.isClickBoy = false
    page:Refresh(0)
end
function CreateRolePage.OnCreateRole()
    if CreateRolePage.isEnter then
        return
    end
    local nick = page:GetUIValue("nick");

    CreateRolePage.current_gender = "1"
    local gender = 1
    if CreateRolePage.isClickBoy ~= true then
        CreateRolePage.current_gender = "2"
        gender = 2
    end
    CurrentAssetList = CharacterAssetsReader.GetAssetInfoList(GenderMap[CreateRolePage.current_gender]);
    local assetInfo = CurrentAssetList[(CreateRolePage.role_index-1) % #CurrentAssetList + 1];

    local skin_id = tonumber(assetInfo.id);
    -- local gender = page:GetValue("gender", "1");
    -- gender = tonumber(gender) or 1;
    -- if(not nick)then
    -- 	echo("Test_ createrole nick nil");
    -- 	_guihelper.MessageBox("请输入昵称！");
    -- 	return
    -- end

    local maxlen = 20;
    local nick = page:GetValue("nick") or "";
    local txt_len = string.len(nick);
    echo(txt_len);
    NPL.load("(gl)script/Seer/Utility/CommonUtility.lua");
    local CommonUtility = commonlib.gettable("Mod.Seer.Utility.CommonUtility");
	local chinese_char_count=CommonUtility.getChineseCharacterCount(nick);
	local none_chinese_char_count=CommonUtility.getNotChineseCharacterCount(nick);
	local max_char_count=10;
  local min_char_count=4;
	local char_count=chinese_char_count*2+none_chinese_char_count;
    if(txt_len <=0)then
        _guihelper.MessageBox("名称不能为空！");
        return;
    elseif(--[[txt_len  > maxlen]]char_count>max_char_count)then
        --_guihelper.MessageBox(string.format("名称太长了，换一个吧！"..txt_len,maxlen));
        _guihelper.MessageBox("名称太长了，换一个吧！");
        return;
    elseif char_count<min_char_count then
        _guihelper.MessageBox("名称太短了，换一个吧！");
        return;
    end
    -- if tonumber(nick) then
    --     _guihelper.MessageBox("昵称不能全部是数字，请重新起名!");
    --     return
    -- end
    --从服务端checknick
    PacketPbHelper.sendCSCheckNickReq(
        nick,
        function (head,msg)
            if msg then
                if msg.flag == 1 then
                    _guihelper.MessageBox("昵称有重复，请重新起名");
                elseif msg.flag == 2 then
                    _guihelper.MessageBox("昵称含有敏感词汇，请重新起名");
                elseif msg.flag == 3 then
                    _guihelper.MessageBox("昵称名字太长，请重新起名");
                elseif msg.flag == 4 then
                    _guihelper.MessageBox("昵称不能全部是数字，请重新起名");
                elseif msg.flag == 0 then
                    PacketPbHelper.sendCSCrtRoleReq(
                        nick,
                        skin_id ,
                        gender ,
                        function(head,body)
                            YcProfile.SetUID(body.uid);
                            YcProfile.SetUserInfo(body.uid, body, true);

                            --在这里添加登陆处理信息
                            NPL.load("(gl)script/Seer/Game/Login/LoginPage.lua");
                            local LoginPage = commonlib.gettable("Mod.Seer.Game.Login.LoginPage");
                            LoginPage.GetOtherServerMsg()
                            --end

                            -- CreateRolePage.OnClose();
                            -- System.options.loginmode = "internet";
                            -- MainLogin:next_step({IsLoginModeSelected = true});
                            NPL.load("(gl)script/Seer/CreateRoleConfirmPage.lua");
                            local CreateRoleConfirmPage = commonlib.gettable("MyCompany.Aries.Game.MainLogin.CreateRoleConfirmPage")
                            CreateRoleConfirmPage.ShowPage();
                            CreateRolePage.isEnter = true
                            Statistics.SendKey("Newbie.PlayerCreated");
                    end)
                else
                    _guihelper.MessageBox("昵称中不能使用特殊符号，请重新起名！");
                end
            end
        end
    )
end

function CreateRolePage.OnSaveRoleInfo()

end
