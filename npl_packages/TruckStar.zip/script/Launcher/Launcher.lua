local Launcher = NPL.export()
local Updater = NPL.load("./Updater.lua")
local NetworkClient = commonlib.gettable("Mod.Seer.Network.NetworkClient");
local PacketPbHelper = commonlib.gettable("Mod.Seer.Network.Packets.PacketPbHelper");

local lastestVersion;
local nid ;
local directory;
local updateLauncher;
function Launcher.init(ip, port, dir, ul)
    directory = dir or "";
    NetworkClient.start("0,0,0,0", 0);
    nid = NetworkClient.connect(ip, port)
    updateLauncher = ul;
end

function Launcher.checkVersion(callback)
    PacketPbHelper.sendCSGetLastVersionReq(nid,
		function (header, body)
            callback({body.field1, body.field2, body.field3, body.field4})
        end);
end

function Launcher.update(cur, lastest, callback,progress)
    Updater.update(nid, directory ,updateLauncher,cur, lastest, function (err)
        callback(err)
    end, progress)
end