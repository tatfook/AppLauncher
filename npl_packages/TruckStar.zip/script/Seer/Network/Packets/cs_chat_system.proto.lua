
--[[
call:
NPL.load("(gl)script/Seer/Network/Packets/PacketPbHelper.lua");
local PacketPbHelper = commonlib.gettable("Mod.Seer.Network.Packets.PacketPbHelper");

]]

NPL.load("(gl)script/Seer/pb/cs_chat_system_pb.lua");

local prefix = "Mod.Seer.Network.Packets.PacketPbHelper."
NPL.load("(gl)script/Seer/Network/Packets/PacketPbHelper.lua");
local PacketPbHelper = commonlib.gettable("Mod.Seer.Network.Packets.PacketPbHelper");



--[[
//��ȡ�����б�
--]]	
function PacketPbHelper.sendCSGetFriendListReq(callback, errcb)
	PacketPbHelper.send("CSGetFriendListReq",{},callback,errcb)
end

--[[
//���Ӻ���
--]]	
function PacketPbHelper.sendCSAddFriendReq(type, name, userid, callback,errcallback)
	PacketPbHelper.send("CSAddFriendReq",{add_type = type, friend_name = name,friend_id = userid,friend_channel = 0}, callback,errcallback);
end

--[[
//ɾ������
--]]	

function PacketPbHelper.sendCSDeleteFriendReq(id,callback, errcallback)
	PacketPbHelper.send("CSDeleteFriendReq", {friend_id = id, friend_channel = 0}, callback,errcallback);
end

--[[
//�û�������Ϣ
--]]
function PacketPbHelper.sendCSChatMsgDataReq(id,data,callback,errcallback)
	PacketPbHelper.send("CSChatMsgDataReq", {to_user_id = id, msg_data = data}, callback,errcallback);
end


function PacketPbHelper.sendCSGetFriendDetailReq(id,callback,errCallback)
	PacketPbHelper.send("CSGetFriendDetailReq", {friend_id = id, friend_channel = 0}, callback,errCallback);
end


--[[
//��ȡ�������б�
--]]	
function PacketPbHelper.sendCSGetBlackListReq(callback)
	PacketPbHelper.send("CSGetBlackListReq", {}, callback);
end
--[[
//�û����Ӻ�����
--]]	
function PacketPbHelper.sendCSAddFriendToBlackReq(id,callback)
	PacketPbHelper.send("CSAddFriendToBlackReq", {friend_id = id,friend_channel = 0}, callback);
end

--[[
//�û��Ƴ�������
--]]
function PacketPbHelper.sendCSRemoveFriendFromBlackReq(id,callback)
	PacketPbHelper.send("CSRemoveFriendFromBlackReq", {friend_id = id,friend_channel = 0}, callback);
end