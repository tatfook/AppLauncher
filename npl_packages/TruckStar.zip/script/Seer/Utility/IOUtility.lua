--[[
    Title: IOUtility
    Author(s): Cellfy
    Date: 2016/02/22
    Desc: Seer io utilities
    use the lib:
    ------------------------------------------------------------
    NPL.load("(gl)script/Seer/Utility/IOUtility.lua");
    local IOUtility = commonlib.gettable("Mod.Seer.Utility.IOUtility");
    -------------------------------------------------------
]]

NPL.load("(gl)script/ide/System/os/os.lua");
NPL.load("(gl)script/Seer/Utility/StringTools.lua");

local os = commonlib.gettable("System.os");
local StringTools = commonlib.gettable("Mod.Seer.Utility.StringTools");

local IOUtility = commonlib.gettable("Mod.Seer.Utility.IOUtility");

function IOUtility.StripFilepath(filename)  
    filename = string.gsub(filename, "\\", "/");
    return string.match(filename, "(.+)/[^/]*%.%w+$") or string.match(filename, "(.+)/[^/]+$")
end  

function IOUtility.StripFilename(filename)  
    filename = string.gsub(filename, "\\", "/");
    return string.match(filename, ".+/([^/]*%.%w+)$") or string.match(filename, ".+/([^/]+)$")
end

--@return "directory" / "file" / "invalid"
function IOUtility.GetPathType(source_path)
    local type_map = {"invalid", "file", "directory"};
    local type_index = 1;
    if StringTools.Valid(source_path) then
        if os.GetPlatform()=="win32" then
            --for windows series, by guessing by pattern, result is not exactly precise
            if string.match(source_path, "[^/]*%.[^/]+$") then
                type_index = 2;
            elseif string.match(source_path, "[^/]+/?$") then
                type_index = 3;
            else
                type_index = 1;
            end
        else
            --for Linux etc. by actually opening the path, result is precise
            local f = io.open(source_path);
            if f then
                --directory fails opening on win32
                if not f:read(0) and f:seek("end") ~= 0 then
                    type_index = 3;
                else
                    type_index = 2;
                end
                f:close();
            else
                type_index = 1;
            end            
        end
    else
        type_index = 1;
    end
    return type_map[type_index];
end

function IOUtility.Zip(source_path, target_name)
    if StringTools.Valid(source_path) and StringTools.Valid(target_name) then
        local path_type = IOUtility.GetPathType(source_path);
        if string.match(target_name, "%.zip$") and path_type~="invalid" then
            local zipFile = ParaIO.CreateZip(target_name,"")
            if path_type=="directory" then
                echo("----------------------------------adding folder----------------------------------");
                echo(source_path);
                source_path = string.gsub(source_path, "/?$", "");
                echo(source_path);
                dir_name = IOUtility.StripFilename(source_path);
                echo(dir_name);
                zipFile:AddDirectory(dir_name, source_path.."/*.*", 16);
            elseif path_type=="file" then
                echo("----------------------------------adding file----------------------------------");
                echo(source_path);
                local fileName = StringTools.StripFilename(source_path);
                zipFile:ZipAdd(fileName,source_path);
            end
            zipFile:close()
        end
    end
end

function IOUtility.UnZip(zip_file_path, target_path)
    LOG.std(nil, "debug", "cellfy", "Unzipping file: %s", zip_file_path);
    
    zip_file_path = string.gsub(zip_file_path, "\\", "/");
    target_path = string.gsub(target_path, "\\", "/");

    if (not ParaAsset.OpenArchive(zip_file_path, false)) then
        LOG.std(nil, "error", "cellfy", "failed to open zip : %s", zip_file_path);
        return nil
    end
    local search_result = ParaIO.SearchFiles("",":.*", zip_file_path, 2, 10000, 0);
    local nCount = search_result:GetNumOfResult();
    local i;
    for i = 0, nCount-1 do
        --log(search_result:GetItem(i).."\n");
        
        local pathname = search_result:GetItem(i);
        local path = IOUtility.StripFilepath(search_result:GetItem(i));
        local name = IOUtility.StripFilename(search_result:GetItem(i));

        pathname_original = ParaIO.GetFileOriginalName(pathname);

        local newname = target_path.."/"..pathname_original;

        -- ensure path exist
        if(string.sub(pathname, -1) == "/") then
            -- is path
            if(not ParaIO.CreateDirectory(newname)) then
                LOG.std(nil, "error", "cellfy", "create path failed: %s", targetDir);
                return nil;
            end

        else
            -- is file            
            if(not ParaIO.CopyFile(pathname, newname, true)) then
                LOG.std(nil, "error", "cellfy", "create file failed: %s", newname);
                return nil
            end
        end	
    end 
    search_result:Release();
    ParaAsset.CloseArchive(zip_file_path);
    return true;
end

function IOUtility.UnZipToSameFolder(zip_file_path)
    local path = IOUtility.StripFilepath(zip_file_path);
    return IOUtility.UnZip(zip_file_path, path);
end
