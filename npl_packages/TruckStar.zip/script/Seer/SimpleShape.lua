--[[
Title: Create Simple Shapes
Author(s): ZhouXing
Date: 2015/5/18
Desc: Create Simple Shapes
use the lib:
------------------------------------------------------------
NPL.load("(gl)script/Seer/SimpleShape.lua");
local SimpleShape = commonlib.gettable("Mod.Seer.UI.SimpleShape");
-------------------------------------------------------
]]
NPL.load("(gl)script/apps/Aries/Creator/Game/Tasks/UndoManager.lua");
NPL.load("(gl)script/apps/Aries/Creator/Game/GUI/Transform3DController.lua");
NPL.load("(gl)script/apps/Aries/Creator/Game/game_logic.lua");
NPL.load("(gl)script/Seer/Game/Editor/Editor.lua");
local Editor = commonlib.gettable("Mod.Seer.Game.Editor");
NPL.load("(gl)script/Seer/Game/Editor/BlockTransformer.lua");
local BlockTransformer = commonlib.gettable("Mod.Seer.Game.Editor.BlockTransformer");
NPL.load("(gl)script/Seer/Game/Editor/Selector.lua");
local UIManager = commonlib.gettable("Mod.Seer.Game.UI.UIManager");
local Selector = commonlib.gettable("Mod.Seer.Game.Editor.Selector");
local GameLogic = commonlib.gettable("MyCompany.Aries.Game.GameLogic");
local undoManager = commonlib.gettable("MyCompany.Aries.Game.UndoManager");
local block_types = commonlib.gettable("MyCompany.Aries.Game.block_types");
local blockEngine = commonlib.gettable("MyCompany.Aries.Game.BlockEngine");
local gameLogic = commonlib.gettable("MyCompany.Aries.Game.GameLogic");
local Transform3DController = commonlib.gettable("MyCompany.Aries.Game.GUI.Transform3DController");
local mathlib = commonlib.gettable("mathlib");

local SimpleShape = commonlib.gettable("Mod.Seer.UI.SimpleShape");

local groupIndexHint = 6;
local minRadius = 1;
local maxRadius = 20;
local minThickness = 1;
SimpleShape.rotatexNum = 0
SimpleShape.rotateyNum = 0
SimpleShape.rotatezNum = 0
function SimpleShape:ShowCube()
	-- if(not self.SimpleCube) then
		self:HideAll();

		self.shape = "SimpleCube";
		self.radiusX = minRadius;
		self.radiusY = minRadius;
		self.radiusZ = minRadius;

		self:InitCenter();
		--Transform3DController.GetSingleton():SetBlockPos(self.centerX, self.centerY, self.centerZ);

		self:InitCube();
		self:ShowShape();

		-- self.SimpleCube = Map3DSystem.mcml.PageCtrl:new({url="script/Seer/SimpleCube.html", enable_esc_key = true, zorder = 1,});
		-- self.SimpleCube = self.SimpleCube:Create("SimpleCube", nil, "_lt", 0, 120, 310, 340).name;
	-- end
end

function SimpleShape:ShowRing()
	if(not self.SimpleRing) then
		self:HideAll();

		self.shape = "SimpleRing";
		self.radius = minRadius;
    self.radiusY = minRadius;
		self.thickness = minThickness;
		self.horizontal = true;

		self:InitCenter();
		--Transform3DController.GetSingleton():SetBlockPos(self.centerX, self.centerY, self.centerZ);

		self:InitRing();
		self:ShowShape();

		-- self.SimpleRing = Map3DSystem.mcml.PageCtrl:new({url="script/Seer/SimpleRing.html"});
		-- self.SimpleRing = self.SimpleRing:Create("SimpleRing", nil, "_lt", 0, 120, 310, 340).name;
	end
end

function SimpleShape:ShowCircle()
	if(not self.SimpleCircle) then
		self:HideAll();

		self.shape = "SimpleCircle";
		self.radius = minRadius;
		self.horizontal = true;

		self:InitCenter();
		--Transform3DController.GetSingleton():SetBlockPos(self.centerX, self.centerY, self.centerZ);

		self:InitCircle();
		self:ShowShape();

		self.SimpleCircle = Map3DSystem.mcml.PageCtrl:new({url="script/Seer/SimpleCircle.html"});
		self.SimpleCircle = self.SimpleCircle:Create("SimpleCircle", nil, "_lt", 0, 120, 310, 340).name;
	end
end

function SimpleShape:ShowSphere()
	if(not self.SimpleSphere) then
		self:HideAll();

		self.shape = "SimpleSphere";
		self.radius = minRadius;
		self.solid = true;

		self:InitCenter();
		--Transform3DController.GetSingleton():SetBlockPos(self.centerX, self.centerY, self.centerZ);

		self:InitSphere();
		self:ShowShape();

		self.SimpleSphere = Map3DSystem.mcml.PageCtrl:new({url="script/Seer/SimpleSphere.html"});
		self.SimpleSphere = self.SimpleSphere:Create("SimpleSphere", nil, "_lt", 0, 120, 310, 340).name;
	end
end

function SimpleShape:ShowEllipsoid()
	if(not self.SimpleEllipsoid) then
		self:HideAll();

		self.shape = "SimpleEllipsoid";
		self.radiusX = minRadius;
		self.radiusY = minRadius;
		self.radiusZ = minRadius;
		self.solid = true;

		self:InitCenter();
		--Transform3DController.GetSingleton():SetBlockPos(self.centerX, self.centerY, self.centerZ);

		self:InitEllipsoid();
		self:ShowShape();

		-- self.SimpleEllipsoid = Map3DSystem.mcml.PageCtrl:new({url="script/Seer/SimpleEllipsoid.html"});
		-- self.SimpleEllipsoid = self.SimpleEllipsoid:Create("SimpleEllipsoid", nil, "_lt", 0, 120, 310, 340).name;
	end
end

function SimpleShape:InitCenter()
	local px, py, pz = ParaScene.GetPlayer():GetPosition();

	self.centerX, self.centerY, self.centerZ = blockEngine:block(px, py + 0.1, pz);
	self:ChangeRotateY()
end

function SimpleShape:InitCube()
	self.blocks = {};

	local i = 0;
  if self.solid then
    for x = -self.radiusX, self.radiusX do
      for y = -self.radiusY, self.radiusY do
        for z = -self.radiusZ, self.radiusZ do
          i = i + 1;
          self.blocks[i] = {x, y, z};
        end
      end
    end
  else
    for x = -self.radiusX, self.radiusX do
      for y = -self.radiusY, self.radiusY do
        for z = -self.radiusZ, self.radiusZ do
          if x==-self.radiusX or x==self.radiusX or y==-self.radiusY or y==self.radiusY or z==-self.radiusZ or z==self.radiusZ then
            self.blocks[#self.blocks+1] = {x, y, z};
          end
        end
      end
    end
  end
  self:ChangeRotateY();
end

function SimpleShape:InitRing()
	self.blocks = {};
	self.tempBlocks = {};
	for a = -self.radius, self.radius do
		self.tempBlocks[a] = {};
		for b = -self.radius, self.radius do
			self.tempBlocks[a][b] = nil;
		end
	end

	--bresenham circle algorithm
	local a = 0;
	local b = self.radius;
	local c = 3 - 2 * b;

	while(a <= b) do
		self:FillRingVerticalLine(a, b);
		self:FillRingHorizontalLine(b, a);

		if(c < 0) then
			c = c + 4 * a + 6;
		else
			b = b - 1;
			c = c + 4 * (a - b) + 10;
		end
			
		a = a + 1;
	end

	local i = 0;

	if(self.horizontal) then
		for a = -self.radius, self.radius do
			for b = -self.radius, self.radius do
				if(self.tempBlocks[a][b]) then
          for y = 0,self.radiusY do
            i = i + 1;
            self.blocks[i] = {a, y, b};
          end
				end
			end
		end
	else
		for a = -self.radius, self.radius do
			for b = -self.radius, self.radius do
				if(self.tempBlocks[a][b]) then
          for y = 0,self.radiusY do
            i = i + 1;
            self.blocks[i] = {y, a, b};
          end
				end
			end
		end
	end

	self.tempBlocks = nil;
	self:ChangeRotateY()
end

function SimpleShape:FillRingHorizontalLine(a, b)
	local thickness = self.thickness - 1;

	for a1 = -a, math.min(-a + thickness, a) do
		self.tempBlocks[a1][b]  = true;
		self.tempBlocks[a1][-b]  = true;
	end

	for a1 = math.max(a - thickness, 0), a do
		self.tempBlocks[a1][b]  = true;
		self.tempBlocks[a1][-b]  = true;
	end
end

function SimpleShape:FillRingVerticalLine(a, b)
	local thickness = self.thickness - 1;

	for b1 = -b, math.min(-b + thickness, b) do
		self.tempBlocks[a][b1] = true;
		self.tempBlocks[-a][b1] = true;
	end

	for b1 = math.max(b - thickness, 0), b do
		self.tempBlocks[a][b1] = true;
		self.tempBlocks[-a][b1] = true;
	end
end

function SimpleShape:InitCircle()
	self.blocks = {};
	
	--bresenham circle algorithm
	local a = 0;
	local b = self.radius;
	local c = 3 - 2 * b;

	while(a <= b) do
		self:FillCircleLine(a, b);

		if(c < 0) then
			c = c + 4 * a + 6;
		else
			b = b - 1;
			c = c + 4 * (a - b) + 10;
		end

		a = a + 1;
	end
	self:ChangeRotateY()
end

function SimpleShape:FillCircleLine(a, b)
	local i = #self.blocks;

	if(self.horizontal) then
		if(a == 0) then
			for b1 = -b, b do
				self.blocks[i + 1] = {0, 0, b1};
				i = i + 1;
			end

			self.blocks[i + 1] = {b, 0, 0};
			self.blocks[i + 2] = {-b, 0, 0};
		else
			for b1 = -b, b do
				self.blocks[i + 1] = {a, 0, b1};
				self.blocks[i + 2] = {-a, 0, b1};
				i = i + 2;
			end

			for a1 = -a, a do
				self.blocks[i + 1] = {b, 0, a1};
				self.blocks[i + 2] = {-b, 0, a1};
				i = i + 2;
			end
		end
	else
		if(a == 0) then
			for b1 = -b, b do
				self.blocks[i + 1] = {0, 0, b1};
				i = i + 1;
			end

			self.blocks[i + 1] = {0, b, 0};
			self.blocks[i + 2] = {0, -b, 0};
		else
			for b1 = -b, b do
				self.blocks[i + 1] = {0, a, b1};
				self.blocks[i + 2] = {0, -a, b1};
				i = i + 2;
			end

			for a1 = -a, a do
				self.blocks[i + 1] = {0, b, a1};
				self.blocks[i + 2] = {0, -b, a1};
				i = i + 2;
			end
		end
	end
end

function SimpleShape:InitSphere()
	--local x1 = os.clock();
	self.blocks = {};
	self.tempBlocks = {};
	for x = -self.radius, self.radius do
		self.tempBlocks[x] = {};
		for y = -self.radius, self.radius do
			self.tempBlocks[x][y] = {};
			for z = -self.radius, self.radius do
				self.tempBlocks[x][y][z] = nil;
			end
		end
	end

	--midpoint circle algorithm
	local x = self.radius;
	local y = 0;
	local w = 1 - x;

	while(x >= y) do
		self:FillSphere(y, x, w);

		y = y + 1;

		if(w < 0) then
			w = w + 2 * y + 1;
		else
			x = x - 1;

			w = w + 2 * (y - x + 1);
		end
	end

	local i = 0;

	for x = -self.radius, self.radius do
		for y = -self.radius, self.radius do
			for z = -self.radius, self.radius do
				if(self.tempBlocks[x][y][z]) then
					i = i + 1;
					self.blocks[i] = {x, y, z};
				end
			end
		end
	end

	self.tempBlocks = nil;
	--local x2 = os.clock();
	--print(string.format("elapsed time: %f\n", x2 - x1));
	self:ChangeRotateY()
end

function SimpleShape:FillSphere(y, radius, w)
	--midpoint circle algorithm
	local x = radius;
	local z = 0;

	while(x >= z) do
		if(self.solid) then
			self:FillSphereBox(x, y, z);
			self:FillSphereBox(x, z, y);
			self:FillSphereBox(y, x, z);
			self:FillSphereBox(y, z, x);
			self:FillSphereBox(z, x, y);
			self:FillSphereBox(z, y, x);
		else
			self:FillSpherePoint(x, y, z);
			self:FillSpherePoint(x, z, y);
			self:FillSpherePoint(y, x, z);
			self:FillSpherePoint(y, z, x);
			self:FillSpherePoint(z, x, y);
			self:FillSpherePoint(z, y, x);
		end

		z = z + 1;

		if(w < 0) then
			w = w + 2 * z + 1;
		else
			x = x - 1;

			w = w + 2 * (z - x + 1);
		end
	end
end

function SimpleShape:FillSpherePoint(x, y, z)
	self.tempBlocks[x][y][z] = true;
	self.tempBlocks[x][y][-z] = true;
	self.tempBlocks[x][-y][z] = true;
	self.tempBlocks[x][-y][-z] = true;
	self.tempBlocks[-x][y][z] = true;
	self.tempBlocks[-x][y][-z] = true;
	self.tempBlocks[-x][-y][z] = true;
	self.tempBlocks[-x][-y][-z] = true;
end

function SimpleShape:FillSphereBox(x1, y1, z)
	for x = -x1, x1 do
		for y = -y1, y1 do
			self.tempBlocks[x][y][z] = true;
			self.tempBlocks[x][y][-z] = true;
		end
	end
end

function SimpleShape:InitEllipsoid()
	local radiusX = self.radiusX;
	local radiusY = self.radiusY;
	local radiusZ = self.radiusZ;

	if(radiusX == radiusY and radiusX == radiusZ) then
		self.radius = radiusX;
		self:InitSphere();
		return;
	end

	self.blocks = {};

	local tempBlocks = {};
	for x = 0, radiusX do
		tempBlocks[x] = {};
		for y = 0, radiusY do
			tempBlocks[x][y] = {};
			for z = 0, radiusZ do
				tempBlocks[x][y][z] = nil;
			end
		end
	end

	local i = 0;

	local radiusXsq = radiusX * radiusX;
	local radiusYsq = radiusY * radiusY;
	local radiusZsq = radiusZ * radiusZ;

	for x = 0, radiusX do
		for y = 0, radiusY do
			for z = 0, radiusZ do
				if(x * x / radiusXsq + y * y / radiusYsq + z * z / radiusZsq <= 1) then
					tempBlocks[x][y][z] = true;

					if(x == radiusX - 1) then
						if(y == 1 and z == 1) then
							self.blocks[i + 1] = {radiusX, 1, 0};
							self.blocks[i + 2] = {radiusX, -1, 0};
							self.blocks[i + 3] = {radiusX, 0, 1};
							self.blocks[i + 4] = {radiusX, 0, -1};
							self.blocks[i + 5] = {-radiusX, 1, 0};
							self.blocks[i + 6] = {-radiusX, -1, 0};
							self.blocks[i + 7] = {-radiusX, 0, 1};
							self.blocks[i + 8] = {-radiusX, 0, -1};
							i = i + 8;
						end

						if(y == 2) then
							self.blocks[i + 1] = {radiusX, 1, 0};
							self.blocks[i + 2] = {radiusX, -1, 0};
							self.blocks[i + 3] = {-radiusX, 1, 0};
							self.blocks[i + 4] = {-radiusX, -1, 0};
							i = i + 4;
						end

						if(z == 2) then
							self.blocks[i + 1] = {radiusX, 0, 1};
							self.blocks[i + 2] = {radiusX, 0, -1};
							self.blocks[i + 3] = {-radiusX, 0, 1};
							self.blocks[i + 4] = {-radiusX, 0, -1};
							i = i + 4;
						end
					end

					if(y == radiusY - 1) then
						if(x == 1 and z == 1) then
							self.blocks[i + 1] = {1, radiusY, 0};
							self.blocks[i + 2] = {-1, radiusY, 0};
							self.blocks[i + 3] = {0, radiusY, 1};
							self.blocks[i + 4] = {0, radiusY, -1};
							self.blocks[i + 5] = {1, -radiusY, 0};
							self.blocks[i + 6] = {-1, -radiusY, 0};
							self.blocks[i + 7] = {0, -radiusY, 1};
							self.blocks[i + 8] = {0, -radiusY, -1};
							i = i + 8;
						end

						if(x == 2) then
							self.blocks[i + 1] = {1, radiusY, 0};
							self.blocks[i + 2] = {-1, radiusY, 0};
							self.blocks[i + 3] = {1, -radiusY, 0};
							self.blocks[i + 4] = {-1, -radiusY, 0};
							i = i + 4;
						end

						if(z == 2) then
							self.blocks[i + 1] = {0, radiusY, 1};
							self.blocks[i + 2] = {0, radiusY, -1};
							self.blocks[i + 3] = {0, -radiusY, 1};
							self.blocks[i + 4] = {0, -radiusY, -1};
							i = i + 4;
						end
					end

					if(z == radiusZ - 1) then
						if(x == 1 and y == 1) then
							self.blocks[i + 1] = {1, 0, radiusZ};
							self.blocks[i + 2] = {-1, 0, radiusZ};
							self.blocks[i + 3] = {0, 1, radiusZ};
							self.blocks[i + 4] = {0, -1, radiusZ};
							self.blocks[i + 5] = {1, 0, -radiusZ};
							self.blocks[i + 6] = {-1, 0, -radiusZ};
							self.blocks[i + 7] = {0, 1, -radiusZ};
							self.blocks[i + 8] = {0, -1, -radiusZ};
							i = i + 8;
						end

						if(x == 2) then
							self.blocks[i + 1] = {1, 0, radiusZ};
							self.blocks[i + 2] = {-1, 0, radiusZ};
							self.blocks[i + 3] = {1, 0, -radiusZ};
							self.blocks[i + 4] = {-1, 0, -radiusZ};
							i = i + 4;
						end

						if(y == 2) then
							self.blocks[i + 1] = {0, 1, radiusZ};
							self.blocks[i + 2] = {0, -1, radiusZ};
							self.blocks[i + 3] = {0, 1, -radiusZ};
							self.blocks[i + 4] = {0, -1, -radiusZ};
							i = i + 4;
						end
					end
				end
			end
		end
	end

	if(not self.solid) then
		radiusXsq = (radiusX - 0.99) * (radiusX - 0.99);
		radiusYsq = (radiusY - 0.99) * (radiusY - 0.99);
		radiusZsq = (radiusZ - 0.99) * (radiusZ - 0.99);

		for x = 0, radiusX - 1 do
			for y = 0, radiusY - 1 do
				for z = 0, radiusZ - 1 do
					if((tempBlocks[x + 1][y][z] and tempBlocks[x][y + 1][z] and tempBlocks[x][y][z + 1]) and x * x / radiusXsq + y * y / radiusYsq + z * z / radiusZsq <= 1) then
						tempBlocks[x][y][z] = nil;
					end
				end
			end
		end
	end

	for x = 0, radiusX do
		for y = 0, radiusY do
			for z = 0, radiusZ do
				if(tempBlocks[x][y][z]) then
					self.blocks[i + 1] = {x, y, z};
					self.blocks[i + 2] = {x, y, -z};
					self.blocks[i + 3] = {x, -y, z};
					self.blocks[i + 4] = {x, -y, -z};
					self.blocks[i + 5] = {-x, y, z};
					self.blocks[i + 6] = {-x, y, -z};
					self.blocks[i + 7] = {-x, -y, z};
					self.blocks[i + 8] = {-x, -y, -z};
					i = i + 8;
				end
			end
		end
	end
	self:ChangeRotateY()
end

function SimpleShape:HideAll()
	self.rotatexNum = 0
	self.rotateyNum = 0
	self.rotatezNum = 0

	if(self.SimpleCube) then
		ParaUI.Destroy(self.SimpleCube);
		self.SimpleCube = nil;
	end

	if(self.SimpleRing) then
		ParaUI.Destroy(self.SimpleRing);
		self.SimpleRing = nil;
	end

	if(self.SimpleCircle) then
		ParaUI.Destroy(self.SimpleCircle);
		self.SimpleCircle = nil;
	end

	if(self.SimpleSphere) then
		ParaUI.Destroy(self.SimpleSphere);
		self.SimpleSphere = nil;
	end

	if(self.SimpleEllipsoid) then
		ParaUI.Destroy(self.SimpleEllipsoid);
		self.SimpleEllipsoid = nil;
	end
  
  if(self.SimpleStairs) then
		ParaUI.Destroy(self.SimpleStairs);
		self.SimpleStairs = nil;
	end
  
  if(self.SimpleCone) then
		ParaUI.Destroy(self.SimpleCone);
		self.SimpleCone = nil;
	end


	--Transform3DController.GetSingleton():Hide();

	self:HideShape();
end

function SimpleShape:ShapeMoveX(delta)
	self.centerX = self.centerX + delta;

	--Transform3DController.GetSingleton():SetBlockPos(self.centerX, self.centerY, self.centerZ);

	self:ShowShape();
end

function SimpleShape:ShapeMoveY(delta)
	self.centerY = self.centerY + delta;

	--Transform3DController.GetSingleton():SetBlockPos(self.centerX, self.centerY, self.centerZ);

	self:ShowShape();
end

function SimpleShape:ShapeMoveZ(delta)
	self.centerZ = self.centerZ + delta;

	--Transform3DController.GetSingleton():SetBlockPos(self.centerX, self.centerY, self.centerZ);

	self:ShowShape();
end
function SimpleShape:GetRotateX()
	return self.rotatexNum
end
function SimpleShape:GetRotateY()
	return self.rotateyNum
end
function SimpleShape:GetRotateZ()
	return self.rotatezNum
end
function SimpleShape:ShapeRotateX(clockwise)
	if(clockwise) then
		self.rotatexNum = (self.rotatexNum+1)%4
	else
		self.rotatexNum = self.rotatexNum -1
		if self.rotatexNum < 0 then
			self.rotatexNum = self.rotatexNum +4
		end
	end
	self:ChangeShapeRotateX(clockwise)
	self:ShowShape();
	return self.rotatexNum
end
function SimpleShape:ShapeRotateY(clockwise)
	if(clockwise) then
		self.rotateyNum = (self.rotateyNum+1)%4
	else
		self.rotateyNum = self.rotateyNum -1
		if self.rotateyNum < 0 then
			self.rotateyNum = self.rotateyNum +4
		end
	end
	self:ChangeShapeRotateY(clockwise)
	self:ShowShape();
	return self.rotateyNum
end
function SimpleShape:ShapeRotateZ(clockwise)
	if(clockwise) then
		self.rotatezNum = (self.rotatezNum+1)%4
	else
		self.rotatezNum = self.rotatezNum -1
		if self.rotatezNum < 0 then
			self.rotatezNum = self.rotatezNum +4
		end
	end
	self:ChangeShapeRotateZ(clockwise)
	self:ShowShape();
	return self.rotatezNum
end
function SimpleShape:ChangeShapeRotateX(clockwise)
	if(clockwise) then
		for i = 1, #(self.blocks) do
			local block = self.blocks[i];
			block[2], block[3] = block[3], -block[2];
		end
	else
		for i = 1, #(self.blocks) do
			local block = self.blocks[i];
			block[2], block[3] = -block[3], block[2];
		end
	end
end
function SimpleShape:ChangeShapeRotateY(clockwise)
	if(clockwise) then
		for i = 1, #(self.blocks) do
			local block = self.blocks[i];
			block[1], block[3] = block[3], -block[1];
		end
	else
		for i = 1, #(self.blocks) do
			local block = self.blocks[i];
			block[1], block[3] = -block[3], block[1];
		end
	end
end
function SimpleShape:ChangeShapeRotateZ(clockwise)
	if(clockwise) then
		for i = 1, #(self.blocks) do
			local block = self.blocks[i];
			block[1], block[2] = block[2], -block[1];
		end
	else
		for i = 1, #(self.blocks) do
			local block = self.blocks[i];
			block[1], block[2] = -block[2], block[1];
		end
	end
end
local BlockTransformerEx=BlockTransformer:new();
BlockTransformerEx.mSimpleShape=nil;
BlockTransformerEx.Oginal_transform=BlockTransformerEx.transform;
BlockTransformerEx.transform=
function(inst,paras)
  local ui=UIManager.getUI("LeftShapeSetBar_PC");
  local ret=inst:Oginal_transform(paras);
  local pos_x,pos_y,pos_z=Editor.getPosition();
  if pos_x+paras.center[1]~=inst.mSimpleShape.centerX then
    local value=pos_x+paras.center[1]-inst.mSimpleShape.centerX;
    inst.mSimpleShape.centerX = inst.mSimpleShape.centerX + value;
    ui.levelNum=ui.levelNum+value;
    ui.page:SetValue("levelLabel", mathlib.clamp(ui.levelNum,-99,99));
    ui.page:SetValue("levelLabel_stairs", mathlib.clamp(ui.levelNum,-99,99));
  end
  if pos_y+paras.center[2]~=inst.mSimpleShape.centerY then
    local value=pos_y+paras.center[2]-inst.mSimpleShape.centerY;
    inst.mSimpleShape.centerY = inst.mSimpleShape.centerY + value;
    ui.verticalNum=ui.verticalNum+value;
    ui.page:SetValue("verticalLabel", mathlib.clamp(ui.verticalNum,-99,99));
    ui.page:SetValue("verticalLabel_stairs", mathlib.clamp(ui.verticalNum,-99,99));
  end
  if pos_z+paras.center[3]~=inst.mSimpleShape.centerZ then
    local value=pos_z+paras.center[3]-inst.mSimpleShape.centerZ;
    inst.mSimpleShape.centerZ = inst.mSimpleShape.centerZ + value;
    ui.aroundNum=ui.aroundNum+value;
    ui.page:SetValue("aroundLabel", mathlib.clamp(ui.aroundNum,-99,99));
    ui.page:SetValue("aroundLabel_stairs", mathlib.clamp(ui.aroundNum,-99,99));
  end
  return ret;
end
BlockTransformerEx.execute=
function(inst,paras,copy)
  local blocks={};
  for _, block in ipairs(paras.outputs) do
    blocks[#blocks+1]={block.x-inst.mSimpleShape.centerX, block.y-inst.mSimpleShape.centerY, block.z-inst.mSimpleShape.centerZ};
  end
  inst.mSimpleShape.blocks=blocks;
end
function SimpleShape:ShowShape()
	self:HideShape();
  Selector.clear();
  for i = 1, #(self.blocks) do
    local block = self.blocks[i];
    Selector.selectOne(block[1] + self.centerX,block[2] + self.centerY,block[3] + self.centerZ);
  end
  BlockTransformerEx.mSimpleShape=self;
  Editor.beginTransformation(BlockTransformerEx,{self.centerX,self.centerY,self.centerZ});
	for i = 1, #(self.blocks) do
		local block = self.blocks[i];
    ParaTerrain.SelectBlock(block[1] + self.centerX, block[2] + self.centerY, block[3] + self.centerZ, false);
		ParaTerrain.SelectBlock(block[1] + self.centerX, block[2] + self.centerY, block[3] + self.centerZ, true, groupIndexHint);
	end
end

function SimpleShape:HideShape()
	ParaTerrain.DeselectAllBlock(groupIndexHint);
end

function SimpleShape:CreateShape()
  Editor.endTransformation();
  
	self:HideAll();

	self.mUndoList = self.mUndoList or {};
  self.mUndoList[#self.mUndoList+1]={};
  local undo_list=self.mUndoList[#self.mUndoList];
  for i = 1, #(self.blocks) do
		local block = self.blocks[i];
    local blockId = gameLogic.GetBlockInRightHand() or block_types.names.Grass;
		local old_block_id=ParaTerrain.GetBlockTemplateByIdx(block[1] + self.centerX, block[2] + self.centerY, block[3] + self.centerZ);
    undo_list[#undo_list+1]={block[1] + self.centerX, block[2] + self.centerY, block[3] + self.centerZ, blockId, old_block_id};
	end

	for i = 1, #(self.blocks) do
		local block = self.blocks[i];
    local blockId = gameLogic.GetBlockInRightHand() or block_types.names.Grass;
		blockEngine:SetBlock(block[1] + self.centerX, block[2] + self.centerY, block[3] + self.centerZ,blockId);
	end

	self.blocks = nil;

	if(gameLogic.GameMode:CanAddToHistory() and #(self.mUndoList) > 0) then
		undoManager.PushCommand(self);
	end
end

function SimpleShape:Undo()
	if(#self.mUndoList > 0 and #self.mUndoList[#self.mUndoList] > 0) then
		local _, block;
		for _, block in ipairs(self.mUndoList[#self.mUndoList]) do
			blockEngine:SetBlock(block[1], block[2], block[3], block[5] or 0);
		end
    self.mRedoList=self.mRedoList or {};
    self.mRedoList[#self.mRedoList+1]=self.mUndoList[#self.mUndoList];
    table.remove(self.mUndoList);
	end
end

function SimpleShape:Redo()
	if(#self.mRedoList > 0 and #self.mRedoList[#self.mRedoList] > 0) then
		local _, block;
		for _, block in ipairs(self.mRedoList[#self.mRedoList]) do
			blockEngine:SetBlock(block[1], block[2], block[3], block[4] or 0);
		end
    self.mUndoList[#self.mUndoList+1]=self.mRedoList[#self.mRedoList];
    table.remove(self.mRedoList);
	end
end

function SimpleShape:GetX()
	return self.radiusX;
end

function SimpleShape:SetX(value)
	self.radiusX = mathlib.clamp(value, minRadius, maxRadius);

	if(self.shape == "SimpleCube") then
    self.radiusX = mathlib.clamp(value, 0, maxRadius);
		self:InitCube();
	elseif(self.shape == "SimpleEllipsoid") then
		self:InitEllipsoid();
	elseif(self.shape == "SimpleStairs") then
    self:InitStairs();
	elseif(self.shape == "SimpleCone") then
    self:InitCone();
	end

	self:ShowShape();

	return self:GetX();
end

function SimpleShape:ChangeX(delta)
	return self:SetX(self.radiusX + delta);
end

function SimpleShape:GetY()
	return self.radiusY;
end

function SimpleShape:SetY(value)
	self.radiusY = mathlib.clamp(value, minRadius, maxRadius);

	if(self.shape == "SimpleCube") then
    self.radiusY = mathlib.clamp(value, 0, maxRadius);
		self:InitCube();
	elseif(self.shape == "SimpleEllipsoid") then
		self:InitEllipsoid();
	elseif(self.shape == "SimpleStairs") then
    self:InitStairs();
	elseif(self.shape == "SimpleCone") then
    self:InitCone();
	elseif(self.shape == "SimpleRing") then
    self:InitRing();
	end

	self:ShowShape();

	return self:GetY();
end

function SimpleShape:ChangeY(delta)
	return self:SetY(self.radiusY + delta);
end

function SimpleShape:GetZ()
	return self.radiusZ;
end

function SimpleShape:SetZ(value)
	self.radiusZ = mathlib.clamp(value, minRadius, maxRadius);

	if(self.shape == "SimpleCube") then
    self.radiusZ = mathlib.clamp(value, 0, maxRadius);
		self:InitCube();
	elseif(self.shape == "SimpleEllipsoid") then
		self:InitEllipsoid();
	elseif(self.shape == "SimpleStairs") then
    self:InitStairs();
	elseif(self.shape == "SimpleCone") then
    self:InitCone();
	end

	self:ShowShape();

	return self:GetZ();
end

function SimpleShape:ChangeZ(delta)
	return self:SetZ(self.radiusZ + delta);
end

function SimpleShape:GetRadius()
	return self.radius;
end

function SimpleShape:SetRadius(value)
	self.radius = mathlib.clamp(value, minRadius, maxRadius);

	if(self.shape == "SimpleRing") then
		self.radius = math.max(self.radius, self.thickness);
		self:InitRing();
	elseif(self.shape == "SimpleCircle") then
		self:InitCircle();
	elseif(self.shape == "SimpleSphere") then
		self:InitSphere();
	end

	self:ShowShape();

	return self:GetRadius();
end

function SimpleShape:ChangeRadius(delta)
	return self:SetRadius(self.radius + delta);
end

function SimpleShape:GetThickness()
	return self.thickness;
end

function SimpleShape:SetThickness(value)
	self.thickness = mathlib.clamp(value, minThickness, self.radius);

	if(self.shape == "SimpleRing") then
		self:InitRing();
	end

	self:ShowShape();

	return self:GetThickness();
end

function SimpleShape:ChangeThickness(delta)
	return self:SetThickness(self.thickness + delta);
end

function SimpleShape:GetHorizontal()
	return self.horizontal;
end

function SimpleShape:ChangeHorizontal()
	if(self.horizontal) then
		self.horizontal = nil;
	else
		self.horizontal = true;
	end

	if(self.shape == "SimpleRing") then
		self:InitRing();
	elseif(self.shape == "SimpleCircle") then
		self:InitCircle();
	end

	self:ShowShape();
	return self:GetHorizontal();
end

function SimpleShape:GetSolid()
	return self.solid;
end
function SimpleShape:ChangeRotateY()
	if self.rotateyNum > 0 then
		for i = 1,self.rotateyNum do
			self:ChangeShapeRotateY(1)
		end
	end
end
function SimpleShape:ChangeCone()
	SimpleShape.mIsCenterEmptyCone=not SimpleShape.mIsCenterEmptyCone;
	SimpleShape:InitCone();
	SimpleShape:ShowShape();
end

function SimpleShape:ChangeStairs(stairsType)
	if stairsType == 1 then
		self.stairsType = 1
		self.mStairsDirection = "x,y"
		self.mIsTriangleStairs = true
	elseif stairsType == 2 then
		self.stairsType = 2
		self.mStairsDirection = "x,-y"
		self.mIsTriangleStairs = false
	elseif stairsType == 3 then
		self.stairsType = 3
		self.mStairsDirection = "x,-y"
		self.mIsTriangleStairs = true
	end
	
	self:InitStairs();
	self:ShowShape();
end



function SimpleShape:ChangeSolid()
	if(self.solid) then
		self.solid = nil;
	else
		self.solid = true;
	end

	if(self.shape == "SimpleSphere") then
		self:InitSphere();
	elseif(self.shape == "SimpleEllipsoid") then
		self:InitEllipsoid();
	elseif self.shape=="SimpleCube" then
		self:InitCube();
	end

	self:ShowShape();
	return self:GetSolid();
end

function SimpleShape:InitStairs()
	self.blocks={};
  --[[if self.radiusX>self.radiusY then
    if self.radiusY==1 then
      for z=0,self.radiusZ-1 do
        for x=0,self.radiusX-1 do
          self.blocks[#self.blocks+1]={x,0,z};
        end
      end
      return;
    end
    local width=math.max(self.radiusX,2);
    local c1=self.radiusY-1;
    local c2=1;
    local w1;
    local w2;
    local test_passed=false;
    for i=2,width do
      w2=i;
      w1=(width-w2)/c1;
      if w1-math.floor(w1)==0 then
        break;
      end
    end
    for z=0,self.radiusZ-1 do
      for y=0,self.radiusY-2 do
        local x_offset=y*w1;
        if self.mIsTriangleStairs then
          for x=x_offset,width-1 do
            self.blocks[#self.blocks+1]={x,y,z};
          end
        else
          for x=0,w1 do
            self.blocks[#self.blocks+1]={x+x_offset,y,z};
          end
        end
      end
      local x_offset=(self.radiusY-1)*w1;
      for x=0,w2-1 do
        self.blocks[#self.blocks+1]={x+x_offset,self.radiusY-1,z};
      end
    end
  elseif self.radiusX<self.radiusY then
    if self.radiusX==1 then
      for z=0,self.radiusZ-1 do
        for y=0,self.radiusY-1 do
          self.blocks[#self.blocks+1]={0,y,z};
        end
      end
      return;
    end
    local height=math.max(self.radiusY,2);
    local c1=self.radiusX-1;
    local c2=1;
    local h1;
    local h2;
    local test_passed=false;
    for i=2,height do
      h2=i;
      h1=(height-h2)/c1;
      if h1-math.floor(h1)==0 then
        break;
      end
    end
    for z=0,self.radiusZ-1 do
      for x=0,self.radiusX-2 do
        local y_offset=x*h1;
        if self.mIsTriangleStairs then
          for y=y_offset,height-1 do
            self.blocks[#self.blocks+1]={x,y,z};
          end
        else
          for y=0,h1 do
            self.blocks[#self.blocks+1]={x,y+y_offset,z};
          end
        end
      end
      local y_offset=(self.radiusX-1)*h1;
      for y=0,h2-1 do
        self.blocks[#self.blocks+1]={self.radiusX-1,y+y_offset,z};
      end
    end
  else
    for z=0,self.radiusZ-1 do
      for x=0,self.radiusX-1 do
        if self.mIsTriangleStairs then
          for y=0,x do
            self.blocks[#self.blocks+1]={x,y,z};
          end
        else
          self.blocks[#self.blocks+1]={x,x,z};
          if x<self.radiusX-1 then
            self.blocks[#self.blocks+1]={x+1,x,z};
          end
        end
      end
    end
  end]]
  self.mStairsDirection=self.mStairsDirection or "x,y";
  if self.mStairsDirection=="x,y" then
    for x=0,self.radiusX-1 do
      for z=0,self.radiusZ-1 do
        if self.mIsTriangleStairs then
          for y=0,math.min(self.radiusY-1,self.radiusX-1-x)+math.max(self.radiusY-self.radiusX,0) do
            self.blocks[#self.blocks+1]={x,y,z};
          end
        else
          if x==self.radiusX-1 then
            for y=0,math.min(self.radiusY-1,self.radiusX-1-x)+math.max(self.radiusY-self.radiusX,0) do
              self.blocks[#self.blocks+1]={x,y,z};
            end
          else
            local y=math.min(self.radiusY-1,self.radiusX-1-x)+math.max(self.radiusY-self.radiusX,0);
            self.blocks[#self.blocks+1]={x,y,z};
          end
        end
      end
    end
  elseif self.mStairsDirection=="-x,y" then
    for x=0,self.radiusX-1 do
      for z=0,self.radiusZ-1 do
        if self.mIsTriangleStairs then
          for y=0,math.min(self.radiusY-1,x)+math.max(self.radiusY-self.radiusX,0) do
            self.blocks[#self.blocks+1]={x,y,z};
          end
        else
          if x==0 then
            for y=0,math.min(self.radiusY-1,x)+math.max(self.radiusY-self.radiusX,0) do
              self.blocks[#self.blocks+1]={x,y,z};
            end
          else
            local y=math.min(self.radiusY-1,x)+math.max(self.radiusY-self.radiusX,0);
            self.blocks[#self.blocks+1]={x,y,z};
          end
        end
      end
    end
  elseif self.mStairsDirection=="x,-y" then
    for y=0,self.radiusY-1 do
      for z=0,self.radiusZ-1 do
        if self.mIsTriangleStairs then
          for x=0,math.min(self.radiusX-1,y)+math.max(self.radiusX-self.radiusY,0) do
            self.blocks[#self.blocks+1]={x,y,z};
          end
        else
          if y==0 then
            for x=0,math.min(self.radiusX-1,y)+math.max(self.radiusX-self.radiusY,0) do
              self.blocks[#self.blocks+1]={x,y,z};
            end
          else
            local x=math.min(self.radiusX-1,y)+math.max(self.radiusX-self.radiusY,0);
            self.blocks[#self.blocks+1]={x,y,z};
          end
        end
      end
    end
  elseif self.mStairsDirection=="-x,-y" then
    for y=0,self.radiusY-1 do
      for z=0,self.radiusZ-1 do
        if self.mIsTriangleStairs then
          for x=self.radiusX-1,math.max(0,self.radiusX-1-y)-math.max(self.radiusX-self.radiusY,0),-1 do
            self.blocks[#self.blocks+1]={x,y,z};
          end
        else
          if y==0 then
            for x=self.radiusX-1,math.max(0,self.radiusX-1-y)-math.max(self.radiusX-self.radiusY,0),-1 do
              self.blocks[#self.blocks+1]={x,y,z};
            end
          else
            local x=math.max(0,self.radiusX-1-y)-math.max(self.radiusX-self.radiusY,0);
            self.blocks[#self.blocks+1]={x,y,z};
          end
        end
      end
    end
  end
  self:ChangeRotateY()
end

function SimpleShape:ShowStairs()
	if(not self.SimpleStairs) then
		self:HideAll();

		self.shape = "SimpleStairs";
		self.radiusX = minRadius;
		self.radiusY = minRadius;
		self.radiusZ = minRadius;

		self:InitCenter();
		--Transform3DController.GetSingleton():SetBlockPos(self.centerX, self.centerY, self.centerZ);

		self:InitStairs();
		self:ShowShape();

		-- self.SimpleStairs = Map3DSystem.mcml.PageCtrl:new({url="script/Seer/SimpleStairs.html", enable_esc_key = true, zorder = 1,});
		-- self.SimpleStairs = self.SimpleStairs:Create("SimpleStairs", nil, "_lt", 0, 120, 310, 340).name;
	end
end

function SimpleShape:InitCone()
	self.blocks={};
  for y=0,self.radiusY-1 do
    for z=y,self.radiusZ-1-y do
      for x=y,self.radiusX-1-y do
        local alone=true;
        if self.mIsCenterEmptyCone then
          if x~=y and x~=self.radiusX-1-y and z~=y and z~=self.radiusZ-1-y then
            alone=false;
          end
        end
        if alone then
          self.blocks[#self.blocks+1]={x,y,z};
        end
      end
    end
  end
  self:ChangeRotateY()
end

function SimpleShape:ShowCone()
	if(not self.SimpleCone) then
		self:HideAll();

		self.shape = "SimpleCone";
		self.radiusX = minRadius;
		self.radiusY = minRadius;
		self.radiusZ = minRadius;

		self:InitCenter();
		--Transform3DController.GetSingleton():SetBlockPos(self.centerX, self.centerY, self.centerZ);

		self:InitCone();
		self:ShowShape();

		-- self.SimpleCone = Map3DSystem.mcml.PageCtrl:new({url="script/Seer/SimpleCone.html", enable_esc_key = true, zorder = 1,});
		-- self.SimpleCone = self.SimpleCone:Create("SimpleCone", nil, "_lt", 0, 120, 310, 340).name;
	end
end

function SimpleShape:canPutBlock()
	local block_id = GameLogic.GetBlockInRightHand();
	local GamingRoomInfo = commonlib.gettable("Mod.Seer.Game.MultiPlayer.GamingRoomInfo");
	local YcProfile = commonlib.gettable("Mod.Seer.Network.YcProfile");
	local meminfo = GamingRoomInfo.getPlayer(YcProfile.uid);
	if meminfo and not meminfo:canUseBlock(block_id) then
		_guihelper.MessageBox("无法使用当前方块")
		return false;
  else
    return true;
	end
end