NPL.load("(gl)script/Seer/Network/Packets/PacketPbHelper.lua");
NPL.load("(gl)script/Seer/pb/items_pb.lua");
local PacketPbHelper = commonlib.gettable("Mod.Seer.Network.Packets.PacketPbHelper");
local PacketPBHelpherPlugin=commonlib.gettable("Mod.Seer.Network.Packets.PacketPBHelpherPlugin");
PacketPBHelpherPlugin.mCallbacks={};
function PacketPBHelpherPlugin.register(proto,callback)
  PacketPBHelpherPlugin.mCallbacks[proto]=PacketPBHelpherPlugin.mCallbacks[proto] or {};
  local callbacks=PacketPBHelpherPlugin.mCallbacks[proto];
  callbacks[#callbacks+1]=callback;
end
function PacketPBHelpherPlugin.unregister(proto,callback)
  local callbacks=PacketPBHelpherPlugin.mCallbacks[proto];
  if callbacks then
    local iterator=nil;
    for i=1,#callbacks do
      if callbacks[i]==callback then
        iterator=i;
        break;
      end
    end
    if iterator then
      table.remove(callbacks,iterator);
    end
  end
end
function PacketPBHelpherPlugin.process(proto,body)
  local callbacks=PacketPBHelpherPlugin.mCallbacks[proto];
  if callbacks then
    for i=1,#callbacks do
      local callback=callbacks[i];
      callback(body);
    end
  end
end
PacketPbHelper.registerFunc("CSNotifyDefinedData",
  function(h,b)
    PacketPBHelpherPlugin.process("CSNotifyDefinedData",b);
  end
);
PacketPbHelper.registerFunc("CSNotifyExpendItem",
  function(h,b)
    PacketPBHelpherPlugin.process("CSNotifyExpendItem",b);
  end
);

PacketPbHelper.registerFunc("CSSetDataArchiveItemNtf",
  function(h,b)
    PacketPBHelpherPlugin.process("CSSetDataArchiveItemNtf",b);
  end
);
PacketPbHelper.registerFunc("CSDelArchiveItemNtf",
  function(h,b)
    PacketPBHelpherPlugin.process("CSDelArchiveItemNtf",b);
  end
);