
NPL.load("(gl)script/Seer/Game/MultiPlayer/RoomPermission.lua");
local RoomPermission = commonlib.gettable("Mod.Seer.Game.MultiPlayer.RoomPermission");
local config = commonlib.gettable("Mod.Seer.Config");
local ItemClient = commonlib.gettable("MyCompany.Aries.Game.Items.ItemClient");

local UIManager = commonlib.gettable("Mod.Seer.Game.UI.UIManager");
local UIBase = commonlib.gettable("Mod.Seer.Game.UI.UIBase");
local RoomBlockAccessPage = commonlib.inherit(UIBase,commonlib.gettable("Mod.Seer.RoomBlockAccessPage"));
NPL.load("(gl)script/Seer/Utility/CommonUtility.lua");
local CommonUtility = commonlib.gettable("Mod.Seer.Utility.CommonUtility");

if CommonUtility:IsMobilePlatform() then
	UIManager.registerUI("RoomBlockAccessPage", RoomBlockAccessPage,"script/Seer/RoomBlockAccessPage.html",
	{
	});
else
	UIManager.registerUI("RoomBlockAccessPage", RoomBlockAccessPage,"script/Seer/RoomBlockAccessPage.PC.html",
	{
	});
end

local laccessInfo = {}
local callback = nil
local lstates = nil

local lCategoryList = {}
function RoomBlockAccessPage:onCreate(paras)
	laccessInfo = paras.accessInfo
	callback = paras.callback
	if paras.accessInfo and paras.accessInfo.states then
		local s = commonlib.copy(paras.accessInfo.states)
		lstates = RoomPermission:new():init(s)
	else
		lstates = RoomPermission:new()
	end

	self:InitNoEditXml()
	self:refresh()
end
function RoomBlockAccessPage:InitNoEditXml()
	lCategoryList = {}
	local categoryInfo = config.NoEditBlock.Category
	local categorySize = categoryInfo:size()
	for i=1,categorySize do
		local data = categoryInfo:get(i)
		table.insert(lCategoryList,data)
	end
end
function RoomBlockAccessPage:GetCategoryInfoByIdx(idx)
	return lCategoryList[idx]
end
function RoomBlockAccessPage:GetOptionInfoByCategoryIdx(idx)
	local info = lCategoryList[idx]
	if info then
		return info.Option._VEC
	end
	return nil
end
function RoomBlockAccessPage:NoBlock_Data(index)
    if(index == nil) then
        return #lCategoryList;
    else
        return lCategoryList[index];
    end
end
function RoomBlockAccessPage:GetTagNameIconStyle(idx)
	local info = self:GetCategoryInfoByIdx(idx)
	local icon = ""
	if info then
	    local iconName = info.Name
	    if iconName == "液体" then
	    	icon = UIUtility.GetMCMLStandardImageDescription("gameassets/textures/ui_06_shop/NewShopUI.png","161.png","#")
	    elseif iconName == "炸药" then
	    	icon = UIUtility.GetMCMLStandardImageDescription("gameassets/textures/ui_06_shop/NewShopUI.png","162.png","#")
	    elseif iconName == "机关" then
	    	icon = UIUtility.GetMCMLStandardImageDescription("gameassets/textures/ui_06_shop/NewShopUI.png","163.png","#")
	    elseif iconName == "家具" then
	    	icon = UIUtility.GetMCMLStandardImageDescription("gameassets/textures/ui_06_shop/NewShopUI.png","164.png","#")
	    end
	end
	local width,height = UIUtility.GetTextureDimension("gameassets/textures/ui_06_shop/NewShopUI.png","161.png")
    local style = string.format("position:relative;margin-left:100px;margin-top:20px;background:url(%s);width:%spx;height:%spx",icon,width,height)
    return style
end
function RoomBlockAccessPage:CheckProhibitBtn(idx)
	local optionInfo = self:GetOptionInfoByCategoryIdx(idx)
	if optionInfo then
		for i,v in pairs(optionInfo) do
			for i,v in pairs(optionInfo) do
				if not self:CheckDisable(v.NoName) then
					self["prohibitBtn"..idx] = false
					return false
				end
			end
		end
		self["prohibitBtn"..idx] = true
		return true
	end
end
function RoomBlockAccessPage:OnProhibitAll(idx)
	if self["prohibitBtn"..idx] then
		self["prohibitBtn"..idx] = false
		self:DoRrohibitAllOptions(idx,false)
	else
		self["prohibitBtn"..idx] = true
		self:DoRrohibitAllOptions(idx,true)
	end
	self:refresh()
end
function RoomBlockAccessPage:DoRrohibitAllOptions(idx,isTrue)
	local optionInfo = self:GetOptionInfoByCategoryIdx(tonumber(idx))
	if optionInfo then
		for i,v in pairs(optionInfo) do
			if isTrue then
				self:DisabledBlock(v.NoName)
			else
				self:EnabledBlock(v.NoName)
			end
		end
	end
end

function RoomBlockAccessPage:GetOneOptionInfo(categoryIdx,idx)
	local optionInfo = self:GetOptionInfoByCategoryIdx(categoryIdx)
	local currentOptionPage = self:GetCurrentOptionPageByCategoryIdx(categoryIdx)
	if optionInfo and optionInfo[idx+(currentOptionPage-1)*5] then
		return optionInfo[idx+(currentOptionPage-1)*5]
	end
	return nil
end
function RoomBlockAccessPage:GetOptionType(categoryIdx,idx)
	local optionInfo = self:GetOneOptionInfo(categoryIdx,idx)
	if optionInfo then
		return optionInfo.Type
	end
	return ""
end
function RoomBlockAccessPage:GetBlockID(categoryIdx,idx)
	local optionInfo = self:GetOneOptionInfo(categoryIdx,idx)
	if optionInfo then
		return tonumber(optionInfo.ID)
	end
	return 76
end
function RoomBlockAccessPage:GetBlockTip(categoryIdx,idx)
	local optionInfo = self:GetOneOptionInfo(categoryIdx,idx)
	if optionInfo then
		return optionInfo.Tip
	end
	return ""
end
function RoomBlockAccessPage:GetBlockIcon(categoryIdx,idx)
	local optionInfo = self:GetOneOptionInfo(categoryIdx,idx)
	if optionInfo then
		return optionInfo.Icon
	end
	return ""
end
function RoomBlockAccessPage:GetOptionCountByCategoryIdx(categoryIdx)
	if self["optionTotalPage"..categoryIdx] then
		return self["optionTotalPage"..categoryIdx]
	end
	local info = self:GetOptionInfoByCategoryIdx(categoryIdx)
	if info then
		self["optionTotalPage"..categoryIdx] = #info
	else
		self["optionTotalPage"..categoryIdx] = 1
	end
	return self["optionTotalPage"..categoryIdx]
end
function RoomBlockAccessPage:GetCurrentOptionPageByCategoryIdx(categoryIdx)
	if not self["optionCurrentPage"..categoryIdx] then
		self["optionCurrentPage"..categoryIdx] = 1
	end
	return self["optionCurrentPage"..categoryIdx]
end
function RoomBlockAccessPage:CheckHaveRightBtn(categoryIdx)
	local currentOptionPage = self:GetCurrentOptionPageByCategoryIdx(categoryIdx) 
	local maxPage = math.ceil(self:GetOptionCountByCategoryIdx(categoryIdx)/5)
	if maxPage>1 and currentOptionPage < maxPage then
		return true
	end
	return false
end
function RoomBlockAccessPage:CheckHaveLeftBtn(categoryIdx)
	local currentOptionPage = self:GetCurrentOptionPageByCategoryIdx(categoryIdx) 
	local maxPage = math.ceil(self:GetOptionCountByCategoryIdx(categoryIdx)/5)
	if currentOptionPage>1 then
		return true
	end
	return false
end
function RoomBlockAccessPage:OnRightBtn(categoryIdx)
	self["optionCurrentPage"..categoryIdx] = self["optionCurrentPage"..categoryIdx] +1
	self:refresh()
end
function RoomBlockAccessPage:OnLeftBtn(categoryIdx)
	self["optionCurrentPage"..categoryIdx] = self["optionCurrentPage"..categoryIdx] -1
	self:refresh()
end
function RoomBlockAccessPage:GetBlockNoName(categoryIdx,idx)
	local optionInfo = self:GetOneOptionInfo(categoryIdx,idx)
	if optionInfo then
		return optionInfo.NoName
	end
	return ""
end
function RoomBlockAccessPage:OnProhibitOne(name)
	self:OnSelect(name)
	self:refresh()
end
function RoomBlockAccessPage:CheckBlockIsProhibited(categoryIdx,idx)
	local optionInfo = self:GetOneOptionInfo(categoryIdx,idx)
	if optionInfo then
		return self:CheckDisable(optionInfo.NoName)
	end
	return false
end

function RoomBlockAccessPage:CheckDisable(name)
	if lstates then
		return lstates:has(name,true)
	end
	return false
end
function RoomBlockAccessPage:DisabledBlock(name)
	if lstates then
		if not lstates:has(name,true) then
			lstates:add(name)
		end
	end
end
function RoomBlockAccessPage:EnabledBlock(name)
	if lstates then
		if lstates:has(name,true) then
			lstates:remove(name)
		end
	end
end

function RoomBlockAccessPage:OnSelect(name)
	if lstates then
		if lstates:has(name,true) then
			lstates:remove(name)
		else
			lstates:add(name)
		end
	end
end

function RoomBlockAccessPage:OnConfirm()
	if callback then
		laccessInfo.states = lstates:getData()
		callback(laccessInfo)
	end
	self:close()
end