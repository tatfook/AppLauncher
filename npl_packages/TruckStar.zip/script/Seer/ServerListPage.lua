--[[
NPL.load("(gl)script/Seer/ServerListPage.lua");
local ServerListPage = commonlib.gettable("Mod.Seer.ServerListPage")
ServerListPage.ShowPage()
--]]
NPL.load("(gl)script/Seer/Utility/CommonUtility.lua");
local CommonUtility = commonlib.gettable("Mod.Seer.Utility.CommonUtility");


NPL.load("(gl)script/Seer/Utility/UserDatabase.lua");
local UserDatabase = commonlib.gettable("Mod.Seer.Utility.UserDatabase");

NPL.load("(gl)script/Seer/Game/Login/ServerManager.lua");
local ServerManager = commonlib.gettable("Mod.Seer.Game.ServerManager");

NPL.load("(gl)script/Seer/Network/Packets/PacketPbHelper.lua");
local PacketPbHelper = commonlib.gettable("Mod.Seer.Network.Packets.PacketPbHelper");

local ServerListPage = commonlib.gettable("Mod.Seer.ServerListPage")

local page;
local loginServerList = {}
local serverList = {}
local selectId = nil -- check with list[?].id
local selectList = {}
local currentList = {}
local callback = nil
local userUid = nil
local userServerList = {}
function ServerListPage.OnInit()
	page = document:GetPageCtrl();
end
function ServerListPage.ShowPage(list,uid)
	userUid = tonumber(uid)
	ServerListPage.InitList(list)
	local _url 
    if CommonUtility:IsMobilePlatform() then
        _url = "script/Seer/ServerListPage.html"
    else
        _url = "script/Seer/ServerListPage.PC.html"
    end
	System.App.Commands.Call("File.MCMLWindowFrame", {
		url = _url, 
		name = "ServerListPage", 
		isShowTitleBar = false,
		DestroyOnClose = true, -- prevent many ViewProfile pages staying in memory
		style = CommonCtrl.WindowFrame.ContainerStyle,
		zorder = 2,
		allowDrag = false,
		enable_esc_key = true,
		directPosition = true,
			align = "_fi",
			x = 0,
			y = 0,
			width = 0,
			height = 0,
		cancelShowAnimation = true,
	});
	ServerListPage.GetUserServerList()
end
function ServerListPage.GetUserServerList()
	if userUid then
		ServerManager.getServerListByUserID(userUid,function(list)
			userServerList = list or {}
			ServerListPage.RefreshPage()
		end)
	end
end
function ServerListPage.CheckUserServerList(index)
	local list = ServerListPage.GetServerListByIndex(index)
	for i,v in pairs(userServerList) do
		if list.id == v.id then
			return true
		end
	end
	return false
end
function ServerListPage.InitList(list)
	loginServerList = list
	callback = ServerListPage.CallBack
	if not selectId then
    	currentList = UserDatabase.getAttribute("LocalServerListId", {}, "local")
		selectId = currentList[1]
		selectList = loginServerList[selectId] or {}
	end
	ServerListPage.SortList(loginServerList)
end
function ServerListPage.CheckIsCurrent(id)
	if id == currentList[1] or id == currentList[2] then
		return true
	end
	return false
end
function ServerListPage.SortList(list)
	serverList = {}
	for i,v in pairs(list) do
		serverList[#serverList+1] = v
	end
	local lens = #serverList
	if lens > 1 then
		for i = 1, lens-1 do
			for j = lens-1,i ,-1 do
				if not ServerListPage.CheckIsCurrent(serverList[j].id) then
					if ServerListPage.CheckIsCurrent(serverList[j+1].id) then
						serverList[j],serverList[j+1] = serverList[j+1],serverList[j]
					elseif serverList[j+1].config_status > serverList[j].config_status then
						serverList[j],serverList[j+1] = serverList[j+1],serverList[j]
					end
				end
			end
		end
	end
	return serverList
end
function ServerListPage.GridviewList(index)
   local ds = serverList or {}
   if(index == nil) then
        return #ds;
   else
        return ds[index];
   end
end

function ServerListPage.GetServerListByIndex(index)
	return serverList[index] or {}
end
function ServerListPage.CheckIsSelect(index)
	local list = ServerListPage.GetServerListByIndex(index)
	if list.id == selectId then
		return true
	end
	return false
end
function ServerListPage.OnSelect(index)
	selectList = ServerListPage.GetServerListByIndex(index)
	selectId = selectList.id
	ServerListPage.RefreshPage()
end
function ServerListPage.GetConfigStatus(index)
	local list = ServerListPage.GetServerListByIndex(index)
	local configStatus = 0
	if list then
		if ServerListPage.CheckIsCurrent(list.id) then
			configStatus =  -1
		else
			configStatus = list.config_status 
		end
	end
	return configStatus
end
function ServerListPage.GetServerStatus(index)
	local list = ServerListPage.GetServerListByIndex(index)
	if list then
		return list.server_status
	end
	return 2
end
function ServerListPage.RefreshPage()
	if page then
		page:Refresh(0)
	end
end
function ServerListPage.OnCancel()
	if page then
		page:CloseWindow()
	end
end
function ServerListPage.OnConfirm()
	if callback then
		callback(selectList)
	end
	if page then
		page:CloseWindow()
	end
end