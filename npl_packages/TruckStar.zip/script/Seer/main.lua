--[[
    Title: Seer Mod
    Author(s): ZhouXing
    Date: 2015/5/18
    Desc: Seer Mod
    use the lib:
    ------------------------------------------------------------
    NPL.load("(gl)script/Seer/main.lua");
    local Seer = commonlib.gettable("Mod.Seer");
    ------------------------------------------------------------
]]
NPL.load("(gl)script/apps/Aries/Creator/Game/Commands/CommandManager.lua");
NPL.load("(gl)script/kids/3DMapSystemApp/mcml/pe_hotkey.lua");
NPL.load("(gl)script/ide/System/Core/SceneContextManager.lua");

NPL.load("(gl)script/Seer/Utility/CommonUtility.lua");
NPL.load("(gl)script/Seer/KeyInput.lua");
NPL.load("(gl)script/Seer/Settings.lua");
NPL.load("(gl)script/Seer/Theme.lua");
NPL.load("(gl)script/Seer/Game/ModuleManager.lua");
NPL.load("(gl)script/Seer/Game/UI/UIManager.lua");

local CommonUtility = commonlib.gettable("Mod.Seer.Utility.CommonUtility");
local UIManager= commonlib.gettable("Mod.Seer.Game.UI.UIManager");
local worldCommon = commonlib.gettable("MyCompany.Aries.Creator.WorldCommon");
local commandManager = commonlib.gettable("MyCompany.Aries.Game.CommandManager");
local Game = commonlib.gettable("MyCompany.Aries.Game");
local GameLogic = commonlib.gettable("MyCompany.Aries.Game.GameLogic");
local GameMode = commonlib.gettable("MyCompany.Aries.Game.GameLogic.GameMode");
local hotkey_manager = commonlib.gettable("Map3DSystem.mcml_controls.hotkey_manager");
local SceneContextManager = commonlib.gettable("System.Core.SceneContextManager");

local KeyInput = commonlib.gettable("Mod.Seer.KeyInput");
local Settings = commonlib.gettable("Mod.Seer.Settings");
local UITheme = commonlib.gettable("Mod.Seer.UI.Theme");

local ModuleManager = commonlib.gettable("Mod.Seer.Game.ModuleManager");

local Seer = commonlib.inherit(commonlib.gettable("Mod.ModBase"),commonlib.gettable("Mod.Seer"));

local inputlistener = nil

function Seer:ctor()
end

-- virtual function get mod name
function Seer:GetName()
    return "Seer"
end

-- virtual function get mod description 
function Seer:GetDesc()
    return "Seer is a plugin in paracraft"
end

function Seer:init()
    LOG.std(nil, "info", "Seer", "main init");

    --if CommonUtility.IsMobilePlatform() then
        LOG.std(nil, "debug", "truckstar", "mobile-version: set screen resolution to 1080p");
        ParaUI.SetMinimumScreenSize(2048,1096,true);
    --end

    UITheme.Init();

    Seer:RegisterWorldGenerator();
    self:initModule()
    Seer:InitContexts();
    self:loadSystemSetting();
end

function Seer:initModule()
    echo("init module")
    
    -- independence
    NPL.load("(gl)script/Seer/Game/Login/Login.lua");
    local Login = commonlib.gettable("Mod.Seer.Game.Login")
    ModuleManager.registerModule("Login", Login)

    NPL.load("(gl)script/Seer/Game/MainMenu/MainMenu.lua");
    local MainMenu = commonlib.gettable("Mod.Seer.Game.MainMenu");
    ModuleManager.registerModule("MainMenu", MainMenu)

    NPL.load("(gl)script/Seer/Game/SelectPlanet/SelectPlanet.lua");
    local SelectPlanet = commonlib.gettable("Mod.Seer.Game.SelectPlanet");
    ModuleManager.registerModule("SelectPlanet", SelectPlanet);

    NPL.load("(gl)script/Seer/Game/CreateRole/CreateRole.lua");
    local CreateRole = commonlib.gettable("Mod.Seer.Game.CreateRole");
    ModuleManager.registerModule("CreateRole", CreateRole);

    NPL.load("(gl)script/Seer/Game/Movie/Movie.lua");
    local Movie = commonlib.gettable("Mod.Seer.Game.Movie");
    ModuleManager.registerModule("Movie", Movie);

    NPL.load("(gl)script/Seer/Game/CreatePlanet/CreatePlanet.lua");
    local CreatePlanet = commonlib.gettable("Mod.Seer.Game.CreatePlanet");
    ModuleManager.registerModule("CreatePlanet", CreatePlanet);

    NPL.load("(gl)script/Seer/Game/Online/Online.lua");
    local Online = commonlib.gettable("Mod.Seer.Game.Online");
    ModuleManager.registerModule("Online",Online);

	NPL.load("(gl)script/Seer/Game/Guide/Guide.lua");
	local Guide = commonlib.gettable("Mod.Seer.Game.Guide");
	ModuleManager.registerModule("Guide",Guide)

    --saver 
    NPL.load("(gl)script/Seer/Game/World/Saver.lua");
    local Saver = commonlib.gettable("Mod.Seer.Game.World.Saver");
    ModuleManager.registerModule("Saver",Saver);

    --input module
	NPL.load("(gl)script/Seer/Game/Input/Input.lua");
    local Input = commonlib.gettable("Mod.Seer.Game.Input");
    ModuleManager.registerModule("Input",Input);

    --world module
    NPL.load("(gl)script/Seer/Game/World/StandAlone.lua");
    local StandAlone = commonlib.gettable("Mod.Seer.Game.World.StandAlone");
    ModuleManager.registerModule("StandAlone",StandAlone);


    NPL.load("(gl)script/Seer/Game/World/BigWorld.lua");
    local BigWorld = commonlib.gettable("Mod.Seer.Game.World.BigWorld");
    ModuleManager.registerModule("BigWorld",BigWorld);

    NPL.load("(gl)script/Seer/Game/World/VisitWorld.lua");
    local VisitWorld = commonlib.gettable("Mod.Seer.Game.World.VisitWorld");
    ModuleManager.registerModule("VisitWorld",VisitWorld);


    NPL.load("(gl)script/Seer/Game/World/GameWorld.lua");
    local GameWorld = commonlib.gettable("Mod.Seer.Game.World.GameWorld");
    ModuleManager.registerModule("GameWorld",GameWorld);
    
    --editmode
    NPL.load("(gl)script/Seer/Game/World/EditMode.lua");
    local EditMode = commonlib.gettable("Mod.Seer.Game.World.EditMode");
	ModuleManager.registerModule("EditMode",EditMode);

    --playmode
    NPL.load("(gl)script/Seer/Game/World/PlayMode.lua");
    local PlayMode = commonlib.gettable("Mod.Seer.Game.World.PlayMode");
    ModuleManager.registerModule("PlayMode",PlayMode);

    
	--bigworld playmode
    NPL.load("(gl)script/Seer/Game/World/MiniGame.lua");
    local MiniGame = commonlib.gettable("Mod.Seer.Game.World.MiniGame");
    ModuleManager.registerModule("MiniGame",MiniGame);
	
	--multiplayer
    NPL.load("(gl)script/Seer/Game/MultiPlayer/MultiPlayerClient.lua");
    local MultiPlayerClient = commonlib.gettable("Mod.Seer.Game.MultiPlayerClient");
    ModuleManager.registerModule("MultiPlayerClient",MultiPlayerClient);

    NPL.load("(gl)script/Seer/Game/MultiPlayer/MultiPlayerServer.lua");
    local MultiPlayerServer = commonlib.gettable("Mod.Seer.Game.MultiPlayerServer");
	ModuleManager.registerModule("MultiPlayerServer",MultiPlayerServer);

    NPL.load("(gl)script/Seer/Game/MultiPlayer/MultiPlayerEdit.lua");
    local MultiPlayerEdit = commonlib.gettable("Mod.Seer.Game.MultiPlayer.MultiPlayerEdit");
    ModuleManager.registerModule("MultiPlayerEdit",MultiPlayerEdit);

    NPL.load("(gl)script/Seer/Game/MultiPlayer/MultiPlayerMiniGame.lua");
    local MultiPlayerMiniGame = commonlib.gettable("Mod.Seer.Game.MultiPlayer.MultiPlayerMiniGame");
    ModuleManager.registerModule("MultiPlayerMiniGame",MultiPlayerMiniGame);


    NPL.load("(gl)script/Seer/Game/Guide/GuideWorld.lua");
    local GuideWorld = commonlib.gettable("Mod.Seer.Game.Guide.GuideWorld");
    ModuleManager.registerModule("GuideWorld", GuideWorld);
    
    NPL.load("(gl)script/Seer/Game/Furniture/FurnitureModule.lua");
    local FurnitureModule = commonlib.gettable("Mod.Seer.Game.Furniture.Module");
    ModuleManager.registerModule("FurnitureModule", FurnitureModule);

    -- guidemission
    NPL.load("(gl)script/Seer/Game/World/GuideMission.lua");
	local GuideMission = commonlib.gettable("Mod.Seer.Game.World.GuideMission");
    ModuleManager.registerModule("GuideMission", GuideMission);

    NPL.load("(gl)script/Seer/Game/Offline/Offline.lua");
	local Offline = commonlib.gettable("Mod.Seer.Game.Offline");
    ModuleManager.registerModule("Offline", Offline);

    NPL.load("(gl)script/Seer/Game/Offline/OfflineMenu.lua");
	local OfflineMenu = commonlib.gettable("Mod.Seer.Game.Offline.OfflineMenu");
    ModuleManager.registerModule("OfflineMenu", OfflineMenu);

    NPL.load("(gl)script/Seer/Game/Entrance/Entrance.lua");
	local Entrance = commonlib.gettable("Mod.Seer.Game.Entrance");
    ModuleManager.registerModule("Entrance", Entrance);
    
  NPL.load("(gl)script/Seer/Game/Asset/AssetModule.lua");
  local AssetModule = commonlib.gettable("Mod.Seer.Game.Asset.Module");
  ModuleManager.registerModule("AssetModule", AssetModule);

    NPL.load("(gl)script/Seer/Game/GameCommon.lua");
    local GameCommon = commonlib.gettable("Mod.Seer.Game.GameCommon");
    ModuleManager.registerModule("GameCommon", GameCommon);

	ModuleManager.addModuleSet("GuideWorldPlay", {"GameWorld","GuideWorld", "Input"})


	ModuleManager.addModuleSet("StandAloneEdit", {"GameWorld", "Input", "EditMode", "Saver", "StandAlone","FurnitureModule","GameCommon"})
	ModuleManager.addModuleSet("StandAlonePlay", {"GameWorld", "PlayInput", "PlayMode", "StandAlone","FurnitureModule"})
	ModuleManager.addModuleSet("MultiPlayerServerGame", {"MultiPlayerServer", "Input", "Saver", "MultiPlayerEdit","FurnitureModule","GameCommon"})
	ModuleManager.addModuleSet("MultiPlayerClientGame", {"MultiPlayerClient", "Input","MultiPlayerEdit","FurnitureModule","GameCommon"})

    ModuleManager.addModuleSet("MultiPlayerServerMiniGame", {"MultiPlayerServer", "Input", "MultiPlayerMiniGame","FurnitureModule","GameCommon"})
    ModuleManager.addModuleSet("MultiPlayerClientMiniGame", {"MultiPlayerClient", "Input","MultiPlayerMiniGame","FurnitureModule","GameCommon"})

    ModuleManager.addModuleSet("BigWorldPlay", {"GameWorld", "Input", "BigWorld","FurnitureModule","AssetModule"}, {path = Settings.seer_ship_path, input="Bigworld", scriptEntry="TS/bigworld/main.lua"})
    ModuleManager.addModuleSet("VisitWorldPlay", {"GameWorld", "VisitWorld", "Input","FurnitureModule"})
    ModuleManager.addModuleSet("VisitMoviePlay", {"GameWorld", "Movie","FurnitureModule"})

    ModuleManager.addModuleSet("OfflinePlay", {"GameWorld","Offline", "Input","GameCommon"});
end

function Seer:RegisterWorldGenerator()
	local fileMaxnum = 100;
	--load sources
	local source_path = "script/Seer/Game/World/Generators/";
	local source_files = commonlib.Files.Find(nil,ParaIO.GetCurDirectory(0)..source_path,0,fileMaxnum,"*.lua");
	for k,v in pairs(source_files) do
		NPL.load("(gl)" .. source_path .. v.filename);
	end
	--load compiled binaries
	local bin_path = "bin/script/Seer/Game/World/Generators/";
	local bin_files = commonlib.Files.Find(nil,bin_path,0,fileMaxnum,"*.o","*.zip");
	for k,v in pairs(bin_files) do
		--cellfy: *.o can be directly loaded like this: "bin/script/Seer/Game/World/Generators/xxx.o" (notice: without "(gl)")
		--but this is quite dependency, restore it to its source version would be a better approach
		local source_filename = string.gsub(v.filename, "%.o$", ".lua");
		NPL.load("(gl)" .. source_path .. source_filename);
	end
end


function Seer:OnLogin()
end

function Seer:OnLeaveWorld()


end

function Seer:OnDestroy()
end

function Seer:handleKeyEvent(event)
    --LOG.std(nil, "debug", "cellfy", "Seer:handleKeyEvent with event: %s, and mode: %s", event.keyname, GameMode:GetMode());
    
    UIManager.handleKeyEvent(event)
	if (event.accepted) then
		echo("catch by ui")
		return
	end
    ModuleManager.handleKeyEvent(event);
end

function Seer:handleMouseEvent(event)
    
    --local self = Seer;
    --local curItem = GameLogic.GetPlayerController():GetItemInRightHand();
    --local event_type = event:GetType();

	UIManager.handleMouseEvent(event)
	if (event.accepted) then
		echo("catch by ui")
		return
	end

    if (ModuleManager.handleMouseEvent(event)) then
        return;
    end
end

function Seer:getInputListener()
    return inputlistener;
end

function Seer:OnInitDesktop()
    local FullScreenMask = self.FullScreenMask or Map3DSystem.mcml.PageCtrl:new({url = "script/Seer/FullScreenMask.html", click_through = true,});
    FullScreenMask = FullScreenMask:Create("FullScreenMask", nil, "_fi", 0, 0, 0, 0);
    FullScreenMask.zorder = -255;
end

function Seer:InitContexts()



    NPL.load("(gl)script/Seer/Game/Input/InputListener.lua");
    local InputListener = commonlib.gettable("Mod.Seer.Game.Input.InputListener");
    inputlistener = InputListener:new():Register("InputListener");
    inputlistener:activate()
end

function Seer:OnActivateDesktop(mode)
    LOG.std(nil, "debug", "cellfy", "Seer:OnActivateDesktop with mode: %s", mode);

    --Cellfy: temporarily put changing skin code here, it should be put after where a new player (with a proper player name and profile) entered the game world
    local myAssetID = Mod.Seer.Network.YcProfile.GetMyCharacterAssetID();
    if myAssetID then
        GameLogic.ChangeCharacterAsset(nil, myAssetID);
    end
    
    ModuleManager.handleEvent("EventActivateMode", mode);
    
    --cellfy: Init Seer contexts, not sure whether it should be here or inside Seer:Init, but AllContexts are inited just before this
    Seer:OnInitMode(mode)

    --cellfy: seems useless?
    GameMode:SetViewMode(false);



    return true
end

function Seer:OnClickExitApp(bForceExit, bRestart)
	local result = {}
	ModuleManager.handleEvent("EventClickClose", result)
    if (result.accepted) then
        return true;
    end

    local Desktop = commonlib.gettable("MyCompany.Aries.Creator.Game.Desktop");
    Desktop.ForceExit();
    return true;
end

function Seer:OnWorldLoad()
    commandManager:RunCommand("/clicktocontinue off");
    commandManager:RunCommand("/property set -camera IgnoreEyeBlockCollisionInSunlight false");

    local Config = commonlib.gettable("Mod.Seer.Config");
    local envconfig = Config.PlanetEnvironment;
    for i=1,envconfig.skybox:size() do
      local skybox = envconfig.skybox:get(i);
      if skybox.fog_colour and skybox.path==GameLogic.GetSkyEntity().filename then
        commandManager:RunCommand("/fog -color "..skybox.fog_colour);
        break;
      end
    end

    ModuleManager.handleEvent("EventEnterWorld");
end

function Seer:OnWorldSave()

end

function Seer:GetSaveFileName()
    local cur_dir = ParaWorld.GetWorldDirectory();
    local worldname = worldCommon.GetWorldTag("name");
    local filepath = cur_dir:gsub("[^/\\]+[/\\]$", worldname.."/");
    local filename = filepath.."/mod.xml";

    return filename;
end

function Seer:OnInitMode(mode)
    LOG.std(nil, "debug", "cellfy", "Seer:OnInitMode with mode: %s", mode);

end

function Seer:OnChangeMode(mode)
    if(mode == "game" or mode== "adventure") then
        GameLogic.EnterGameMode();
    elseif(mode == "editor" or mode=="creative") then
        GameLogic.EnterEditorMode();
    elseif(mode == "survival") then
        GameLogic.EnterGameMode(true);
    elseif(mode == "movie") then
        GameLogic.EnterMovieMode();
    elseif(mode == "community") then
        Seer:EnterCommunityMode();
    end

    Seer:OnInitMode();
end

function Seer:EnterCommunityMode()
    LOG.std(nil, "debug", "cellfy", "Seer:EnterCommunityMode");

    GameLogic.EnterCommunityMode();
    
    local context = SceneContextManager:GetContext("community");
    echo(type(context));
    if context then
        context:activate();
    end
end

function Seer:loadSystemSetting()
  NPL.load("(gl)script/Seer/SystemSettingsPage.lua");
  local SystemSettingsPage = commonlib.gettable("Mod.Seer.UI.SystemSettingsPage");
  SystemSettingsPage.setting_ds=SystemSettingsPage.setting_ds or {};
	SystemSettingsPage.checkBoxEnableTeamInvite(MyCompany.Aries.Player.LoadLocalData("SystemSettingsPage.checkBoxEnableTeamInvite", false));
	SystemSettingsPage.checkBoxAutoHPPotion(MyCompany.Aries.Player.LoadLocalData("SystemSettingsPage.checkBoxAutoHPPotion", false));
	SystemSettingsPage.checkBoxEnableHeadonTextScaling(MyCompany.Aries.Player.LoadLocalData("SystemSettingsPage.checkBoxEnableHeadonTextScaling", false));
	SystemSettingsPage.checkBoxAllowAddFriend(MyCompany.Aries.Player.LoadLocalData("SystemSettingsPage.checkBoxAllowAddFriend", false));
	SystemSettingsPage.checkBoxEnableFriendTeleport(MyCompany.Aries.Player.LoadLocalData("SystemSettingsPage.EnableFriendTeleport", false));
	SystemSettingsPage.checkBoxEnableAutoPickSingleTarget(MyCompany.Aries.Player.LoadLocalData("SystemSettingsPage.EnableAutoPickSingleTarget", false));
	SystemSettingsPage.checkBoxEnableForceHideHead(MyCompany.Aries.Player.LoadLocalData("SystemSettingsPage.EnableForceHideHead", false));
	SystemSettingsPage.checkBoxEnableForceHideBack(MyCompany.Aries.Player.LoadLocalData("SystemSettingsPage.EnableForceHideBack", false));
  local enable_sound=MyCompany.Aries.Player.LoadLocalData("Paracraft_System_Sound_State", true,true);
  local sound_volume=MyCompany.Aries.Player.LoadLocalData("Paracraft_System_Sound_Volume", 2.5,true);
  if enable_sound then
    ParaAudio.SetVolume(sound_volume);
  else
    ParaAudio.SetVolume(0);
  end
	local MapArea = commonlib.gettable("MyCompany.Aries.Desktop.MapArea");
	if(MapArea.EnableMusic) then
		MapArea.EnableMusic(enable_sound);
	end
  
	ParaEngine.GetAttributeObject():SetField("IsMouseInverse", MyCompany.Aries.Player.LoadLocalData("Paracraft_System_Mouse_Inverse", false,true));
  
  SystemSettingsPage.setting_ds["render_dist"]=MyCompany.Aries.Player.LoadLocalData("Paracraft_System_Render_Distance",150,true);
  
  SystemSettingsPage.newMemLimit=MyCompany.Aries.Player.LoadLocalData("Paracraft_System_Memory_Limit",258,true);
  local attr = ParaTerrain.GetBlockAttributeObject();
  local max_mem_bytes = SystemSettingsPage.newMemLimit * 1024 * 1024;
  attr:SetField("VertexBufferSizeLimit", max_mem_bytes);
  attr:SetField("MaxVisibleVertexBufferBytes", max_mem_bytes/4);
  
  local super_render_dist=MyCompany.Aries.Player.LoadLocalData("Paracraft_System_Super_Render_Distance",0,true);
  GameLogic.options:SetSuperRenderDist(super_render_dist);
  
  SystemSettingsPage.setting_ds["water_reflection"]=MyCompany.Aries.Player.LoadLocalData("Paracraft_System_Water_Reflection",true,true);
  ParaTerrain.GetBlockAttributeObject():SetField("UseWaterReflection",SystemSettingsPage.setting_ds["water_reflection"]);
  
  SystemSettingsPage.setting_ds["sunlight_shadow"]=MyCompany.Aries.Player.LoadLocalData("Paracraft_System_Shadow",true,true);

  SystemSettingsPage.setting_ds["emulational_lighting_value"]=MyCompany.Aries.Player.LoadLocalData("Paracraft_System_Shader",1,true);
  GameLogic.GetShaderManager():GetFancyShader():SetEnabled(if_else(SystemSettingsPage.setting_ds["emulational_lighting_value"]>=2,true,false));
  GameLogic.GetShaderManager():GetFancyShader():EnableBloomEffect(if_else(SystemSettingsPage.setting_ds["emulational_lighting_value"]>=3,true,false));
  
  ParaEngine.GetAttributeObject():SetField("ScreenResolution",MyCompany.Aries.Player.LoadLocalData("Paracraft_System_Screen_Resolution",{1280,720},true));
  ParaEngine.GetAttributeObject():CallField("UpdateScreenMode");
end
