--[[
	NPL.load("(gl)script/Seer/Utility/qiniuHash.lua");
	local QiniuHash = commonlib.gettable("Mod.Seer.Utility.QiniuHash");
]]


NPL.load("(gl)script/ide/System/Encoding/sha1.lua");
local Encoding = commonlib.gettable("System.Encoding");
local sha1 = Encoding.sha1

local ZZBase64 = commonlib.gettable("ZZBase64");
local QiniuHash = commonlib.gettable("Mod.Seer.Utility.QiniuHash");

function QiniuHash.hash(filestream)
	local fileSize = filestream:GetFileSize();

	local maxSize = 4 * 1024 * 1024;
	local readSize = 0;
	local hash = "";
	if (fileSize == 0) then
		hash = sha1("");
	else
		while (readSize < fileSize) do
			local chunkEnd = math.min(readSize + maxSize, fileSize);
			local data = filestream:GetText(readSize, chunkEnd-readSize);
			hash = hash .. sha1(data)
			readSize = readSize + maxSize;
		end
	end

	local result;
	if (hash:len() == 20) then
		result = ZZBase64.encode(string.char(22)..hash);
	else
		result = ZZBase64.encode(string.char(150)..sha1(hash));
	end

	result = string.gsub(result,"+","-")
	result = string.gsub(result,"/","_")
	return result;
end

function QiniuHash.hashFile(path)
	local file = ParaIO.open(path,"r");
	if file and file:IsValid() then
		local hash = QiniuHash.hash(file);
		file:close()
		return hash;
	end
end