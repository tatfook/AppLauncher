--[[
Title: Guide Picture
Author(s): Devil
Date: 2015/7/23
Desc: 
Use Lib:
-------------------------------------------------------
NPL.load("(gl)script/Seer/GuidePicture.lua");
local GuidePicture = commonlib.gettable("Mod.Seer.UI.GuidePicture");
GuidePicture.ShowPage(true)
-------------------------------------------------------
]]
local lPictures={};
local lPage=nil;
local lCurrentPictureIndex=1;
local lVisible=false;
local lFinishCallback=nil;
local GuidePicture = commonlib.gettable("Mod.Seer.UI.GuidePicture");
function GuidePicture.OnInit()
	lPage = document:GetPageCtrl();
end
function GuidePicture.setPictures(pictures)
	lPictures=pictures;
	lCurrentPictureIndex=1;
end
function GuidePicture.showPage()
	local params = {
			url = "script/Seer/GuidePicture.html", 
			name = "GuideBox.showPage", 
			isShowTitleBar = false,
			DestroyOnClose = true,
			bToggleShowHide=true, 
			style = CommonCtrl.WindowFrame.ContainerStyle,
			allowDrag = false,
			--bShow = bShow,
			click_through = false, 
			zorder = 2,
			directPosition = true,
      enable_esc_key = true,
				align = "_fi",
				x = 0,
				y = 0,
				width = 0,
				height = 0,
		};
	System.App.Commands.Call("File.MCMLWindowFrame", params);
	GuidePicture.refresh();
	ParaCamera.GetAttributeObject():SetField("BlockInput", true);
  lVisible=true;
end
function GuidePicture.clickClose()
  lPage:CloseWindow();
	ParaCamera.GetAttributeObject():SetField("BlockInput", false);
  lVisible=false;
  if lFinishCallback then
    lFinishCallback();
  end
end
function GuidePicture.clickPreview()
	lCurrentPictureIndex=lCurrentPictureIndex-1;
	GuidePicture.refresh();
end
function GuidePicture.clickNext()
	lCurrentPictureIndex=lCurrentPictureIndex+1;
	GuidePicture.refresh();
end
function GuidePicture.hasNext()
	return lCurrentPictureIndex<#lPictures;
end
function GuidePicture.hasPreview()
	-- local truth = (lCurrentPictureIndex>1 )and (lCurrentPictureIndex~= #lPictures)
	return lCurrentPictureIndex>1
end

function GuidePicture.isLastPage()
	return lCurrentPictureIndex==#lPictures;
end

function GuidePicture.isGuideFinish()
	return string.sub(tostring(lPictures[1]),-10,-5) == "finish"
end

function GuidePicture.leaveGuide()
	-- close Page
	lPage:CloseWindow();
	ParaCamera.GetAttributeObject():SetField("BlockInput", false);
  	lVisible=false;
  	if lFinishCallback then
    	lFinishCallback();
  	end
	-- finish Guide
	-- NPL.load("(gl)script/Seer/Game/ModuleManager.lua");
	-- local ModuleManager = commonlib.gettable("Mod.Seer.Game.ModuleManager");
	-- ModuleManager.handleEvent("EventClickClose", {})

	NPL.load("(gl)script/Seer/Game/UI/TextBookPage.lua");
	local TextBookPage= commonlib.gettable("Mod.Seer.Game.UI.TextBookPage");

	TextBookPage.OnComplate()
	_guihelper.MessageBox("恭喜你已经通关，是否进入下一关？", function(res)
		if(res and res == _guihelper.DialogResult.Yes) then
			-- pressed YES
			_guihelper.CloseMessageBox(true); -- fast close without animation
			TextBookPage.OnNextLevel()
		else
			TextBookPage.OnExitLevel()
		end
	end, _guihelper.MessageBoxButtons.YesNo);
end

function GuidePicture.refresh()
	lPage:Refresh(0);
	local ctl = lPage:FindControl("picture");
	ctl.background=lPictures[lCurrentPictureIndex];
end

function GuidePicture.isVisible()
  return lVisible;
end

function GuidePicture.setFinishCallback(callback)
  lFinishCallback=callback;
end