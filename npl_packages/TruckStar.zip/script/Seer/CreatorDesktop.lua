--[[
Title: creator desktop
Author(s): WangXiXi
Date: 2015/6/24
Desc: the creator desktop
Use Lib:
-------------------------------------------------------
NPL.load("(gl)script/Seer/CreatorDesktop.lua");
local CreatorDesktop = commonlib.gettable("Mod.Seer.UI.CreatorDesktop");
CreatorDesktop.ShowPage(true)
-------------------------------------------------------
]]
NPL.load("(gl)script/apps/Aries/Creator/Game/Items/ItemClient.lua");
local ItemClient = commonlib.gettable("MyCompany.Aries.Game.Items.ItemClient");
local Desktop = commonlib.gettable("MyCompany.Aries.Creator.Game.Desktop");
local GameLogic = commonlib.gettable("MyCompany.Aries.Game.GameLogic")

local CreatorDesktop = commonlib.gettable("Mod.Seer.UI.CreatorDesktop");

local page;

function CreatorDesktop.OnInit()
	page = document:GetPageCtrl();
	GameLogic.events:AddEventListener("game_mode_change", CreatorDesktop.OnGameModeChanged, CreatorDesktop, "CreatorDesktop");
end


CreatorDesktop.tabview_index = 1;
--CreatorDesktop.tabview_Item_DS = {};

CreatorDesktop.tabview_ds = {
    {text="建造", name="NewBuilding", url="script/Seer/BuilderFramePage.html?version=1", enabled=true},
}

CreatorDesktop.new_page = nil;
CreatorDesktop.IsExpanded = false;

function CreatorDesktop.GetTab()
	return CreatorDesktop.tabview_ds[CreatorDesktop.tabview_index];
end

-- @param IsExpanded: nil to toggle. true or false to show expanded or not. false by default. 
function CreatorDesktop.ShowPage(IsExpanded)

	if(IsExpanded == nil) then
		if(CreatorDesktop.new_page and CreatorDesktop.new_page:IsVisible()) then
			IsExpanded = not CreatorDesktop.IsExpanded;
			if(IsExpanded) then
				-- do a full collection here
				collectgarbage("collect");
			end
		else
			IsExpanded = true;
		end
	end
	if(IsExpanded) then
		GameLogic.events:AddEventListener("game_mode_change", CreatorDesktop.OnGameModeChangedNew, CreatorDesktop, "CreatorDesktop");
	end

	if(CreatorDesktop.new_page and CreatorDesktop.IsExpanded) then
		NPL.load("(gl)script/apps/Aries/Creator/Game/Areas/BuilderFramePage.lua");
		local BuilderFramePage = commonlib.gettable("MyCompany.Aries.Creator.Game.Desktop.BuilderFramePage");
		BuilderFramePage.isSearching = false;
		local search_text_obj = ParaUI.GetUIObject("block_search_text_obj");
		if(search_text_obj:IsValid())then
			search_text_obj:LostFocus();
		end	
	end
	CreatorDesktop.IsExpanded = IsExpanded;

	CreatorDesktop.new_page_params = CreatorDesktop.new_page_params  or {
			url = "script/Seer/CreatorDesktop.html", 
			--url = url,
			name = "CreatorDesktop.ShowPage", 
			isShowTitleBar = false,
			DestroyOnClose = false,
			bToggleShowHide=true, 
			style = CommonCtrl.WindowFrame.ContainerStyle,
			allowDrag = false,
			-- enable_esc_key = true,
			click_through = true, 
			zorder = -1,
			refresh = true,
			app_key = MyCompany.Aries.Creator.Game.Desktop.App.app_key, 
			directPosition = true,
				align = "_ctr",
				x = 0,
				y = 0,
				width = 257,
				height = 480,
		};
	CreatorDesktop.new_page_params.bShow = IsExpanded;
	System.App.Commands.Call("File.MCMLWindowFrame", CreatorDesktop.new_page_params);

end