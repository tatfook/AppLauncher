--[[
    Title: CriticalSection
    Author(s): Cellfy
    Date Created: Jul 26, 2016
    Date Updated: Jul 26, 2016
    Desc: Locks and mutex for critical section
        2 ways to use the lock, check these examples (search "CriticalSection" in them):
            example 1: script/Seer/Game/Login/LoginPage.lua
            example 2: script/Seer/ServerHallPage.lua
    Usage:
    ------------------------------------------------------------
    NPL.load("(gl)script/Seer/Framework/CriticalSection.lua");
    local CriticalSection = commonlib.gettable("Mod.Seer.Framework.CriticalSection");
    ------------------------------------------------------------
]]

local CriticalSection = commonlib.gettable("Mod.Seer.Framework.CriticalSection");
local Lock = commonlib.inherit(nil, commonlib.gettable("Mod.Seer.Framework.Lock"));

local LockPool = {};

--cellfy: can't imagine a scenario this function is needed, make it local for now
--function CriticalSection.GetLock(id)
local function GetLock(id)
    local lock = LockPool[id];
    return lock;
end

-- @param id: uid of the new lock, could be type, but string is recommended for debug convenience
-- @return : the lock object (ok to lock) of nil (already locked by others)
function CriticalSection.NewLock(id)
    local lock = GetLock(id);
    if lock then
        LOG.std(nil, "debug", "lock", "trying to create an existing lock");
        return nil;
    else
        lock = Lock:new():Init(id);
        LockPool[id] = lock;
        LOG.std(nil, "debug", "lock", "new lock created");
        return lock;
    end    
end

function CriticalSection.ReleaseLock(lock)
    local lockID = nil;
    if type(lock)=="table" then
        lockID = lock:GetID();
    elseif type(lock)=="string" and string.len(lock)>0 then
        lockID = lock
    end
    if lockID then
        local lockToBeReleased = LockPool[lockID];
        if lockToBeReleased then
            local tmp_lock = LockPool[lockID];
            tmp_lock:Release();
            LockPool[lockID] = nil;
            LOG.std(nil, "debug", "lock", "lock released");
        else
            LOG.std(nil, "error", "lock", "user try to release a non-existent lock, id may be incorrect or the lock is already released somewhere else");
        end
    else
        LOG.std(nil, "error", "lock", "illegal lock id detected when trying to release a lock");
    end
end

--------------------------------------------------------------------------------
--  Lock
--------------------------------------------------------------------------------
local LockPrivateData = {};
--local lock_uid = 1;
function Lock:ctor()
    LockPrivateData[self] = {};
    --cellfy: use lock_uid and uncomment codes below for debugging convenience
    -- LockPrivateData[lock_uid] = {};
    -- self.lock_uid = lock_uid;
    -- lock_uid = lock_uid + 1;
end

function Lock:Init(id)
    local privateData = LockPrivateData[self]; --.lock_uid];
    privateData.id = id;
    return self;
end

function Lock:GetID()
    local privateData = LockPrivateData[self]; --.lock_uid];
    if privateData then
        return privateData.id;
    else
        LOG.std(nil, "error", "lock", "lock private data not valid, something is wrong");
    end
end

function Lock:Release()
    LockPrivateData[self] = nil; --.lock_uid] = nil;
end
