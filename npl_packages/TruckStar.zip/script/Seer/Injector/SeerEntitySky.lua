--[[
    Title: SeerEntitySky
    Author(s): Devil
    Date: 2016/05/19
    Desc: EntitySky extension. 
    A Injector class.
    Injection Target: MyCompany.Aries.Game.EntityManager.EntitySky
    use the lib:
    -------------------------------------------------------
    NPL.load("(gl)script/apps/Aries/Creator/Game/Entity/EntitySky.lua");
    NPL.load("(gl)script/Seer/Injector/SeerEntitySky.lua");
    local EntitySky = commonlib.gettable("MyCompany.Aries.Game.EntityManager.EntitySky")
    local SeerEntitySky = commonlib.gettable("Mod.Seer.Injector.SeerEntitySky");
    Inject(SeerEntitySky, EntitySky);
    -------------------------------------------------------
]]
NPL.load("(gl)script/apps/Aries/Creator/Game/Entity/EntitySky.lua");
NPL.load("(gl)script/Seer/Game/UI/UIManager.lua");
local UIManager = commonlib.gettable("Mod.Seer.Game.UI.UIManager");
local WeatherEffect = commonlib.gettable("MyCompany.Aries.Game.Effects.WeatherEffect");
local InventoryBase = commonlib.gettable("MyCompany.Aries.Game.Items.InventoryBase");
local ItemClient = commonlib.gettable("MyCompany.Aries.Game.Items.ItemClient");
local BlockEngine = commonlib.gettable("MyCompany.Aries.Game.BlockEngine")
local TaskManager = commonlib.gettable("MyCompany.Aries.Game.TaskManager")
local block_types = commonlib.gettable("MyCompany.Aries.Game.block_types")
local GameLogic = commonlib.gettable("MyCompany.Aries.Game.GameLogic")
local EntityManager = commonlib.gettable("MyCompany.Aries.Game.EntityManager");
local SeerEntitySky = commonlib.gettable("Mod.Seer.Injector.SeerEntitySky");
function SeerEntitySky:SaveToXMLNode(node)
  local ret=self:Original_SaveToXMLNode(node)
	local attr = ret.attr;
  attr.DayLength=ParaScene.GetAttributeObjectSunLight():GetField("DayLength",attr.DayLength);
  attr.TimeOfDay=ParaScene.GetTimeOfDaySTD();
	return attr;
end

function SeerEntitySky:LoadFromXMLNode(node)
  self:Original_LoadFromXMLNode(node);
	local attr = node.attr;
  local env_frame_page = UIManager.getUI("EnvFramePage");
  if env_frame_page then
    if attr.DayLength and tonumber(attr.DayLength)<999 then
      env_frame_page:SetDayLength(tonumber(attr.DayLength));
      env_frame_page.inf_time_per_day=false;
    else
      env_frame_page.inf_time_per_day=true;
    end
    env_frame_page:SetTime(tonumber(attr.TimeOfDay));
  else
    if attr.DayLength then
      ParaScene.GetAttributeObjectSunLight():SetField("DayLength",tonumber(attr.DayLength));
    end
    if attr.TimeOfDay then
      ParaScene.SetTimeOfDaySTD(tonumber(attr.TimeOfDay));
    end
  end
  NPL.load("(gl)script/apps/Aries/Creator/Game/Shaders/FancyPostProcessing.lua");
  local FancyV1 = GameLogic.GetShaderManager():GetFancyShader();
  FancyV1:setTimeParametersFile(GameLogic.world:GetWorldPath().."Fancy.xml");
end