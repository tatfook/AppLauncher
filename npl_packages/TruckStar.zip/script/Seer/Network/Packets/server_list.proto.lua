NPL.load("(gl)script/Seer/pb/server_list_pb.lua");
NPL.load("(gl)script/Seer/Network/Packets/PacketPbHelper.lua");
local PacketPbHelper = commonlib.gettable("Mod.Seer.Network.Packets.PacketPbHelper");

function PacketPbHelper.sendCSGetAllServerListReq(connid, callback)
	PacketPbHelper.sendTo({nid=connid},{"CSGetAllServerListReq"},callback);
end

function PacketPbHelper.sendCSGetUserServerListReq(connid,id, callback)
	PacketPbHelper.sendTo({nid=connid},{"CSGetUserServerListReq", {uid=id}},callback);
end