--[[
    Title: UITextureListReader
    Author(s): Cellfy
    Date Created: 1 Nov 2016
    Date Updated: 1 Nov 2016
    Desc: Reader interface for UITextureList.xml
    Usage:
    ------------------------------------------------------------
    NPL.load("(gl)script/Seer/Config/UITextureListReader.lua");
    local UITextureListReader = commonlib.gettable("Mod.Seer.Config.UITextureListReader");
    ------------------------------------------------------------
]]
local UITextureListReader = commonlib.gettable("Mod.Seer.Config.UITextureListReader");

local TextureList2D = {};
local TextureList3D = {};
local TextureListCube = {};

function UITextureListReader.Load()
    local Config = commonlib.gettable("Mod.Seer.Config");

    Mod.Seer.Config.loadConfig("script/Seer/Config/UITextureList.xml");

    TextureList2D = Config.UITextureList.Texture2D;
end

function UITextureListReader.GetTexture2DFile(tex_name)
    local filename = nil;
    local tex_info = TextureList2D:find(tex_name);
    if tex_info then
        filename = tex_info.file;
    else
        LOG.std(nil, "error", "truckstar", "invalid texture name: %s", tex_name);
    end
    return filename;
end
