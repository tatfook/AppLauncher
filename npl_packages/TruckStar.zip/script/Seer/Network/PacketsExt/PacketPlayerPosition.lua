--[[
    Title: PacketPlayerPosition
    Author(s): Cellfy
    Date Created: Jul 9, 2016
    Date Updated: Jul 9, 2016
    Desc: send a player's position to a client player, could be used as either a response to PacketPlayerPositionReq, or a standalone notification
    Usage:
    ------------------------------------------------------------
    NPL.load("(gl)script/Seer/Network/PacketsExt/PacketPlayerPosition.lua");
    local PacketPlayerPosition = commonlib.gettable("Mod.Seer.Network.PacketsExt.PacketPlayerPosition");
    ------------------------------------------------------------
]]

NPL.load("(gl)script/Seer/Network/PacketsExt/SeerPacketBase.lua");
local PacketPlayerPosition = commonlib.inherit(commonlib.gettable("Mod.Seer.Network.PacketsExt.SeerPacketBase"), commonlib.gettable("Mod.Seer.Network.PacketsExt.PacketPlayerPosition"));

function PacketPlayerPosition:ctor()
end

--init as a response for PacketPlayerPositionReq
function PacketPlayerPosition:InitAsRsp(req_packet, pos_x, pos_y, pos_z)
    PacketPlayerPosition._super.InitAsRsp(self, req_packet);
    self.user_id = req_packet.user_id;
    self.posX = pos_x;
    self.posY = pos_y;
    self.posZ = pos_z;
    return self;
end

--init as a standalone packet (such as notification)
function PacketPlayerPosition:Init(user_id, pos_x, pos_y, pos_z)
    PacketPlayerPosition._super.Init(self);
    self.user_id = user_id;
    self.posX = pos_x;
    self.posY = pos_y;
    self.posZ = pos_z;
    return self;
end

-- Passes this Packet on to the NetHandler for processing.
-- Cellfy: no need to write this function if nothing else need to be done besides of user callback
function PacketPlayerPosition:ProcessPacket(net_handler)
    PacketPlayerPosition._super.ProcessPacket(self, net_handler);
    if(net_handler.handlePlayerPosition) then
        net_handler:handlePlayerPosition(self);
    end
end
