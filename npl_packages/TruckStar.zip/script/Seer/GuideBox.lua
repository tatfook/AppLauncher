﻿--[[
Title: Guide Box
Author(s): Ted
Date: 2015/7/23
Desc: 
Use Lib:
-------------------------------------------------------
NPL.load("(gl)script/Seer/GuideBox.lua");
local GuideBox = commonlib.gettable("Mod.Seer.UI.GuideBox");
GuideBox.ShowPage(true)
-------------------------------------------------------
]]

NPL.load("(gl)script/apps/Aries/Creator/Game/Login/MainLogin.lua");

local AudioEngine = commonlib.gettable("AudioEngine");
local Game = commonlib.gettable("MyCompany.Aries.Game");
local GameLogic = commonlib.gettable("MyCompany.Aries.Game.GameLogic");
local MainLogin = commonlib.gettable("MyCompany.Aries.Game.MainLogin");

NPL.load("(gl)script/apps/Aries/Creator/Game/GameDesktop.lua");
local Desktop = commonlib.gettable("MyCompany.Aries.Creator.Game.Desktop");

NPL.load("(gl)script/Seer/Game/ModuleManager.lua");
local ModuleManager = commonlib.gettable("Mod.Seer.Game.ModuleManager");

NPL.load("(gl)script/ide/timer.lua");

NPL.load("(gl)script/Seer/Settings.lua");
local Settings = commonlib.gettable("Mod.Seer.Settings");

local GuideBox = commonlib.gettable("Mod.Seer.UI.GuideBox");

local UserDatabase = commonlib.gettable("Mod.Seer.Utility.UserDatabase");


local page;

function GuideBox.OnInit()
	page = document:GetPageCtrl();
end

function GuideBox.ShowPage()
	local params = {
			url = "script/Seer/GuideBox.html", 
			name = "GuideBox.ShowPage", 
			isShowTitleBar = false,
			DestroyOnClose = true,
			bToggleShowHide=true, 
			style = CommonCtrl.WindowFrame.ContainerStyle,
			allowDrag = false,
			--bShow = bShow,
			click_through = false, 
			zorder = 2,
			directPosition = true,
				align = "_fi",
				x = 0,
				y = 0,
				width = 0,
				height = 0,
		};
		
	System.App.Commands.Call("File.MCMLWindowFrame", params);
end

function GuideBox.ClosePage()
    page:CloseWindow();
   --MainLogin:next_step({IsLoginModeSelected = true});
end

function GuideBox.CompleteGuide()
	UserDatabase.setAttribute("Guide.newplayer", false);

end

function GuideBox.OnEnterGuide()
	AudioEngine.PlayUISound("btn_confirm");
	GuideBox.CompleteGuide();
	GuideBox.ClosePage();


	local Settings = commonlib.gettable("Mod.Seer.Settings");
	local WorldCommon = commonlib.gettable("MyCompany.Aries.Creator.WorldCommon");
	WorldCommon.OpenWorld(Settings.guide_path, true);

end

function GuideBox.OnSelectWorld()
	AudioEngine.PlayUISound("btn_confirm");
	GuideBox.CompleteGuide();
	GuideBox.ClosePage();

	System.App.Commands.Call("File.MCMLWindowFrame", {
		url = "script/apps/Aries/Creator/Game/Login/InternetLoadWorld_yoocraft.html", 
		name = "LoadMainWorld", 
		isShowTitleBar = false,
		DestroyOnClose = true, -- prevent many ViewProfile pages staying in memory
		style = CommonCtrl.WindowFrame.ContainerStyle,
		zorder = 0,
		allowDrag = false,
		bShow = bShow,
		directPosition = true,
		align = "_fi",
		x = 0,
		y = 0,
		width = 0,
		height = 0,
		cancelShowAnimation = true,
	});
end

function GuideBox.GetGuideEnterMode()
	local newplayer = UserDatabase.getAttribute("Guide.newplayer", true);
	return false
end

function GuideBox.ExitGuide()
	AudioEngine.PlayUISound("btn_confirm");
    GuideBox.page:CloseWindow();
	
	-- NPL.load("(gl)script/Seer/Game/ModuleManager.lua");
	-- local ModuleManager = commonlib.gettable("Mod.Seer.Game.ModuleManager");

	ModuleManager.startModule("BigWorldPlay");
	-- ModuleManager.startModule("MainMenu")
end