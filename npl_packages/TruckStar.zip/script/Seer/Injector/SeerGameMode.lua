--[[
    Title: SeerGameMode
    Author(s): Cellfy
    Date: 2016/01/15
    Desc: GameMode extension. 
    A Injector class.
    Injection Target: MyCompany.Aries.Game.GameLogic.GameMode
    use the lib:
    -------------------------------------------------------
    NPL.load("(gl)script/apps/Aries/Creator/Game/GameRules/GameMode.lua");
    NPL.load("(gl)script/Seer/Injector/SeerGameMode.lua");
    local GameMode = commonlib.gettable("MyCompany.Aries.Game.GameLogic.GameMode");
    local SeerGameMode = commonlib.gettable("Mod.Seer.Injector.SeerGameMode");
    Inject(SeerGameMode, GameMode);
    -------------------------------------------------------
]]

--Cellfy:
--Use this as an injection example.

local SeerGameMode = commonlib.gettable("Mod.Seer.Injector.SeerGameMode");

function SeerGameMode:IsEditor()
    --LOG.std(nil, "debug", "cellfy", "SeerGameMode.IsEditor called");
    --print(GameMode);
    --print(self);
    --print(SeerGameMode);
    
    return self:Original_IsEditor();
end

SeerGameMode.SubModes = {
};

function SeerGameMode:MarkSubMode(sub_mode, is_on)
    if is_on==true then
        LOG.std(nil, "debug", "cellfy", "try marking sub_mode %s on", sub_mode);
    else
        LOG.std(nil, "debug", "cellfy", "try marking sub_mode %s off", sub_mode);
    end
    
    if self.SubModes[sub_mode] ~= nil then
        self.SubModes[sub_mode] = (is_on == true);
    else
        LOG.std(nil, "debug", "cellfy", "SubMode \"%s\" is not valid", sub_mode);
    end
end

function SeerGameMode:IsSubModeOn(sub_mode)
    return (self.SubModes[sub_mode]==true);
end

--only sub modes listed here are valid modes
--Visitor, open a world created by others as a visitor
function SeerGameMode:InitSubModes()
    self.SubModes["Visitor"] = false;
end
