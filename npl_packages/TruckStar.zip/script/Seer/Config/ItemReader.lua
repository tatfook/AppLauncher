--[[
    Title: ItemReader
    Author(s): sunwei
    Date: Oct 18, 2016
    Desc: Interface to visit Item.xml
    Usage:
    ------------------------------------------------------------
    NPL.load("(gl)script/Seer/Config/ItemReader.lua");
    local ItemReader = commonlib.gettable("Mod.Seer.Config.ItemReader");
    ------------------------------------------------------------
]]
local CharacterAssetsReader = commonlib.gettable("Mod.Seer.Config.CharacterAssetsReader");

local ItemReader = commonlib.gettable("Mod.Seer.Config.ItemReader");

local AllItems = {}
local ItemConfigList = {}

function ItemReader.Load()
    Mod.Seer.Config.loadConfig("script/Seer/Config/Item.xml");
    Mod.Seer.Config.loadConfig("script/Seer/Config/ItemType.xml");

    local Config = commonlib.gettable("Mod.Seer.Config");
    local items = Config.Items.Item
    local items_size = items:size()
    ItemConfigList = items
end

function ItemReader.GetAssetInfoByID(id)
	local skinInfo = ItemConfigList:find(id)
	if skinInfo and skinInfo.Type == "1" then
		skinInfo = CharacterAssetsReader.GetAssetInfoByID(skinInfo.TypeItemIDInClient)
	else
		skinInfo = CharacterAssetsReader.GetAssetInfoByID(id)
	end
	return skinInfo
end