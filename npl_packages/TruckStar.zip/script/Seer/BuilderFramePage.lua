--[[
Title: Builder Frame Page
Author(s): WangXiXi
Date: 2015/6/12
Desc: 
Use Lib:
-------------------------------------------------------
NPL.load("(gl)script/Seer/BuilderFramePage.lua");
local BuilderFramePage = commonlib.gettable("Mod.Seer.UI.BuilderFramePage");
BuilderFramePage.ShowPage(true)
-------------------------------------------------------
]]
NPL.load("(gl)script/apps/Aries/Creator/Game/Areas/BlockTemplatePage.lua");
NPL.load("(gl)script/apps/Aries/Creator/Game/Items/ItemClient.lua");
NPL.load("(gl)script/Seer/Config/Config.lua");
NPL.load("(gl)script/Seer/Utility/UserDatabase.lua");
local UserDatabase = commonlib.gettable("Mod.Seer.Utility.UserDatabase");
local Config = commonlib.gettable("Mod.Seer.Config");
local ItemClient = commonlib.gettable("MyCompany.Aries.Game.Items.ItemClient");
local BlockTemplatePage = commonlib.gettable("MyCompany.Aries.Creator.Game.Desktop.BlockTemplatePage");
local Desktop = commonlib.gettable("MyCompany.Aries.Creator.Game.Desktop");
local block_types = commonlib.gettable("MyCompany.Aries.Game.block_types")
local GameLogic = commonlib.gettable("MyCompany.Aries.Game.GameLogic")
local BlockEngine = commonlib.gettable("MyCompany.Aries.Game.BlockEngine")
local ItemClient = commonlib.gettable("MyCompany.Aries.Game.Items.ItemClient");
local pe_gridview = commonlib.gettable("Map3DSystem.mcml_controls.pe_gridview");

NPL.load("(gl)script/Seer/Game/UI/UIManager.lua");
local UIManager= commonlib.gettable("Mod.Seer.Game.UI.UIManager");
local BuilderFramePage = commonlib.inherit(commonlib.gettable("Mod.Seer.Game.UI.UIBase"),commonlib.gettable("Mod.Seer.UI.BuilderFramePage"));

NPL.load("(gl)script/seer/Utility/CommonUtility.lua");
local CommonUtility = commonlib.gettable("Mod.Seer.Utility.CommonUtility");
if CommonUtility:IsMobilePlatform() then

UIManager.registerUI("BuilderFramePage",BuilderFramePage,"script/Seer/BuilderFramePage.html",
{
	isShowTitleBar = false,
	DestroyOnClose = false,
	bToggleShowHide=true, 
	style = CommonCtrl.WindowFrame.ContainerStyle,
	allowDrag = true,
	enable_esc_key = true,
	--bShow = bShow,
	click_through = false, 
	directPosition = true,
		align = "_rt",
		x = -370,
		y = 200,
		width = 486,
		height = 715,
});

else

UIManager.registerUI("BuilderFramePage",BuilderFramePage,"script/Seer/BuilderFramePage.PC.html",
{
	isShowTitleBar = false,
	DestroyOnClose = false,
	bToggleShowHide=true, 
	style = CommonCtrl.WindowFrame.ContainerStyle,
	allowDrag = true,
	enable_esc_key = true,
	--bShow = bShow,
	click_through = false, 
	directPosition = true,
		align = "_rt",
		x = -370,
		y = 200,
		width = 486,
		height = 715,
});

end




local page;



BuilderFramePage.bag_block_show = false;


local category_ds = {
    {text="建造方块",   name="building_blocks",     enabled=true},
    {text="红石机关", name="redstone",     enabled=true},
	{text="自然装饰",   name="deco",     enabled=true},
    {text="其他杂项", name="others",     enabled=true},
}

local block_lable = {
	["Ziran"]={button_pic_on = "texpack:addr_simple_by_id(NewBuilderFrame->14.png)", button_pic_on_off = "texpack:addr_simple_by_id(NewBuilderFrame->13.png)"}
}

function BuilderFramePage:getButtonPic(buttonName, status)
	if status == "on" then
		return block_lable[buttonName].button_pic_on
	else
		return block_lable[buttonName].button_pic_off
	end
end

function BuilderFramePage:ctor()
	self.selectBlockId = 0
	self.category_index = 1;
	self.Current_Item_DS = {};

end

function BuilderFramePage:GetCategoryButtons()
	return category_ds;
end

-- clicked a block
function BuilderFramePage:OnClickBlock(block_id)
	self.selectBlockId = block_id
	local search_text_obj = ParaUI.GetUIObject("block_search_text_obj");
	if(search_text_obj:IsValid())then
		search_text_obj:LostFocus();
	end	
    if(block_id) then
		local item = ItemClient.GetItem(block_id)
		if(item) then
			item:OnClick();
		end

		
		local insert = true

		if next(self.blockHistory) then
			for i=#self.blockHistory, 1,-1 do
				if block_id == tonumber(self.blockHistory[i]) then
					table.remove(self.blockHistory, i)
					break
				end
			end
		end
		table.insert(self.blockHistory, 1, block_id)
		if #self.blockHistory > 28 then
			table.remove(self.blockHistory, #self.blockHistory)
		end
		UserDatabase.setAttribute("BlockHistory", self.blockHistory ,"local")
	end
	
	local gvw_name = "new_builder_gvwItems";
	local node = self:getPage():GetNode(gvw_name);
	pe_gridview.DataBind(node, gvw_name, false);
end

-- @param bRefreshPage: false to stop refreshing the page
function BuilderFramePage:OnChangeCategory(index)
    self.category_index = tonumber(index or self.category_index);
	local category = category_ds[self.category_index];
	if self.category_index ~= 1 then
		self.filter = false
	end
	if self.category_index == 4 then
		self:getAllBlocks()
		self:runFilter()
	else
		self.Current_Item_DS = ItemClient.GetBlockDS(category.name);
	end

	self.category_name = category.name;
	
	self:refresh()
end

function BuilderFramePage:getAllBlocks()
  local search_result1 = ItemClient.GetBlockDS(category_ds[1].name);
  local search_result2 = ItemClient.GetBlockDS(category_ds[2].name);
  local search_result3 = ItemClient.GetBlockDS(category_ds[3].name);
  local search_result4 = ItemClient.GetBlockDS(category_ds[4].name);
  self.Current_Item_DS=search_result1;
  if search_result2 then
    self.Current_Item_DS=self.Current_Item_DS or {};
    for _,value in pairs(search_result2) do
      self.Current_Item_DS[#self.Current_Item_DS+1]=value;
    end
  end
  if search_result3 then
    self.Current_Item_DS=self.Current_Item_DS or {};
    for _,value in pairs(search_result3) do
      self.Current_Item_DS[#self.Current_Item_DS+1]=value;
    end
  end
  if search_result4 then
    self.Current_Item_DS=self.Current_Item_DS or {};
    for _,value in pairs(search_result4) do
      self.Current_Item_DS[#self.Current_Item_DS+1]=value;
    end
  end
end

local first_search = true;
local search_text_nil;

function BuilderFramePage:SearchBlock(search_text)
	--local block_tag;
	if(search_text) then
		local block_tag = string.gsub(search_text,"%s","");
		if(block_tag == "") then
			search_text_nil = true;
			local category = category_ds[1];
			-- 历史
			if self.category_index == 4 then
				self:getAllBlocks()
			else
				self.Current_Item_DS = ItemClient.GetBlockDS(category.name);
			end
		else
			if(first_search or search_text_nil) then
				search_text_nil = false;
			end 
			
			local search_result1 = ItemClient.SearchBlocks(block_tag,category_ds[1].name);
			local search_result2 = ItemClient.SearchBlocks(block_tag,category_ds[2].name);
			local search_result3 = ItemClient.SearchBlocks(block_tag,category_ds[3].name);
			local search_result4 = ItemClient.SearchBlocks(block_tag,category_ds[4].name);
      
      self.Current_Item_DS=search_result1;
      if search_result2 then
        self.Current_Item_DS=self.Current_Item_DS or {};
        for _,value in pairs(search_result2) do
          self.Current_Item_DS[#self.Current_Item_DS+1]=value;
        end
      end
      if search_result3 then
        self.Current_Item_DS=self.Current_Item_DS or {};
        for _,value in pairs(search_result3) do
          self.Current_Item_DS[#self.Current_Item_DS+1]=value;
        end
      end
      if search_result4 then
        self.Current_Item_DS=self.Current_Item_DS or {};
        for _,value in pairs(search_result4) do
          self.Current_Item_DS[#self.Current_Item_DS+1]=value;
        end
      end
		end
		self:runFilter()
		-- local cur_category_obj = ParaUI.GetUIObject("builder_cur_category_btn");
		-- if(self.category_index == 1) then
		-- 	cur_category_obj.background = UIUtility.GetMCMLStandardImageDescription("gameassets/textures/ui_09_bag/builderframetemp.png","8.png")

		-- elseif(self.category_index == 2) then
		-- 	cur_category_obj.background = UIUtility.GetMCMLStandardImageDescription("gameassets/textures/ui_09_bag/builderframetemp.png","9.png")
		-- elseif(self.category_index == 3) then
		-- 	cur_category_obj.background = UIUtility.GetMCMLStandardImageDescription("gameassets/textures/ui_09_bag/builderframetemp.png","10.png")
		-- else
		-- 	cur_category_obj.background = UIUtility.GetMCMLStandardImageDescription("gameassets/textures/ui_09_bag/builderframetemp.png","11.png")
		-- end

	end
	local gvw_name = "new_builder_gvwItems";
	local node = self:getPage():GetNode(gvw_name);
	pe_gridview.DataBind(node, gvw_name, false);

end

function BuilderFramePage:onCreate()

    --local search_ctl = self:getPage():FindUIControl("block_search_text_ctl");
    --search_ctl.text="";
    self:getBlockFilter()
    --读方块历史
    self.blockHistory = UserDatabase.getAttribute("BlockHistory", nil, "local") or {}
--    echotable(self.blockFilter)
	self:OnChangeCategory(1);
end

function BuilderFramePage:getBlockFilter()
	self.blockFilter = {["ZiRan"] = {},["ZhuanShi"] = {}, ["CaiSe"] = {},["TaiJie"] = {}, ["DiBan"] = {}}
	local filename = "config/Aries/creator/block_list.xml";
	local xmlRoot = ParaXML.LuaXML_ParseFile(filename);
	if(xmlRoot) then
		xmlRoot = GameLogic.GetFilters():apply_filters("block_list", xmlRoot);

		local node, category_node;
		for node in commonlib.XPath.eachNode(xmlRoot, "/blocklist/category") do
			local category_name = node.attr.name;
			category_node = node;
			for node in commonlib.XPath.eachNode(category_node, "/block") do
				local attr = node.attr;
				if attr.ZiRan then
					table.insert(self.blockFilter["ZiRan"],attr.id)
				end
				if attr.ZhuanShi then
					table.insert(self.blockFilter["ZhuanShi"],attr.id)
				end
				if attr.CaiSe then
					table.insert(self.blockFilter["CaiSe"],attr.id)
				end
				if attr.TaiJie then
					table.insert(self.blockFilter["TaiJie"],attr.id)
				end
				if attr.DiBan then
					table.insert(self.blockFilter["DiBan"],attr.id)
				end
			end
		end
	end
end

function BuilderFramePage:handleKeyEvent(event)
    local dik_key = event.keyname;
	if (dik_key == "DIK_ESCAPE") then
		self:close();
		event:accept();
	end

	--catch all
	return true;
end

-- 筛选开关
function BuilderFramePage:OnFilter()
	if not self.filter then
		self.filter = true
	else
		self.filter = not self.filter
		local category = category_ds[self.category_index];
		self.Current_Item_DS = ItemClient.GetBlockDS(category.name);
	end
	for k,v in pairs(self.blockFilter) do
		v.selected = false
	end
	self:refresh()
end

function BuilderFramePage:OnSelectLable(name)
	self.blockFilter[name].selected = not self.blockFilter[name].selected
	local category = category_ds[self.category_index];
	self.Current_Item_DS = ItemClient.GetBlockDS(category.name);
	self:runFilter()
	self:refresh()
end

function BuilderFramePage:runFilter()
	-- 标签筛选
	if self.filter then
		local temp = {}
		-- 若没有选择任何标签，返回所有方块
		local needFilter = false
		for i = 1,#self.Current_Item_DS do
			for k,v in pairs(self.blockFilter) do
				if v.selected then
					needFilter = true
					for key,value in pairs(v) do
						if self.Current_Item_DS[i].id == tonumber(value) then
							local insert = true
							if next(temp) then
								for j=1,#temp do
									if temp[j].id == self.Current_Item_DS[i].id then
										insert = false									
									end
								end							
							end
							if insert then
								table.insert(temp, self.Current_Item_DS[i])
							end
						end
					end
				end		
			end
		end
		if needFilter then
			self.Current_Item_DS = temp
		end
	-- 历史方块，对比所有方块列表和本地userdata记录的历史方块
	elseif self.category_index == 4 then
		local temp = {}
		for j = 1, #self.blockHistory do
			for i = 1, #self.Current_Item_DS do
				if self.blockHistory[j] == self.Current_Item_DS[i].id then
					table.insert(temp, self.Current_Item_DS[i])
					break
				end
			end
		end
		self.Current_Item_DS = temp
	end
end

function BuilderFramePage:isLableSelected(name)
	if self.blockFilter[name].selected then
		return true
	else
		return false
	end
end