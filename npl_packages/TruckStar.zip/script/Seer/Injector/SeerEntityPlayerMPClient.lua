--[[
    Title: SeerEntityPlayerMPClient
    Author(s): Devil
    Date: 2016/05/04
    Desc: EntityPlayerMPClient extension. 
    A Injector class.
    Injection Target: MyCompany.Aries.Game.EntityManager.EntityPlayerMPClient
    use the lib:
    -------------------------------------------------------
	NPL.load("(gl)script/apps/Aries/Creator/Game/Entity/EntityPlayerMPClient.lua");
    NPL.load("(gl)script/Seer/Injector/SeerEntityPlayerMPClient.lua");
	local EntityPlayerMPClient = commonlib.gettable("MyCompany.Aries.Game.EntityManager.EntityPlayerMPClient")
    local SeerEntityPlayerMPClient = commonlib.gettable("Mod.Seer.Injector.SeerEntityPlayerMPClient");
    Inject(SeerEntityPlayerMPClient, EntityPlayerMPClient);
    -------------------------------------------------------
]]
NPL.load("(gl)script/apps/Aries/Creator/Game/Entity/EntityPlayerMPClient.lua");
local GameLogic = commonlib.gettable("MyCompany.Aries.Game.GameLogic")
local PlayerSkins = commonlib.gettable("MyCompany.Aries.Game.EntityManager.PlayerSkins")
local rshift = mathlib.bit.rshift;
local lshift = mathlib.bit.lshift;
local band = mathlib.bit.band;
local bor = mathlib.bit.bor;
local SeerEntityPlayerMPClient = commonlib.gettable("Mod.Seer.Injector.SeerEntityPlayerMPClient");
function SeerEntityPlayerMPClient:OnLivingUpdate()
  self:UpdateEntityActionState();
	local bx, by, bz = self:GetBlockPos();
	local chunkX = rshift(bx, 4);
	local chunkZ = rshift(bz, 4);
	local chunk = self.worldObj:GetChunkFromChunkCoords(chunkX, chunkZ);
	if(not chunk or chunk:GetTimeStamp()<=0) then
		self.isNearbyChunkLoaded = false;

		-- making the player having no vertical speed. 
		local obj = self:GetInnerObject();
		if(obj) then
			obj:SetField("VerticalSpeed", 0);
		end

		-- TODO: chunk is not loaded, do not let the player to move. 
		-- for simplicity, just goto the spawn point. This is not the case, when server teleport the player to a position. 
		-- it should be the server to reset the player position. after chunk is loaded. 
		local x, y, z = self.worldObj:GetSpawnPoint();
		self:SetPosition(x, y, z);
	else
		self.isNearbyChunkLoaded = true;
	end
end
function SeerEntityPlayerMPClient:UpdateEntityActionState()
	GameLogic.GetFilters():apply_filters("entity_player_mp_client_entity_action_state_updated", self);
end
