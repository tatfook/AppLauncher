--[[
    Title: SeerEntityManager
    Author(s): Devil
    Date: 2016/9/7
    Desc: EntityManager extension. 
    A Injector class.
    Injection Target: Mod.Seer.Injector.SeerEntityManager
    use the lib:
    -------------------------------------------------------
    NPL.load("(gl)script/apps/Aries/Creator/Game/Entity/EntityManager.lua");
    NPL.load("(gl)script/Seer/Injector/SeerEntityManager.lua");
    local EntityManager = commonlib.gettable("MyCompany.Aries.Game.EntityManager");
    local SeerEntityManager = commonlib.gettable("Mod.Seer.Injector.SeerEntityManager");
    Inject(SeerEntityManager, EntityManager);
    -------------------------------------------------------
]]
NPL.load("(gl)script/apps/Aries/Creator/Game/Entity/EntityManager.lua");
local EntityManager = commonlib.gettable("MyCompany.Aries.Game.EntityManager");
local SeerEntityManager = commonlib.gettable("Mod.Seer.Injector.SeerEntityManager");
local lLastTriggerEntitys={};
-- the lastest trigger entity, such as the one that pressed a button or step on a pressure plat, etc.  
function SeerEntityManager.GetLastTriggerEntity(x,y,z)
  if x and y and z then
    return lLastTriggerEntitys[tostring(x)..","..tostring(y)..","..tostring(z)];
  else
    return EntityManager.Original_GetLastTriggerEntity();
  end
end

-- set lastest trigger entity. 
function SeerEntityManager.SetLastTriggerEntity(entity,x,y,z)
	EntityManager.Original_SetLastTriggerEntity(entity)
  lLastTriggerEntitys[tostring(x)..","..tostring(y)..","..tostring(z)]=entity;
end

function SeerEntityManager.RegisterEntities()
  EntityManager.Original_RegisterEntities();

  NPL.load("script/Seer/Game/Entity/EntityImageOnline.lua")

end