--[[
    Title: SeerItem
    Author(s): Devil
    Date: 2016/04/11
    Desc: Item extension. 
    A Injector class.
    Injection Target: MyCompany.Aries.Game.Items.Item
    use the lib:
    -------------------------------------------------------
	NPL.load("(gl)script/apps/Aries/Creator/Game/Items/Item.lua");
    NPL.load("(gl)script/Seer/Injector/SeerItem.lua");
	local Item = commonlib.gettable("MyCompany.Aries.Game.Items.Item");
    local SeerItem = commonlib.gettable("Mod.Seer.Injector.SeerItem");
    Inject(SeerItem, Item);
    -------------------------------------------------------
]]
NPL.load("(gl)script/apps/Aries/Creator/Game/Items/Item.lua");
local GameMode = commonlib.gettable("MyCompany.Aries.Game.GameLogic.GameMode");
local ObjEditor = commonlib.gettable("ObjEditor");
local Image3DDisplay = commonlib.gettable("MyCompany.Aries.Game.Effects.Image3DDisplay");
local BlockEngine = commonlib.gettable("MyCompany.Aries.Game.BlockEngine")
local TaskManager = commonlib.gettable("MyCompany.Aries.Game.TaskManager")
local block_types = commonlib.gettable("MyCompany.Aries.Game.block_types")
local GameLogic = commonlib.gettable("MyCompany.Aries.Game.GameLogic")
local EntityManager = commonlib.gettable("MyCompany.Aries.Game.EntityManager");
local ItemStack = commonlib.gettable("MyCompany.Aries.Game.Items.ItemStack");
local SeerItem = commonlib.gettable("Mod.Seer.Injector.SeerItem");
SeerItem.icon_size=64;
function SeerItem:GetIcon()
	if(not self.icon_generated) then
		self.icon_generated = true;
		if(not self.disable_gen_icon) then
			local model_filename = self:GetItemModel();	
			if(model_filename and model_filename ~= "icon") then
				-- only add block with real models. 
				local atlas = self:GetIconAtlas();
				if(self.block_id) then
					local region = atlas:AddRegionByBlockId(self.block_id);
					if(region) then
						self.icon = region:GetTexturePath();
					end
				end
			end
		end
	end
	
	if(self.icon) then
		return self.icon;
	else
		local block_template = block_types.get(self.block_id);
		if(block_template) then
			return block_template:GetIcon();
		end
	end
	return "";
end