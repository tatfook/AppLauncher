local GitlabAPI = commonlib.inherit(nil, NPL.export());

local Encoding = commonlib.gettable("commonlib.Encoding");

local function copy(src, dst)
    for k,v in ipairs(src) do
        dst[#dst + 1] = v;
    end
end

function GitlabAPI:init(baseurl, token)
    self.apiBaseUrl = baseurl;
    self.dataSourceToken = token;

    return self;
end

function GitlabAPI:geturl(params, callback, func)
    params = params or {};
    params.json = true;
    params.headers = 
    {
        ["PRIVATE-TOKEN"] = self.dataSourceToken,
        ["User-Agent"]    = "npl",
        ["content-type"]  = "application/json"      
    }

    NPL.GetURL(params, function (code, msg, data)
        local error = false;
        if  code ~= 200 and -- ok 
            code ~= 202 and 
            code ~= 204 and -- No Content
            code ~= 201 and -- Created
            code ~= 304 then -- Not Modified
            LOG.std("GitlabAPI","error",func,"return code: %d, url: %s", code, params.url);
            error = true;
            echotable(msg)
        end
        if callback then
            callback(data, error);
        else
            echo(params.url)
        end
    end)
end

-- projects
function GitlabAPI:createProject(groupid,name,callback)
    local params = 
    {
        url = string.format("%s/projects", self.apiBaseUrl),
        form = 
        {
            name = name,
            path = name,
            visibility = "public",
            namespace_id = groupid,
        }
    }

    self:geturl(params, callback, "createProject");   

end

function GitlabAPI:destroyProject(id)
    local params = 
    {
        url = self.apiBaseUrl .. "/projects/" .. id,
        method = "DELETE",
    }
    self:geturl(params, callback,"destroyProject");
end

function GitlabAPI:getProject(IDorNAME,callback)
    local params = 
    {
        url = self.apiBaseUrl .. "/projects/" .. Encoding.url_encode(IDorNAME),
    }
    self:geturl(params, callback,"getProject");
end

-- file

-- path: The path inside repository. Used to get contend of subdirectories
-- recursive: Boolean value used to get a recursive tree (false by default)
function GitlabAPI:tree(id,commitid, path, recursive, callback)
    commitid = commitid or "master"
    recursive = recursive or "false";
    path = path or ""

    local total = {};
    local function tree(page)
        local optional = string.format("path=%s&recursive=%s&ref=%s&page=%s&per_page=100", Encoding.url_encode(path), recursive,commitid, page);
        local params = 
        {
            url = string.format("%s/projects/%d/repository/tree?%s",self.apiBaseUrl, id, optional),
        }
        
        self:geturl(params, function (data, err)
            if err then return callback(data, err) end;
            if (#data == 0) then
                return callback(total, err);
            else
                copy(data, total);
                tree(page + 1);
            end
        end,"tree");
    end
    tree(1);
end

function GitlabAPI:commit(id, files, callback)
    local params = 
    {
        url = string.format("%s/projects/%d/repository/commits", self.apiBaseUrl, id),
        form = files,
    }
    self:geturl(params, callback, "commit");
end

function GitlabAPI:listCommits(id, page, perPage,callback)
    page = page or 1;
    perPage = perPage or 100;
    local params = 
    {
        url = string.format("%s/projects/%d/repository/commits?page=%s&per_page=%s", self.apiBaseUrl, id, page, perPage),
    }
    self:geturl(params, callback, "listcommits");
end

-- sha: The commit hash or name of a repository branch or tag
function GitlabAPI:getCommit(id, sha,callback)
    sha = sha or "master"
    local params = 
    {
        url = string.format("%s/projects/%d/repository/commits/%s", self.apiBaseUrl, id, sha),
    }
    self:geturl(params, callback, "getCommit");    
end

function GitlabAPI:add(id, path, content, callback)
    -- self:commit(id, {branch = "master", commit_message = "commit", actions = {{action="create",file_path=path,content=content}}}, callback)

    path = Encoding.url_encode(path);
    local params = 
    {
        url = string.format("%s/projects/%d/repository/files/%s", self.apiBaseUrl, id,path),
        form = 
        {
            content = content,
            branch = "master",
            commit_message = "truckstar commit " .. path,
        },
    }
    self:geturl(params, callback, "add");
end

function GitlabAPI:get(id, file, commitid, callback)
    commitid = commitid or "master"
    local params = 
    {
        url = string.format("%s/projects/%d/repository/files/%s?ref=%s", self.apiBaseUrl, id, Encoding.url_encode(file),commitid),
    }
    self:geturl(params, callback, "get");
end

function GitlabAPI:getRaw(id, file, commitid, callback)
    commitid = commitid or "master"
    local params = 
    {
        url = string.format("%s/projects/%d/repository/files/%s/raw?ref=%s", self.apiBaseUrl, id, Encoding.url_encode(file),commitid),
    }
    self:geturl(params, callback, "getraw");
end

function GitlabAPI:update(id, file, content, callback)
    local params =
    {
        url = string.format("%s/projects/%d/repository/files/%s?ref=%s", self.apiBaseUrl, id, Encoding.url_encode(file),commitid),
        json = true,
        method = "PUT",
        form = 
        {
            branch = "master",
            content = content,
            commit_message = "update: " .. file,
        }
    }
    self:geturl(params, callback)
end

-- compare braches, tags, commits
function GitlabAPI:compare(id, from, to, callback)
    local params = 
    {
        url = string.format("%s/projects/%d/repository/compare?from=%s&to=%s", self.apiBaseUrl, id, from, to),
    }
    self:geturl(params, callback, "compare");
end


--group 
-- pathname : group name in url
function GitlabAPI:createGroup(name, desc, parentid, callback)
    local params = 
    {
        url = string.format("%s/groups", self.apiBaseUrl),
        json = true,
        form = 
        {
            name = name,
            path = name,
        } ,
    }
    self:geturl(params, callback, "createGroup");
end

function GitlabAPI:searchGroup(keyword,callback) 
    local params = 
    {
        url = string.format("%s/groups?search=%s", self.apiBaseUrl, keyword),
    }
    self:geturl(params, callback, "searchGroup");
end

function GitlabAPI:listProjects(groupid, page, per_page,callback)
    local per_page = per_page or 100;
    local page = page or 1;
    local params = 
    {
        url = string.format("%s/groups/%s/projects?simple=true&owned=true&per_page=%s&page=%s", self.apiBaseUrl, groupid, per_page, page),
    }
    self:geturl(params, callback, "listProjects");   
end

