--[[
	NPL.load("(gl)script/Seer/Utility/UserDatabase.lua");
	local UserDatabase = commonlib.gettable("Mod.Seer.Utility.UserDatabase");

	-----------------
data in file:
	data = {
		50500 = {
			Field1 = {
				Field2 = {
					attribute = "fuck"
				}
			}
		}
	}
	
use: 

	echo(UserDatabase.getAttribute("Field1"))
	echo(UserDatabase.getAttribute("Field1.Field2"))
	echo(UserDatabase.getAttribute("Field1.Field2.attribute"))
	
output:
	"{Filed2={attribute="fuck"},}"
	"{attribute="fuck"}"
	"fuck"
]]

local UserDatabase = commonlib.gettable("Mod.Seer.Utility.UserDatabase");
local PacketPbHelper = commonlib.gettable("Mod.Seer.Network.Packets.PacketPbHelper");


local string_gfind = string.gfind;

local current;
local localdata;
local userdata
local timer;

local function loadUserData()
	return commonlib.LoadTableFromFile("userdata") or {};
end

local function saveUserData( d)
	commonlib.SaveTableToFile(d, "userdata")
end

local function get(field, path, default)
	local t = field;
	local w,d;
	for w,d in string_gfind(path,"([%w_]+)(.?)") do
		if (nil == t[w]) then
			return default
		end
		t = t[w]
	end
	if nil == t then
		t = default
	end
	return t;
end

local function set(field, path, value)
	local t = field;
	local w,d;
	for w,d in string_gfind(path,"([%w_]+)(.?)") do
		if (d == "") then
			t[w] = value
		else
			t[w] = t[w] or {}
			t = t[w]
		end
	end
end

local function unpack(tbl, path, value)
	if type(value) == "table" then
		for k,v in pairs(value) do
			unpack(tbl, path .. "." .. k, v);
		end
	else
		tbl[#tbl + 1] = {key=path, value=tostring(value)};
	end
	
end

function UserDatabase.init()
	localdata = loadUserData(userid);
end

function UserDatabase.update(callback)
	userdata = {};
	PacketPbHelper.sendCSGetAllCustomDataReq();
	PacketPbHelper.registerFunc("CSGetCustomDataNtf", 
		function (h,b)
			for k,v in pairs(b.pairs or {}) do
				local value = NPL.LoadObjectFromString(v.value);
				if value == nil then
					value = v.value;
				end
				UserDatabase.setAttribute(v.key,value,"update")
			end

			if b.is_end then
				callback();
			end
		end)
end

function UserDatabase.getAttribute(path, defaultvalue,type)
	if (type == "local" ) then
		if  not localdata then
			LOG.std(nil, "error", "UserDatabase", "error: UserDatabase is nil");
			return defaultvalue;
		else
			return get(localdata, path, defaultvalue);
		end
	elseif userdata then
		return get(userdata, path, defaultvalue);
	else
		echo({"error UserDatabase.getAttribute: ",path, type})
		return defaultvalue;
	end
end

function UserDatabase.setAttribute(path, value, type)
	if type == "local" then
		if (not localdata) then
			LOG.std(nil, "error", "UserDatabase", "error: UserDatabase is nil");
			return false;
		else
			set(localdata, path, value);
			UserDatabase.save(true)
		end
	elseif userdata then
		set(userdata, path, value);
		
		if type == "update" then
			return true;
		end

		if value == nil then
			PacketPbHelper.sendCSDeleteCustomDataReq({path});
		else
			local data = {};
			if (type == "pack") then
				data = {{key=path, value=commonlib.serialize(value)}};
			else
				unpack(data, path, value);
			end

			for k,v in ipairs(data) do
				if v.value:len()  >= cs_custom_pb.KEY_VALUE_SIZE then
					LOG.std(nil, "error", "UserDatabase", "%s value is too long to record", v.key);
					return false;
				end
			end

			PacketPbHelper.sendCSUpdateCustomDataReq(data);
		end
	else
		echo({"error UserDatabase.setAttribute: ",path, value, type})
	end
	
	return true;
end

function UserDatabase.save(deferred)
	if deferred then
		if (not timer) then
			timer = commonlib.Timer:new({callbackFunc = function (t)
					saveUserData( localdata);
					timer = nil;
				end})
			timer:Change(1000);
		end
	else
		saveUserData( localdata);
	end
end
