--[[
Title: inventory
Author(s): WangXiXi
Date: 2015/7/29
Desc: 
Use Lib:
-------------------------------------------------------
NPL.load("(gl)script/Seer/InventoryPage.lua");
local InventoryPage = commonlib.gettable("Mod.UI.InventoryPage");
InventoryPage.ShowPage()
-------------------------------------------------------
]]
NPL.load("(gl)script/apps/Aries/Creator/Game/Areas/BlockTemplatePage.lua");
NPL.load("(gl)script/apps/Aries/Creator/Game/Items/ItemClient.lua");
local ItemClient = commonlib.gettable("MyCompany.Aries.Game.Items.ItemClient");
NPL.load("(gl)script/apps/Aries/Creator/Game/Entity/EntityManager.lua");
local EntityManager = commonlib.gettable("MyCompany.Aries.Game.EntityManager");
local BlockTemplatePage = commonlib.gettable("MyCompany.Aries.Creator.Game.Desktop.BlockTemplatePage");
local Desktop = commonlib.gettable("MyCompany.Aries.Creator.Game.Desktop");
local block_types = commonlib.gettable("MyCompany.Aries.Game.block_types")
local GameLogic = commonlib.gettable("MyCompany.Aries.Game.GameLogic")
local BlockEngine = commonlib.gettable("MyCompany.Aries.Game.BlockEngine")

local InventoryPage = commonlib.gettable("Mod.UI.InventoryPage");

local page;
InventoryPage.modifyName = false;

function InventoryPage.OnInit()
	page = document:GetPageCtrl();
	if(page) then
		page.OnClose = function ()
			InventoryPage.modifyName = false;
		end
	end
	GameLogic.events:AddEventListener("OnHandToolIndexChanged", InventoryPage.OnHandToolIndexChanged, InventoryPage, "InventoryPage");
end

function InventoryPage.OnInitMobile()
	page = document:GetPageCtrl();
end

function InventoryPage.OneTimeInit()
	if(InventoryPage.is_inited) then
		return;
	end
	InventoryPage.is_inited = true;
	-- TODO: 
end

function InventoryPage:OnHandToolIndexChanged(event)
	if(page) then
		local ctl = page:FindControl("handtool_highlight_bg");
		if(ctl) then
			ctl.x = (GameLogic.GetPlayerController():GetHandToolIndex()-1)*40+3;
		end
	end
end

function InventoryPage.GetPlayerDisplayName()
	local player = EntityManager.GetPlayer()
	if(player) then
		local name = player:GetDisplayName();
		if(name) then
			return name;
		end
	end
end

function InventoryPage.SetPlayerDisplayName()
	local player = EntityManager.GetPlayer()
	if(player) then
		local obj = ParaUI.GetUIObject("inventory_player_displayname");
		local displayname = obj.text;
		player:SetDisplayName(displayname);
	end
end

function InventoryPage.ShowPage()
	if(InventoryPage.last_player ~= EntityManager.GetPlayer()) then
		InventoryPage.last_player = EntityManager.GetPlayer();
		if(page) then
			-- destroy the previous window if player has changed
			page:CloseWindow(true);
		end
	end

	local params = {
			url = "script/Seer/InventoryPage.html", 
			name = "InventoryPage.ShowPage", 
			app_key = MyCompany.Aries.Creator.Game.Desktop.App.app_key, 
			isShowTitleBar = false,
			DestroyOnClose = false,
			enable_esc_key = true,
			bToggleShowHide=true, 
			style = CommonCtrl.WindowFrame.ContainerStyle,
			zorder = -3,
			allowDrag = true,
			click_through = true,
			directPosition = true,
				align = "_ct",
				x = -430/2,
				y = -460/2,
				width = 430,
				height = 460,
		};
		System.App.Commands.Call("File.MCMLWindowFrame", params);
	
end

