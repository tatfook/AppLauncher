--[[
    Title: SeerBroadcastHelper
    Author(s): Devil
    Date: 2017/3/22
    Desc: BroadcastHelper extension. 
    A Injector class.
    Injection Target: Mod.Seer.Injector.SeerBroadcastHelper
    use the lib:
    -------------------------------------------------------
    NPL.load("(gl)script/ide/TooltipHelper.lua");
    NPL.load("(gl)script/Seer/Injector/SeerBroadcastHelper.lua");
    local BroadcastHelper = commonlib.gettable("CommonCtrl.BroadcastHelper");
    local SeerBroadcastHelper = commonlib.gettable("Mod.Seer.Injector.SeerBroadcastHelper");
    Inject(SeerBroadcastHelper, BroadcastHelper);
    -------------------------------------------------------
]]
NPL.load("(gl)script/ide/TooltipHelper.lua");
NPL.load("(gl)script/Seer/Game/UI/UIBulletsStack.lua");
local BulletBroadcastHelper = commonlib.gettable("Mod.Seer.Game.UI.BulletBroadcastHelper");
local BroadcastHelper = commonlib.gettable("CommonCtrl.BroadcastHelper");
local SeerBroadcastHelper = commonlib.gettable("Mod.Seer.Injector.SeerBroadcastHelper");
local lEnableBulletScreen=true;
function SeerBroadcastHelper.enableBulletScreen(enable)
  BroadcastHelper.Clear();
	BulletBroadcastHelper.Clear();
  lEnableBulletScreen=enable;
end

function SeerBroadcastHelper.getBulletScreenEnable()
  return lEnableBulletScreen;
end

function SeerBroadcastHelper.PushLabel(args, bPushToFront, autoBulletScreenMode)
  if autoBulletScreenMode and lEnableBulletScreen then
    BulletBroadcastHelper.PushLabel(args, bPushToFront)
  else
    BroadcastHelper.Original_PushLabel(args, bPushToFront);
  end
end
