--[[
    Title: SeerBlockRedstoneConductor
    Author(s): Devil
    Date: 2016/08/10
    Desc: BlockRedstoneConductor extension. 
    A Injector class.
    Injection Target: Mod.Seer.Injector.SeerBlockRedstoneConductor
    use the lib:
    -------------------------------------------------------
    NPL.load("(gl)script/apps/Aries/Creator/Game/blocks/BlockRedstoneConductor.lua");
    NPL.load("(gl)script/Seer/Injector/SeerBlockRedstoneConductor.lua");
    local BlockRedstoneConductor = commonlib.gettable("MyCompany.Aries.Game.blocks.BlockRedstoneConductor")
    local SeerBlockRedstoneConductor = commonlib.gettable("Mod.Seer.Injector.SeerBlockRedstoneConductor");
    Inject(SeerBlockRedstoneConductor, BlockRedstoneConductor);
    -------------------------------------------------------
]]
NPL.load("(gl)script/apps/Aries/Creator/Game/blocks/BlockRedstoneConductor.lua");
local ItemClient = commonlib.gettable("MyCompany.Aries.Game.Items.ItemClient");
local BlockEngine = commonlib.gettable("MyCompany.Aries.Game.BlockEngine")
local TaskManager = commonlib.gettable("MyCompany.Aries.Game.TaskManager")
local block_types = commonlib.gettable("MyCompany.Aries.Game.block_types")
local GameLogic = commonlib.gettable("MyCompany.Aries.Game.GameLogic")
local EntityManager = commonlib.gettable("MyCompany.Aries.Game.EntityManager");
local names = commonlib.gettable("MyCompany.Aries.Game.block_types.names")
local block = commonlib.gettable("Mod.Seer.Injector.SeerBlockRedstoneConductor");

function block:tickRate()
	return tonumber(self.tick_rate) or 2;
end
-- this block is a diode, which is only weakly powered by the block that it sits on. 
function block:isWeaklyPowered(x,y,z)
  local dir=self.direction or "up";
  local offset=0;
  if dir=="down" then
    offset=1;
  else
    offset=-1;
  end
	local y1 = y+offset;
	local src_block = BlockEngine:GetBlock(x,y1,z);
	if(src_block) then
		local src_state = src_block:GetInternalStateNumber(x,y1,z);
		if(src_state) then
			-- source state has priority over weak power
			return src_state and src_state>0;
		else
			return BlockEngine:hasWeakPowerOutputTo(x,y1,z);
		end
	else
		return false;
	end
end

-- providing power except for the block that it sits on. 
function block:isProvidingWeakPower(x, y, z, direction)
	if (not self.torchActive) then
        return 0;
  else
    local dir=self.direction or "up";
    local test=0;
    if dir=="down" then
      test=5;
    else
      test=4;
    end
    if(direction == test) then
      return 0;
    else
      return 15;
    end
  end
end

-- only provide strong power to the top block
function block:isProvidingStrongPower(x, y, z, direction)
  local dir=self.direction or "up";
  local test=0;
  if dir=="down" then
    test=4;
  else
    test=5;
  end
	if(direction ==test) then
		return self:isProvidingWeakPower(x, y, z, direction);
	else
		return 0;
	end
end

-- revert back to unpressed state
function block:updateTick(x,y,z)
	if(not GameLogic.isRemote) then
    local dir=self.direction or "up";
    local name_add="";
    if dir=="down" then
      name_add="_Down";
    end
		local is_indirectly_powered = self:isWeaklyPowered(x,y,z);

		if (self.torchActive) then
			if(not is_indirectly_powered) then
				-- turn it off
				BlockEngine:SetBlock(x,y,z,names["Redstone_Conductor"..name_add], data, 3);
			end
		else
			if(is_indirectly_powered) then
				-- turn it on
				BlockEngine:SetBlock(x,y,z,names["Redstone_Conductor_On"..name_add], data, 3);
			end
		end
	end
end

