--[[
    Title: Unit test for zipping and unzipping
    Author(s): Cellfy
    Date Created: May 3, 2016
    Date Updated: May 3, 2016
    Desc: 
    Usage:
    ------------------------------------------------------------
    NPL.load("(gl)script/Seer/UnitTests/ZipTest.lua");
    local ZipTest = commonlib.gettable("Mod.Seer.UnitTests.ZipTest");
    ------------------------------------------------------------
]]

NPL.load("(gl)script/Seer/Utility/IOUtility.lua");

local IOUtility = commonlib.gettable("Mod.Seer.Utility.IOUtility");

local ZipTest = commonlib.gettable("Mod.Seer.UnitTests.ZipTest");

function ZipTest.TestZip()
    local zipPath = "worlds/1.zip"
    local zipFile = ParaIO.CreateZip(zipPath,"")

    local filePath = "worlds/1.txt";
    local fileName = "1.txt";

    local ret = zipFile:ZipAdd(fileName,filePath);
    if (ret ~= 0 ) then
        LOG.std(nil, "error", "cellfy", "zip add error");
    end

    zipFile:close();
end

function ZipTest.TestUnzip()
	return IOUtility.UnZipToSameFolder("worlds/1.zip");    
end
