--[[
    Title: BaseDestructionObject
    Author(s): Devil
    Date: 2017/10/11
    Desc: Seer BaseDestructionObject
    use the lib:
    ------------------------------------------------------------
    NPL.load("(gl)script/Seer/Utility/BaseDestructionObject.lua");
    local BaseDestructionObject=commonlib.gettable("Mod.Seer.Utility.BaseDestructionObject");
    -------------------------------------------------------
]]
local BaseDestructionObject=commonlib.inherit(nil,commonlib.gettable("Mod.Seer.Utility.BaseDestructionObject"));
BaseDestructionObject.ClassName="Mod.Seer.Utility.BaseDestructionObject";
function BaseDestructionObject:delete(class)
  class=class or self;
  class._delete(self);
  if class._super then
    class._super.delete(self,class._super);
  else
    for key,value in pairs(self) do
      self[key]=nil;
    end
  end
end

function BaseDestructionObject:_delete()
end