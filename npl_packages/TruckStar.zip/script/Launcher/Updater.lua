
NPL.load("./Headers.lua")

local Updater = NPL.export();
local PacketPbHelper = commonlib.gettable("Mod.Seer.Network.Packets.PacketPbHelper");
local QiniuHash = commonlib.gettable("Mod.Seer.Utility.QiniuHash");
local UrlFileTransfer = NPL.load("script/Seer/Utility/UrlFileTransfer.lua")

local downloadQueue = "launcher_download";

local function relaunch()
    
end

function Updater.update(nid,root, updateLauncher,curVer, lastestVer, callback, progress)
    PacketPbHelper.sendCSGetUpdateInfoReq(nid, function (h, b )
        local domain = b.resource_domain
        local bucket = b.resource_bucket

        root = root or ""

        PacketPbHelper.sendCSGetLastExeInfoReq(nid, lastestVer, function (h,b)
            -- update launcher
            local hash = QiniuHash.hashFile(root .. b.file_path);

            if not updateLauncher or hash == b.hash then 
                PacketPbHelper.sendCSGetLastFileListsReq(nid, curVer, function (h, b)
                    local sum = b.change_number;
                    local count = 0;
                    local filelists = {};
                    if sum == 0 then 
                        callback();
                        return;
                    end

                    PacketPbHelper.unregisterFunc("CSNotifyFileToken");
                    PacketPbHelper.registerFunc("CSNotifyFileToken", function (h, b)
                        if b.op_type == 2 then 
                            -- delete file
                            return 
                        end

                        count = count + 1;
                        if b.hash ~= QiniuHash.hashFile(root .. b.file_path) then
                            filelists[#filelists + 1] = {path = root .. b.file_path, hash = b.hash, url = string.format("http://%s/%s%s?e=%s&token=%s", domain, b.key,b.file_path, b.expires, b.token)}
                        end

                        if sum == count then
                            if #filelists == 0 then 
                                return callback();
                            end
                            count = 0;
                            for k,v in ipairs(filelists) do 
                                UrlFileTransfer.download(v.url, v.path, function (path, error) 
                                    count = count + 1;
                                    if error then 
                                        callback(string.format("failed to download file %s", path));
                                        UrlFileTransfer.terminateQueue(downloadQueue);
                                    end

                                    -- complete
                                    if count == #filelists then 
                                        callback();
                                    end
                                end, 
                                function (path, curpercent, total)
                                    if progress then 
                                        progress(count , #filelists);
                                    end
                                end,
                                downloadQueue)
                            end
                        end
                    end)
                end)
            else
                local url = string.format("http://%s/%s%s?e=%s&token=%s", domain, b.key,root .. b.file_path, b.expires, b.token);
                echo(b)
                UrlFileTransfer.download(url, root .. b.file_path, function (path, error)
                    if error then return callback("failed to update launcher") end;
                    relaunch();                    
                end, nil, downloadQueue);
            end


        end)

    end)

end