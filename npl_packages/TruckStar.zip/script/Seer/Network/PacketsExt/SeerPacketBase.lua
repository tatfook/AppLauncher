--[[
    Title: SeerPacketBase
    Author(s): Cellfy
    Date Created: Jul 12, 2016
    Date Updated: Jul 12, 2016
    Desc: Base class for extended packets by seer
    Usage:
    ------------------------------------------------------------
    NPL.load("(gl)script/Seer/Network/PacketsExt/SeerPacketBase.lua");
    local SeerPacketBase = commonlib.gettable("Mod.Seer.Network.PacketsExt.SeerPacketBase");
    ------------------------------------------------------------
]]

NPL.load("(gl)script/apps/Aries/Creator/Game/Network/Packets/Packet.lua");
NPL.load("(gl)script/Seer/Network/PacketsExt/SeerPacketTypes.lua");

local SeerPacketTypes = commonlib.gettable("Mod.Seer.Network.PacketsExt.SeerPacketTypes");

local SeerPacketBase = commonlib.inherit(commonlib.gettable("MyCompany.Aries.Game.Network.Packets.Packet"), commonlib.gettable("Mod.Seer.Network.PacketsExt.SeerPacketBase"));

function SeerPacketBase:ctor()
end

function SeerPacketBase:InitAsReq(callback_func)
    self.category = "request";
    self.callback = callback_func;
    SeerPacketTypes:RegisterCallback(self);
end

function SeerPacketBase:InitAsRsp(req_packet)
    self.category = "response";
    if req_packet.sequence and type(req_packet.sequence)=="number" and req_packet.sequence>0 then
        self.sequence = req_packet.sequence;
    else
        LOG.std(nil, "warning", "cellfy", "trying to send a response packet without a valid sequence number");
    end
end

function SeerPacketBase:Init()
    self.category = "standalone";
    self.sequence = 0;
    self.callback = nil;
end

local function RequestInternalHandler(packet, net_handler)
end

local function ResponseInternalHandler(packet, net_handler)
    SeerPacketTypes:RunCallback(packet);
end

local function StandaloneInternalHandler(packet, net_handler)
end

function SeerPacketBase:ProcessPacket(net_handler)
    if self.category == "request" then
        RequestInternalHandler(self);
    elseif self.category == "response" then
        ResponseInternalHandler(self);
    elseif self.category == "standalone" then
        StandaloneInternalHandler(self);
    end
end
