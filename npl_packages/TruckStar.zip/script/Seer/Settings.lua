--[[
Title: Seer Mod Settings
Author(s): ZhouXing
Date: 2015/6/18
Desc: Seer Mod Settings
use the lib:
------------------------------------------------------------
NPL.load("(gl)script/Seer/Settings.lua");
local Settings = commonlib.gettable("Mod.Seer.Settings");
------------------------------------------------------------
]]

local Settings = commonlib.gettable("Mod.Seer.Settings");

Settings.version = "1.1.6.2688"
Settings.isVersionValid = false;

Settings.channel = 0;
-- 这是外网
-- Settings.netconfig = "release";
-- 这是40000
Settings.netconfig = "dev_team_stable";
-- 这是30000
-- Settings.netconfig = "dev_team_dev";


-- Settings.createNewCraftFiles = {"attribute.db","NPC.db","preview.jpg","tag.xml","tagMod.xml","flat.txt","worldconfig.txt"}
Settings.newCreateSaveCraftFiles = {"attribute.db","flat.txt","NPC.db","preview.jpg","tag.xml","tagMod.xml","worldconfig.txt","entity.xml"}
Settings.saveCraftFiles = {"attribute.db","entity.xml","tag.xml","tagMod.xml",}
Settings.needCheckSaveCraftFiles = {"LocalNPC.xml","revision.xml","blockWorld.lastsave/customblocks.xml","blockWorld.lastsave/neurons.xml","players/0.entity.xml"}
Settings.seer_ship_path = "TS/bigworld.pkg"
Settings.guide_path = "TS/guide/chapter1/guiderecordnew.pkg";
Settings.cg_path = "TS/CG.pkg"

--Settings.default_texture_path = commonlib.Encoding.Utf8ToDefault("TS/BlockTextures/local/SeerCraft32x_r1材质包.zip");
Settings.default_texture_path = commonlib.Encoding.Utf8ToDefault("worlds/BlockTextures/SeerCraft32x_r1.zip");
Settings.default_texture_type = "local";
Settings.default_texture_url  = "";
Settings.default_texture_name = "SeerCraft32x_r1";

Settings.dpi_scaling_factor = 1;

function Settings.SetDPIScalingFactor(scale_factor)
    if scale_factor and type(scale_factor)=="number" and scale_factor>0.3 and scale_factor<=2 then
        Settings.dpi_scaling_factor = scale_factor;
        LOG.std(nil, "debug", "truckstar", "setting dpi factor to: %d", scale_factor);
    else
        LOG.std(nil, "debug", "truckstar", "invalid dpi factor");
    end
end

function Settings.GetLocalPlanetFolder(id)
	local YcProfile = commonlib.gettable("Mod.Seer.Network.YcProfile");
	local info = YcProfile.GetUserInfo();
	return string.format("worlds/DesignHouse/localRecord/%s/%s/", info.zone_id, id);
	--return "worlds/DesignHouse/"..ParaEngine.GetAppCommandLineByParam("SeerName", "localRecord").."/" .. id .. "/"
end

-- change internet entityplayer's nid to this: "prefix + user_id"
function Settings.GetPlayerNetNID(uid)
	return "netplayer".."_"..tostring(uid);
end

function Settings.GetPlanetFolder(id)
  NPL.load("(gl)script/Seer/Game/ModuleManager.lua");
  NPL.load("(gl)script/Seer/Game/World/PlanetManager.lua");
  local planetMgr = commonlib.gettable("Mod.Seer.Game.World.PlanetManager");
  local ModuleManager = commonlib.gettable("Mod.Seer.Game.ModuleManager");
  --id:0 bigworld
  --id:1 guideworld
  if id and type(id)=="string" then
    return Settings.GetLocalPlanetFolder(id);
  else
    if ModuleManager.checkModule("BigWorld") then
      return Settings.seer_ship_path;
    elseif ModuleManager.checkModule("Guide") then
      return Settings.guide_path;
    else
      return planetMgr.getCurrentPlanet():getPath();
    end
  end
end
