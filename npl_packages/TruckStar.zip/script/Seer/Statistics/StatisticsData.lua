--[[
    Title: StatisticsData
    Author(s): Cellfy
    Date Created: Sep 20, 2016
    Date Updated: Sep 20, 2016
    Desc: Basic data structure for statistics usage
    Usage:
    ------------------------------------------------------------
    NPL.load("(gl)script/Seer/Statistics/StatisticsData.lua");
    local StatisticsData = commonlib.gettable("Mod.Seer.Statistics.StatisticsData");
    local StatisticsDataKeyValue = commonlib.gettable("Mod.Seer.Statistics.StatisticsDataKeyValue");
    ------------------------------------------------------------
]]

--------------------------------------------------------------------------------
-- Basic Data Type
--------------------------------------------------------------------------------
local StatisticsData = commonlib.inherit(nil, commonlib.gettable("Mod.Seer.Statistics.StatisticsData"));

function StatisticsData:ctor()
    self.DataType = "Base";
end

function StatisticsData:Type()
    return self.DataType;
end

--------------------------------------------------------------------------------
-- Key-Value Data Type
--------------------------------------------------------------------------------
local StatisticsDataKeyValue = commonlib.inherit(StatisticsData, commonlib.gettable("Mod.Seer.Statistics.StatisticsDataKeyValue"));

function StatisticsDataKeyValue:ctor()
    self.DataType = "KeyValue";
end

function StatisticsDataKeyValue:SetData(str_key, str_value)
    local check_ok = true;
    if type(str_key)~="string" then
        LOG.std(nil, "error", "truckstar", "StatisticsDataKeyValue: invalid key");
        check_ok = false;
    end
    if type(str_value)~="string" then
        LOG.std(nil, "error", "truckstar", "StatisticsDataKeyValue: invalid value");
        check_ok = false;
    end
    if check_ok then
        self.Key = str_key;
        self.Value = str_value;
    end
end
