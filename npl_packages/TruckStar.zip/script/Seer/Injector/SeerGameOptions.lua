NPL.load("(gl)script/Seer/Injector/SeerBlockButton.lua");
local SeerGameOptions = commonlib.gettable("Mod.Seer.Injector.SeerGameOptions");


function SeerGameOptions:ShowTouchPad(bShow)

end