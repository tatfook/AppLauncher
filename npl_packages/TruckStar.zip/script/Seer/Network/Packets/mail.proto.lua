NPL.load("(gl)script/Seer/pb/mail_pb.lua");
NPL.load("(gl)script/Seer/Network/Packets/PacketPbHelper.lua");
local PacketPbHelper = commonlib.gettable("Mod.Seer.Network.Packets.PacketPbHelper");
NPL.load("(gl)script/Seer/Game/Mail/MailManager.lua");
local MailManager = commonlib.gettable("Mod.Seer.Game.Mail.MailManager");

-- 获取一个用户的所有mail信息列表，只能获取自己的邮件列表
function PacketPbHelper.CSGetMailHeaderListReq(callback,errcallback)
	PacketPbHelper.send("CSGetMailHeaderListReq", {}, callback,errcallback)
end

-- 发送阅读回执
function PacketPbHelper.CSSendMailReceiptNotify(mail_id)
	PacketPbHelper.send("CSSendMailReceiptNotify", {mail_id = mail_id})
end

-- 获取mail内容，对于已经阅读的mail,不应该再发送回执。
function PacketPbHelper.CSGetMailContentReq(mail_id, callback, errcallback)
	PacketPbHelper.send("CSGetMailContentReq", {mail_id = mail_id}, callback, errcallback)
end

-- 领取附件
function PacketPbHelper.CSObtainAttachmentReq(mail_id, is_force, callback, errcallback)
	PacketPbHelper.send("CSObtainAttachmentReq", {mail_id = mail_id, is_force = is_force}, callback, errcallback)
end

-- 推送用户新邮件
PacketPbHelper.registerFunc("CSPushNewMailNotify", 
	function (h,b)
		MailManager:pushNewMail(b)
	end)


