--[[
    Title: shell_loop_check_version
    Author(s): Cellfy
    Date: 2016/06/27
    Desc: entrance script for checking version of distribution
    use the lib:
    -------------------------------------------------------
    In shell script:
    ./ParaEngineServer 'bootstrapper="script/Seer/installer/shell_loop_check_version.lua"'
    -------------------------------------------------------
]]
NPL.load("(gl)script/ide/commonlib.lua"); 

local function activate()
    print("Checking release version for current directory...");
    print("Please make sure there's no individual script/Seer/Settings.lua inside current directory")

    NPL.load("(gl)script/Seer/Settings.lua");
    local Settings = commonlib.gettable("Mod.Seer.Settings");

    echo("Current version number: ");
    echo(string.format("    %s", Settings.version));
    echo("Current net config: ");
    echo(string.format("    %s", Settings.netconfig));
    echo("This net config is supposed to be used for: ");
    if Settings.netconfig == "release" then
        echo("    Final Release");
    elseif Settings.netconfig == "qa_team" then
        echo("    QA");
    else
        echo("    Development")
    end
    
    ParaGlobal.ExitApp();
    
    print("Checking Finished");
end

NPL.this(activate);
