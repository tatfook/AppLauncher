--[[
    Title: NetworkConfigReader
    Author(s): Cellfy
    Date Created: May 25, 2016
    Date Updated: May 25, 2016
    Desc: Interface to visit NetworkConfig.xml
    Usage:
    ------------------------------------------------------------
    NPL.load("(gl)script/Seer/Config/NetworkConfigReader.lua");
    local NetworkConfigReader = commonlib.gettable("Mod.Seer.Config.NetworkConfigReader");
    ------------------------------------------------------------
]]

NPL.load("(gl)script/Seer/Settings.lua");
local Settings = commonlib.gettable("Mod.Seer.Settings");
local Config = commonlib.gettable("Mod.Seer.Config");
local NetworkConfigReader = commonlib.gettable("Mod.Seer.Config.NetworkConfigReader");

local current_config = nil;

function NetworkConfigReader.Load()
    Config.loadConfig("script/Seer/Config/NetworkConfig.xml");
    local config_id = Settings.netconfig or "dev_team_stable";
    current_config = Config.NetworkConfig.Client:get(1).client_config:find(config_id);
    if not current_config then
        current_config = Config.NetworkConfig.Client:get(1).client_config:get(1);
    end
    if not current_config then
        LOG.std(nil, "error", "cellfy", "fatal error, there is not even one valid network config");
    end
end

function NetworkConfigReader.CurrentListen(idx)
    return Config.NetworkConfig.Listen:get(idx or 1);
end

function NetworkConfigReader.CurrentConfig()
    if not current_config then
        LOG.std(nil, "error", "cellfy", "current_config invalid, something bad is gonna happen");
    end
    return current_config;
end

function NetworkConfigReader.CurrentVersionServer(idx)
    return NetworkConfigReader.CurrentConfig().version:get(idx or 1);
end

function NetworkConfigReader.CurrentServerListServer(idx)
    return NetworkConfigReader.CurrentConfig().serverlist:get(idx or 1);
end
