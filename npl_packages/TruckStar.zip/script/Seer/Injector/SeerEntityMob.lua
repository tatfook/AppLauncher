--[[
    Title: SeerEntityMob
    Author(s): Cellfy
    Date: 2016/05/06
    Desc: EntityMob extension. 
    A Injector class.
    Injection Target: MyCompany.Aries.Game.EntityManager.EntityMob
    use the lib:
    -------------------------------------------------------
    NPL.load("(gl)script/apps/Aries/Creator/Game/Entity/EntityMob.lua");
    NPL.load("(gl)script/Seer/Injector/SeerEntityMob.lua");
    local EntityMob = commonlib.gettable("MyCompany.Aries.Game.EntityManager.EntityMob")
    local SeerEntityMob = commonlib.gettable("Mod.Seer.Injector.SeerEntityMob");
    Inject(SeerEntityMob, EntityMob);
    -------------------------------------------------------
]]

NPL.load("(gl)script/Seer/Utility/StringTools.lua");

local StringTools = commonlib.gettable("Mod.Seer.Utility.StringTools");

local SeerEntityMob = commonlib.gettable("Mod.Seer.Injector.SeerEntityMob");

function SeerEntityMob:SetCharacterAsset(asset_id)
    asset_id = tonumber(asset_id);
    if asset_id then
        local ItemReader = commonlib.gettable("Mod.Seer.Config.ItemReader");
        local assetInfo = ItemReader.GetAssetInfoByID(asset_id);
        if assetInfo then
            self:SetMainAssetPath(assetInfo.model);
            self.AssetID = asset_id;
            if StringTools.Valid(assetInfo.texture) then
                self:SetSkin(assetInfo.texture);
            else
                self:SetSkin(nil);
            end
        end
    end
end
