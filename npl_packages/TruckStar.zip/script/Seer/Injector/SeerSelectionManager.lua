--[[
    Title: SeerSelectionManager
    Author(s): Devil
    Date: 2016/05/19
    Desc: SelectionManager extension. 
    A Injector class.
    Injection Target: MyCompany.Aries.Game.Network.ServerManager
    use the lib:
    -------------------------------------------------------
    NPL.load("(gl)script/apps/Aries/Creator/Game/SceneContext/SelectionManager.lua");
    NPL.load("(gl)script/Seer/Injector/SeerSelectionManager.lua");
    local SelectionManager = commonlib.gettable("MyCompany.Aries.Game.SelectionManager");
    local SeerSelectionManager = commonlib.gettable("Mod.Seer.Injector.SeerSelectionManager");
    Inject(SeerSelectionManager, SelectionManager);
    -------------------------------------------------------
]]
NPL.load("(gl)script/apps/Aries/Creator/Game/SceneContext/SelectionManager.lua");
local GameLogic = commonlib.gettable("MyCompany.Aries.Game.GameLogic")
local CameraController = commonlib.gettable("MyCompany.Aries.Game.CameraController")
local BlockEngine = commonlib.gettable("MyCompany.Aries.Game.BlockEngine")
local UndoManager = commonlib.gettable("MyCompany.Aries.Game.UndoManager");
local EntityManager = commonlib.gettable("MyCompany.Aries.Game.EntityManager");
local GameMode = commonlib.gettable("MyCompany.Aries.Game.GameLogic.GameMode");
local CommandManager = commonlib.gettable("MyCompany.Aries.Game.CommandManager");
local block_types = commonlib.gettable("MyCompany.Aries.Game.block_types")
local SeerSelectionManager = commonlib.gettable("Mod.Seer.Injector.SeerSelectionManager");
-- @param bPickBlocks, bPickPoint, bPickObjects: default to true
-- return result;
function SeerSelectionManager:MousePickBlock(bPickBlocks, bPickPoint, bPickObjects, picking_dist)
	self:ClearPickingResult();
	
	local filter;
	local eye_pos = ParaCamera.GetAttributeObject():GetField("Eye position", {0,0,0});
	local result=self.result;
	picking_dist = picking_dist or self:GetPickingDist();
	-- pick blocks
	if(bPickBlocks~=false) then
		result = ParaTerrain.MousePick(picking_dist, result, 0xffffffff);
		if(result.blockX) then
			result.block_id = ParaTerrain.GetBlockTemplateByIdx(result.blockX,result.blockY,result.blockZ);
			if(result.block_id > 0) then
				local block = block_types.get(result.block_id);
				if(not block) then
					-- remove blocks for non-exist blocks
					LOG.std(nil, "warn", "MousePick", "non-exist block detected with id %d", result.block_id);
					BlockEngine:SetBlock(result.blockX,result.blockY,result.blockZ, 0);
				elseif(block.material:isLiquid() and (not GameLogic.GetBlockInRightHand() or not block_types.get(GameLogic.GetBlockInRightHand()) or block_types.get(GameLogic.GetBlockInRightHand()).class~="BlockLilypad")) then
					-- if we are picking a liquid object, we discard it and pick again for solid or obstruction or customModel object. 
					result = ParaTerrain.MousePick(picking_dist, result, 0x85);
					if(result.blockX) then
						result.block_id = ParaTerrain.GetBlockTemplateByIdx(result.blockX,result.blockY,result.blockZ);
					end
				end
			end
			local root_ = ParaUI.GetUIObject("root");
			local mouse_pos = root_:GetAttributeObject():GetField("MousePosition", {0,0});
		end
	end

	-- pick any point (like terrain and phyical mesh)
	if(bPickPoint~=false) then
		local pt = ParaScene.MousePick(picking_dist, "point");
		if(pt:IsValid())then
		
			local x, y, z = pt:GetPosition();
			local blockX, blockY, blockZ = BlockEngine:block(x,y+0.1,z); -- tricky we will slightly add 0.1 to y value. 
		
			local length = math.sqrt((eye_pos[1] - x)^2 + (eye_pos[2] - y)^2 + (eye_pos[3] - z)^2);
		
			if(not result.length or (result.length>=picking_dist) or (result.length > length)) then
				result.length = length;
				result.x, result.y, result.z = x, y, z;
				result.blockX, result.blockY, result.blockZ = blockX, blockY-1, blockZ;
				result.side = 5;
				result.block_id = nil;
				local entityName = pt:GetName();
				if(entityName) then
					local bx, by, bz = entityName:match("^(%d+),(%d+),(%d+)$");
					if(bx and by and bz) then
						bx = tonumber(bx);
						by = tonumber(by);
						bz = tonumber(bz);
						local entity = BlockEngine:GetBlockEntity(bx, by, bz);
						if(entity) then
							result.entity = entity;
							result.block_id = result.block_id or entity:GetBlockId();
							result.blockY = blockY; -- restore blockY-1 in case terrain point is picked. 
						end
					end
          --add by devilwalk,furniture use physical mesh but is not a block
          if not result.entity then
            local entity=EntityManager.GetEntity(entityName);
            if entity then
              result.entity=entity;
              result.obj=entity:GetInnerObject();
              result.blockY = blockY; -- restore blockY-1 in case terrain point is picked. 
            end
          end
				end
			end
		end
	end

	-- pick any scene object
	if(bPickObjects~=false) then
		local obj_filter;
		local obj = ParaScene.MousePick(result.length or picking_dist, "anyobject"); 
		if(not obj:IsValid() or obj.name == "_bm_") then
			-- ignore block custom model
			obj = nil;
		else
			result.obj = obj;
			local x, y, z = obj:GetPosition();
			local length = math.sqrt((eye_pos[1] - x)^2 + (eye_pos[2] - y)^2 + (eye_pos[3] - z)^2);
			--if(not result.length or result.length > length) then
				result.length = length;
				result.x, result.y, result.z = x, y, z;
				local blockX, blockY, blockZ = BlockEngine:block(x,y+0.1,z); -- tricky we will slightly add 0.1 to y value. 
				result.blockX, result.blockY, result.blockZ = blockX, blockY-1, blockZ;
				result.side = 5;
				result.block_id = nil;
			--end
			result.entity = EntityManager.GetEntityByObjectID(obj:GetID());
		end
	end
	return result;
end
