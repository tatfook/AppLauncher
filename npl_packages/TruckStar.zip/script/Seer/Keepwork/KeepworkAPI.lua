local KeepworkAPI = NPL.export();

local domain = "http://keepwork.com";

--debug
--local domain = "http://dev.keepwork.com";

KeepworkAPI.user = {};
KeepworkAPI.website = {};
KeepworkAPI.oauth_app = {};
-- user
local function geturl(para, callback, func, retry)
    NPL.GetURL(para, function (code, msg, data)
        if code ~= 200 then
            LOG.std("KeepworkAPI","error",func,"return code: %d", code);
            if code == 0 and retry and retry > 0 then
                LOG.std("KeepworkAPI", "warning", func, "retry %s", func );
                geturl(para, callback, func, retry - 1);
                return;
            end
        end
        callback(data, code ~= 200);
    end)
end

function KeepworkAPI.getDomain()
    return domain;
end

-- account can be username, email, telnumber
function KeepworkAPI.user.login(account, password, callback, retry)
    local para = 
    {
        url = domain .. "/api/wiki/models/user/login",
        json = true,
        form = 
        {
            username = account,
            password = password,
        }
    }
    geturl(para, callback, "login", retry);
end

function KeepworkAPI.user.register(username, password, callback)   
    local para = 
    {
        url = domain .. "/api/wiki/models/user/register",
        json = true,
        form = 
        {
            username = username, 
            password = password,
        },
    }
    geturl(para, callback, "register");
end


-- oauth
function KeepworkAPI.oauth_app.agreeOauth(username,authorization, callback)
    local para = 
    {
        url = domain .. "/api/wiki/models/oauth_app/agreeOauth",
        json = true,
        headers = 
        {
            Authorization = authorization,
        },
        form = 
        {
            username = username,
            client_id = 1000004,
        },
    }

    geturl(para, callback, "agreeOauth");
end


-- website
--[[
form =
{
    categoryId,
    categoryName,
    desc,
    displayName,        - required
    domain,
    logoUrl,
    name,               - required
    styleId,
    styleName,      
    templateId,
    templateName,
    userId,             - required
    username,           - required
}
]]
function KeepworkAPI.website.new(form, authtoken, callback)
    local para = 
    {
        url = domain .. "/api/wiki/models/website/new",
        json = true,
        headers = 
        {
            Authorization = authtoken,
        },
        form = form,
    }
    geturl(para, callback, "new");
end

function KeepworkAPI.website.getDetailInfo(username, sitename, authtoken, callback)
    local para = 
    {
        url = domain .. "/api/wiki/models/website/getDetailInfo",
        json = true,
        headers = {Authorization = authtoken},
        form = 
        {
            username = username,
            sitename = sitename,
        },
    }
    geturl(para, callback, "getDetailInfo");
end