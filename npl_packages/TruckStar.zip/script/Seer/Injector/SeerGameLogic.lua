--[[
    Title: SeerGameLogic
    Author(s): Cellfy
    Date: 2016/03/31
    Desc: GameLogic extension. 
    A Injector class.
    Injection Target: MyCompany.Aries.Game.GameLogic
    use the lib:
    -------------------------------------------------------
    NPL.load("(gl)script/apps/Aries/Creator/Game/game_logic.lua");
    NPL.load("(gl)script/Seer/Injector/SeerGameLogic.lua");
    local GameLogic = commonlib.gettable("MyCompany.Aries.Game.GameLogic")
    local SeerGameLogic = commonlib.gettable("Mod.Seer.Injector.SeerGameLogic");
    Inject(SeerGameLogic, GameLogic);
    -------------------------------------------------------
]]

local SeerGameLogic = commonlib.gettable("Mod.Seer.Injector.SeerGameLogic");

--@param player_name: nil for current controlling player
--@param asset_id: id of the character asset
function SeerGameLogic.ChangeCharacterAsset(player_name, asset_id, bBroadCast)
    local player = MyCompany.Aries.Game.EntityManager.GetPlayer(player_name);
    if player then
        player:SetCharacterAsset(asset_id, bBroadCast);
    end
end
