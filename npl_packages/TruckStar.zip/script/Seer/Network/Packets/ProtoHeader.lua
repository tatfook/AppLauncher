--[[
	NPL.load("(gl)script/Seer/Network/Packets/ProtoHeader.lua");
]]
NPL.load("(gl)script/Seer/pb/error_code_pb.lua");
NPL.load("(gl)script/Seer/pb/base_define_pb.lua");
NPL.load("(gl)script/Seer/pb/base_attribute_pb.lua")
NPL.load("(gl)script/Seer/pb/cs_attribute_id_pb.lua");

--include protcol files-----------------------------------
NPL.load("(gl)script/Seer/Network/Packets/error_code.proto.lua");
NPL.load("(gl)script/Seer/Network/Packets/game.proto.lua");
NPL.load("(gl)script/Seer/Network/Packets/cs_basic.proto.lua");
NPL.load("(gl)script/Seer/Network/Packets/cs_chat_system.proto.lua");
NPL.load("(gl)script/Seer/Network/Packets/cs_storage.proto.lua");
NPL.load("(gl)script/Seer/Network/Packets/update_resource.proto.lua");
NPL.load("(gl)script/Seer/Network/Packets/cs_room.proto.lua");
NPL.load("(gl)script/Seer/Network/Packets/server_list.proto.lua");
NPL.load("(gl)script/Seer/Network/Packets/cs_custom.proto.lua");
NPL.load("(gl)script/Seer/Network/Packets/cs_shop.proto.lua");
NPL.load("(gl)script/Seer/Network/Packets/cs_item.proto.lua");
NPL.load("(gl)script/Seer/Network/Packets/mail.proto.lua");
NPL.load("(gl)script/Seer/Network/Packets/cs_resource_platform.proto.lua");

