--[[
    Title: GlobalMessageDispatcher
    Author(s): Devil
    Date: 2016/06/14
    Desc: Seer Global Message Dispatcher
    use the lib:
    ------------------------------------------------------------
    NPL.load("(gl)script/Seer/Utility/GlobalMessageDispatcher.lua");
    local GlobalMessageDispatcher=commonlib.gettable("Mod.Seer.Utility.GlobalMessageDispatcher");
    -------------------------------------------------------
]]
NPL.load("(gl)script/Seer/Utility/MessageSource.lua");
local lGlobalMessageSource=Mod.Seer.Utility.MessageSource:new();
local GlobalMessageDispatcher=commonlib.gettable("Mod.Seer.Utility.GlobalMessageDispatcher");
function GlobalMessageDispatcher.getMessageSource()
  return lGlobalMessageSource;
end
function GlobalMessageDispatcher.getDefaultMessageOrder()
  return 100;
end
---------------------------------------------------message--------------------------------------
function GlobalMessageDispatcher.getMessage_UnreadMessageEnableChange()
  return 0;
end
function GlobalMessageDispatcher.getMessage_EntityPlayerConstruction()
  return 1;
end
function GlobalMessageDispatcher.getMessage_ServerResponse()
  return 2;
end
function GlobalMessageDispatcher.getMessage_AssetModuleInitialize()
  return 3;
end
function GlobalMessageDispatcher.getMessage_ShaderLevelChange()
  return 4;
end
function GlobalMessageDispatcher.getMessage_GamingRoomInfo_RemoveAllPlayer()
  return 5;
end