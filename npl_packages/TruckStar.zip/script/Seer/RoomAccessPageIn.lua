
NPL.load("(gl)script/Seer/Game/MultiPlayer/RoomPermission.lua");
local RoomPermission = commonlib.gettable("Mod.Seer.Game.MultiPlayer.RoomPermission");

local UIManager = commonlib.gettable("Mod.Seer.Game.UI.UIManager");

local UIBase = commonlib.gettable("Mod.Seer.Game.UI.UIBase");
local RoomAccessPageIn = commonlib.inherit(UIBase,commonlib.gettable("Mod.Seer.RoomAccessPageIn"));
NPL.load("(gl)script/Seer/Utility/CommonUtility.lua");
local CommonUtility = commonlib.gettable("Mod.Seer.Utility.CommonUtility");
if CommonUtility:IsMobilePlatform() then
	UIManager.registerUI("RoomAccessPageIn", RoomAccessPageIn,"script/Seer/RoomAccessPageIn.html",
	{
	});
else
	UIManager.registerUI("RoomAccessPageIn", RoomAccessPageIn,"script/Seer/RoomAccessPageIn.PC.html",
	{
	});
end
local lroomAccessList = {}
local callback = nil
local lstates = nil
function RoomAccessPageIn:onCreate(paras)
	lroomAccessList = paras.accessInfo
	callback = paras.callback
	if paras.accessInfo and paras.accessInfo.states then
		local s = commonlib.copy(paras.accessInfo.states)
		lstates = RoomPermission:new():init(s)
	else
		lstates = RoomPermission:new()
	end
	self:refresh()
end


function RoomAccessPageIn:CheckOpenFly()
	if lstates and lstates:has("toggleFly") then
		return true
	end
	return false
end
function RoomAccessPageIn:OnOpenFly()
	if self:CheckOpenFly() then
		lstates:remove("toggleFly")
	else
		lstates:add("toggleFly")
	end
end
function RoomAccessPageIn:CheckOpenTeleport()
	if lstates and lstates:has("teleport") then
		return true
	end
	return false
end
function RoomAccessPageIn:OnOpenTeleport()
	if self:CheckOpenTeleport() then
		lstates:remove("teleport")
	else
		lstates:add("teleport")
	end
end
function RoomAccessPageIn:CheckOpenEdit()
	if lstates and lstates:has("edit") then
		return true
	end
	return false
end
function RoomAccessPageIn:OnOpenEdit()
	if self:CheckOpenEdit() then
		lstates:remove("edit")
	else
		lstates:add("edit")
	end
end

function RoomAccessPageIn:CheckOpenTools()
	if lstates and lstates:has("useTools") then
		return true
	end
	return false
end
function RoomAccessPageIn:OnOpenTools()
	if self:CheckOpenTools() then
		lstates:remove("useTools")
		lstates:remove("useToolsFriends")
	else
		lstates:add("useTools")
		lstates:remove("useToolsFriends")
	end
end

function RoomAccessPageIn:OnEditBlockAccess()
	local callback = function (list)
		lstates = RoomPermission:new():init(list.states)
		lroomAccessList = list
	end
	lroomAccessList.states = lstates:getData()
	UIManager.createUI("RoomBlockAccessPage",self,nil,{accessInfo = lroomAccessList,callback=callback});
end

function RoomAccessPageIn:OnCancel()
	self:close()
end
function RoomAccessPageIn:OnConfirm()
	if callback then
		lroomAccessList.states = lstates:getData()
		callback(lroomAccessList)
	end
	self:close()
end