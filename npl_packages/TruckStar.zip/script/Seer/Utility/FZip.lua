--[[
NPL.load("(gl)script/Seer/Utility/FZip.lua");
local FZip = commonlib.gettable("Mod.Seer.Utility.FZip");
]]
NPL.load("(gl)script/Seer/Utility/IOUtility.lua");
local IOUtility = commonlib.gettable("Mod.Seer.Utility.IOUtility");

NPL.load("(gl)script/Seer/Utility/qiniuHash.lua");
local QiniuHash = commonlib.gettable("Mod.Seer.Utility.QiniuHash");

NPL.load("(gl)script/Seer/Utility/StringTools.lua");
local StringTools = commonlib.gettable("Mod.Seer.Utility.StringTools");

local FZip = commonlib.gettable("Mod.Seer.Utility.FZip");

function FZip.ZipFileAndHash(filePath)
	local zipPath = filePath..".zip"
	local zipFile = ParaIO.CreateZip(zipPath,"")

	local fileName = StringTools.StripFilename(filePath) 

	local ret = zipFile:ZipAdd(fileName,filePath);
	if (ret ~= 0 ) then
		return nil;
	end

	zipFile:close()
	local hash = ""
	local file = ParaIO.open(zipPath,"r");
	if (file) then
		hash = QiniuHash.hash(file);
		file:close()
	end
	return hash
end

function FZip.UnZipFile(filePath)
	return IOUtility.UnZipToSameFolder(filePath);
end

