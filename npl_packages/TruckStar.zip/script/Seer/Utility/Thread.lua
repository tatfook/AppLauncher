--[[
	NPL.load("(gl)script/Seer/Utility/Thread.lua");
    local ThreadPool = commonlib.gettable("Mod.Seer.Utility.ThreadPool");
    ThreadPool.init();
  
    -- see more in Future.lua
]]

NPL.load("(gl)script/ide/commonlib.lua");

local Thread = commonlib.inherit(nil, {class_name = "Thread"});
local ThreadPool = commonlib.gettable("Mod.Seer.Utility.ThreadPool");

local Queue = commonlib.gettable("commonlib.Queue");
local tasks ;

Thread.Working = 1;
Thread.Waitting = 2;


local function activate(from, to ,type, data)
    NPL.activate(format("(%s)%s", to, "script/Seer/Utility/Thread.lua"), {from = from, to = to, type = type, data = data})
end

local function call(func, params)
    local index = #params + 1;
    local function get()
        index = index - 1;
        if index <= 0 then
            return nil
        else
            return params[index];
        end
    end

    local function parse(...)
        local val = get();
        if val ~= nil then
            return parse(val, ...);
        else
            return func(...);
        end
    end
    return parse(get());
end

-- Thread
function Thread:ctor()
    self.runtime = NPL.CreateRuntimeState(self.id, 0);
    self.runtime:Start();
    self.state = Thread.Waitting;
end

function Thread:delete()
    NPL.DeleteRuntimeState(self.runtime);
    self.runtime = nil;
end

function Thread:activate(func, params, callback)
    activate("main", self.id, "start", {func, params});
    self.callback = callback;
    self.state = Thread.Working;
    callback("start", self);
end

function Thread:setValue(name, value)
    activate("main", self.id, "setvalue", {name, value})
end

function Thread:getValue(name)
    activate("main", self.id, "getvalue", {name})
end


function Thread:this(type,data)
    if type == "complete" then
        if self.callback then
            self.callback(type);
            self.callback = nil;
        end
        self.state = Thread.Waitting;

        if tasks:empty() then
            return 
        end
        local task = tasks:pop();
        self:activate(task[1], task[2],task[3])
    elseif type == "setvalue" then
        self.callback(type, data);
    end
end


-- ThreadPool
local pool = {};
function ThreadPool.init(count)
    local threadcount = count or 4;
    for i = 1, threadcount do
        local id = "diligent_worker_" .. i;
        pool[id] = Thread:new({id = id});
    end
    tasks = Queue:new();
end

function ThreadPool.addTask(task, params, callback)
    tasks:push({task, params, callback});
    ThreadPool.notifyNewTask();
end

function ThreadPool.notifyNewTask()
    for k,v in pairs(pool) do
        if v.state == Thread.Waitting then
            if tasks:empty() then
                return 
            end
            local task = tasks:pop();
            v:activate(task[1], task[2],task[3]);            
        end
    end
end

NPL.this(function ()
    local msg = msg;
    local dst = msg.to;
    local src = msg.from;
    local type = msg.type;
    local data = msg.data;
    local setvalue = function (name, value) activate(dst, src,"setvalue", {name, value}); end

    if type == "start" then
        local str = data[1];
        local params = data[2];
        local result;
        if string.match(str, "^.+%.lua$") then
            local func = NPL.load(format("(%s)%s", dst, str));
            result = {call(func, params)}; 
        else
            local codefunc, err = loadstring(str, "function");
            if err then
                error(err);
                return
            end
            local ok, func = pcall(codefunc);
            if not ok then
                error(func);
                return;
            end

            result = {call(func, params)};
        end
        
        setvalue("_result", result);
        activate(dst, src,"complete");
    elseif type == "complete" then
        pool[src]:this(type, data)
    elseif type == "setvalue" then
        if src == "main" then
            _G[data[1]] = data[2];
        else
            pool[src]:this(type, data)
        end
    elseif type == "getvalue" then
        if src == "main" then
            setvalue(data[1], {_G[data[1]]});
        else

        end
    end

end)