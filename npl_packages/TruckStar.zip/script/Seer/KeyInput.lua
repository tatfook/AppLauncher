﻿--[[
    Title: Seer Mod KeyInput
    Author(s): ZhouXing
    Date: 2015/6/19
    Desc: Seer Mod KeyInput
    use the lib:
    ------------------------------------------------------------
    NPL.load("(gl)script/Seer/KeyInput.lua");
    local KeyInput = commonlib.gettable("Mod.Seer.KeyInput");
    ------------------------------------------------------------
]]
NPL.load("(gl)script/Seer/ChatWindow.lua");
NPL.load("(gl)script/apps/Aries/Creator/Game/GUI/TeleportListPage.lua");
NPL.load("(gl)script/apps/Aries/Creator/Game/Tasks/TeleportPlayerTask.lua");
NPL.load("(gl)script/apps/Aries/Creator/Game/Tasks/UndoManager.lua");
NPL.load("(gl)script/apps/Aries/Creator/Game/World/CameraController.lua");
NPL.load("(gl)script/Seer/UIPage.lua");
NPL.load("(gl)script/apps/Aries/Creator/Game/Areas/QuickSelectBar.lua");
NPL.load("(gl)script/ide/AudioEngine/AudioEngine.lua");
NPL.load("(gl)script/Seer/Settings.lua");
NPL.load("(gl)script/Seer/Game/UI/UIManager.lua");
NPL.load("(gl)script/Seer/Game/UI/UIHeader.lua");

local UIManager= commonlib.gettable("Mod.Seer.Game.UI.UIManager");
local Settings = commonlib.gettable("Mod.Seer.Settings");
local AudioEngine = commonlib.gettable("AudioEngine");
local CameraController = commonlib.gettable("MyCompany.Aries.Game.CameraController");
local ChatEdit = commonlib.gettable("MyCompany.Aries.ChatSystem.ChatEdit");
local EventHandler = commonlib.gettable("MyCompany.Aries.Creator.Game.EventHandler")
local GameLogic = commonlib.gettable("MyCompany.Aries.Game.GameLogic");
local TeleportListPage = commonlib.gettable("MyCompany.Aries.Game.GUI.TeleportListPage");
local UndoManager = commonlib.gettable("MyCompany.Aries.Game.UndoManager");
local UIPage = commonlib.gettable("Mod.Seer.UI.Page");
local QuickSelectBar = commonlib.gettable("MyCompany.Aries.Creator.Game.Desktop.QuickSelectBar");



local KeyInput = commonlib.gettable("Mod.Seer.KeyInput");

function KeyInput.handleKeyEventCommon(event)
    local virtual_key = event.virtual_key;
    local dik_key = event.keyname;
    local ctrl_pressed = event.ctrl_pressed;
    local alt_pressed = event.alt_pressed;
    local shift_pressed = event.shift_pressed;

    if(dik_key == "DIK_F1") then
        AudioEngine.PlayUISound("panel_show");
        NPL.load("(gl)script/Seer/HelpPage.lua");
        local HelpPage = commonlib.gettable("Mod.Tasks.HelpPage");
        HelpPage.ShowPage();
	elseif(dik_key == "DIK_F1") then
        AudioEngine.PlayUISound("panel_show");
        NPL.load("(gl)script/Seer/HelpPage.lua");
        local HelpPage = commonlib.gettable("Mod.Tasks.HelpPage");
        HelpPage.ShowPage();
	else

		if(not System.options.IsMobilePlatform) then
			-- For Numeric key 1-9
			local key_index = event.keyname:match("^DIK_(%d)");
			if(key_index) then
				key_index = tonumber(key_index);
				--NPL.load("(gl)script/Seer/QuickSelectBar.lua");
				--local QuickSelectBar = commonlib.gettable("Mod.Seer.UI.QuickSelectBar");
				GameLogic.GetPlayerController():OnClickHandToolIndex(key_index);
				event:accept();
				return true;
			end
		end

		return false;
	end
	event.accepted = true;
	return true;
end
