
NPL.load("(gl)script/Seer/pb/cs_storage_pb.lua");
NPL.load("(gl)script/Seer/Network/Packets/PacketPbHelper.lua");
local PacketPbHelper = commonlib.gettable("Mod.Seer.Network.Packets.PacketPbHelper");


--[[
//获取关于上传下载空间域名信息
--]]
function PacketPbHelper.sendCSGetStorageInfoReq(userid, callback)
	PacketPbHelper.send("CSGetStorageInfoReq", {uid=userid, channel=0, },callback)
end

--[[
//获取存档全部文件信息
--]]
function PacketPbHelper.sendCSGetCraftFileListReq(resourceid, id, userid, mode, callback, errcallback)
	PacketPbHelper.send("CSGetCraftFileListReq", {resource_id=resourceid, global_craft_uid = id, owner_uid=userid, owner_channel=0, mode=mode},callback,errcallback)
end
--[[
//获取下载Token
--]]
function PacketPbHelper.sendCSGetDownloadTokenReq(resourceid,id, fileinfo,callback)
	return PacketPbHelper.send("CSGetDownloadTokenReq",
		{resource_id=resourceid,file_info=fileinfo,global_craft_uid=id},
		callback);
end

function PacketPbHelper.sendCSStartUploadTokenReq(resourceid, id, filecount, callback)
	return PacketPbHelper.send("CSStartUploadTokenReq", {resource_id = resourceid, global_craft_uid = id, file_number = filecount},callback);
end

--[[
//获取上传的Token
--]]
function PacketPbHelper.sendCSGetUploadTokenReq(resourceid, id, fileinfo, callback)
	return PacketPbHelper.send("CSGetUploadTokenReq",
		{resource_id=resourceid, global_craft_uid=id, file_info=fileinfo},
		callback);
end
--[[
//创建新的星球
--]]
function PacketPbHelper.sendCSCreateNewCraftReq(worldid, worldname,  callback,errcallback)
	PacketPbHelper.send("CSCreateNewCraftReq",
		{resource_id=worldid, craft_name=worldname,},
		callback,errcallback);
end
--[[
//删除新球
--]]
function PacketPbHelper.sendCSDeleteCraftReq(id,callback)
	PacketPbHelper.send("CSDeleteCraftReq",{global_craft_uid=id},callback)
end

--进入星球通知
function PacketPbHelper.sendCSEntryCraftNtf(id,mode,owner_uid)
	PacketPbHelper.send("CSEntryCraftNtf", {global_craft_uid = id,mode = mode,owner_uid = owner_uid})
end

--离开星球通知
function PacketPbHelper.sendCSLeaveCraftNtf(id,mode,owner_uid)
	PacketPbHelper.send("CSLeaveCraftNtf", {global_craft_uid = id,mode = mode,owner_uid = owner_uid})
end

--[[
	参观部分协议
]]

function PacketPbHelper.sendCSGetAllCraftInfoReq(userid, mode, callback)
	PacketPbHelper.send("CSGetAllCraftInfoReq", {uid=userid, channel = 0, mode = mode,}, callback);
end
--[[
	星球权限设置
--]]
function PacketPbHelper.sendCSSetCraftViewStatusReq(id, viewStatus, callback)
	PacketPbHelper.send("CSSetCraftViewStatusReq", {global_craft_uid = id, view_status = viewStatus}, callback);
end

--[[
	评论星球
--]]
function PacketPbHelper.sendCSReviewCraftReq(owner_uid, id, type,review_op,callback, errCallback)
	PacketPbHelper.send("CSReviewCraftReq", {owner_uid = owner_uid,owner_channel = 0,global_craft_uid= id, type = type,review_op = review_op}, callback, errCallback);
end

--[[
	判断用户是否已经点赞
--]]
function PacketPbHelper.sendCSIsReviewCraftReq(owner_uid, id, type,callback)
	PacketPbHelper.send("CSIsReviewCraftReq", {owner_uid = owner_uid,owner_channel = 0,global_craft_uid = id, review_type = type}, callback);
end

--[[
	获取星球详细信息
--]]
function PacketPbHelper.sendCSGetCraftDetailReq(id,owner_uid,callback,errcallback)
	PacketPbHelper.send("CSGetCraftDetailReq", {global_craft_uid = id,owner_uid = owner_uid,owner_channel = 0}, callback,errcallback);
end

--[[
	检测是否能够参观星球
--]]
function PacketPbHelper.sendCSIsVisitCraftReq(id,owner_uid,callback)
	PacketPbHelper.send("CSIsVisitCraftReq", {global_craft_uid = id,owner_uid = owner_uid,owner_channel = 0}, callback);
end

function PacketPbHelper.sendCSGetStorageVersionReq(id,callback)
	PacketPbHelper.send("CSGetStorageVersionReq", {global_craft_uid = {id}}, callback);
end

--获取星球排行榜信息
function PacketPbHelper.sendCSGetCraftRankingReq(mode,time_mode,callback,errcallback)
	PacketPbHelper.send("CSGetCraftRankingReq", {mode = mode,time_mode = time_mode}, callback,errcallback);
end

function PacketPbHelper.sendCSGetGlobalCraftIDReq(resourceid,callback, err)
	PacketPbHelper.send("CSGetGlobalCraftIDReq", {res_id = resourceid}, callback, err)
end