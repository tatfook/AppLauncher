--[[
Title: Quick SelectBar
Author(s): WangXiXi
Date: 2015/5/18
Desc: Quick SelectBar
use the lib:
------------------------------------------------------------
NPL.load("(gl)script/Seer/QuickSelectBar.lua");
local QuickSelectBar = commonlib.gettable("Mod.Seer.UI.QuickSelectBar");
-------------------------------------------------------
]]
NPL.load("(gl)script/apps/Aries/Creator/Game/GameRules/GameMode.lua");
local gameMode = commonlib.gettable("MyCompany.Aries.Game.GameLogic.GameMode");

NPL.load("(gl)script/apps/Aries/Creator/Game/Tasks/SelectBlocksTask.lua");
local selectBlocks = commonlib.gettable("MyCompany.Aries.Game.Tasks.SelectBlocks");

NPL.load("(gl)script/apps/Aries/Creator/Game/Tasks/UndoManager.lua");
local undoManager = commonlib.gettable("MyCompany.Aries.Game.UndoManager");

NPL.load("(gl)script/ide/AudioEngine/AudioEngine.lua");
local AudioEngine = commonlib.gettable("AudioEngine");

local GameLogic = commonlib.gettable("MyCompany.Aries.Game.GameLogic")

NPL.load("(gl)script/Seer/Utility/GlobalMessageDispatcher.lua");
local GlobalMessageDispatcher=commonlib.gettable("Mod.Seer.Utility.GlobalMessageDispatcher");

NPL.load("(gl)script/Seer/Game/MultiPlayer/GamingRoomInfo.lua");
local GamingRoomInfo = commonlib.gettable("Mod.Seer.Game.MultiPlayer.GamingRoomInfo");

NPL.load("(gl)script/Seer/Game/Friend/FriendManager.lua");
local FriendManager = commonlib.gettable("Mod.Seer.Game.Friend.FriendManager");

local QuickSelectBar = commonlib.inherit(commonlib.gettable("Mod.Seer.Game.UI.UIBase"),commonlib.gettable("Mod.Seer.UI.QuickSelectBar"));

NPL.load("(gl)script/Seer/Game/UI/UIManager.lua");
local UIManager = commonlib.gettable("Mod.Seer.Game.UI.UIManager");

NPL.load("(gl)script/seer/Utility/CommonUtility.lua");
local CommonUtility = commonlib.gettable("Mod.Seer.Utility.CommonUtility");

if CommonUtility:IsMobilePlatform() then

UIManager.registerUI("QuickSelectBar",QuickSelectBar,"script/Seer/QuickSelectBar.html", 
{
	isShowTitleBar = false,
	DestroyOnClose = true,
	bToggleShowHide=true, 
	style = CommonCtrl.WindowFrame.ContainerStyle,
	allowDrag = false,
	enable_esc_key = false,
	cancelShowAnimation = true,
	click_through = false, 
	directPosition = true,
	align = "_ctb",
	x = -60,
	y = 0,
	width = 1080,
	height = 130,
});

else

UIManager.registerUI("QuickSelectBar",QuickSelectBar,"script/Seer/QuickSelectBar.PC.html", 
{
	isShowTitleBar = false,
	DestroyOnClose = true,
	bToggleShowHide=true, 
	style = CommonCtrl.WindowFrame.ContainerStyle,
	allowDrag = false,
	enable_esc_key = false,
	cancelShowAnimation = true,
	click_through = false, 
	directPosition = true,
	align = "_ctb",
	x = 0,
	y = -5,
	width = 650,
	height = 80,
});
end

QuickSelectBar.blockWidth = 0;

function QuickSelectBar:ctor()
	self.custombtn_nodes = {
		{},{},{},{},{},{},{},{},{},
	};
	self.toolIndex = 1;
end
function QuickSelectBar:Refresh()
	self.page:Refresh(0.01);
end

function QuickSelectBar:onCreate()
	GameLogic.events:AddEventListener("OnPlayerReplaced", self.OnPlayerReplaced, self, "QuickSelectBar");
	local gridview = self.page:GetNode("quickSelectBar");
	if gridview then
		QuickSelectBar.blockWidth = gridview:GetInt("DefaultNodeWidth", 0);
	end
end

-- inventory changed (example: entityplayer -->  entityplayermpclient)
function QuickSelectBar:OnPlayerReplaced()
	self:refresh();
end

function QuickSelectBar:onDestroy()
	for k,v in pairs(self.children) do
		echo(k)
	end
end

function QuickSelectBar:ds_CustomBtn(index)
    if(not index) then
        return #(self.custombtn_nodes);
    else
        return self.custombtn_nodes[index];
    end
end

function QuickSelectBar:OnClickItem(mcmlNode)
	self:setItem(mcmlNode.slot.slotIndex)
end

function QuickSelectBar:setItem(index)
	if (index <= 0 or index > #self.custombtn_nodes) then
		return
	end
	self.toolIndex = index;
	local EntityManager = commonlib.gettable("MyCompany.Aries.Game.EntityManager");
	local player = EntityManager.GetPlayer();
	if(player) then
		local res = player.inventory:SetHandToolIndex(self.toolIndex, true);
		local itemStack = player:GetItemInRightHand();
		if(itemStack) then
			local item = itemStack:GetItem();
			if(item and item.OnClickInHand) then
				item:OnClickInHand(itemStack, player);
			end
		end
	end
	local ctl = self.page:FindControl("handtool_highlight_bg");
	if(ctl) then
		ctl.x = (self.toolIndex - 1) * QuickSelectBar.blockWidth;
	end
end

function QuickSelectBar:handleKeyEvent(event)
	local key_index = event.keyname:match("^DIK_(%d)");
	if(key_index) then
		key_index = tonumber(key_index);
		self:setItem(key_index);
		event:accept();
		return true;
	end
end

function QuickSelectBar:handleMouseEvent(event)
	local event_type = event:GetType();
		if (event_type == "mouseWheelEvent" ) then
		if (not event.ctrl_pressed) then
			self:setItem(self.toolIndex - event.mouse_wheel);
			event.accepted = true;
		end
	end
end
