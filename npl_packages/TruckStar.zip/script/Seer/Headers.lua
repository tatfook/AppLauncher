--[[
    Title: Seer Mod Headers
    Author(s): Cellfy
    Date: 2016/1/14
    Desc: This is the first chance that mod scripts can get loaded. 
        All Seer scripts that need to be pre-loaded should be put here.
    use the lib:
    ------------------------------------------------------------
    NPL.load("(gl)script/Seer/Headers.lua");
    ------------------------------------------------------------
]]

--load additional resource packages
if System.options.IsMobilePlatform then
    LOG.std(nil, "debug", "truckstar", "truck star mobile");
    for file_index = 100,999 do
        local pkgName = string.format("crate%03d.pkg", file_index);
        if ParaIO.DoesFileExist(pkgName, false) then
            ParaAsset.OpenArchive(pkgName);
        end
    end
else
    LOG.std(nil, "debug", "truckstar", "truck star desktop");
end

--put load scripts here
NPL.load("(gl)script/Seer/Utility/CommonUtility.lua");
NPL.load("(gl)script/Seer/Config/Config.lua");
NPL.load("(gl)script/Seer/Framework/SeerFilters.lua");
NPL.load("(gl)script/apps/Aries/Creator/Game/blocks/block_types.lua");
NPL.load("(gl)script/Seer/Game/UI/UIHeader.lua");
NPL.load("(gl)script/Seer/Framework/Preload.lua");
NPL.load("(gl)script/Seer/Game/World/SeerBuildingTemplateFileManager.lua");
NPL.load("(gl)script/Seer/Utility/UserDatabase.lua");
NPL.load("(gl)script/Seer/Game/Furniture/FurnitureAPI.lua");

local CommonUtility = commonlib.gettable("Mod.Seer.Utility.CommonUtility");

--load config 
local Config = commonlib.gettable("Mod.Seer.Config");
Config.loadAll();
--put initing functions here
local block_types = commonlib.gettable("MyCompany.Aries.Game.block_types")
NPL.load("(gl)script/Seer/Game/Blocks/BlockFBX.lua");
NPL.load("(gl)script/Seer/Game/Blocks/BlockTrampoline.lua");

NPL.load("(gl)script/Seer/Game/Items/ItemFurniture.lua");
block_types.init();
NPL.load("(gl)script/Seer/Game/Entity/EntityCustom.lua");
NPL.load("(gl)script/Seer/Game/Movie/EntityMoviePlayer.lua");
--preload resources
local Preload = commonlib.gettable("Mod.Seer.Framework.Preload");
Preload.load("general");
--init UI
local UIManager = commonlib.gettable("Mod.Seer.Game.UI.UIManager");
UIManager.initialize();
local UI = commonlib.gettable("Mod.Seer.Game.UI");
UI.load(); 
local SeerBuildingTemplateFileManager = commonlib.gettable("Mod.Seer.Game.World.SeerBuildingTemplateFileManager");
SeerBuildingTemplateFileManager.load();
local FurnitureAPI=commonlib.gettable("Seer.Game.Furniture.API");
FurnitureAPI.initializeSystem();
-- user database
local UserDatabase = commonlib.gettable("Mod.Seer.Utility.UserDatabase");
UserDatabase.init();
NPL.load("(gl)script/Seer/Statistics/Statistics.lua");
Statistics = commonlib.gettable("Mod.Seer.Statistics.Statistics");
Statistics.Init("none", true);

-- thread
NPL.load("(gl)script/Seer/Utility/Thread.lua");
NPL.load("(gl)script/Seer/Utility/Future.lua");
local ThreadPool = commonlib.gettable("Mod.Seer.Utility.ThreadPool");
ThreadPool.init();

if CommonUtility.IsDevVersion() then
    NPL.load("(gl)script/Seer/installer/BuildSeerPKG.lua");
    local BuildSeerPKG = commonlib.gettable("Mod.Seer.Installer.BuildSeerPKG");
    BuildSeerPKG.Init();
end

--injection implementation
local function Inject(NewTable, OriginalTable)
    for k,v in pairs(NewTable) do
        local original_v = OriginalTable[k];
        if original_v then
            if type(original_v) == "function" then
                OriginalTable["Original_"..k] = original_v;
            end

            if type(v) ~= type(original_v) then
                LOG.std(nil, "warning", "cellfy", "Seer Injection: \"%s\" hid a different type field of the original table", k);
            end
        end
        OriginalTable[k] = v;
    end

    --[[    
        echo("----------------------------------Injection Result----------------------------------");
        for k,v in pairs(OriginalTable) do
            echo(k);
        end

        for k,v in pairs(NewTable) do
            echo(k)
        end
    ]]
end

local function StartInjection()
    --put injectinos here

    --inject SeerGameMode into GameMode
    NPL.load("(gl)script/apps/Aries/Creator/Game/GameRules/GameMode.lua");
    NPL.load("(gl)script/Seer/Injector/SeerGameMode.lua");
    local GameMode = commonlib.gettable("MyCompany.Aries.Game.GameLogic.GameMode");
    local SeerGameMode = commonlib.gettable("Mod.Seer.Injector.SeerGameMode");
    Inject(SeerGameMode, GameMode);

    --inject SeerBuildParaWorld into BuildParaWorld
    -- NPL.load("(gl)script/installer/BuildParaWorld.lua");
    -- NPL.load("(gl)script/Seer/Injector/SeerBuildParaWorld.lua");
    -- local BuildParaWorld = commonlib.gettable("commonlib.BuildParaWorld");
    -- local SeerBuildParaWorld = commonlib.gettable("Mod.Seer.Injector.SeerBuildParaWorld");
    -- Inject(SeerBuildParaWorld, BuildParaWorld);
    -- BuildParaWorld:InitSeerBuildProfiles();

    --inject SeerGameLogic into GameLogic
    NPL.load("(gl)script/apps/Aries/Creator/Game/game_logic.lua");
    NPL.load("(gl)script/Seer/Injector/SeerGameLogic.lua");
    local GameLogic = commonlib.gettable("MyCompany.Aries.Game.GameLogic")
    local SeerGameLogic = commonlib.gettable("Mod.Seer.Injector.SeerGameLogic");
    Inject(SeerGameLogic, GameLogic);

	--inject SeerGUIChat into GUIChat
	NPL.load("(gl)script/apps/Aries/Creator/Game/GUI/GUIChat.lua");
    NPL.load("(gl)script/Seer/Injector/SeerGUIChat.lua");
	local GUIChat = commonlib.gettable("MyCompany.Aries.Game.GUI.GUIChat");
    local SeerGUIChat = commonlib.gettable("Mod.Seer.Injector.SeerGUIChat");
    Inject(SeerGUIChat, GUIChat);

    --inject SeerEntityMob into EntityMob
    NPL.load("(gl)script/apps/Aries/Creator/Game/Entity/EntityMob.lua");
    NPL.load("(gl)script/Seer/Injector/SeerEntityMob.lua");
    local EntityMob = commonlib.gettable("MyCompany.Aries.Game.EntityManager.EntityMob")
    local SeerEntityMob = commonlib.gettable("Mod.Seer.Injector.SeerEntityMob");
    Inject(SeerEntityMob, EntityMob);

    --inject SeerEntityPlayer into EntityPlayer
    NPL.load("(gl)script/apps/Aries/Creator/Game/Entity/EntityPlayer.lua");
    NPL.load("(gl)script/Seer/Injector/SeerEntityPlayer.lua");
    local EntityPlayer = commonlib.gettable("MyCompany.Aries.Game.EntityManager.EntityPlayer")
    local SeerEntityPlayer = commonlib.gettable("Mod.Seer.Injector.SeerEntityPlayer");
    Inject(SeerEntityPlayer, EntityPlayer);

    --inject SeerEntityPlayerMP into EntityPlayerMP
    NPL.load("(gl)script/apps/Aries/Creator/Game/Entity/EntityPlayerMP.lua");
    NPL.load("(gl)script/Seer/Injector/SeerEntityPlayerMP.lua");
    local EntityPlayerMP = commonlib.gettable("MyCompany.Aries.Game.EntityManager.EntityPlayerMP")
    local SeerEntityPlayerMP = commonlib.gettable("Mod.Seer.Injector.SeerEntityPlayerMP");
    Inject(SeerEntityPlayerMP, EntityPlayerMP);

    --inject SeerEntitySky into EntitySky
    NPL.load("(gl)script/apps/Aries/Creator/Game/Entity/EntitySky.lua");
    NPL.load("(gl)script/Seer/Injector/SeerEntitySky.lua");
    local EntitySky = commonlib.gettable("MyCompany.Aries.Game.EntityManager.EntitySky")
    local SeerEntitySky = commonlib.gettable("Mod.Seer.Injector.SeerEntitySky");
    Inject(SeerEntitySky, EntitySky);
    
    --inject SeerNetClientHandler into NetClientHandler
    NPL.load("(gl)script/apps/Aries/Creator/Game/Network/NetClientHandler.lua");
    NPL.load("(gl)script/Seer/Injector/SeerNetClientHandler.lua");
    local NetClientHandler = commonlib.gettable("MyCompany.Aries.Game.Network.NetClientHandler");
    local SeerNetClientHandler = commonlib.gettable("Mod.Seer.Injector.SeerNetClientHandler");
    Inject(SeerNetClientHandler, NetClientHandler);

    --inject SeerNetServerHandler into NetServerHandler
    NPL.load("(gl)script/apps/Aries/Creator/Game/Network/NetServerHandler.lua");
    NPL.load("(gl)script/Seer/Injector/SeerNetServerHandler.lua");
    local NetServerHandler = commonlib.gettable("MyCompany.Aries.Game.Network.NetServerHandler");
    local SeerNetServerHandler = commonlib.gettable("Mod.Seer.Injector.SeerNetServerHandler");
    Inject(SeerNetServerHandler, NetServerHandler);
    
    --inject SeerServerManager into ServerManager
    NPL.load("(gl)script/apps/Aries/Creator/Game/Network/ServerManager.lua");
    NPL.load("(gl)script/Seer/Injector/SeerServerManager.lua");
    local ServerManager = commonlib.gettable("MyCompany.Aries.Game.Network.ServerManager");
    local SeerServerManager = commonlib.gettable("Mod.Seer.Injector.SeerServerManager");
    Inject(SeerServerManager, ServerManager);
    
    --inject SeerItem into Item
    NPL.load("(gl)script/apps/Aries/Creator/Game/Items/Item.lua");
    NPL.load("(gl)script/Seer/Injector/SeerItem.lua");
    local Item = commonlib.gettable("MyCompany.Aries.Game.Items.Item");
    local SeerItem = commonlib.gettable("Mod.Seer.Injector.SeerItem");
    Inject(SeerItem, Item);

    --inject SeerMobPropertyPage into MobPropertyPage
    NPL.load("(gl)script/apps/Aries/Creator/Game/GUI/MobPropertyPage.lua");
    NPL.load("(gl)script/Seer/Injector/SeerMobPropertyPage.lua");
    local MobPropertyPage = commonlib.gettable("MyCompany.Aries.Game.GUI.MobPropertyPage");
    local SeerMobPropertyPage = commonlib.gettable("Mod.Seer.Injector.SeerMobPropertyPage");
    Inject(SeerMobPropertyPage, MobPropertyPage);

    --inject SeerSelectionManager into SelectionManager
    NPL.load("(gl)script/apps/Aries/Creator/Game/SceneContext/SelectionManager.lua");
    NPL.load("(gl)script/Seer/Injector/SeerSelectionManager.lua");
    local SelectionManager = commonlib.gettable("MyCompany.Aries.Game.SelectionManager");
    local SeerSelectionManager = commonlib.gettable("Mod.Seer.Injector.SeerSelectionManager");
    Inject(SeerSelectionManager, SelectionManager);

    --inject SeerItemSlab into ItemSlab
    NPL.load("(gl)script/apps/Aries/Creator/Game/Items/ItemSlab.lua");
    NPL.load("(gl)script/Seer/Injector/SeerItemSlab.lua");
    local ItemSlab = commonlib.gettable("MyCompany.Aries.Game.Items.ItemSlab");
    local SeerItemSlab = commonlib.gettable("Mod.Seer.Injector.SeerItemSlab");
    Inject(SeerItemSlab, ItemSlab);

    --inject SeerBlockInEntityHandle into BlockInEntityHand
    NPL.load("(gl)script/apps/Aries/Creator/Game/Entity/BlockInEntityHand.lua");
    NPL.load("(gl)script/Seer/Injector/SeerBlockInEntityHandle.lua");
    local BlockInEntityHand = commonlib.gettable("MyCompany.Aries.Game.EntityManager.BlockInEntityHand");
    local SeerBlockInEntityHandle = commonlib.gettable("Mod.Seer.Injector.SeerBlockInEntityHandle");
    Inject(SeerBlockInEntityHandle, BlockInEntityHand);

    --inject SeerBlockTemplateTask into BlockTemplateTask
    NPL.load("(gl)script/apps/Aries/Creator/Game/Tasks/BlockTemplateTask.lua");
    NPL.load("(gl)script/Seer/Injector/SeerBlockTemplateTask.lua");
    local BlockTemplate = commonlib.gettable("MyCompany.Aries.Game.Tasks.BlockTemplate");
    local SeerBlockTemplateTask = commonlib.gettable("Mod.Seer.Injector.SeerBlockTemplateTask");
    Inject(SeerBlockTemplateTask, BlockTemplate);
    
    --inject SeerBlockSlope into BlockSlope
    NPL.load("(gl)script/apps/Aries/Creator/Game/blocks/BlockSlope.lua");
    NPL.load("(gl)script/Seer/Injector/SeerBlockSlope.lua");
    local BlockSlope = commonlib.gettable("MyCompany.Aries.Game.blocks.BlockSlope");
    local SeerBlockSlope = commonlib.gettable("Mod.Seer.Injector.SeerBlockSlope");
    Inject(SeerBlockSlope, BlockSlope);

    --inject SeerEntityManager into EntityManager
    NPL.load("(gl)script/apps/Aries/Creator/Game/Entity/EntityManager.lua");
    NPL.load("(gl)script/Seer/Injector/SeerEntityManager.lua");
    local EntityManager = commonlib.gettable("MyCompany.Aries.Game.EntityManager");
    local SeerEntityManager = commonlib.gettable("Mod.Seer.Injector.SeerEntityManager");
    Inject(SeerEntityManager, EntityManager);

    --inject SeerBlockButton into BlockButton
    NPL.load("(gl)script/apps/Aries/Creator/Game/blocks/BlockButton.lua");
    NPL.load("(gl)script/Seer/Injector/SeerBlockButton.lua");
    local BlockButton = commonlib.gettable("MyCompany.Aries.Game.blocks.BlockButton");
    local SeerBlockButton = commonlib.gettable("Mod.Seer.Injector.SeerBlockButton");
    Inject(SeerBlockButton, BlockButton);

    --inject SeerEntityBlockModel into EntityBlockModel
    NPL.load("(gl)script/apps/Aries/Creator/Game/Entity/EntityBlockModel.lua");
    NPL.load("(gl)script/Seer/Injector/SeerEntityBlockModel.lua");
    local EntityBlockModel = commonlib.gettable("MyCompany.Aries.Game.EntityManager.EntityBlockModel")
    local SeerEntityBlockModel = commonlib.gettable("Mod.Seer.Injector.SeerEntityBlockModel");
    Inject(SeerEntityBlockModel, EntityBlockModel);

    --inject SeerShapeAABB into ShapeAABB
    NPL.load("(gl)script/ide/math/ShapeAABB.lua");
    NPL.load("(gl)script/Seer/Injector/SeerShapeAABB.lua");
    local ShapeAABB = commonlib.gettable("mathlib.ShapeAABB");
    local SeerShapeAABB = commonlib.gettable("Mod.Seer.Injector.SeerShapeAABB");
    Inject(SeerShapeAABB, ShapeAABB);

    NPL.load("(gl)script/apps/Aries/Creator/Game/Entity/EntityPlayerMPClient.lua");
    NPL.load("(gl)script/Seer/Injector/SeerEntityPlayerMPClient.lua");
    local EntityPlayerMPClient = commonlib.gettable("MyCompany.Aries.Game.EntityManager.EntityPlayerMPClient")
    local SeerEntityPlayerMPClient = commonlib.gettable("Mod.Seer.Injector.SeerEntityPlayerMPClient");
    Inject(SeerEntityPlayerMPClient, EntityPlayerMPClient);

    NPL.load("(gl)script/apps/Aries/Creator/Game/Tasks/ReplaceBlockTask.lua");
    NPL.load("(gl)script/Seer/Injector/SeerReplaceBlockTask.lua");
    local ReplaceBlockTask = commonlib.gettable("MyCompany.Aries.Game.Tasks.ReplaceBlock");
    local SeerReplaceBlockTask = commonlib.gettable("Mod.Seer.Injector.SeerReplaceBlockTask");
    Inject(SeerReplaceBlockTask, ReplaceBlockTask);

	--inject SeerGameOptions into options
    NPL.load("(gl)script/apps/Aries/Creator/Game/game_options.lua");
    NPL.load("(gl)script/Seer/Injector/SeerGameOptions.lua");
    local options = commonlib.gettable("MyCompany.Aries.Game.GameLogic.options")
    local SeerGameOptions = commonlib.gettable("Mod.Seer.Injector.SeerGameOptions");
    Inject(SeerGameOptions, options);

    NPL.load("(gl)script/apps/Aries/Creator/Game/GameDesktop.lua");
    NPL.load("(gl)script/Seer/Injector/SeerGameDesktop.lua");
    local GameDesktop = commonlib.gettable("MyCompany.Aries.Creator.Game.Desktop");
    local SeerGameDesktop = commonlib.gettable("Mod.Seer.Injector.SeerGameDesktop");
    Inject(SeerGameDesktop, GameDesktop);

    NPL.load("(gl)script/ide/TooltipHelper.lua");
    NPL.load("(gl)script/Seer/Injector/SeerBroadcastHelper.lua");
    local BroadcastHelper = commonlib.gettable("CommonCtrl.BroadcastHelper");
    local SeerBroadcastHelper = commonlib.gettable("Mod.Seer.Injector.SeerBroadcastHelper");
    Inject(SeerBroadcastHelper, BroadcastHelper);

    NPL.load("(gl)script/apps/Aries/Creator/Game/blocks/BlockRedstoneConductor.lua");
    NPL.load("(gl)script/Seer/Injector/SeerBlockRedstoneConductor.lua");
    local BlockRedstoneConductor = commonlib.gettable("MyCompany.Aries.Game.blocks.BlockRedstoneConductor")
    local SeerBlockRedstoneConductor = commonlib.gettable("Mod.Seer.Injector.SeerBlockRedstoneConductor");
    Inject(SeerBlockRedstoneConductor, BlockRedstoneConductor);
end

StartInjection();

----------------------------------------------------------------------------
----------------------------------------------------------------------------
--injection
--Cellfy: a failed attemption, this is highly dependent on the first NPL.Load of the original table, it's a dead end when there are files cross loading
--[[
local GameMode = commonlib.gettable("MyCompany.Aries.Game.GameLogic.GameMode");
local SeerGameMode = commonlib.gettable("Mod.Seer.Game.GameLogic.SeerGameMode");


echo("----------------------------------1----------------------------------");
print(MyCompany.Aries.Game.GameLogic.GameMode);
echo(MyCompany.Aries.Game.GameLogic.GameMode);
print(Mod.Seer.Game.GameLogic.SeerGameMode);
echo(Mod.Seer.Game.GameLogic.SeerGameMode);
echo(getmetatable(Mod.Seer.Game.GameLogic.SeerGameMode));


function SeerGameMode:IsEditor()
    LOG.std(nil, "debug", "cellfy", "SeerGameMode.IsEditor called");
    print(self);
    echo(self);
    echo(getmetatable(self));
    --local originalClass = getmetatable(self);
    --return originalClass:IsEditor();
    return true;
end

echo("----------------------------------2----------------------------------");
print(MyCompany.Aries.Game.GameLogic.GameMode);
echo(MyCompany.Aries.Game.GameLogic.GameMode);
print(Mod.Seer.Game.GameLogic.SeerGameMode);
echo(Mod.Seer.Game.GameLogic.SeerGameMode);
echo(getmetatable(Mod.Seer.Game.GameLogic.SeerGameMode));

LOG.std(nil, "debug", "cellfy", "setting metatable");
setmetatable(SeerGameMode, { __index = GameMode, __newindex = GameMode });
MyCompany.Aries.Game.GameLogic.GameMode = SeerGameMode;

echo("----------------------------------3----------------------------------")
print(MyCompany.Aries.Game.GameLogic.GameMode);
echo(MyCompany.Aries.Game.GameLogic.GameMode);
print(Mod.Seer.Game.GameLogic.SeerGameMode);
echo(Mod.Seer.Game.GameLogic.SeerGameMode);
echo(getmetatable(Mod.Seer.Game.GameLogic.SeerGameMode));
echo(getmetatable(MyCompany.Aries.Game.GameLogic.GameMode));

echo("----------------------------------4----------------------------------")
NPL.load("(gl)script/apps/Aries/Creator/Game/GameRules/GameMode.lua");
local gm2 = commonlib.gettable("MyCompany.Aries.Game.GameLogic.GameMode");
print(gm2);
]]
