local API=commonlib.gettable("MyCompany.Aries.ChatSystem.API");
local Private={mChatCallbacks={}};
function API.registerChatCallback(key,callback)
  Private.mChatCallbacks[key]=callback;
end
function API.unregisterChatCallback(key)
  Private.mChatCallbacks[key]=nil;
end

--{NickName, Message, ID}
function API.onChat(paras)
  for key,value in pairs(Private.mChatCallbacks) do
    value(paras);
  end
end