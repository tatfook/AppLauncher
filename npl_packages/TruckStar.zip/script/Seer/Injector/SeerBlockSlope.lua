--[[
    Title: SeerBlockSlope
    Author(s): Devil
    Date: 2016/9/7
    Desc: BlockSlope extension. 
    A Injector class.
    Injection Target: Mod.Seer.Injector.SeerBlockSlope
    use the lib:
    -------------------------------------------------------
    NPL.load("(gl)script/apps/Aries/Creator/Game/blocks/BlockSlope.lua");
    NPL.load("(gl)script/Seer/Injector/SeerBlockSlope.lua");
    local BlockSlope = commonlib.gettable("MyCompany.Aries.Game.blocks.BlockSlope");
    local SeerBlockSlope = commonlib.gettable("Mod.Seer.Injector.SeerBlockSlope");
    Inject(SeerBlockSlope, BlockSlope);
    -------------------------------------------------------
]]
NPL.load("(gl)script/apps/Aries/Creator/Game/blocks/BlockSlope.lua");
local SeerBlockSlope = commonlib.gettable("Mod.Seer.Injector.SeerBlockSlope");
local lEdgeBlockRotationList;
local lOuterCornerBlockRotationList;
local lInnerCornerBlockRotationList;
local lEdgeBlockMirrorList;
local lOuterCornerBlockMirrorList;
local lInnerCornerBlockMirrorList;
local function _adjustAngle(angle)
    local ret=angle;
    while ret>6.28 do
      ret=ret-6.28;
    end
    while ret<0 do
      ret=ret+6.28;
    end
    return ret;
end
local function _buildEdgeBlockRotationList()
  if lEdgeBlockRotationList then
    return;
  end
  lEdgeBlockRotationList={{},{}};
  lEdgeBlockRotationList[1]["0"]=0;
  lEdgeBlockRotationList[1]["1.57"]=7;
  lEdgeBlockRotationList[1]["3.14"]=1;
  lEdgeBlockRotationList[1]["4.71"]=6;
  lEdgeBlockRotationList[1]["6.28"]=0;
  lEdgeBlockRotationList[2]["0"]=2;
  lEdgeBlockRotationList[2]["1.57"]=5;
  lEdgeBlockRotationList[2]["3.14"]=3;
  lEdgeBlockRotationList[2]["4.71"]=4;
  lEdgeBlockRotationList[2]["6.28"]=2;
end
local function _buildOuterCornerBlockRotationList()
  if lOuterCornerBlockRotationList then
    return;
  end
  lOuterCornerBlockRotationList={{},{}};
  lOuterCornerBlockRotationList[1]["0"]=0;
  lOuterCornerBlockRotationList[1]["1.57"]=4;
  lOuterCornerBlockRotationList[1]["3.14"]=1;
  lOuterCornerBlockRotationList[1]["4.71"]=5;
  lOuterCornerBlockRotationList[1]["6.28"]=0;
  lOuterCornerBlockRotationList[2]["0"]=2;
  lOuterCornerBlockRotationList[2]["1.57"]=7;
  lOuterCornerBlockRotationList[2]["3.14"]=3;
  lOuterCornerBlockRotationList[2]["4.71"]=6;
  lOuterCornerBlockRotationList[2]["6.28"]=2;
end
local function _buildInnerCornerBlockRotationList()
  if lInnerCornerBlockRotationList then
    return;
  end
  lInnerCornerBlockRotationList={{},{}};
  lInnerCornerBlockRotationList[1]["0"]=0;
  lInnerCornerBlockRotationList[1]["1.57"]=2;
  lInnerCornerBlockRotationList[1]["3.14"]=4;
  lInnerCornerBlockRotationList[1]["4.71"]=6;
  lInnerCornerBlockRotationList[1]["6.28"]=0;
  lInnerCornerBlockRotationList[2]["0"]=1;
  lInnerCornerBlockRotationList[2]["1.57"]=3;
  lInnerCornerBlockRotationList[2]["3.14"]=5;
  lInnerCornerBlockRotationList[2]["4.71"]=7;
  lInnerCornerBlockRotationList[2]["6.28"]=1;
end
local function _buildEdgeBlockMirrorList()
  if lEdgeBlockMirrorList then
    return;
  end
  lEdgeBlockMirrorList={x={},y={},z={}};
  lEdgeBlockMirrorList.x[0]=1;
  lEdgeBlockMirrorList.x[1]=0;
  lEdgeBlockMirrorList.x[2]=3;
  lEdgeBlockMirrorList.x[3]=2;
  lEdgeBlockMirrorList.x[4]=4;
  lEdgeBlockMirrorList.x[5]=5;
  lEdgeBlockMirrorList.x[6]=6;
  lEdgeBlockMirrorList.x[7]=7;
  lEdgeBlockMirrorList.y[0]=3;
  lEdgeBlockMirrorList.y[1]=2;
  lEdgeBlockMirrorList.y[2]=1;
  lEdgeBlockMirrorList.y[3]=0;
  lEdgeBlockMirrorList.y[4]=7;
  lEdgeBlockMirrorList.y[5]=6;
  lEdgeBlockMirrorList.y[6]=5;
  lEdgeBlockMirrorList.y[7]=4;
  lEdgeBlockMirrorList.z[0]=0;
  lEdgeBlockMirrorList.z[1]=1;
  lEdgeBlockMirrorList.z[2]=2;
  lEdgeBlockMirrorList.z[3]=3;
  lEdgeBlockMirrorList.z[4]=5;
  lEdgeBlockMirrorList.z[5]=4;
  lEdgeBlockMirrorList.z[6]=7;
  lEdgeBlockMirrorList.z[7]=6;
end
local function _buildOuterCornerBlockMirrorList()
  if lOuterCornerBlockMirrorList then
    return;
  end
  lOuterCornerBlockMirrorList={x={},y={},z={}};
  lOuterCornerBlockMirrorList.x[0]=5;
  lOuterCornerBlockMirrorList.x[1]=4;
  lOuterCornerBlockMirrorList.x[2]=7;
  lOuterCornerBlockMirrorList.x[3]=6;
  lOuterCornerBlockMirrorList.x[4]=1;
  lOuterCornerBlockMirrorList.x[5]=0;
  lOuterCornerBlockMirrorList.x[6]=3;
  lOuterCornerBlockMirrorList.x[7]=2;
  lOuterCornerBlockMirrorList.y[0]=7;
  lOuterCornerBlockMirrorList.y[1]=6;
  lOuterCornerBlockMirrorList.y[2]=5;
  lOuterCornerBlockMirrorList.y[3]=4;
  lOuterCornerBlockMirrorList.y[4]=3;
  lOuterCornerBlockMirrorList.y[5]=2;
  lOuterCornerBlockMirrorList.y[6]=1;
  lOuterCornerBlockMirrorList.y[7]=0;
  lOuterCornerBlockMirrorList.z[0]=4;
  lOuterCornerBlockMirrorList.z[1]=5;
  lOuterCornerBlockMirrorList.z[2]=6;
  lOuterCornerBlockMirrorList.z[3]=7;
  lOuterCornerBlockMirrorList.z[4]=0;
  lOuterCornerBlockMirrorList.z[5]=1;
  lOuterCornerBlockMirrorList.z[6]=2;
  lOuterCornerBlockMirrorList.z[7]=3;
end
local function _buildInnerCornerBlockMirrorList()
  if lInnerCornerBlockMirrorList then
    return;
  end
  lInnerCornerBlockMirrorList={x={},y={},z={}};
  lInnerCornerBlockMirrorList.x[0]=2;
  lInnerCornerBlockMirrorList.x[1]=3;
  lInnerCornerBlockMirrorList.x[2]=0;
  lInnerCornerBlockMirrorList.x[3]=1;
  lInnerCornerBlockMirrorList.x[4]=6;
  lInnerCornerBlockMirrorList.x[5]=7;
  lInnerCornerBlockMirrorList.x[6]=4;
  lInnerCornerBlockMirrorList.x[7]=5;
  lInnerCornerBlockMirrorList.y[0]=1;
  lInnerCornerBlockMirrorList.y[1]=0;
  lInnerCornerBlockMirrorList.y[2]=3;
  lInnerCornerBlockMirrorList.y[3]=2;
  lInnerCornerBlockMirrorList.y[4]=5;
  lInnerCornerBlockMirrorList.y[5]=4;
  lInnerCornerBlockMirrorList.y[6]=7;
  lInnerCornerBlockMirrorList.y[7]=6;
  lInnerCornerBlockMirrorList.z[0]=6;
  lInnerCornerBlockMirrorList.z[1]=7;
  lInnerCornerBlockMirrorList.z[2]=4;
  lInnerCornerBlockMirrorList.z[3]=5;
  lInnerCornerBlockMirrorList.z[4]=2;
  lInnerCornerBlockMirrorList.z[5]=3;
  lInnerCornerBlockMirrorList.z[6]=0;
  lInnerCornerBlockMirrorList.z[7]=1;
end
local function _getEdgeBlockRotationIndex(blockIndex,angle)
  local ret=blockIndex;
  _buildEdgeBlockRotationList();
  local type_index;
  if 0==blockIndex 
  or 7==blockIndex
  or 1==blockIndex
  or 6==blockIndex
  then
    type_index=1;
  else
    type_index=2;
  end
  local angle_from_start=angle;
  for key,value in pairs(lEdgeBlockRotationList[type_index]) do
    if value==blockIndex then
      angle_from_start=angle+tonumber(key);
      break;
    end
  end
  angle_from_start=_adjustAngle(angle_from_start);
  ret=lEdgeBlockRotationList[type_index][tostring(angle_from_start)];
  return ret;
end
local function _getOuterBlockRotationIndex(blockIndex,angle)
  local ret=blockIndex;
  _buildOuterCornerBlockRotationList();
  local type_index;
  if 0==blockIndex 
  or 4==blockIndex
  or 1==blockIndex
  or 5==blockIndex
  then
    type_index=1;
  else
    type_index=2;
  end
  local angle_from_start=angle;
  for key,value in pairs(lOuterCornerBlockRotationList[type_index]) do
    if value==blockIndex then
      angle_from_start=angle+tonumber(key);
      break;
    end
  end
  angle_from_start=_adjustAngle(angle_from_start);
  ret=lOuterCornerBlockRotationList[type_index][tostring(angle_from_start)];
  return ret;
end
local function _getInnerBlockRotationIndex(blockIndex,angle)
  local ret=blockIndex;
  _buildInnerCornerBlockRotationList();
  local type_index;
  if 0==blockIndex 
  or 2==blockIndex
  or 4==blockIndex
  or 6==blockIndex
  then
    type_index=1;
  else
    type_index=2;
  end
  local angle_from_start=angle;
  for key,value in pairs(lInnerCornerBlockRotationList[type_index]) do
    if value==blockIndex then
      angle_from_start=angle+tonumber(key);
      break;
    end
  end
  angle_from_start=_adjustAngle(angle_from_start);
  ret=lInnerCornerBlockRotationList[type_index][tostring(angle_from_start)];
  return ret;
end
local function _getEdgeBlockMirrorIndex(blockIndex,axis)
  _buildEdgeBlockMirrorList();
  return lEdgeBlockMirrorList[axis][blockIndex];
end
local function _getOuterBlockMirrorIndex(blockIndex,axis)
  _buildOuterCornerBlockMirrorList();
  return lOuterCornerBlockMirrorList[axis][blockIndex];
end
local function _getInnerBlockMirrorIndex(blockIndex,axis)
  _buildInnerCornerBlockMirrorList();
  return lInnerCornerBlockMirrorList[axis][blockIndex];
end
-- rotate the block data by the given angle and axis. This is mosted reimplemented in blocks with orientations stored in block data, such as slope, bones, etc. 
-- @param blockData: current block data
-- @param angle: usually 1.57, -1.57, 3.14, -3.14, 0. 
-- @param axis: "x|y|z", if nil, it should default to "y" axis
-- @return the rotated block data. 
function SeerBlockSlope:RotateBlockData(blockData, angle, axis)
  local ret=blockData;
  local adjust_angle=_adjustAngle(angle);
  local type_index=math.floor(blockData/8);
  local block_index=blockData%8;
	if 0~=angle and axis=="y" then
    if 0==type_index then
      ret=_getEdgeBlockRotationIndex(block_index,adjust_angle);
    elseif 1==type_index then
      ret=_getOuterBlockRotationIndex(block_index,adjust_angle);
    elseif 2==type_index then
      ret=_getInnerBlockRotationIndex(block_index,adjust_angle);
    else
      echo("devilwalk:error type index");
    end
  end
  ret=type_index*8+ret;
  return ret;
end
-- mirror the block data along the given axis. This is mosted reimplemented in blocks with orientations stored in block data, such as stairs, bones, etc. 
-- @param blockData: current block data
-- @param axis: "x|y|z", if nil, it should default to "y" axis
-- @return the mirrored block data. 
function SeerBlockSlope:MirrorBlockData(blockData, axis)
  echo("devilwalk------------------blockData:"..tostring(blockData));
  echo("devilwalk------------------axis:"..axis);
  local ret=blockData;
  local type_index=math.floor(blockData/8);
  local block_index=blockData%8;
  if 0==type_index then
    ret=_getEdgeBlockMirrorIndex(block_index,axis);
  elseif 1==type_index then
    ret=_getOuterBlockMirrorIndex(block_index,axis);
  elseif 2==type_index then
    ret=_getInnerBlockMirrorIndex(block_index,axis);
  else
    echo("devilwalk:error type index");
  end
  echo("devilwalk------------------ret:"..tostring(ret));
  ret=type_index*8+ret;
  return ret;
end

