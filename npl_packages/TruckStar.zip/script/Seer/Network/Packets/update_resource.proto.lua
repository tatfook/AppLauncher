
NPL.load("(gl)script/Seer/pb/update_resource_pb.lua");
NPL.load("(gl)script/Seer/Network/Packets/PacketPbHelper.lua");
local PacketPbHelper = commonlib.gettable("Mod.Seer.Network.Packets.PacketPbHelper");

function PacketPbHelper.sendCSGetLastVersionReq(nid, callback)
	PacketPbHelper.sendTo({nid = nid},{"CSGetLastVersionReq"}, callback);
end

function PacketPbHelper.sendCSGetUpdateInfoReq(nid, callback)
	PacketPbHelper.sendTo({nid = nid},{"CSGetUpdateInfoReq"}, callback);
end

function PacketPbHelper.sendCSGetLastExeInfoReq(nid, version, callback)
	PacketPbHelper.sendTo({nid = nid},{"CSGetLastExeInfoReq", {field1 = version[1], field2 = version[2], field3 = version[3], field4 = version[4]}}, callback);
end

function PacketPbHelper.sendCSGetLastFileListsReq(nid, version, callback)
	PacketPbHelper.sendTo({nid = nid},{"CSGetLastFileListsReq", {field1 = version[1], field2 = version[2], field3 = version[3], field4 = version[4]}}, callback);
end