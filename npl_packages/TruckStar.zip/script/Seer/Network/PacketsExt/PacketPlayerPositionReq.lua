--[[
    Title: PacketPlayerPositionReq
    Author(s): Cellfy
    Date Created: Jul 9, 2016
    Date Updated: Jul 9, 2016
    Desc: a client request to the server for the position of a specified player in the room
    Usage:
    ------------------------------------------------------------
    NPL.load("(gl)script/Seer/Network/PacketsExt/PacketPlayerPositionReq.lua");
    local PacketPlayerPositionReq = commonlib.gettable("Mod.Seer.Network.PacketsExt.PacketPlayerPositionReq");
    ------------------------------------------------------------
]]

NPL.load("(gl)script/Seer/Network/PacketsExt/SeerPacketBase.lua");
local PacketPlayerPositionReq = commonlib.inherit(commonlib.gettable("Mod.Seer.Network.PacketsExt.SeerPacketBase"), commonlib.gettable("Mod.Seer.Network.PacketsExt.PacketPlayerPositionReq"));

function PacketPlayerPositionReq:ctor()
end

function PacketPlayerPositionReq:InitAsReq(player_user_id, callback_func)
    PacketPlayerPositionReq._super.InitAsReq(self, callback_func);
    self.user_id = player_user_id;
    return self;
end

-- Passes this Packet on to the NetHandler for processing.
function PacketPlayerPositionReq:ProcessPacket(net_handler)
    PacketPlayerPositionReq._super.ProcessPacket(self, net_handler);
    if(net_handler.handlePlayerPositionReq) then
        net_handler:handlePlayerPositionReq(self);
    end
end
