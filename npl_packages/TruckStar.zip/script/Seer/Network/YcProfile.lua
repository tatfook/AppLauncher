--[[
Title: YcProfile
Author(s): leio
Date: 2015/9/2
Desc: 
use the lib:
-------------------------------------------------------
NPL.load("(gl)script/Seer/NetWork/YcProfile.lua");
local YcProfile = commonlib.gettable("Mod.Seer.Network.YcProfile");
-------------------------------------------------------
]]
local YcProfile = commonlib.gettable("Mod.Seer.Network.YcProfile");

NPL.load("(gl)script/Seer/Network/Packets/PacketPbHelper.lua");
local PacketPbHelper = commonlib.gettable("Mod.Seer.Network.Packets.PacketPbHelper");
--[[
UserInfo: check cs_basic.proto -> CSLoginRsp
message UserInfo
{
	required uint32 user_id = 1;     					//用户米米号
	required uint32 avatar_id = 2;   					//用户头像的ID值
	required bytes nick_name = 3;    					//用户昵称
	required uint32 gender = 4;                         //性别：0男、1女
	required uint32 zone_id = 5;
	optional uint32 login_channel = 6 [default = 0];    //登陆渠道 用于统计渠道登陆量(方便以后扩展)
	optional uint32 reg_time = 7 [default = 0];         //用户创建角色时间
}
]]

YcProfile.uid = nil;
YcProfile.cur_world_id = nil;

YcProfile.users_info = {};

YcProfile.friends_info = {};
YcProfile.blacks_info = {};

YcProfile.strangers_info = {};

YcProfile.storage_info = {};

YcProfile.viewUid = nil

YcProfile.viewStorageInfo = {}

-- sample:  { [5002] = {online = true, }, }
YcProfile.world_users_status = {};

YcProfile.PlanetTotalRankListData={}
YcProfile.PlanetMonthRankListData={}

YcProfile.UserItems = {}
function YcProfile.SetWorldID(world_id)
	YcProfile.cur_world_id = world_id;
end
function YcProfile.GetWorldID()
	return YcProfile.cur_world_id or 1;
end
function YcProfile.SetUID(uid)
	YcProfile.uid = uid;
end
function YcProfile.GetUID()
	return YcProfile.uid;
end
--uid is uint32
function YcProfile.SetUserInfo(uid,info, isSpecialForm)
	if(uid and info)then
		if(YcProfile.GetUID() == uid and isSpecialForm)then
			info = YcProfile.ConvertMyInfo(info);
		end

		-- local v = YcProfile.users_info[uid];
		-- if(v) then
		-- 	info.login_time = v.login_time;
		-- end
		
		YcProfile.users_info[uid] = info;

		-- YcProfile.users_info[uid] = info;

		if YcProfile.friends_info[uid] then
			YcProfile.friends_info[uid] = info
		end
		if YcProfile.blacks_info[uid] then
			YcProfile.blacks_info[uid] = info
		end
		if YcProfile.strangers_info[uid] then
			YcProfile.strangers_info[uid] = info
		end
	end
end

function YcProfile.GetMyInfo()
    return YcProfile.GetUserInfo(nil);
end

function YcProfile.GetMyGender()
    local myProfile = YcProfile.GetMyInfo();
    if myProfile then
        return myProfile.gender;
    end
end

function YcProfile.GetMyNickname()
    local myProfile = YcProfile.GetMyInfo();
    if myProfile then
        return myProfile.nick_name;
    end
end

function YcProfile.GetMyCharacterAssetID()
    local myProfile = YcProfile.GetMyInfo();
    if myProfile then
        return myProfile.avatar_id;
    end
end

function YcProfile.GetMyCharacterModel()
    local myProfile = YcProfile.GetMyInfo();
    if myProfile then
        local assetInfo = Mod.Seer.Config.ItemReader.GetAssetInfoByID(myProfile.avatar_id);
        if assetInfo then
            return assetInfo.model;
        end
    end    
end

function YcProfile.GetMyCharacterTexture()
    local myProfile = YcProfile.GetMyInfo();
    if myProfile then
        local assetInfo = Mod.Seer.Config.ItemReader.GetAssetInfoByID(myProfile.avatar_id);
        if assetInfo then
            return assetInfo.texture;
        end
    end
end

function YcProfile.GetMyCharacterHeadIcon()
    local myProfile = YcProfile.GetMyInfo();
    if myProfile then
        local assetInfo = Mod.Seer.Config.ItemReader.GetAssetInfoByID(myProfile.avatar_id);
        if assetInfo then
            return assetInfo.head_icon;
        end
    end
end
function YcProfile.GetMyCharacterHeadIconFrame()
    local myProfile = YcProfile.GetMyInfo();
    if myProfile then
        local assetInfo = Mod.Seer.Config.ItemReader.GetAssetInfoByID(myProfile.avatar_id);
        if assetInfo then
            return assetInfo.head_icon_frame;
        end
    end
end
function YcProfile.GetCharacterHeadIconById(id)
	local id = id or 10001
    local assetInfo = Mod.Seer.Config.ItemReader.GetAssetInfoByID(id);
    if assetInfo then
    	return assetInfo.head_icon
    end
    return ""
end
function YcProfile.GetCharacterHeadIconFrameById(id)
	local id = id or 10001
    local assetInfo = Mod.Seer.Config.ItemReader.GetAssetInfoByID(id);
    if assetInfo then
    	return assetInfo.head_icon_frame
    end
    return ""
end
-- nil is myself info
function YcProfile.GetUserInfo(uid)
	uid = uid or YcProfile.uid;
	if(uid)then
		return YcProfile.users_info[uid];
	end
end

function YcProfile.GetUserCount()
	local i, u ;
	local count = 0;
	for i,u in pairs(YcProfile.users_info) do
		if (u and i ~= YcProfile.uid) then
			count = count + 1
		end
	end
	return count
end

function YcProfile.ConvertMyInfo(info)
	if(not info)then
		return
	end
	local v = {
		user_id = info.uid,
		avatar_id = info.skin_id,
		nick_name = info.nick,
		gender = info.gender,
		zone_id = info.zone_id,
		login_channel = info.channel,
		reg_time = info.reg_time,
		total_time = info.total_time,
	}
	return v;
end

function YcProfile.AddFriendInfo(uid, friendInfo)
	-- move info from strangerlist to friendlist
	if(uid and YcProfile.strangers_info[uid]) then
		YcProfile.strangers_info[uid] = nil;
	end

	if(uid and friendInfo) then
		YcProfile.friends_info[uid] = friendInfo;
	end
end

function YcProfile.DeleteFriendInfo(uid)
	uid = tonumber(uid);
	YcProfile.friends_info[uid] = nil;
end

function YcProfile.GetFriendsInfo()
	return YcProfile.friends_info;
end

function YcProfile.GetFriendInfo(uid)
	if(YcProfile.friends_info[uid]) then
		return YcProfile.friends_info[uid];
	end
end

function YcProfile.AddBlackInfo(uid, blackInfo)
	-- move info from strangerlist to blacklist
	if(uid and YcProfile.strangers_info[uid]) then
		YcProfile.strangers_info[uid] = nil;
	end
	
	if(uid and blackInfo) then
		YcProfile.blacks_info[uid] = blackInfo;
	end
end

function YcProfile.DeleteBlackInfo(uid)
	uid = tonumber(uid);
	YcProfile.blacks_info[uid] = nil;
end

function YcProfile.GetBlacksInfo()
	return YcProfile.blacks_info;
end

function YcProfile.GetBlacksInfoById(uid)
	if(YcProfile.blacks_info[uid]) then
		return YcProfile.blacks_info[uid];
	end
end

function YcProfile.AddStrangerInfo(uid, strangerInfo)
	if(uid and strangerInfo) then
		YcProfile.strangers_info[uid] = strangerInfo;
	end
end

function YcProfile.DeleteStrangerInfo(uid)
	uid = tonumber(uid);
	YcProfile.strangers_info[uid] = nil;
end

function YcProfile.GetStrangersInfo()
	return YcProfile.strangers_info;
end

function  YcProfile.SetStorageInfo(uid,msg)
	YcProfile.storage_info = msg
end
function YcProfile.GetStorageInfo()

	return YcProfile.storage_info
end
function YcProfile.ResetYcInfo()

	YcProfile.uid = nil;
	YcProfile.cur_world_id = nil;

	YcProfile.users_info = {};

	YcProfile.friends_info = {};
	YcProfile.blacks_info = {};

	YcProfile.strangers_info = {};

	YcProfile.storage_info = {};

	YcProfile.viewUid = nil

	YcProfile.viewStorageInfo = {}

	-- sample:  { [5002] = {online = true, }, }
	YcProfile.world_users_status = {};

	YcProfile.PlanetRankListData = {}

	echo("test====Reset====YcProfile")
end
function YcProfile.SetPlanetTotalRankList(list)
	if list then
		YcProfile.PlanetTotalRankListData = list
	end
end

function YcProfile.SetPlanetMonthRankList(list)
	if list then
		YcProfile.PlanetMonthRankListData = list
	end
end

function YcProfile.GetRankingIconByGlobalUid(uid)
	local num = 0
	local icon = ""
	local list = YcProfile.PlanetMonthRankListData
	if list and next(list) then
		for i=1,3 do
			if list[i] and list[i].global_craft_uid == uid then
				num = i+3
				break;
			end
		end
	end
	list = YcProfile.PlanetTotalRankListData
	if list and next(list) then
		for i=1,3 do
			if list[i] and list[i].global_craft_uid == uid then
				num = i
				break;
			end
		end
	end
	if num == 1 then
		icon = "15.png"
	elseif num == 2 then
		icon = "16.png"
	elseif num == 3 then
		icon = "17.png"
	elseif num == 4 then
		icon = "18.png"
	elseif num == 5 then
		icon = "19.png"
	elseif num == 6 then
		icon = "20.png"
	end
	if icon ~= "" then
		return UIUtility.GetMCMLStandardImageDescription("gameassets/textures/ui_17_ranklist/PlanetRankListUI.png",icon,";")
	end
	return ""
end
function YcProfile.SetUserItems(list)
	YcProfile.UserItems = list
end
function YcProfile.GetUserItems()
	return YcProfile.UserItems
end
function YcProfile.ChangeItems(list)
	local info = YcProfile.UserItems[list.item_id]
	if info then
		info.number = list.item_number
	else
		YcProfile.UserItems[list.item_id] = {}
		YcProfile.UserItems[list.item_id].item_id = list.item_id
		YcProfile.UserItems[list.item_id].number = list.item_number
	end
end
function YcProfile.setUserAttributes(attributes)
  for i=1,#attributes do
    local attr=attributes[i];
    YcProfile.GetUserInfo().mAttributes[attr.attribute_id]=attr;
  end
end
function YcProfile.getUserAttributes()
  return YcProfile.GetUserInfo().mAttributes;
end
function YcProfile.getUserAttribute(attributeID)
  return YcProfile.GetUserInfo().mAttributes[attributeID];
end