--[[
Title: Welcome Page
Author(s): WuZhao
Date: 2015/9/7
Desc:
use the lib:
------------------------------------------------------------
NPL.load("(gl)script/Seer/WelcomePage.lua");
local WelcomePage = commonlib.gettable("Mod.Seer.UI.WelcomePage");
WelcomePage.ShowPage();
------------------------------------------------------------
]]
NPL.load("(gl)script/Seer/EscFramePage.lua");

NPL.load("(gl)script/Seer/FriendPage.lua");
NPL.load("(gl)script/Seer/FriendChat.lua");
NPL.load("(gl)script/Seer/FriendSuspension.lua");

NPL.load("(gl)script/Seer/SelectBlocksScale.lua");
NPL.load("(gl)script/apps/Aries/Creator/Game/Tasks/SelectBlocksTask.lua");
NPL.load("(gl)script/Seer/Utility/CommonUtility.lua");

local CommonUtility = commonlib.gettable("Mod.Seer.Utility.CommonUtility");

local WelcomePage = commonlib.gettable("Mod.Seer.UI.WelcomePage");

function WelcomePage.ShowPage()
	System.App.Commands.Call("File.MCMLWindowFrame", {
		url = "script/Seer/WelcomePage.html",
		name = "WelcomePage",
		isShowTitleBar = false,
		DestroyOnClose = true, -- prevent many ViewProfile pages staying in memory
		style = CommonCtrl.WindowFrame.ContainerStyle,
		zorder = 0,
		allowDrag = false,
		bShow = bShow,
		directPosition = true,
		align = "_fi",
		x = 0,
		y = 0,
		width = 0,
		height = 0,
		cancelShowAnimation = true,
	});
end

function WelcomePage.OnClickRegister()
    if CommonUtility:IsDevVersion() then
        --Context independent unit test can be put here
        echo("----------------------------------unit test 1----------------------------------");
    else
        ParaGlobal.ShellExecute("open", "iexplore.exe", "http://account.61.com/register", "", 1);
    end
end

function WelcomePage.OnClickBBS()
    if CommonUtility:IsDevVersion() then
        --Context independent unit test can be put here
        echo("----------------------------------unit test 2----------------------------------");
    else
        ParaGlobal.ShellExecute("open", "iexplore.exe", "http://account.61.com/main", "", 1);
    end
end

function WelcomePage.OnClickFavorite()
    if CommonUtility:IsDevVersion() then
        --Context independent unit test can be put here
        echo("----------------------------------unit test 3----------------------------------");
    else
        --No Implementation
    end
end

function WelcomePage.OnClickService()
    if CommonUtility:IsDevVersion() then
        --Context independent unit test can be put here
        echo("----------------------------------unit test 4----------------------------------");
    else
        ParaGlobal.ShellExecute("open", "iexplore.exe", "http://kf.61.com", "", 1);
    end
end

function WelcomePage.OnClickNotice()
    if CommonUtility:IsDevVersion() then
        --Context independent unit test can be put here
        echo("----------------------------------unit test 5----------------------------------");
    else
        ParaGlobal.ShellExecute("open", "iexplore.exe", "http://parents.61.com/care", "", 1);
    end
end
