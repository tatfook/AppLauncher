﻿--[[
    Title: Esc Frame Page
    Author(s): WangXiXi
    Date: 2015/6/16
    Desc: 
    Use Lib:
    -------------------------------------------------------
    NPL.load("(gl)script/Seer/EscFramePage.lua");
    local EscFramePage = commonlib.gettable("Mod.Seer.UI.EscFramePage");
    EscFramePage.ShowPage(true)
    -------------------------------------------------------
]]

NPL.load("(gl)script/apps/Aries/Creator/Game/Login/MainLogin.lua");
NPL.load("(gl)script/Seer/UIPage.lua");
NPL.load("(gl)script/ide/AudioEngine/AudioEngine.lua");
NPL.load("(gl)script/Seer/Game/ModuleManager.lua");
local ModuleManager = commonlib.gettable("Mod.Seer.Game.ModuleManager");
local AudioEngine = commonlib.gettable("AudioEngine");
local Game = commonlib.gettable("MyCompany.Aries.Game");
local MainLogin = commonlib.gettable("MyCompany.Aries.Game.MainLogin");
local GameMode = commonlib.gettable("MyCompany.Aries.Game.GameLogic.GameMode");
NPL.load("(gl)script/Seer/Game/UI/UIManager.lua");
local UIManager= commonlib.gettable("Mod.Seer.Game.UI.UIManager");
NPL.load("(gl)script/Seer/Settings.lua");
local Settings = commonlib.gettable("Mod.Seer.Settings");
local UserDatabase = commonlib.gettable("Mod.Seer.Utility.UserDatabase");
local BroadcastHelper = commonlib.gettable("CommonCtrl.BroadcastHelper");

local EscFramePage = commonlib.inherit(commonlib.gettable("Mod.Seer.Game.UI.UIBase"),commonlib.gettable("Mod.Seer.UI.EscFramePage"));

NPL.load("(gl)script/seer/Utility/CommonUtility.lua");
local CommonUtility = commonlib.gettable("Mod.Seer.Utility.CommonUtility");
if CommonUtility:IsMobilePlatform() then
UIManager.registerUI("EscFramePageEdit",EscFramePage,"script/Seer/EscFramePageEditor.html");
UIManager.registerUI("EscFramePageVisit",EscFramePage,"script/Seer/EscFramePageVisitor.html");
UIManager.registerUI("EscFramePageBigWorld",EscFramePage,"script/Seer/EscFramePageBigWorld.html");
else
UIManager.registerUI("EscFramePageEdit",EscFramePage,"script/Seer/EscFramePageEditor.PC.html",
	{
		allowDrag = false,
		click_through = false,
		align = "_ct",
		x = -79,
		y = -170,
		width = 158,
		height = 340,
	}
);
UIManager.registerUI("EscFramePageVisit",EscFramePage,"script/Seer/EscFramePageVisitor.PC.html",
	{
		allowDrag = false,
		click_through = false,
		align = "_ct",
		x = -79,
		y = -106,
		width = 158,
		height = 212,
	}
);
UIManager.registerUI("EscFramePageBigWorld",EscFramePage,"script/Seer/EscFramePageBigWorld.PC.html",
	{
		allowDrag = false,
		click_through = false,
		align = "_ct",
		x = -79,
		y = -106,
		width = 158,
		height = 212,
	}
);
end

local lcomment_ui = {}
function EscFramePage:onCreate(userdata)
	self:InitXml()
	self:refresh(0)
	self:SetCommentBtn()
	self.paras = userdata
	self.escaper = userdata;
end
function EscFramePage:InitXml()
	local comment_list = {}
	local config = commonlib.gettable("Mod.Seer.Config");
	local slide = config.Comment.Slide
	local slide_size = slide:size()
	for i = 1,slide_size do
		local slide_data = slide:get(i)
		table.insert(comment_list,slide_data)
	end
	local lrandom_index = math.random(1,slide_size) or 1
	lcomment_ui = comment_list[lrandom_index]
end
function EscFramePage:SetCommentBtn()
	local btnNode = self.page:GetNode("commentbtn")
	if btnNode then
		local ctl = btnNode:GetControl()
		local icon = self:GetCommentBg()
		ctl.background = icon.."; 0 0 256 256"
	end
end
function EscFramePage:OnComment()
	if self.isClick then
		return
	end
	self.isClick = true
	local mytimer = commonlib.Timer:new({callbackFunc = function()
		self.isClick = false
  		end})
  	mytimer:Change(3000);
  	local url = lcomment_ui.Link
  	if url then
		ParaGlobal.ShellExecute("open", "iexplore.exe", url, "", 1);
	end
end
function EscFramePage:GetCommentBg()
	return lcomment_ui.Bgicon or ""
end
function EscFramePage:GetTextPic()
	return lcomment_ui.Texticon or ""
end

function EscFramePage:escape()
	self:close();
	self.escaper:escape();
end

function EscFramePage:LeavePlanet(saving)
	local planetMgr = commonlib.gettable("Mod.Seer.Game.World.PlanetManager");
	local planet = planetMgr.getCurrentPlanet();
	if (planet and planet:isUploading()) then
		_guihelper.MessageBox("正在上传，无法保存，一会儿再试")
		return;
	end
    -- directly leave world if it's a internet world
    if not saving  then
        --SavingWorldPage.LeavePlanet();
		-- ModuleManager.startModule("MainMenu");
		ModuleManager.startModule("BigWorldPlay");
        return;
    end

    function OnSavingWorldPage()
    	local uiMain = UIManager.getUI("UIMain")
		GameLogic.QuickSave(
			function (err)
				if (not err) then
					ModuleManager.startModule("BigWorldPlay");
				else
					_guihelper.MessageBox("网络异常,上传失败！", 
						function(res) 
							if(res and res == _guihelper.DialogResult.OK) then 
								ModuleManager.startModule("BigWorldPlay");
							end
						end, _guihelper.MessageBoxButtons.OK);
				end
			end
		)
		UIManager.createUI("SavingWorldPage",uiMain);
    end
    local this = self or EscFramePage
	local isAutoSave= this.CheckIsAutoSave();
	if not isAutoSave then
		_guihelper.MessageBox("你未开启自动保存，退出游戏前是否进行保存?", function(res)
			if(res and res == _guihelper.DialogResult.Yes) then
				_guihelper.CloseMessageBox(true); -- fast close without animation
				OnSavingWorldPage()
			else
				ModuleManager.startModule("BigWorldPlay");
			end
		end, _guihelper.MessageBoxButtons.YesNo);
	else
		OnSavingWorldPage()
	end
end
function EscFramePage:OnSaveWorld()
	if ModuleManager.checkModule("Offline") then
		self:close()
		local timer = commonlib.Timer:new({callbackFunc = function(timer)
            timer:Change();
            local plt = self.escaper.planet
			plt:save(function (err)
	            if err then 
	                echo(err);  
	            else
	            	BroadcastHelper.PushLabel({id="GameLogic", label = format(L"保存成功"), max_duration=4000, color = "0 255 0", scaling=1.1, bold=true, shadow=true,});
	            end
	        end)
        end});
        timer:Change(1)   
	else
	    local GameLogic = commonlib.gettable("MyCompany.Aries.Game.GameLogic");
	    AudioEngine.PlayUISound("btn_show");
	    GameLogic.QuickSave();
		ModuleManager.handleEvent("ResetTimer")
	end
end
function EscFramePage:CheckIsAutoSave()
	return UserDatabase.getAttribute("AutoSave",true);
end
function EscFramePage:GetAutoSaveText()
	if self:CheckIsAutoSave() then
		return ""
	end
	return "自动保存关闭中"
end