--[[
Title: Environment Frame page
Author(s): WangXiXi
Date: 2015/8/7
Desc: 
Use Lib:
-------------------------------------------------------
NPL.load("(gl)script/Seer/EnvFramePage.lua");
local EnvFramePage = commonlib.gettable("Mod.UI.EnvFramePage");
EnvFramePage.ShowPage()
-------------------------------------------------------
]]

local AudioEngine = commonlib.gettable("AudioEngine");
local GameLogic = commonlib.gettable("MyCompany.Aries.Game.GameLogic");
local CommandManager = commonlib.gettable("MyCompany.Aries.Game.CommandManager");
local EnvFramePage = commonlib.gettable("Mod.UI.EnvFramePage");
local UIManager = commonlib.gettable("Mod.Seer.Game.UI.UIManager");

local EnvFramePage = commonlib.inherit(commonlib.gettable("Mod.Seer.Game.UI.UIBase"),commonlib.gettable("Mod.Seer.UI.EnvFramePage"));

UIManager.registerUI("EnvFramePage",EnvFramePage,"script/Seer/EnvFramePage.html",
{
	directPosition = true,
	align = "_rt",
	x = -234,
	y = 0,
	width = 234,
	height = 280,
})


function EnvFramePage:ctor()

	self.sky_index = 1;
	self.sky_select_index = 1;

	self.inf_time_per_day = nil;

end
function EnvFramePage:onCreate()
	self.is_inited = true;
	self.sky_index = 1; 
	self.sky_select_index = 1;

	local old_daylength = ParaScene.GetAttributeObjectSunLight():GetField("DayLength", day_length);
	if(old_daylength > 999 ) then
		self.inf_time_per_day = true;
	end
		--local mytimer = commonlib.Timer:new({callbackFunc = function(timer)
      --local old_time = ParaScene.GetTimeOfDaySTD();
      --local value = (old_time/2 + 0.5) * 1000;
      --if page then
        --page:SetValue("mcTimeSlider",value);
      --end
--
		--end})
		--mytimer:Change(500, 500);


	self:RefreshDayNightState();

	local page = self.page;
	if self:IsDayNightOn() then
		page:SetValue("weather_set_daylength",tonumber(ParaScene.GetAttributeObjectSunLight():GetField("DayLength", day_length)));
	end
	page:SetValue("mcTimeSlider",(ParaScene.GetTimeOfDaySTD()/2+0.5)*1000);

	local Config = commonlib.gettable("Mod.Seer.Config");
	local envconfig = Config.PlanetEnvironment;
	for i=1,envconfig.skybox:size() do
		local skybox = envconfig.skybox:get(i);
		if skybox.path==GameLogic.GetSkyEntity().filename then
			EnvFramePage.sky_select_index=i;
			break;
		end
	end

	if not Statistics.TempStatus.EnvOpened then
		Statistics.TempStatus.EnvOpened = true;
		Statistics.SendKey("Environment.Env.FirstOpen");
	end
end
function EnvFramePage:onDestroy()
	local ui = UIManager.getUI("RoomMemBar")
	if ui then
		ui:RefreshInfo()
	end
end

function EnvFramePage.ShowPage()
	NPL.load("(gl)script/Seer/Minimap.lua");

	if(EnvFramePage.page) then
		bShow = not EnvFramePage.page:IsVisible();
	else
		bShow = true;
	end

	echo("Test_  EnvFramePage.ShowPage");
	echo("bShow   "..tostring(bShow));

	if(bShow) then
		NPL.load("(gl)script/Seer/Minimap.lua");
		local Minimap = commonlib.gettable("Mod.Seer.UI.Minimap");
		Minimap.pageStatus = 2;
	end
  
  local Config = commonlib.gettable("Mod.Seer.Config");
  local envconfig = Config.PlanetEnvironment;
  for i=1,envconfig.skybox:size() do
    local skybox = envconfig.skybox:get(i);
    if skybox.path==GameLogic.GetSkyEntity().filename then
      EnvFramePage.sky_select_index=i;
      break;
    end
  end

	local params = {
				url = "script/Seer/EnvFramePage.html", 
				name = "EnvFramePage.ShowPage", 
				isShowTitleBar = false,
				DestroyOnClose = false,
				bToggleShowHide= true, 
				style = CommonCtrl.WindowFrame.ContainerStyle,
				allowDrag = false,
				enable_esc_key = true,
				bShow = bShow,
				click_through = false, 
				app_key = MyCompany.Aries.Creator.Game.Desktop.App.app_key, 
				zorder = 3,
				directPosition = true,
					align = "_rt",
					x = -234,
					y = 0,
					width = 234,
					height = 280,
			};
	System.App.Commands.Call("File.MCMLWindowFrame", params);
	if(bShow) then
		EnvFramePage.RefreshDayNightState();
	end	

	NPL.load("(gl)script/Seer/Settings.lua");
	local Settings = commonlib.gettable("Mod.Seer.Settings");

	NPL.load("(gl)script/Seer/Game/Guide/GuideMask.lua");
	local GuideMask = commonlib.gettable("Mod.Seer.Game.Guide.GuideMask");
	GuideMask.guide("Env");
	if EnvFramePage.IsDayNightOn() then
		page:SetValue("weather_set_daylength",tonumber(ParaScene.GetAttributeObjectSunLight():GetField("DayLength", day_length)));
	end
	page:SetValue("mcTimeSlider",(ParaScene.GetTimeOfDaySTD()/2+0.5)*1000);
end



-- from night to noo by sliderbar
function EnvFramePage:OnTimeSliderChanged(value)
	AudioEngine.PlayUISound("btn_scroll");
	if (value) then
		echo(value)
		local time=(value/1000-0.5)*2;
		CommandManager:RunCommand("time", tostring(time));
	end	
end

function EnvFramePage:OnChangeSkyBox()

	local Config = commonlib.gettable("Mod.Seer.Config");
	local envconfig = Config.PlanetEnvironment
	local skybox = envconfig.skybox:get(self.sky_select_index)
	CommandManager:RunCommand("/sky -clear");
	CommandManager:RunCommand("sky", skybox.path);
  if skybox.fog_colour then
    CommandManager:RunCommand("/fog -color "..skybox.fog_colour);
  end
end

function EnvFramePage:OnChangeRealSky()
	CommandManager:RunCommand("/sky -clear");
	GameLogic.GetSkyEntity():UseSimulatedSky();
end

function EnvFramePage:OnOffDayNight()
	AudioEngine.PlayUISound("btn_show");
	self.inf_time_per_day = not self.inf_time_per_day;
	self:RefreshDayNightState();
end

function EnvFramePage:RefreshDayNightState()
	local page = self.page;
	local leftBtn = page:GetNode("weather_sub_daylength");
	local _editbox = page:GetNode("weather_set_daylength");
	local rightBtn = page:GetNode("weather_add_daylength");

	local leftBtn = page:GetNode("weather_sub_daylength");

	if(self.inf_time_per_day) then
		local day_length = 100000000;
		self:SetDayLength(day_length);	
		leftBtn:SetAttribute("enabled", "false");
		_editbox:SetAttribute("ReadOnly", "true");
		_editbox:SetAttribute("value", "");
		rightBtn:SetAttribute("enabled", "false");	
	else
		local value = self.last_dayLength or 60;

		self:SetDayLength(value);	

		leftBtn:SetAttribute("enabled", "true");
		_editbox:SetAttribute("ReadOnly", "false");
		page:SetValue("weather_set_daylength", value);
		rightBtn:SetAttribute("enabled", "true");	
	end

	local old_time = ParaScene.GetTimeOfDaySTD();
	local value = (old_time/2 + 0.5) * 1000;
	page:SetValue("mcTimeSlider",value);

	page:Refresh(0);
end

function EnvFramePage:IsDayNightOn()
	return not self.inf_time_per_day;
end

function EnvFramePage:CoordinateDayLength(name,mcmlNode)
	local page = self.page;
	AudioEngine.PlayUISound("btn_show");
	if(not self.inf_time_per_day) then
		value = page:GetValue("weather_set_daylength", 1);
		value = tonumber(value) or 60;
		if(name == "weather_sub_daylength") then
			value = value - 1;
			
		elseif(name == "weather_set_daylength") then

		elseif(name == "weather_add_daylength") then
			value = value + 1;
		end

		if(value < 1) then
			value = 1;
		end
		if(value > 99) then
			value = 99;
		end
		page:SetValue("weather_set_daylength",value);
		self:SetDayLength(value);		
		page:Refresh(0);
	end
end

function EnvFramePage:OnKeyUp(name, mcmlNode)
	local page = self.page;
	local _editbox = page:FindUIControl("weather_set_daylength");
	if(_editbox and _editbox:IsValid()) then
		local callbacks = {
				[Event_Mapping.EM_KEY_RETURN] = function ()
					self:ChangeDayNightTime();
				end,
				[Event_Mapping.EM_KEY_NUMPADENTER] = function()
					self:ChangeDayNightTime();
				end,
				["other"] = function ()

				end,
		};

		local callback;
		if(callbacks) then
			callback = callbacks[virtual_key] or callbacks["other"];
		end
		if(callback) then
			callback();
		end
	end
end

function EnvFramePage:ChangeDayNightTime()
	local page = self.page;
	local _editbox = page:FindUIControl("weather_set_daylength");
	local text = page:GetValue("weather_set_daylength","60");

	if(not tonumber(text)) then
		text = "60";
	end

	local time = tonumber(text);
	if(time < 1) then
		time = 1;
	end
	if(time > 99) then
		time = 99;
	end

	


	local day_length = tonumber(_editbox.text);
	self:SetDayLength(day_length);

	_editbox:LostFocus();

	page:SetValue("weather_set_daylength",time);

	self.last_dayLength = day_length;

	page:Refresh(0);
end

function EnvFramePage:SetDayLength(value)
	local page = self.page;
	local day_length = tonumber(value) or 60;
	local old_time = ParaScene.GetTimeOfDaySTD();
	ParaScene.GetAttributeObjectSunLight():SetField("DayLength", day_length);
	ParaScene.SetTimeOfDaySTD(old_time);
  if page then
    page:SetValue("weather_set_daylength",day_length);
  end

	if( day_length > 0 and day_length < 100) then
		self.last_dayLength = day_length;
	end
end

function EnvFramePage:ShowMinimap()
	EnvFramePage.ClosePage();
	AudioEngine.PlayUISound("btn_show");
	NPL.load("(gl)script/Seer/Minimap.lua");
	local Minimap = commonlib.gettable("Mod.Seer.UI.Minimap");
	Minimap.Show();
end

function EnvFramePage:SetTime(time)
	local page = self.page;
  time=time or ParaScene.GetTimeOfDaySTD();
  ParaScene.SetTimeOfDaySTD(time);
  if page then
    page:SetValue("mcTimeSlider",(time/2+0.5)*1000);
  end
end

function EnvFramePage:handleKeyEvent(event)
    local dik_key = event.keyname;
	if (dik_key == "DIK_ESCAPE") then
		self:close();
		-- event:accept();
	end

	--catch all
	return true;
end
