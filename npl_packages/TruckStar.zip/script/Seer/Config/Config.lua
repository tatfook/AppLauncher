--[[
    NPL.load("(gl)script/Seer/Config/Config.lua");
    local Config = commonlib.gettable("Mod.Seer.Config");

--------------------------
file:
	Sample.xml
	<Sample>
		<Item id="ok" _KEY="id">
			<Sub attribute="sub"/>
		</Item>
		<Item attribute="item">
	</Sample>

code:
	Config.loadConfig("Sample.xml")
	-- get from array in order
	echo(Config.Sample.Item:get(2).attribute)
	-- find with "id"
	echo(Config.Sample.Item:find("ok"):get(1).attribute)

output:
	"item"
	"sub"

]]

local Config = commonlib.gettable("Mod.Seer.Config");

NPL.load("(gl)script/Seer/Config/ConfigPaser.lua");
local ConfigPaser = commonlib.gettable("Mod.Seer.Config.ConfigPaser");

function Config.loadConfig(path)
    local cfg = ConfigPaser.parse(path);
    if (cfg) then
        Config[cfg._NAME] = cfg;
        commonlib.log("config: load ".. path .. " ... done.\n")
    end
end


-- load config
function Config.loadAll()
    --load xml directly
    Config.loadConfig("script/Seer/Config/PlanetTemplate.xml");
    Config.loadConfig("script/Seer/Config/PlanetEnvironment.xml")
    Config.loadConfig("script/Seer/Config/GuideMask.xml")
    Config.loadConfig("script/Seer/Config/Preload.xml")
    Config.loadConfig("script/Seer/Config/InputConfig.xml")
    Config.loadConfig("script/Seer/Config/WikiConfig.xml")
    Config.loadConfig("script/Seer/Config/CommentUIConfig.xml")
    Config.loadConfig("script/Seer/Config/TextBookConfig.xml")
    Config.loadConfig("script/Seer/Config/SmileyConfig.xml")
    Config.loadConfig("script/Seer/Config/RoomPermission.xml")
    Config.loadConfig("script/Seer/Config/LoadingTipsConfig.xml")

    Config.loadConfig("script/Seer/Config/Store.xml")
    Config.loadConfig("script/Seer/Config/Store_sell_items.xml")
    Config.loadConfig("script/Seer/Config/Item.xml")
    Config.loadConfig("script/Seer/Config/ItemType.xml")
    Config.loadConfig("script/Seer/Config/Skills.xml")
    Config.loadConfig("script/Seer/Config/GuideMission.xml")
    
    Config.loadConfig("script/Seer/Config/CommandList.xml")

    Config.loadConfig("script/Seer/Config/NoEditBlock.xml")

    Config.loadConfig("script/Seer/Config/Avatars.xml")

    Config.loadConfig("script/Seer/Config/Attachment.xml")
    --configs loading through reader interfaces
    NPL.load("(gl)script/Seer/Config/NetworkConfigReader.lua");
    NPL.load("(gl)script/Seer/Config/CharacterAssetsReader.lua");
    NPL.load("(gl)script/Seer/Config/ItemReader.lua");
    NPL.load("(gl)script/Seer/Config/UITextureListReader.lua");
    Config.ItemReader.Load();
    Config.NetworkConfigReader.Load();
    Config.CharacterAssetsReader.Load();
    Config.UITextureListReader.Load();
end
