--[[
Title: chatwindow
Author(s): zrf, refactored by WangXiXi
Date: 2015/7/7
Desc:  
Use Lib:
-------------------------------------------------------
NPL.load("(gl)script/Seer/ChatWindow.lua");
local ChatWindow = commonlib.gettable("MyCompany.Aries.ChatSystem.ChatWindow");
-------------------------------------------------------
]]
NPL.load("(gl)script/apps/Aries/BBSChat/ChatSystem/SmileyPage.lua");
NPL.load("(gl)script/Seer/Utility/ChatCoder.lua");
NPL.load("(gl)script/Seer/NetWork/YcProfile.lua");
local YcProfile = commonlib.gettable("Mod.Seer.Network.YcProfile");
local ChatCoder=commonlib.gettable("Seer.Utility.ChatCoder");
local SmileyPage = commonlib.gettable("MyCompany.Aries.ChatSystem.SmileyPage");

NPL.load("(gl)script/ide/AudioEngine/AudioEngine.lua");
local AudioEngine = commonlib.gettable("AudioEngine");

--NPL.load("(gl)script/apps/Aries/Creator/Game/Areas/ChatSystem/CommandHelpPage.lua");
--local CommandHelpPage = commonlib.gettable("MyCompany.Aries.ChatSystem.CommandHelpPage");
NPL.load("(gl)script/Seer/CommandHelpPage.lua");

NPL.load("(gl)script/Seer/CommandHelpPage.lua");
local CommandHelpPage = commonlib.gettable("Mod.Chat.CommandHelpPage");

NPL.load("(gl)script/apps/Aries/BBSChat/ChatSystem/ChatChannel.lua");
local ChatChannel = commonlib.gettable("MyCompany.Aries.ChatSystem.ChatChannel");

NPL.load("(gl)script/apps/Aries/SlashCommand/SlashCommand.lua");
local SlashCommand = commonlib.gettable("MyCompany.Aries.SlashCommand.SlashCommand");
NPL.load("(gl)script/apps/Aries/BBSChat/ChatSystem/ChatWindow.lua");
NPL.load("(gl)script/apps/Aries/Chat/BadWordFilter.lua");
local ChatWindow = commonlib.gettable("MyCompany.Aries.ChatSystem.ChatWindow");
local EntityManager = commonlib.gettable("MyCompany.Aries.Game.EntityManager");
local sentence_history = commonlib.gettable("MyCompany.Aries.BBSChat.sentence_history");

local CommonUtility = commonlib.gettable("Mod.Seer.Utility.CommonUtility");




NPL.load("(gl)script/Seer/Game/UI/UIManager.lua");
local UIManager= commonlib.gettable("Mod.Seer.Game.UI.UIManager");
local ChatWindowProxy = commonlib.inherit(commonlib.gettable("Mod.Seer.Game.UI.UIBase"),commonlib.gettable("Mod.Seer.UI.ChatWindowProxy"));


UIManager.registerUI("ChatWindow",ChatWindowProxy);

function ChatWindowProxy:create(layout, name, zorder, paras)
	self.name = name;
	self.zorder = zorder;


	NPL.load("(gl)script/Seer/ChatWindow.lua");
	MyCompany.Aries.ChatSystem.ChatWindow.ShowPage();
end

function ChatWindowProxy:clear()
	if ChatWindow.page then
		ChatWindow.page:CloseWindow();
	end

	local functionBarUI = UIManager.getUI("FunctionBar")
	if functionBarUI then
		functionBarUI:EventCloseUI({name="billboard"})
	end
	Mod.Chat.CommandHelpPage.ClosePage();
end

function ChatWindowProxy:handleMouseEvent(event)
  local event_type = event:GetType();
  if (event_type == "mouseWheelEvent" ) then
    local vscrollbar = ParaUI.GetUIObject("ChatWindow_CreateTreeView_VScrollBar");
    if(vscrollbar:IsValid())then
      vscrollbar.value=vscrollbar.value+vscrollbar.height*event.mouse_wheel*(-1);
      ChatWindow.OnScrollBarChange();
    end
    event.accepted = true;
  end
end


ChatWindow.tag_button_ds = {
   {text=L"综合", name="public"},
   {text=L"私聊", name="private"},
   {text=L"系统", name="system"},
};

ChatWindow.tag_button_index = 1;

ChatWindow.selected_channel = ChatWindow.selected_channel or 1;
ChatWindow.mIsInited=false;
function ChatWindow.Init()
  if ChatWindow.mIsInited then
    return;
  end
	ChatChannel.Init();
	ChatChannel.SetAppendEventCallback(ChatWindow.AppendChatMessage);
	ChatChannel.AddFilter(ChatWindow.BadWordsFilter);
	ChatChannel.AddFilter(ChatWindow.ChatCommandFilter);
  for i=1,#ChatChannel.chatdata do
    local chatdata=ChatChannel.chatdata[i];
    ChatWindow.AppendChatMessage(chatdata,true);
  end
  ChatWindow.mIsInited=true;
end

function ChatWindow.GetTagIndex()
	return ChatWindow.tag_button_index;
end

function ChatWindow.GetTagButtons()
	return ChatWindow.tag_button_ds;
end

function ChatWindow.CreateTreeViewScrollBar(param, mcmlNode)
	local vscrollbar = ParaUI.CreateUIObject("scrollbar", "ChatWindow_CreateTreeView_VScrollBar","_lt", param.left,param.top,param.width,param.height);
	vscrollbar.visible = true;
	vscrollbar:SetPageSize(param.height);
	vscrollbar.onchange = ";MyCompany.Aries.ChatSystem.ChatWindow.OnScrollBarChange()";
	param.parent:AddChild(vscrollbar);
  ChatWindow.RefreshTreeView();
end

function ChatWindow.OnScrollBarChange()
	local ctl = ChatWindow.GetTreeView();
	local vscrollbar = ParaUI.GetUIObject("ChatWindow_CreateTreeView_VScrollBar");
	if(ctl and vscrollbar:IsValid())then
		ctl.ClientY = vscrollbar.value;
		ctl:RefreshUI();
	end
end

function ChatWindow.CreateTreeView(param, mcmlNode)
    local _container = ParaUI.CreateUIObject("container", "chatwindow_tvcon", "_lt", param.left,param.top,param.width,param.height);
	_container.background = "";
	_container:GetAttributeObject():SetField("ClickThrough", true);
	param.parent:AddChild(_container);
	
	-- create get the inner tree view
	local ctl = ChatWindow.GetTreeView(nil, _container, 0, 0, param.width, param.height);
	ctl:Show(true, nil, true);
	local _parentctl = ParaUI.GetUIObject(ctl.name);
	_parentctl:GetChild("main").onmousewheel = string.format(";MyCompany.Aries.ChatSystem.ChatWindow.OnTreeViewMouseWheel()");
end

function ChatWindow.OnTreeViewMouseWheel()
	--commonlib.echo("!!:OnTreeViewMouseWheel");
	CommonCtrl.TreeView.OnTreeViewMouseWheel("ChatWindow.TreeView");
	ChatWindow.RefreshScrollBar();
end

function ChatWindow.OnKeyUp(name, mcmlNode)
	local _editbox = ChatWindow.GetInputControl();
	if(_editbox and _editbox:IsValid()) then
		local sentText = _editbox.text;

		if(string.len(sentText) > 120) then
			_editbox.text = string.sub(sentText, 1, 120);
			_editbox:SetCaretPosition(-1);
		end
		
		local callbacks = {
			[Event_Mapping.EM_KEY_RETURN] = ChatWindow.OnClickSend,
			[Event_Mapping.EM_KEY_NUMPADENTER] = ChatWindow.OnClickSend,
			[Event_Mapping.EM_KEY_UP] = function ()
				local sentence = sentence_history:PreviousSentence()
				if(sentence) then
					_editbox.text = sentence;
					_editbox:SetCaretPosition(-1);
				end
			end,
			[Event_Mapping.EM_KEY_DOWN] = function ()
				local sentence = sentence_history:NextSentence()
				if(sentence) then
					_editbox.text = sentence;
					_editbox:SetCaretPosition(-1);
				end
			end,
		}
		local x,y = _editbox:GetAbsPosition();
		
		if CommonUtility:IsDevVersion() then
			CommandHelpPage.HandlerKeyUp({x = x,y = y,rows = 10,offset_x = -5,offset_y = 9},virtual_key,callbacks,sentText);
		else
			if (callbacks[virtual_key]) then
				callbacks[virtual_key]();
			end
		end
	end
end
local lLastMessageTime=0;
function ChatWindow.OnClickSend(name)
	AudioEngine.PlayUISound("btn_confirm");
	local words = "";
	local _editbox = ChatWindow.GetInputControl();
	if(_editbox) then
		if(not name or name == "send") then
			words = _editbox.text;
		elseif(name == "cancel") then
			words = "";
		end
	end
	if(words == "")then
		ChatWindow.ClosePage()
		return;
	end
  NPL.load("(gl)script/Seer/Utility/CommonUtility.lua");
  local CommonUtility = commonlib.gettable("Mod.Seer.Utility.CommonUtility");
  if not CommonUtility:IsDevVersion() then
    NPL.load("(gl)script/Seer/Utility/SensitiveWordManager.lua");
    local SensitiveWordManager = commonlib.gettable("Mod.Seer.Utility.SensitiveWordManager");
    words=SensitiveWordManager.process(words);
  end

	if(_editbox) then
		if((#words) > 120) then
			-- _editbox.text = "你输入的文字太多了";
			_guihelper.MessageBox("你输入的文字太多了");
			return;
		end
		local current_message_time=os.clock();
		if current_message_time-lLastMessageTime<2 then
			ChatChannel.AppendChat({ ChannelIndex = ChatChannel.EnumChannels.System, words = ChatCoder.encode2("你手速太快了，服务器跟不上了!","系统") });
			return;
		else
			lLastMessageTime=current_message_time;
		end
		-- internally it will run all GM commands. 
		local original_msg = words;

		local bSendMessage = true;
		if (words:match("^/")) then
			if CommonUtility:IsDevVersion() then
				NPL.load("(gl)script/apps/Aries/Creator/Game/Commands/CommandManager.lua");
				local CommandManager = commonlib.gettable("MyCompany.Aries.Game.CommandManager");
				words, bSendMessage = CommandManager:RunFromConsole(words);
				if(type(words) ~= "string") then
					words = "";
				end
			end
			CommandHelpPage.ClosePage();
			ChatWindow.ClosePage()
			return;	
		else
			local player = EntityManager.GetPlayer();
			if(player:SendChatMsg(ChatCoder.encode(words))) then
				bSendMessage = false; 
			end
		end

		if(replace_map) then
			local name, value;
			for name, value in pairs(replace_map) do
				name = name:gsub("([%(%)%[%]%%%^%+%-%.%*%?])", "%%%1");
				words = words:gsub(name, value);
			end
			replace_map = nil;
		end

		--if(System.options.version == "kids") then
			words = SmileyPage.RemoveNotOwnedGsid(words);
		--end

		if(bSendMessage) then	
			if(words == sentence_history:PeekLastSentence()) then
				--_editbox.text = "不能连续发送相同内容";
				_guihelper.MessageBox("不能连续发送相同内容");
			elseif(ChatChannel.SendMessage( ChatWindow.selected_channel, nil, nil, ChatCoder.encode(words) )) then
				NPL.load("(gl)script/Seer/Settings.lua");
				local Settings = commonlib.gettable("Mod.Seer.Settings");
				local name = Settings.GetPlayerNetNID(YcProfile.GetUID());
				headon_speech.Speak(name, words, 5);

				ChatWindow.ResetDefaultChannelText(true);
				sentence_history:PushSentence(words);
				--ChatWindow.LostFocus();
			end
		else
			ChatWindow.ResetDefaultChannelText(true);
			sentence_history:PushSentence(original_msg);
			-- ChatWindow.LostFocus();
		end
	end
end

function ChatWindow.GetInputControl()
	if(ChatWindow.redirect_UI_name) then
		-- redirected ui control
		return ParaUI.GetUIObject(ChatWindow.redirect_UI_name);
	else
		-- default ui control in mcml page
		if(ChatWindow.page) then
			return ChatWindow.page:FindUIControl("chatedit_words");
			--return ChatEdit.page:FindUIControl("chatedit_words");
		end
	end
end

function ChatWindow.ResetDefaultChannelText(bSetFocus)
	local channel = ChatChannel.GetChannel(ChatWindow.selected_channel);
	if(channel) then
		local input = ChatWindow.GetInputControl();
		if(input)then
			input.text = channel.default_channel_text or "";
			if(bSetFocus)then
				input:Focus();
				input:SetCaretPosition(-1);
			end
		end
	end
end

function ChatWindow.LostFocus()
	local _editbox = ChatWindow.GetInputControl();
	if(_editbox) then
		_editbox:LostFocus();
	end
	local vscrollbar = ParaUI.GetUIObject("ChatWindow_CreateTreeView_VScrollBar");
	if(vscrollbar:IsValid())then
		vscrollbar.visible = false;
	end
	CommandHelpPage.ClosePage();
end

-- callback function whenever ChatChannel received a message. 
-- @param chatdata: 参见ChatChannel.lua中的msgdata结构
-- @param needrefresh: bool	如为true,则会刷新聊天记录中的treeview
--]]---------------------------------------------------------------------------------------------------
function ChatWindow.AppendChatMessage(chatdata, needrefresh)
	if(chatdata==nil or type(chatdata)~="table")then
		commonlib.echo("error: chatdata 不可为空 in ChatWindow.AppendChatMessage");
		return;
	end

	--commonlib.echo("!!:AppendChatMessage");
	if(chatdata.ChannelIndex == ChatChannel.EnumChannels.BroadCast)then
		
		if(chatdata.words and string.match(chatdata.words,"lobby|(.+)|lobby"))then
			NPL.load("(gl)script/apps/Aries/CombatRoom/LobbyClientServicePage.lua");
			local LobbyClientServicePage = commonlib.gettable("MyCompany.Aries.CombatRoom.LobbyClientServicePage");
			local words = LobbyClientServicePage.GetLobbyCallMsg(chatdata.from,chatdata.words);
			if(not words)then
				return
			end
			chatdata.ChannelIndex = ChatChannel.EnumChannels.Lobby;
			chatdata.channelname = ChatChannel.channels[ChatChannel.EnumChannels.Lobby].name;
			chatdata.color = ChatChannel.channels[ChatChannel.EnumChannels.Lobby].color;
			chatdata.words = words;
			chatdata.is_direct_mcml = true;
		else
			if(needrefresh) then
				ChatWindow.AddBroadCastLine(chatdata);
			end
			if(not ChatChannel.AppendFilter[chatdata.ChannelIndex]) then
				return;
			end
		end
	end

	local ctl = ChatWindow.GetTreeView();
	local rootNode = ctl.RootNode;
	
	if(rootNode:GetChildCount() > 200) then
		rootNode:RemoveChildByIndex(1);
	end
	rootNode:AddChild(CommonCtrl.TreeNode:new({
			Name = "text", 
			chatdata = chatdata,
		}));

	if(needrefresh)then
		ChatWindow.RefreshTreeView();
	end
	
end

function ChatWindow.BadWordsFilter(msgdata)
	if(msgdata and msgdata.words)then
		msgdata.words = MyCompany.Aries.Chat.BadWordFilter.FilterString(msgdata.words);
	end
	return msgdata;
end

-- filter commands. this function will be called by ChatChannel.lua
-- @param msgdata: message data
-- @param return true if processed. 
function ChatWindow.ChatCommandFilter(msgdata)
	if(msgdata and msgdata.words )then
		-- internally it will run all GM commands. 
		local lastText = msgdata.words;
		local sentText, bSendMessage = SlashCommand.GetSingleton():Run(lastText);
		if(not bSendMessage) then
			return true;
		end

		if(string.sub(msgdata.words,1,1)=="@")then
			-- private chat
			local command, words = string.match(msgdata.words, "^@(%d+)%s+(.*)$" );
			if(not command or not words) then
				command, words = string.match(msgdata.words, "^@([^:]+):(.*)$" );
				if(command and words)then
					command = ChatWindow.GetNidByName(command);
				end
			end
			
			if(command and words)then
				msgdata.to = command;
				msgdata.words = words;
				msgdata.ChannelIndex = ChatChannel.EnumChannels.Private;
				return msgdata;
			end
		elseif(msgdata.ChannelIndex == ChatChannel.EnumChannels.Private)then
			return;
		elseif(string.sub(msgdata.words,1,1)=="#")then
			msgdata.words = string.sub(msgdata.words,2,-1);
			-- 这里添加#开头的命令行解析代码
		else
			return msgdata;
		end
	end
end

function ChatWindow.ShowPage()
    local CommonUtility = commonlib.gettable("Mod.Seer.Utility.CommonUtility");
    local lalign = "_rt"
	local lx = -707
	local ly = 0
	if not CommonUtility:IsMobilePlatform() then
		lalign = "_lb"
		lx = 0
		ly = -827
	end

	NPL.load("(gl)script/seer/Utility/CommonUtility.lua");
	local CommonUtility = commonlib.gettable("Mod.Seer.Utility.CommonUtility");

	if CommonUtility:IsMobilePlatform() then

	local params = {
				url = "script/Seer/ChatWindow.html", 
				name = "ChatWindow.ShowPage", 
				isShowTitleBar = false,
				DestroyOnClose = true,
				bToggleShowHide=true, 
				style = CommonCtrl.WindowFrame.ContainerStyle,
				allowDrag = false,
				enable_esc_key = true,
				click_through = false, 
				app_key = MyCompany.Aries.Creator.Game.Desktop.App.app_key, 
				directPosition = true,
					align = lalign,
					x = lx,
					y = ly,
					width = 553,
					height = 694,
			};
			System.App.Commands.Call("File.MCMLWindowFrame", params);
	else

	local params = {
				url = "script/Seer/ChatWindow.PC.html", 
				name = "ChatWindow.ShowPage", 
				isShowTitleBar = false,
				DestroyOnClose = true,
				bToggleShowHide=true, 
				style = CommonCtrl.WindowFrame.ContainerStyle,
				allowDrag = false,
				enable_esc_key = true,
				click_through = false, 
				app_key = MyCompany.Aries.Creator.Game.Desktop.App.app_key, 
				directPosition = true,
					align = "_lb",
					x = 5,
					y = -380,
					width = 390,
					height = 400,
			};
			System.App.Commands.Call("File.MCMLWindowFrame", params);
	end

	
end

function ChatWindow.SetEditorText(text)
	local _editbox = ChatWindow.GetInputControl();
	if(_editbox) then
		_editbox.text = tostring(text or "");
		_editbox:SetCaretPosition(-1);
	end
end
function ChatWindow.ClosePage()
	ChatWindow.LostFocus();
	if ChatWindow.page then
		ChatWindow.page:CloseWindow();
	end
	Mod.Chat.CommandHelpPage.ClosePage();
	UIManager.destroyUI("ChatWindow")
end
function ChatWindow.GetBulletEnable()
	if not ChatWindow.initBullet then
		ChatWindow.initBullet = true
	    MyCompany.Aries.Creator.Game.Desktop.InitDesktop();
	end
    return MyCompany.Aries.Creator.Game.Desktop.GetChatGUI():getBulletScreenEnable();
end
function ChatWindow.ChangeBullet()
	MyCompany.Aries.Creator.Game.Desktop.GetChatGUI():changeBulletScreenEnable();
    ChatWindow.page:Refresh(0.01);
end