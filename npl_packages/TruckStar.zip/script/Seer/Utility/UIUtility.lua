NPL.load("(gl)script/Seer/Settings.lua");
local Settings = commonlib.gettable("Mod.Seer.Settings");

local UIUtility = commonlib.createtable("UIUtility", {});
local TexturePackCoordinates = commonlib.createtable("UIUtility.TexturePackCoordinates", {});

local function ParseTexProperties(file_node)
    local propertyNode = nil;
    local tempKeys = {};
    local tempValues = {};

    for i,v in ipairs(file_node) do
	if (v.name == "key") then
	    table.insert(tempKeys, v[1])
	elseif (v[1]==nil) then
	    table.insert(tempValues, v.name)
	else
	    table.insert(tempValues, v[1])
	end
    end

    local resultTable = {};
    for i=1,#tempKeys do
	resultTable[tempKeys[i]]=tempValues[i];
    end

    return resultTable;
end


function UIUtility.ParsePlist(texture_file_path)
    local texture_file_prefix = texture_file_path
    if (string.match(texture_file_prefix, "(.*)%.png$")) then
        texture_file_prefix = string.gsub(texture_file_prefix, "(.*)%.png$", "%1")
    end

    local plistpath = texture_file_prefix .. ".plist";
    local plistRoot = ParaXML.LuaXML_ParseFile(plistpath);

    if (plistRoot) then
        TexturePackCoordinates[texture_file_path] = {}
	local framesNode = nil;
	local framesFound = false;
	local framesIndex = 0;
	for curNode in commonlib.XPath.eachNode(plistRoot, "/plist/dict/key") do
	    framesIndex = framesIndex+1;
	    if(curNode[1] == "frames") then
		framesNode = curNode;
		framesFound = true;
		break;
	    end
	end
	if (framesFound) then
	    for curNode in commonlib.XPath.eachNode(plistRoot, "/plist/dict/dict") do
		framesIndex = framesIndex-1;
		if (framesIndex == 0) then
		    framesNode = curNode;
		    break;
		end
	    end

	    local tempKeys = {};
	    local tempValues = {};
	    
	    local fileNode = nil;
	    for fileNode in commonlib.XPath.eachNode(framesNode, "/key") do
		table.insert(tempKeys, fileNode[1]);
	    end
	    for fileNode in commonlib.XPath.eachNode(framesNode, "/dict") do
		table.insert(tempValues, ParseTexProperties(fileNode));
	    end

	    for i=1,#tempKeys do
		TexturePackCoordinates[texture_file_path][tempKeys[i]]=tempValues[i];
	    end
	    --echo(TexturePackCoordinates)
	end
    end    --if (plistRoot)
end

function UIUtility.GetTextureProperties(texture_file_path, texture_name)
    local resultTable = nil
    if (type(texture_file_path)=="string") then
	if (TexturePackCoordinates[texture_file_path] == nil) then
	    UIUtility.ParsePlist(texture_file_path)
	end
        if TexturePackCoordinates[texture_file_path] then
            resultTable = TexturePackCoordinates[texture_file_path][texture_name];
        end
    end --if type(texture_file_path)=="string")
    return resultTable
end

function UIUtility.NeedScale()
    return Settings.dpi_scaling_factor ~= 1;
end

function UIUtility.AutoScale(value_in)
    return math.floor(value_in * Settings.dpi_scaling_factor);
end

function UIUtility.AntiAutoScale(value_in)
    return math.floor(value_in / Settings.dpi_scaling_factor);
end

function UIUtility.AutoScaleT(table_in)
    local table_in_clone = commonlib.clone(table_in);
    for k,v in pairs(table_in_clone) do        
        if type(v)=="number" then
            table_in_clone[k] = UIUtility.AutoScale(v);
        end
    end
    return table_in_clone;
end

function UIUtility.AntiAutoScaleT(table_in)
    local table_in_clone = commonlib.clone(table_in);
    for k,v in pairs(table_in_clone) do        
        if type(v)=="number" then
            table_in_clone[k] = UIUtility.AntiAutoScale(v);
        end
    end
    return table_in_clone;
end

function UIUtility.GetTextureCoord(texture_file_path, texture_name)
    --echo("----------------------------------UIUIUI----------------------------------");
    --echo(texture_file_path);
    --echo(texture_name);
    if (type(texture_file_path)=="string") then
	local texProperties = UIUtility.GetTextureProperties(texture_file_path, texture_name);
        local texCoordStr = nil;
        if texProperties then
            texCoordStr = texProperties.frame;
        else
            texCoordStr = "{{0,0},{1,1}}";
            LOG.std(nil, "debug", "truckstar", "invalid texcoord: %s, %s", texture_file_path, texture_name);
        end	
	texCoordStr = "texCoord = "..texCoordStr;
	loadstring(texCoordStr)();
	return texCoord[1][1], texCoord[1][2], texCoord[2][1], texCoord[2][2];
    end --if type(texture_file_path)=="string")
    return nil,nil,nil,nil;
end

function UIUtility.GetTextureDimension(texture_file_path, texture_name)
    local posX, posY, widthX, heightY = UIUtility.GetTextureCoord(texture_file_path, texture_name);
    return widthX, heightY;
end

function UIUtility.GetMCMLStandardImageDescription(texture_file_path, texture_name, splitter)
    splitter = splitter or ";";
    local posX, posY, widthX, heightY = UIUtility.GetTextureCoord(texture_file_path, texture_name);
    value = texture_file_path..splitter..posX.." "..posY.." "..widthX.." "..heightY;
    return value;
end

--test
--[[
posX, posY, width, height = UIUtility.GetTextureCoord("gameassets/textures/ui_22_welcome/WelcomeUI.png", "1.png");
echo(posX)
echo(posY)
echo(width)
echo(height)
]]

