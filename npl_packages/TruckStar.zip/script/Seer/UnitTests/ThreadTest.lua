local Test = NPL.export()

NPL.load("(gl)script/Seer/Utility/Thread.lua");
local ThreadPool = commonlib.gettable("Mod.Seer.Utility.ThreadPool");
ThreadPool.init();

function Test.testFunctionFromFile()
	NPL.load("(gl)script/Seer/Utility/Future.lua");
    local Async = commonlib.gettable("Mod.Seer.Utility.Async");

    local num = 444444443;
    local future = Async.call("script/Seer/UnitTests/FileBasedFunctionTest.lua", num);
    future:get(function (isPrime)
        if isPrime then
            echo(num .. " is prime" );
        else
            echo(num .. " is not prime");
        end
    end)

end

function Test.testFunctionFromString()
	NPL.load("(gl)script/Seer/Utility/Future.lua");
    local Async = commonlib.gettable("Mod.Seer.Utility.Async");

    local num = 444444443;
    local future = Async.call(" return function (num) for i = 2, num - 1 do if num % i == 0 then return false; end end return true; end ", num); 
        future:get(function (isPrime)
        if isPrime then
            echo(num .. " is prime" );
        else
            echo(num .. " is not prime");
        end
    end)

end