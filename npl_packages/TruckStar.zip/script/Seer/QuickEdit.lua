﻿--[[
Title: Quick Edit
Author(s): ZhouXing
Date: 2015/5/18
Desc: Quick Edit
use the lib:
------------------------------------------------------------
NPL.load("(gl)script/Seer/QuickEdit.lua");
local QuickEdit = commonlib.gettable("Mod.Seer.UI.QuickEdit");
QuickEdit.ShowPage();
-------------------------------------------------------
]]
NPL.load("(gl)script/apps/Aries/Creator/Game/GameRules/GameMode.lua");
local gameMode = commonlib.gettable("MyCompany.Aries.Game.GameLogic.GameMode");

NPL.load("(gl)script/apps/Aries/Creator/Game/Tasks/SelectBlocksTask.lua");
local selectBlocks = commonlib.gettable("MyCompany.Aries.Game.Tasks.SelectBlocks");

NPL.load("(gl)script/apps/Aries/Creator/Game/Tasks/UndoManager.lua");
local undoManager = commonlib.gettable("MyCompany.Aries.Game.UndoManager");

NPL.load("(gl)script/Seer/SimpleShape.lua");
local SimpleShape = commonlib.gettable("Mod.Seer.UI.SimpleShape");

NPL.load("(gl)script/apps/Aries/Creator/Game/game_logic.lua");
local GameLogic = commonlib.gettable("MyCompany.Aries.Game.GameLogic");

NPL.load("(gl)script/ide/AudioEngine/AudioEngine.lua");
local AudioEngine = commonlib.gettable("AudioEngine");

local UIManager = commonlib.gettable("Mod.Seer.Game.UI.UIManager");

local UIBase = commonlib.gettable("Mod.Seer.Game.UI.UIBase");
local QuickEdit = commonlib.inherit(UIBase,commonlib.gettable("Mod.Seer.Game.UI.QuickEdit"));

UIManager.registerUI("QuickEdit", QuickEdit,"script/Seer/QuickEdit.html",
{
	isShowTitleBar = false,
	DestroyOnClose = true,
	bToggleShowHide=true, 
	style = CommonCtrl.WindowFrame.ContainerStyle,
	allowDrag = false,
	enable_esc_key = false,
	cancelShowAnimation = true,
	click_through = false, 
	directPosition = true,
		align = "_lt",
		x = 0,
		y = 0,
		width = 400,
		height = 140,
})

function QuickEdit:onCreate()
	-- NPL.load("(gl)script/Seer/Game/Guide/GuideMask.lua");
	-- local GuideMask = commonlib.gettable("Mod.Seer.Game.Guide.GuideMask");
	-- GuideMask.guide("QuickEdit");
end

function QuickEdit:onDestroy()
	self.parent:refresh();-- QuickBtnBar;

	SimpleShape:HideAll();
end

function QuickEdit.Undo()
	AudioEngine.PlayUISound("btn_show");
	if(gameMode:IsAllowGlobalEditorKey()) then
		undoManager.Undo();
	end
end

function QuickEdit.Redo()
	AudioEngine.PlayUISound("btn_show");
	if(gameMode:IsAllowGlobalEditorKey()) then
		undoManager.Redo();
	end
end

function QuickEdit.Cut()
	AudioEngine.PlayUISound("btn_show");
	local instance = selectBlocks.GetCurrentInstance();
	if(instance) then
		instance:CopyBlocks(true);
	end
end

function QuickEdit.Copy()
	AudioEngine.PlayUISound("btn_show");
	local instance = selectBlocks.GetCurrentInstance();
	if(instance) then
		instance:CopyBlocks(false);
	end
end

function QuickEdit.Paste()
	AudioEngine.PlayUISound("btn_show");
	local instance = selectBlocks.GetCurrentInstance();

	local posX, posY, posZ = ParaScene.GetPlayer():GetPosition();
	local BlockEngine = commonlib.gettable("MyCompany.Aries.Game.BlockEngine");
	local bx, by, bz = BlockEngine:block(posX, posY+0.1, posZ);

	if(instance) then
		instance:PasteBlocks(bx,by,bz);
		--instance:PasteBlocks();
	end
end
function QuickEdit.click(name)
	NPL.load("(gl)script/Seer/Game/MultiPlayer/GamingRoomInfo.lua");
	local GamingRoomInfo = commonlib.gettable("Mod.Seer.Game.MultiPlayer.GamingRoomInfo");
	local YcProfile = commonlib.gettable("Mod.Seer.Network.YcProfile");
	local me = GamingRoomInfo.getPlayer(YcProfile.GetUID());
	NPL.load("(gl)script/Seer/Network/bit.lua");
	local bit= commonlib.gettable("YcAPI.bit");



	AudioEngine.PlayUISound("btn_show");
	if name == "cube" then
		Statistics.SendKeyValue("Build.Tools", "Cube")
		SimpleShape:ShowCube();
	elseif name == "ring" then
		Statistics.SendKeyValue("Build.Tools", "Torus")
		SimpleShape:ShowRing();
	elseif name == "circle" then
		Statistics.SendKeyValue("Build.Tools", "Circle")
		SimpleShape:ShowCircle();
	elseif name == "sphere" then
		Statistics.SendKeyValue("Build.Tools", "Sphere")
		SimpleShape:ShowSphere();
	elseif name == "ellipsoid" then
		Statistics.SendKeyValue("Build.Tools", "Ellipsoid")
		SimpleShape:ShowEllipsoid();
	elseif name == "stairs" then
		Statistics.SendKeyValue("Build.Tools", "Stairs")
		SimpleShape:ShowStairs();
	elseif name == "cone" then
		Statistics.SendKeyValue("Build.Tools", "Cone")
		SimpleShape:ShowCone();
	end
end


