--[[
Title: code behind for page SystemSettingsPage.html
Author(s): WangXiXi
Date: 2014/6/18
Desc: script/Seer/SystemSettingsPage.html
Use Lib:
-------------------------------------------------------
NPL.load("(gl)script/Seer/SystemSettingsPage.lua");
local SystemSettingsPage = commonlib.gettable("Mod.Seer.UI.SystemSettingsPage");
SystemSettingsPage.ShowPage()
-------------------------------------------------------
]]
NPL.load("(gl)script/apps/Aries/Creator/Game/Commands/CommandManager.lua");
NPL.load("(gl)script/apps/Aries/Scene/main.lua");
NPL.load("(gl)script/apps/Aries/Player/main.lua");
NPL.load("(gl)script/apps/Aries/Creator/Game/game_logic.lua");
NPL.load("(gl)script/ide/AudioEngine/AudioEngine.lua");
NPL.load("(gl)script/Seer/Utility/UserDatabase.lua");

local ModuleManager = commonlib.gettable("Mod.Seer.Game.ModuleManager");
local AudioEngine = commonlib.gettable("AudioEngine");
local Scene = commonlib.gettable("MyCompany.Aries.Scene");
local GameLogic = commonlib.gettable("MyCompany.Aries.Game.GameLogic")
local CommandManager = commonlib.gettable("MyCompany.Aries.Game.CommandManager");
local pe_gridview = commonlib.gettable("Map3DSystem.mcml_controls.pe_gridview");
local UserDatabase = commonlib.gettable("Mod.Seer.Utility.UserDatabase");

local SystemSettingsPage = commonlib.gettable("Mod.Seer.UI.SystemSettingsPage");
local page;

local WorldCommon = commonlib.gettable("MyCompany.Aries.Creator.WorldCommon");
local UIManager= commonlib.gettable("Mod.Seer.Game.UI.UIManager");
local SysytemSettingsPageProxy = commonlib.inherit(commonlib.gettable("Mod.Seer.Game.UI.UIBase"),commonlib.gettable("Mod.Seer.UI.SysytemSettingsPageProxy"));

NPL.load("(gl)script/seer/Utility/CommonUtility.lua");
local CommonUtility = commonlib.gettable("Mod.Seer.Utility.CommonUtility");

UIManager.registerUI("SystemSettingsPage", SysytemSettingsPageProxy);

local userData = {}
SystemSettingsPage.inf_time_per_day = true
function SysytemSettingsPageProxy:create(layout, name, zorder, paras)
	userData = self.userdata
	self.name = name;
	self.zorder = zorder;

	local Config = commonlib.gettable("Mod.Seer.Config");
	local envconfig = Config.PlanetEnvironment;
	-- for i=1,envconfig.skybox:size() do
	-- 	local skybox = envconfig.skybox:get(i);
	-- 	if skybox.path==GameLogic.GetSkyEntity().filename then
	-- 		echo("Soul1: "..GameLogic.GetSkyEntity().filename)
	-- 		SystemSettingsPage.skySelectIndex=i;
	-- 		break;
	-- 	end
	-- end

	local old_daylength = ParaScene.GetAttributeObjectSunLight():GetField("DayLength", day_length);
	if(old_daylength > 999 ) then
		SystemSettingsPage.inf_time_per_day = true;
	end

	SystemSettingsPage.ShowPage(zorder);
end

function SysytemSettingsPageProxy:onDestroy()
	if (page) then
		SystemSettingsPage.ClosePage();
	end
	if userData and userData.callback then
		userData.callback()
	end
end



function SysytemSettingsPageProxy:handleKeyEvent(event)
    local dik_key = event.keyname;
	if (dik_key == "DIK_ESCAPE") then
		self:close();
		event:accept();
	end
	--catch all
	return true;
end

function SystemSettingsPage:isMobile()
	local CommonUtility = commonlib.gettable("Mod.Seer.Utility.CommonUtility");
	if CommonUtility:IsMobilePlatform() then
		return true
	else
		return false
	end
end


local CheckBoxText = {
	on = "开启",
	off = "关闭",
}

local function GetCheckBoxText(value)
	if(value == true or value == "true") then
		return CheckBoxText.on;
	else
		return CheckBoxText.off;
	end
end

local recommended_resolution = {1020,595}
local recommended_resolution_web_browser = {960,560}
local recommended_resolution_teen = {1280,760}

SystemSettingsPage.category_ds_index = 1;

-- purchase the item directly from global store
function SystemSettingsPage.OnInit()
	SystemSettingsPage.category_ds = {
		{text=L"游戏", name="gameparma"},
		{text=L"视频", name="show"},
		{text=L"控制", name="operation"},
	}

	SystemSettingsPage.sound_volume_list = {
		[L"低"] = {dist = 0.5, next = L"中"},
		[L"中"] = {dist = 1.5, next = L"高"},
		[L"高"] = {dist = 2.5, next = L"低"},
	}

	SystemSettingsPage.render_dist_list = {
	[L"低"] = {dist = 60, next = L"中"},
	[L"中"] = {dist = 120,next = L"高"},
	[L"高"] = {dist = 180,next = L"低"},
}

	page = document:GetPageCtrl();
	page.OnClose = SystemSettingsPage.OnClose;
	SystemSettingsPage.setting_ds = SystemSettingsPage.setting_ds or {};
	SystemSettingsPage.InitPageParams();	
end

local function GetRenderDistText(dist)
	local text = "";
	if(dist < 90) then
		text = L"低"
	elseif(dist < 150) then
		text = L"中"
	elseif(dist < 210) then
		text = L"高"
	end
	return text;
end

local function GetSoundVolumeText(value)
	local text = "";
	if(value < 1) then
		text = L"低"
	elseif(value < 2) then
		text = L"中"
	else
		text = L"高"
	end
	return text;
end

function SystemSettingsPage.InitPageParams()
	local ds = SystemSettingsPage.setting_ds;
	-- load the current settings. 
	local att = ParaEngine.GetAttributeObject();
	-- 反转鼠标
	local mouse_inverse = att:GetField("IsMouseInverse", false);
	-- page:SetNodeValue("btn_MouseInverse", if_else(mouse_inverse,L"开启",L"关闭"));
	SystemSettingsPage.ChangeButtonValue("btn_MouseInverse",mouse_inverse)
	ds["mouse_inverse"] = mouse_inverse;

	-- 超远视距
	local value = GameLogic.options:GetSuperRenderDist();
	if value > 0 then
		SystemSettingsPage.ChangeButtonValue("btn_superrender",true)
	else
		SystemSettingsPage.ChangeButtonValue("btn_superrender",false)
	end

	-- 视角摇晃
	local view_bobbing = GameLogic.options.ViewBobbing;
	-- page:SetNodeValue("btn_ViewBobbing", if_else(view_bobbing,L"开启",L"关闭"));
	SystemSettingsPage.ChangeButtonValue("btn_ViewBobbing",view_bobbing)
	ds["view_bobbing"] = view_bobbing;

	--立体输出
	local mode = GameLogic.options:IsStereoMode()
	SystemSettingsPage.ChangeStereoValue("stereomode",mode)
	GameLogic.options:EnableStereoMode(mode);

	-- 全屏
	--local is_full_screen = att:GetField("IsFullScreenMode", false);
	--page:SetNodeValue("btn_FullScreenMode", GetCheckBoxText(is_full_screen))
	--ds["is_full_screen"] = is_full_screen;
	-- 鼠标反转
	--local is_mouse_inverse = att:GetField("IsMouseInverse", false);
	--page:SetNodeValue("btn_MouseInverse", GetCheckBoxText(is_mouse_inverse))
	--ds["is_mouse_inverse"] = is_mouse_inverse;
	-- 分辨率
	local screen_resolution =  string.format("%s × %s", att:GetDynamicField("ScreenWidth", 1020), att:GetDynamicField("ScreenHeight", 680))
	page:SetValue("ScreenResolution", screen_resolution) -- 分辨率	
	ds["screen_resolution"] = screen_resolution;
	-- 锁定摄像机
	--local lock_camera;
	--local AutoCameraController = commonlib.gettable("MyCompany.Aries.AutoCameraController");
	--if(AutoCameraController.IsEnabled) then
		----page:SetNodeValue("checkBoxLockCamera", AutoCameraController:IsEnabled())
		--lock_camera = false;
	--else
		--lock_camera = true;
	--end
	--page:SetNodeValue("btn_LockCamera", GetCheckBoxText(lock_camera))
	--ds["lock_camera"] = lock_camera;
--
	--page:SetNodeValue("viewBobbing", GetCheckBoxText(GameLogic.options.ViewBobbing));

	-- 音乐开关
	local open_sound = if_else(ParaAudio.GetVolume()>0,true,false)
	-- page:SetNodeValue("btn_EnableSound", if_else(open_sound,L"开启",L"关闭"))
	SystemSettingsPage.ChangeButtonValue("btn_EnableSound",open_sound)
	ds["open_sound"] = open_sound;

	-- 音量大小
	local sound_volume = ParaAudio.GetVolume();
	-- local sound_volume = MyCompany.Aries.Player.LoadLocalData(key,1,true);
	local sound_volume_text = GetSoundVolumeText(sound_volume);
	-- page:SetNodeValue("btn_SoundVolume", sound_volume_text);
	SystemSettingsPage.ChangeSoundValue("btn_SoundVolume",sound_volume)
	ds["sound_volume"] = sound_volume_text;


	-- 真实光影
	-- local emulational_lighting = if_else(ParaTerrain.GetBlockAttributeObject():GetField("BlockRenderMethod", 1) == 2,true,false)
	-- -- page:SetNodeValue("btn_Shader", if_else(emulational_lighting,L"开启",L"关闭"));
	-- SystemSettingsPage.ChangeButtonValue("btn_Shader",emulational_lighting)
	-- ds["emulational_lighting"] = emulational_lighting;

	local emulational_lighting_value = string.format("%s",ParaTerrain.GetBlockAttributeObject():GetField("BlockRenderMethod",1))
	local num_value = tonumber(emulational_lighting_value)

	local effect = GameLogic.GetShaderManager():GetEffect("Fancy");
	if(num_value >= 2 and effect) then
		if effect:HasDepthOfViewEffect() then
			num_value = 4
		elseif effect:HasBloomEffect() then
			num_value = 3
		end
	end

	page:SetNodeValue("btn_Shader",tostring(num_value));
	ds["emulational_lighting_value"] = num_value;
	
	-- 场景投影
	local sunlight_shadow = if_else(ParaTerrain.GetBlockAttributeObject():GetField("UseSunlightShadowMap", false) == true,true,false);
	-- page:SetNodeValue("btn_Shadow", if_else(sunlight_shadow,L"开启",L"关闭"));
	SystemSettingsPage.ChangeButtonValue("btn_Shadow",sunlight_shadow)
	ds["sunlight_shadow"] = sunlight_shadow;

	-- 水面反射
	local water_reflection = if_else(ParaTerrain.GetBlockAttributeObject():GetField("UseWaterReflection", false) == true,true,false);
	-- page:SetNodeValue("btn_WaterReflection", if_else(water_reflection,L"开启",L"关闭"));
	SystemSettingsPage.ChangeButtonValue("btn_WaterReflection",water_reflection)
	ds["water_reflection"] = water_reflection;

	-- 主角显示
	local show_mainplayer = if_else(ParaScene.GetAttributeObject():GetField("ShowMainPlayer", false) == true,true,false);
	-- page:SetNodeValue("btn_ShowPlayer", if_else(show_mainplayer,L"开启",L"关闭"));
	SystemSettingsPage.ChangeButtonValue("btn_ShowPlayer",show_mainplayer)
	ds["show_mainplayer"] = show_mainplayer;

	-- 能见度, 低：30 - 90 中：90 - 150 高：150 - 210
	local render_dist = ParaTerrain.GetBlockAttributeObject():GetField("RenderDist", 100);
	local render_dist_text = GetRenderDistText(render_dist);
	page:SetNodeValue("btn_RenderDist", render_dist_text);
	ds["render_dist"] = render_dist_text;

	--自动保存
    SystemSettingsPage.isAutoSave = UserDatabase.getAttribute("AutoSave",true,"local");
	SystemSettingsPage.ChangeButtonValue("btn_AutoSave",SystemSettingsPage.isAutoSave)
	--NPC
    SystemSettingsPage.NPC_type = UserDatabase.getAttribute("SystemPreferences.NPC.On",false,"local");
    SystemSettingsPage.ChangeButtonValue("btn_BlockNPC",SystemSettingsPage.NPC_type)
end

function SystemSettingsPage.OnClose()
end

-- shader version
local function GetShaderVersion()
	local stats = SystemSettingsPage.GetPCStats();
	local ps_Version = stats.ps;
	local vs_Version = stats.vs;
	local shader_version = 0;
	if(vs_Version > ps_Version) then
		shader_version = ps_Version;
	else
		shader_version = vs_Version;
	end
	return shader_version;
end

local min_requirement_data = nil;

function SystemSettingsPage.onclickShowHeadOnDisplay(bChecked)
	AudioEngine.PlayUISound("btn_show");
    ParaScene.GetAttributeObject():SetField("ShowHeadOnDisplay", bChecked);
end

function SystemSettingsPage.onclickFreeWindowSize(bChecked)
	AudioEngine.PlayUISound("btn_show");
    ParaEngine.GetAttributeObject():SetField("IgnoreWindowSizeChange", not bChecked);
end

function SystemSettingsPage.checkBoxEnableTeamInvite(bChecked)
	MyCompany.Aries.Player.SaveLocalData("SystemSettingsPage.checkBoxEnableTeamInvite", bChecked);
end

function SystemSettingsPage.checkBoxDisableFamilyChat(bChecked)
	-- MyCompany.Aries.Player.SaveLocalData("SystemSettingsPage.checkBoxDisableFamilyChat", bChecked);
	NPL.load("(gl)script/apps/Aries/Chat/FamilyChatWnd.lua");
	local FamilyChatWnd = commonlib.gettable("MyCompany.Aries.Chat.FamilyChatWnd");
	FamilyChatWnd.BlockChat(bChecked);
end

function SystemSettingsPage.checkBoxAutoHPPotion(bChecked)
	MyCompany.Aries.Player.SaveLocalData("SystemSettingsPage.checkBoxAutoHPPotion", bChecked);
end

function SystemSettingsPage.checkBoxEnableHeadonTextScaling(bChecked)
	MyCompany.Aries.Player.SaveLocalData("SystemSettingsPage.checkBoxEnableHeadonTextScaling", bChecked);
	ParaScene.GetAttributeObject():SetField("HeadOn3DScalingEnabled", bChecked);
end

function SystemSettingsPage.checkBoxAllowAddFriend(bChecked)
	MyCompany.Aries.Player.SaveLocalData("SystemSettingsPage.checkBoxAllowAddFriend", bChecked);
	System.options.isAllowAddFriend = bChecked;
end


function SystemSettingsPage.checkBoxEnableFriendTeleport(bChecked)
	System.options.EnableFriendTeleport = bChecked;
	MyCompany.Aries.Player.SaveLocalData("SystemSettingsPage.EnableFriendTeleport", bChecked);
	ParaScene.GetAttributeObject():SetField("checkBoxEnableFriendTeleport", bChecked);
end

function SystemSettingsPage.checkBoxEnableAutoPickSingleTarget(bChecked)
	System.options.EnableAutoPickSingleTarget = bChecked;
	MyCompany.Aries.Player.SaveLocalData("SystemSettingsPage.EnableAutoPickSingleTarget", bChecked);
	ParaScene.GetAttributeObject():SetField("checkBoxEnableAutoPickSingleTarget", bChecked);
end

function SystemSettingsPage.checkBoxEnableForceHideHead(bChecked)
	System.options.EnableForceHideHead = bChecked;
	MyCompany.Aries.Player.SaveLocalData("SystemSettingsPage.EnableForceHideHead", bChecked);
	ParaScene.GetAttributeObject():SetField("checkBoxEnableForceHideHead", bChecked);
	-- force refresh avatar
	System.Item.ItemManager.RefreshMyself();
end

function SystemSettingsPage.checkBoxEnableForceHideBack(bChecked)
	System.options.EnableForceHideBack = bChecked;
	MyCompany.Aries.Player.SaveLocalData("SystemSettingsPage.EnableForceHideBack", bChecked);
	ParaScene.GetAttributeObject():SetField("checkBoxEnableForceHideBack", bChecked);
	-- force refresh avatar
	System.Item.ItemManager.RefreshMyself();
end

function SystemSettingsPage.onclickLockCamera(bChecked)
    MyCompany.Aries.AutoCameraController:MakeEnable(bChecked); 
end

function SystemSettingsPage.checkBoxRightBottomTips(bChecked)
	NPL.load("(gl)script/apps/Aries/Desktop/Dock/LoopTips.lua");
	local LoopTips = commonlib.gettable("MyCompany.Aries.Desktop.LoopTips");
	LoopTips.OnCheckExpandBtn(bChecked)
end

-- check if minimum requirement is met to run the game. 
-- @param bShowUI: true to display UI when minimum requirement is not met. 
-- @param callbackFunc: the callback function (result, msg, bContinue)  end, in case bShowUI is true. the callback is called after user has clicked OK;
-- @return result, msg: There are three possible outcome: 1 user is qualified to run; 0 user is not fully qualified to run but can run in low resolution mode; -1 can not run no matter what. 
-- Text message is also shown to the user. 
function SystemSettingsPage.CheckMinimumSystemRequirement(bShowUI, callbackFunc)
	local result = 1;
	local sMsg = "";
	min_requirement_data = {};
	local function SetResult(res, msg)
		if(result>res) then
			result = res;
			min_requirement_data.result = res;
		end
		if(msg) then
			min_requirement_data.sMsg = sMsg.."<br/>"..msg;
			sMsg = sMsg.."\n"..msg;
		end
	end

	local stats = SystemSettingsPage.GetPCStats();
	if(stats.memory and stats.memory<500) then
		if(stats.memory<300) then
			SetResult(-1, "您的电脑内存太小了");
		else
			SetResult(0, "您的电脑内存太小了");
		end
	end
	
	if(stats.ps<2 or stats.vs < 2) then
		SetResult(0, "您的电脑显卡太旧了");
	end

	if(bShowUI) then
		-- TODO: FOR testing, set result to 0 or -1
		-- SetResult(0, "您的电脑显卡太旧了<br/>您的电脑内存太小了");
		if(result<=0) then
			local params = {
				url = "script/apps/Aries/Desktop/AriesMinRequirementPage.html", 
				name = "AriesMinRequirementWnd", 
				isShowTitleBar = false,
				DestroyOnClose = true, -- prevent many ViewProfile pages staying in memory
				style = CommonCtrl.WindowFrame.ContainerStyle,
				zorder = 2,
				isTopLevel = true,
				directPosition = true,
					align = "_ct",
					x = -550/2,
					y = -380/2,
					width = 550,
					height = 380,
			}
			System.App.Commands.Call("File.MCMLWindowFrame", params);
			params._page.OnClose = function()
				if(callbackFunc) then
					callbackFunc(result, sMsg);
				end
			end
			return result, sMsg;
		end
	end
	if(callbackFunc) then
		callbackFunc(result, sMsg);
	end
	return result, sMsg;
end

local pc_stats;
-- get a table containing all kinds of stats for this computer. 
-- @return {videocard, os, memory, ps, vs}
function SystemSettingsPage.GetPCStats()
	if(not pc_stats) then
		pc_stats = {};
		pc_stats.videocard = ParaEngine.GetStats(0);
		pc_stats.os = ParaEngine.GetStats(1);
		
		local att = ParaEngine.GetAttributeObject();
		local sysInfoStr = att:GetField("SystemInfoString", "");
		echo(sysInfoStr);
		local name, value, line;
		for line in sysInfoStr:gmatch("[^\r\n]+") do
			name,value = line:match("^(.*):(.*)$");
			if(name == "TotalPhysicalMemory") then
				value = tonumber(value)/1024;
				pc_stats.memory = value;
			else
				-- TODO: other OS settings
			end
		end
		pc_stats.ps = att:GetField("PixelShaderVersion", 0);
		pc_stats.vs = att:GetField("VertexShaderVersion", 0);

		-- uncomment to test low shader 
		--pc_stats.ps = 1;
		--pc_stats.memory = 300

		local att = ParaEngine.GetAttributeObject();
		pc_stats.IsFullScreenMode = att:GetField("IsFullScreenMode", false);
		pc_stats.resolution_x = tonumber(att:GetDynamicField("ScreenWidth", 1020)) or 1020;
		pc_stats.resolution_y = tonumber(att:GetDynamicField("ScreenHeight", 680)) or 680;
		pc_stats.IsWebBrowser = System.options.IsWebBrowser;
	end
	return pc_stats;
end

--return monitor resolution
--return width,height
function SystemSettingsPage.GetMonitorResolution()
	local att = ParaEngine.GetAttributeObject();
	local res = att:GetField("MonitorResolution",{1024,768})
	return res[1], res[2];
end

--return all supported display mode
--return value: { {width,height,refreshRate},{width,height,refreshRate}...}
function SystemSettingsPage.GetSupportDisplayMode()
	local att = ParaEngine.GetAttributeObject();
	local displayStr = att:GetField("DisplayMode","");
	if(displayStr == "")then
		return nil;
	end
	
	local result = {};
	local match;
	for match in string.gmatch(displayStr,"%d+ %d+ %d+") do
		local displayMode = {};
		displayMode.width,displayMode.height,displayMode.refreshRate = string.match(match,"(%d+) (%d+) (%d+)");
		table.insert(result,displayMode);
	end
	return result;
end

local standard_resolution_list = {
    [1] = { value="1280 × 720", selected="true", text="1280 × 720", }, 
    [2] = { value="1440 × 900", text="1440 × 900"}, 
    [3] = { value="1680 × 1050", text="1680 × 1050"}, 
    [4] = { value="1920 × 1080", text="1920 × 1080"}, 
    [5] = { value="1920 × 1200", text="1920 × 1200"}, 
    [6] = { value="2048 × 1080", text="2048 × 1080"}, 
    [7] = { value="2560 × 1440", text="2560 × 1440"}, 
    [8] = { value="2560 × 1600", text="2560 × 1600"}, 
    [9] = { value="3840 × 2160", text="3840 × 2160"}, 
    [10] = { value="4096 × 2160", text="4096 × 2160"},
}
-- local standard_resolution_list = {
--     [1] = { value="1280 × 720", selected="true", text="1280 × 720 (HD)(推荐)", }, 
--     [2] = { value="1440 × 900", text="1440 × 900 (推荐)"}, 
--     [3] = { value="1680 × 1050", text="1680 × 1050"}, 
--     [4] = { value="1920 × 1080", text="1920 × 1080 (FHD)(推荐)"}, 
--     [5] = { value="1920 × 1200", text="1920 × 1200"}, 
--     [6] = { value="2048 × 1080", text="2048 × 1080 (DCI 2K)"}, 
--     [7] = { value="2560 × 1440", text="2560 × 1440"}, 
--     [8] = { value="2560 × 1600", text="2560 × 1600"}, 
--     [9] = { value="3840 × 2160", text="3840 × 2160 (UHD)"}, 
--     [10] = { value="4096 × 2160", text="4096 × 2160 (DCI 4K)"},
-- }

--return resolution list for SystemSettingsPage.ScreenResolution combobox
function SystemSettingsPage.GetResolutionList()
    local monitor_width, monitor_height = SystemSettingsPage.GetMonitorResolution();
    local supported_resolution = {};
    for i,v in ipairs(standard_resolution_list) do
        local res_x,res_y = string.match(v.value or "", "(%d+)%D+(%d+)");
        if res_x and res_y then
            res_x = tonumber(res_x);
            res_y = tonumber(res_y);
            if res_x <= monitor_width and res_y <= monitor_height then
                table.insert(supported_resolution, v);
            end
        else
            LOG.std(nil, "warning", "cellfy", "invalid resolution item, please check again");
        end
    end
    if #supported_resolution == 0 then
        LOG.std(nil, "error", "cellfy", "not even one single resolution supported by this moniter, there may be something wrong (or the player's monitor is extremely old)");
    end
    return supported_resolution;
end

-- get a table containing {result, sMsg} as in CheckMinimumSystemRequirement;
function SystemSettingsPage.GetMinRequirementData()
	if(not min_requirement_data) then
		SystemSettingsPage.CheckMinimumSystemRequirement();
	end
	return min_requirement_data;
end

-- automatically adjust according to current graphics card shader version. 
-- @param bShowUI: true to display UI for user confirmation. 
-- @param callbackFunc: the callback function when settings have been adjusted. function(bChanged)  end
-- @param OnChangeCallback: nil or a callback function that is invoked before changes are applied. 
-- It gives the caller a chance to drop any changes made by returning false. e.g. in web edition, we can not modified changes directly,instead we need to invoke via IPC to change. 
function SystemSettingsPage.AutoAdjustGraphicsSettings(bShowUI, callbackFunc, OnChangeCallback)
	local att = ParaEngine.GetAttributeObject();
	local shader_version = GetShaderVersion();
	
	NPL.load("(gl)script/apps/Aries/Player/main.lua");
	local is_user_confirmed = MyCompany.Aries.Player.LoadLocalData("user_confirmed", false, true);
	
	local effect_level = att:GetField("Effect Level", 0);
	local screen_resolution = att:GetField("ScreenResolution", {800, 600}); 
	local new_screen_resolution;
	local new_effect_level;
	local use_terrain_normal;

	-- uncomment to test a given setting. 
	-- local new_screen_resolution = {400,300};
	-- local new_effect_level = 0;
	
	if(shader_version < 3) then
		-- for shader version smaller than 2, use 800*600 as default. 
		if(screen_resolution[1] > 800) then
			new_screen_resolution = {800, 533}
		end
		
		if(shader_version < 2) then
			if(effect_level ~= 1024) then
				new_effect_level = 1024;
			end
		elseif(shader_version < 3) then	
			if(effect_level > 0 and effect_level<100) then
				new_effect_level = 0;
			end
		end
		-- if video card is old, we will not use 32bits textures, which saves lots of video memory. 
		ParaEngine.GetAttributeObject():SetField("Is32bitsTextureEnabled", false)
		ParaScene.GetAttributeObjectOcean():SetField("IsAnimateFFT", false);
		use_terrain_normal = false;
	end

	local stats = SystemSettingsPage.GetPCStats();
	-- local test_low_memory = true; -- comment this at release time
	if(test_low_memory) then
		LOG.warn("this test line should be removed");
		stats.memory = 512;
	end
	
	local res_width, res_height = SystemSettingsPage.GetMonitorResolution();
	if(System.options.version=="teen") then
		NPL.load("(gl)script/apps/Aries/Player/main.lua");

		if(att:GetField("IsFullScreenMode",false) == false) then
			-- windowed mode
			recommended_resolution = recommended_resolution_teen;	
			if((res_width-60)<recommended_resolution[1]) then
				recommended_resolution[1] = res_width - 60;
			end
			if((res_height-80)<recommended_resolution[2]) then
				recommended_resolution[2] = res_height - 80;
			end
		end
	end
	recommended_resolution[1] = math.min(res_width, recommended_resolution[1]);
	recommended_resolution[2] = math.min(res_height, recommended_resolution[2]);

	if(System.options.IsWebBrowser) then
		recommended_resolution = recommended_resolution_web_browser;

		if(screen_resolution[1]>recommended_resolution[1] or screen_resolution[1] > recommended_resolution[2]) then
			-- for web version, the maximum resolution for web to start initially is this.  
			new_screen_resolution = recommended_resolution;
		end
	end

	if(shader_version >= 3 and effect_level == 0) then
		if(stats.memory and stats.memory>2000) then
			-- if shader version is high and physical memory is large, we will enable mesh reflection when effect level is high. 
			ParaScene.GetAttributeObjectOcean():SetField("EnableMeshReflection", true)
		end
	end
	
	-- if system memory is small, we will not use 32bits textures. 
	if(stats.memory and stats.memory < 600) then
		ParaEngine.GetAttributeObject():SetField("Is32bitsTextureEnabled", false);
		use_terrain_normal = false;
	end
	if(stats.memory and stats.memory < 2000) then
		-- we will assume memory over 2G is high end computer, so only animate FFT on it.  
		ParaScene.GetAttributeObjectOcean():SetField("IsAnimateFFT", false);
	end
	if(use_terrain_normal == false) then
		ParaTerrain.GetAttributeObject():SetField("UseNormals", false);
	end

	if(shader_version >= 3 and stats.memory>2000) then
		-- this allows us to change the resolution by dragging the window size. 
		ParaEngine.GetAttributeObject():SetField("IgnoreWindowSizeChange", false);
		-- only set when the computer is pretty cool. 
		
		if(not stats.IsFullScreenMode) then
			if(not System.options.IsWebBrowser) then
				if(screen_resolution[1]<recommended_resolution[1] or screen_resolution[1] < recommended_resolution[2]) then
					-- this is the recommended resolution for good computers with shader 3 and memory >2GB
					new_screen_resolution = recommended_resolution;
				end
			end
		end
		LOG.std(nil, "system", "settings", "enabled render resolution matching with window size, because your system is good enough.");
	end

	if(is_user_confirmed) then
		-- tricky: if the user has already confirmed changing the resolution, we will ignore auto modifications. 
		-- such that user can use a smaller or bigger resolution or effect regardless of its hardware. 
		new_effect_level =nil;
		if(not System.options.IsWebBrowser) then
			new_screen_resolution = nil;
		end
	end

	if(new_effect_level or new_screen_resolution) then
		local function ApplyChanges()
			local bApplyChange = true;
			if(OnChangeCallback) then
				local params = {
					shader_version = shader_version, -- number
					new_effect_level = new_effect_level, -- number
					new_screen_resolution = new_screen_resolution, -- nil or {x,y}
				}
				bApplyChange = (OnChangeCallback(params)~=false)
			end
			if(bApplyChange) then
				if(new_screen_resolution) then
					if(System.options.IsWebBrowser) then
						commonlib.app_ipc.ActivateHostApp("change_resolution", nil, new_screen_resolution[1], new_screen_resolution[2]);
					else	
						att:SetField("ScreenResolution", new_screen_resolution); 
					end	
				end	
				if(new_effect_level) then
					SystemSettingsPage.AdjustGraphicsSettingsByEffectLevel(new_effect_level)
					if(use_terrain_normal == false) then
						ParaEngine.GetAttributeObject():SetField("UseNormals", use_terrain_normal);
					end
				end
				if(new_screen_resolution) then
					att:CallField("UpdateScreenMode");
				end	
				ParaEngine.WriteConfigFile("config/config.txt");
				if(type(callbackFunc) == "function") then
					callbackFunc(true);
				end
			else
				callbackFunc(false);
			end	
		end
		
		if(bShowUI) then
			local text;
			if(new_effect_level == 1024) then
				_guihelper.MessageBox("为了更好的运行程序, 我们建议您购买新的3D显卡。我们即将自动为您调整为最低的3D画面质量", function(res)
					ApplyChanges();
				end, _guihelper.MessageBoxButtons.OK)
			else
				_guihelper.MessageBox("我们发现您的计算机显卡比较旧, 为了更好的运行程序, 您是否希望我们自动为您调整为较低的画面质量？", function(res)
					if(res and res == _guihelper.DialogResult.Yes) then
						ApplyChanges();
					else
						if(type(callbackFunc) == "function") then
							callbackFunc(false);
						end
					end	
				end, _guihelper.MessageBoxButtons.YesNo)
			end
			
		else
			ApplyChanges();
		end
	else
		if(type(callbackFunc) == "function") then
			callbackFunc(false);
		end
	end
end

-- set graphics settings by effect level.  This function can be called at the beginning. 
-- @param value: -1024, -1, 0,1,2
function SystemSettingsPage.AdjustGraphicsSettingsByEffectLevel(effect_level)
	local att = ParaEngine.GetAttributeObject();
	local att_ocean = ParaScene.GetAttributeObjectOcean();
	
	local FarPlane = 420;
	att:SetField("Effect Level", effect_level);
	
	local shader_version = GetShaderVersion();
	
	if(effect_level == 1024) then
		att:SetField("TextureLOD", 1);
		att:SetField("SetShadow", false);
		
		att_ocean:SetField("EnableTerrainReflection", false)
		att_ocean:SetField("EnableMeshReflection", false)
		att_ocean:SetField("EnablePlayerReflection", false)
		att_ocean:SetField("EnableCharacterReflection", false)
		
		FarPlane = 100;
				
	elseif(effect_level == -1) then
		att:SetField("TextureLOD", 1);
		att:SetField("SetShadow", false);
	
		att_ocean:SetField("EnableTerrainReflection", false)
		att_ocean:SetField("EnableMeshReflection", false)
		att_ocean:SetField("EnablePlayerReflection", false)
		att_ocean:SetField("EnableCharacterReflection", false)
		
		FarPlane = 120;
		
	elseif(effect_level == 0) then
		att:SetField("TextureLOD", 0);
		att:SetField("SetShadow", false);
	
		att_ocean:SetField("EnableTerrainReflection", false)
		att_ocean:SetField("EnableMeshReflection", false)
		att_ocean:SetField("EnablePlayerReflection", false)
		att_ocean:SetField("EnableCharacterReflection", false)
		
		if(shader_version > 2) then
			FarPlane = 420;
		else
			FarPlane = 220;
		end	
		
	elseif(effect_level == 1) then
		att:SetField("TextureLOD", 0);
		att:SetField("SetShadow", true);
	
		att_ocean:SetField("EnableTerrainReflection", true)
		att_ocean:SetField("EnableMeshReflection", true)
		att_ocean:SetField("EnablePlayerReflection", false)
		att_ocean:SetField("EnableCharacterReflection", false)
		
		FarPlane = 420;
		
	elseif(effect_level == 2) then
		att:SetField("TextureLOD", 0);
		att:SetField("SetShadow", true);
		
		att_ocean:SetField("EnableTerrainReflection", true)
		att_ocean:SetField("EnableMeshReflection", true)
		att_ocean:SetField("EnablePlayerReflection", true)
		att_ocean:SetField("EnableCharacterReflection", true)
		
		FarPlane = 420;
	end

	att:SetField("UseDropShadow", not att:GetField("SetShadow", false));
	
	if(FarPlane) then
		local FarPlane_range = {from=100,to=420}
		local FogStart_range = {from=50,to=80}
		local FogEnd_range	 = {from=70,to=130}
		
		value = (FarPlane-FarPlane_range.from) / (FarPlane_range.to- FarPlane_range.from);
		att:SetField("FogEnd", FogEnd_range.from + (FogEnd_range.to - FogEnd_range.from) * value);
		att:SetField("FogStart", FogStart_range.from + (FogStart_range.to - FogStart_range.from) * value);
		ParaCamera.GetAttributeObject():SetField("FarPlane", FarPlane);
	end	
end

-- 音效sliderbar
function SystemSettingsPage.OnSoundSliderChanged(value)
	MyCompany.Aries.Player.SaveLocalData("Paracraft_System_Sound_State",true,true);
	MyCompany.Aries.Player.SaveLocalData("Paracraft_System_Sound_Volume",value,true);
	ParaAudio.SetVolume(value);
end

-- Fov sliderbar
function SystemSettingsPage.OnFovSliderChanged(value)
	NPL.load("(gl)script/apps/Aries/Creator/Game/World/CameraController.lua");
	local CameraController = commonlib.gettable("MyCompany.Aries.Game.CameraController")
	MyCompany.Aries.Player.SaveLocalData("SystemSettingsPage_Fov",value,true);
	CameraController.AnimateFieldOfView(value, nil);
end

function SystemSettingsPage.OnClickEnableSound()
	AudioEngine.PlayUISound("btn_show");
	--local openMusic = SystemSettingsPage.setting_ds["open_sound"];
	local cur_state = SystemSettingsPage.setting_ds["open_sound"];
	local next_state = not cur_state;
	SystemSettingsPage.setting_ds["open_sound"] = next_state;
	if(page)then
		if(next_state) then
			-- page:SetValue("btn_EnableSound", L"开启")
			SystemSettingsPage.ChangeButtonValue("btn_EnableSound",true)
			local sound_volume = MyCompany.Aries.Player.LoadLocalData("Paracraft_System_Sound_Volume",1,true);
			ParaAudio.SetVolume(sound_volume);
		else
			-- page:SetValue("btn_EnableSound", L"关闭");
			SystemSettingsPage.ChangeButtonValue("btn_EnableSound",false)
			SystemSettingsPage.OnClickChangeSoundVolume();
		end
	end
	local MapArea = commonlib.gettable("MyCompany.Aries.Desktop.MapArea");
	if(MapArea.EnableMusic) then
		MapArea.EnableMusic(next_state);
	end
	local key = "Paracraft_System_Sound_State";
	MyCompany.Aries.Player.SaveLocalData(key,next_state,true);
end

function SystemSettingsPage.OnClickEnableShader()
	AudioEngine.PlayUISound("btn_show");
	local cur_state = SystemSettingsPage.setting_ds["emulational_lighting"];
	local next_state = not cur_state;
	if(not GameLogic.GetShaderManager():SetShaders(if_else(next_state, 2,1))) then
        if(next_state) then 
            Page:SetValue("checkboxShader", false);
            _guihelper.MessageBox(L"您的显卡不支持这个效果, 请升级您的显卡");
        end
    else
		-- page:SetValue("btn_Shader", GetCheckBoxText(next_state));
		SystemSettingsPage.ChangeButtonValue("btn_Shader",next_state)
		SystemSettingsPage.setting_ds["emulational_lighting"] = next_state;
		WorldCommon.GetWorldInfo().rendermethod = tostring(if_else(next_state, 2,1));
    end
end

function SystemSettingsPage.OnClickEnableShadow()
	AudioEngine.PlayUISound("btn_show");
	local cur_state = SystemSettingsPage.setting_ds["sunlight_shadow"];
	local next_state = not cur_state;
	-- page:SetValue("btn_Shadow", GetCheckBoxText(next_state));
	SystemSettingsPage.ChangeButtonValue("btn_Shadow",next_state)
    ParaTerrain.GetBlockAttributeObject():SetField("UseSunlightShadowMap", next_state);
	SystemSettingsPage.setting_ds["sunlight_shadow"] = next_state;
	WorldCommon.GetWorldInfo().shadow = tostring(next_state);
  MyCompany.Aries.Player.SaveLocalData("Paracraft_System_Shadow",next_state,true);
end

function SystemSettingsPage.OnClickEnableShowMainPlayer()
	AudioEngine.PlayUISound("btn_show");
	local cur_state = SystemSettingsPage.setting_ds["show_mainplayer"];
	local next_state = not cur_state;
	-- page:SetValue("btn_ShowPlayer", GetCheckBoxText(next_state));
	SystemSettingsPage.ChangeButtonValue("btn_ShowPlayer",next_state)
	ParaScene.GetAttributeObject():SetField("ShowMainPlayer", next_state);
	SystemSettingsPage.setting_ds["show_mainplayer"] = next_state;
end

function SystemSettingsPage.OnClickEnableWaterReflection()
	AudioEngine.PlayUISound("btn_show");
	local cur_state = SystemSettingsPage.setting_ds["water_reflection"];
	local next_state = not cur_state;
	--page:SetValue("btn_WaterReflection", GetCheckBoxText(next_state));
	SystemSettingsPage.ChangeButtonValue("btn_WaterReflection",next_state)
	ParaTerrain.GetBlockAttributeObject():SetField("UseWaterReflection", next_state)
	SystemSettingsPage.setting_ds["water_reflection"] = next_state;
	WorldCommon.GetWorldInfo().waterreflection = tostring(next_state);
	MyCompany.Aries.Player.SaveLocalData("Paracraft_System_Water_Reflection",next_state,true);
end

function SystemSettingsPage.OnClickEnableMouseInverse()
	AudioEngine.PlayUISound("btn_show");
	local cur_state = SystemSettingsPage.setting_ds["mouse_inverse"];
	local next_state = not cur_state;
	-- page:SetValue("btn_MouseInverse", GetCheckBoxText(next_state));
	SystemSettingsPage.ChangeButtonValue("btn_MouseInverse",next_state)
	ParaEngine.GetAttributeObject():SetField("IsMouseInverse", next_state);
	--ParaTerrain.GetBlockAttributeObject():SetField("UseWaterReflection", not value)
	SystemSettingsPage.setting_ds["mouse_inverse"] = next_state;
	local key = "Paracraft_System_Mouse_Inverse";
	MyCompany.Aries.Player.SaveLocalData(key,next_state,true);
end

function SystemSettingsPage.OnClickChangeRenderDist()
	AudioEngine.PlayUISound("btn_show");
	local text = SystemSettingsPage.setting_ds["render_dist"];
	local new_text = SystemSettingsPage.render_dist_list[text]["next"];
	local next_dist = SystemSettingsPage.render_dist_list[new_text]["dist"];

	page:SetValue("btn_RenderDist", new_text);
	GameLogic.options:SetRenderDist(next_dist);
	SystemSettingsPage.setting_ds["render_dist"] = new_text;
	WorldCommon.GetWorldInfo().renderdist = tostring(next_dist);
end

function SystemSettingsPage.OnChangeVisibility(value)
	AudioEngine.PlayUISound("btn_scroll");
	value = tonumber(value);
	GameLogic.options:SetRenderDist(value);
	WorldCommon.GetWorldInfo().renderdist = tostring(value);
  SystemSettingsPage.setting_ds["render_dist"]=value;
  MyCompany.Aries.Player.SaveLocalData("Paracraft_System_Render_Distance",value,true);
end

-- function SystemSettingsPage.OnChangeSuperrender(value)
-- 	AudioEngine.PlayUISound("btn_scroll");
-- 	value = tonumber(value);
-- 	GameLogic.options:SetSuperRenderDist(value);
-- end
function SystemSettingsPage.OnClickChangeSoundVolume()
	AudioEngine.PlayUISound("btn_show");
	local text = SystemSettingsPage.setting_ds["sound_volume"];
	local new_text = SystemSettingsPage.sound_volume_list[text]["next"];
	local next_volume = SystemSettingsPage.sound_volume_list[new_text]["dist"];

	-- page:SetValue("btn_SoundVolume", new_text);
	local sound_state = SystemSettingsPage.setting_ds["open_sound"];
	if sound_state then
    SystemSettingsPage.setting_ds["sound_volume"] = new_text;
  else
    next_volume=0;
	end
  SystemSettingsPage.ChangeSoundValue("btn_SoundVolume",next_volume)
  ParaAudio.SetVolume(next_volume);
	local key = "Paracraft_System_Sound_Volume";
	MyCompany.Aries.Player.SaveLocalData(key,next_volume,true);
end

function SystemSettingsPage.OnChangeMemLimit(value)
	AudioEngine.PlayUISound("btn_scroll");
	local text = (value*4).." MB";
	page:SetValue("txt_MemLimit", text);

	SystemSettingsPage.newMemLimit = tonumber(value);
end

function SystemSettingsPage.OnOK()
	AudioEngine.PlayUISound("btn_show");
	local bNeedUpdateScreen;
	local att = ParaEngine.GetAttributeObject();
	local ds = SystemSettingsPage.setting_ds;

	local btn_Shader_value = page:GetValue("btn_Shader")
    local shaderValue = tonumber(btn_Shader_value);
    if shaderValue then
		local cur_state = SystemSettingsPage.setting_ds["emulational_lighting_value"];
		if cur_state ~= shaderValue then
			if (not GameLogic.GetShaderManager():SetShaders(math.min(2, shaderValue))) then
				page:SetValue("btn_Shader",cur_state)
	            _guihelper.MessageBox(L"您的显卡不支持这个效果, 请升级您的显卡");
	        else

				--ParaTerrain.GetBlockAttributeObject():SetField("UseLinearTorchBrightness", shaderValue >=3);
				if(shaderValue >=2) then
					local effect = GameLogic.GetShaderManager():GetEffect("Fancy");
					if(effect) then
						effect:EnableBloomEffect(shaderValue >=3);
						effect:EnableDepthOfViewEffect(shaderValue >=4);
					end
				end
				
				SystemSettingsPage.setting_ds["emulational_lighting_value"] = shaderValue;
				WorldCommon.GetWorldInfo().rendermethod = shaderValue;
          
        NPL.load("(gl)script/Seer/Utility/GlobalMessageDispatcher.lua");
        local GlobalMessageDispatcher=commonlib.gettable("Mod.Seer.Utility.GlobalMessageDispatcher");
        GlobalMessageDispatcher.getMessageSource():notify(GlobalMessageDispatcher.getMessage_ShaderLevelChange(),shaderValue);
	        end
		end
	end

	if(not System.options.IsWebBrowser) then
		value = page:GetValue("ScreenResolution");
		local x,y = string.match(value or "", "(%d+)%D+(%d+)");
		if(x~=nil and y~=nil) then
			x = tonumber(x)
			y = tonumber(y)
			if(x~=nil and y~=nil) then
				local size = {x, y};
				local oldsize = att:GetField("ScreenResolution", {1020,680});
				if(oldsize[1] ~=x or oldsize[2]~= y) then
					bNeedUpdateScreen = true;
				end
				if(System.options.IsWebBrowser) then
					commonlib.app_ipc.ActivateHostApp("change_resolution", nil, size[1], size[2]);
				else	
					att:SetField("ScreenResolution", size);
				end	
			end
		end
	end

	if(bNeedUpdateScreen) then
		_guihelper.MessageBox("您的显示设备即将改变:如果您的显卡不支持, 需要您重新登录。是否继续?", function ()
			ParaEngine.GetAttributeObject():CallField("UpdateScreenMode");
			GameLogic.options:EnableStereoMode(false);  --disable stereo mode temporarily before refining the resolution list
			-- we will save to "config.new.txt", so the next time the game engine is started, it will ask the user to preserve or not. 
			ParaEngine.WriteConfigFile("config/config.new.txt");
		end)
	else
		ParaEngine.WriteConfigFile("config/config.new.txt");
	end

	if(SystemSettingsPage.newMemLimit and SystemSettingsPage.newMemLimit ~= SystemSettingsPage.oldMemLimit) then
		local attr = ParaTerrain.GetBlockAttributeObject();
		local max_mem_bytes = SystemSettingsPage.newMemLimit * 1024 * 1024;
		attr:SetField("VertexBufferSizeLimit", max_mem_bytes);
		attr:SetField("MaxVisibleVertexBufferBytes", max_mem_bytes/4);
	end
	MyCompany.Aries.Player.SaveLocalData("Paracraft_System_Memory_Limit",SystemSettingsPage.newMemLimit,true);
	MyCompany.Aries.Player.SaveLocalData("Paracraft_System_Shader",SystemSettingsPage.setting_ds["emulational_lighting_value"],true);
	MyCompany.Aries.Player.SaveLocalData("Paracraft_System_Screen_Resolution",att:GetField("ScreenResolution",{800, 600}),true);
	UserDatabase.setAttribute("SystemPreferences.NPC.On", SystemSettingsPage.NPC_type,"local");

	SystemSettingsPage.ClosePage()
end

function SystemSettingsPage.ShowPage(zorder)
	NPL.load("(gl)script/seer/Utility/CommonUtility.lua");
	local CommonUtility = commonlib.gettable("Mod.Seer.Utility.CommonUtility");
	
	local params;

	if CommonUtility:IsMobilePlatform() then

		params = {
		url = "script/Seer/SystemSettingsPage.html", 
		name = "SystemSettingsPage.ShowPage", 
		isShowTitleBar = false,
		DestroyOnClose = true,
		bToggleShowHide=true, 
		style = CommonCtrl.WindowFrame.ContainerStyle,
		allowDrag = false,
		enable_esc_key = true,
		--bShow = bShow,
		click_through = false, 
		zorder = zorder,
		app_key = MyCompany.Aries.Creator.Game.Desktop.App.app_key, 
		directPosition = true,
			align = "_fi",
			x = 0,
			y = 0,
			width = 0,
			height = 0,
		};

	else

		params = {
		url = "script/Seer/SystemSettingsPage.PC.html", 
		name = "SystemSettingsPage.ShowPage", 
		isShowTitleBar = false,
		DestroyOnClose = true,
		bToggleShowHide=true, 
		style = CommonCtrl.WindowFrame.ContainerStyle,
		allowDrag = true,
		enable_esc_key = true,
		--bShow = bShow,
		click_through = false,
		zorder = zorder,
		app_key = MyCompany.Aries.Creator.Game.Desktop.App.app_key, 
		directPosition = true,
			align = "_ct",
			x = -366,
			y = -230,
			width = 732,
			height = 460,
		};

	end
	
	--CreatorDesktop.params.bShow = bShow;
	System.App.Commands.Call("File.MCMLWindowFrame", params);
	--SystemSettingsPage.InitPageParams()
	SystemSettingsPage.RefreshDayNightState()
	SystemSettingsPage.InitPageParams();
	SystemSettingsPage.RefreshPage();
end

function SystemSettingsPage.OnCancel()
	AudioEngine.PlayUISound("btn_show");
	SystemSettingsPage.ClosePage()
end

function SystemSettingsPage.RefreshPage()
	value = GameLogic.options:GetRenderDist();
	page:SetValue("visibility", tostring(value));

	-- value = GameLogic.options:GetSuperRenderDist();
	-- page:SetValue("superrender", tostring(value));

	local attr = ParaTerrain.GetBlockAttributeObject();
	value = attr:GetField("VertexBufferSizeLimit", 100*1024*1024);
	value = value / 1024 / 1024;
	SystemSettingsPage.oldMemLimit = value;
	page:SetValue("memlimit", value);
	local text = tostring(value*4).." MB";
	page:SetValue("txt_MemLimit", text);
	page:SetValue("sound", ParaAudio.GetVolume());
	page:SetValue("fov", MyCompany.Aries.Player.LoadLocalData("SystemSettingsPage_Fov",1.04,true));
end

function SystemSettingsPage.ChangeSoundValue(name,value)
	local btnNode = page:GetNode(name)
	if btnNode then
		local ctl = btnNode:GetControl()
		if ctl then
			if value <1 then
				ctl.background = UIUtility.GetMCMLStandardImageDescription("gameassets/textures/ui_11_esc/NewSettingsUI.png","93.png")
			elseif value < 2 then
				ctl.background = UIUtility.GetMCMLStandardImageDescription("gameassets/textures/ui_11_esc/NewSettingsUI.png","92.png")
			else
				ctl.background = UIUtility.GetMCMLStandardImageDescription("gameassets/textures/ui_11_esc/NewSettingsUI.png","91.png")
			end
		end
	end
end
function SystemSettingsPage.ChangeButtonValue(name,value)

	local btnNode = page:GetNode(name)
	if btnNode then
		local ctl = btnNode:GetControl()
		if ctl then
			
 			if CommonUtility:IsMobilePlatform() then
 				if value == true or value == "true" then
					ctl.background = UIUtility.GetMCMLStandardImageDescription("gameassets/textures/ui_11_esc/NewSettingsUI.png","95.png")
				else
					ctl.background = UIUtility.GetMCMLStandardImageDescription("gameassets/textures/ui_11_esc/NewSettingsUI.png","94.png")
				end
			else
				if value == true or value == "true" then
					ctl.background = UIUtility.GetMCMLStandardImageDescription("gameassets_pc/textures/ui_settings/systemsettings.png","37.png")
				else
					ctl.background = UIUtility.GetMCMLStandardImageDescription("gameassets_pc/textures/ui_settings/systemsettings.png","38.png")
				end
			end

			
		end
	end
end
function SystemSettingsPage.ChangeStereoValue(name,value)
	local btnNode = page:GetNode(name)
	if btnNode then
		local ctl = btnNode:GetControl()
		if ctl then
			if CommonUtility:IsMobilePlatform() then
				if value == true or value == "true" then
					ctl.background = UIUtility.GetMCMLStandardImageDescription("gameassets/textures/ui_11_esc/NewSettingsUI.png","95.png")
				else
					ctl.background = UIUtility.GetMCMLStandardImageDescription("gameassets/textures/ui_11_esc/NewSettingsUI.png","94.png")
				end
			else
				if value == true or value == "true" then
					ctl.background = UIUtility.GetMCMLStandardImageDescription("gameassets_pc/textures/ui_settings/systemsettings.png","37.png")
				else
					ctl.background = UIUtility.GetMCMLStandardImageDescription("gameassets_pc/textures/ui_settings/systemsettings.png","38.png")
				end
			end
		end
	end
end

function SystemSettingsPage.OnSuperrender()
	AudioEngine.PlayUISound("btn_show");
	local value = GameLogic.options:GetSuperRenderDist();
	local dist = 0;
	local btnValue = false
	if value > 100 then
		dist = 0
		btnValue = false
	else
		dist = 2000
		btnValue = true
	end
	GameLogic.options:SetSuperRenderDist(dist);
	SystemSettingsPage.ChangeButtonValue("btn_superrender",btnValue)
  MyCompany.Aries.Player.SaveLocalData("Paracraft_System_Super_Render_Distance",dist,true);
end
function SystemSettingsPage.OnToggleViewBobbing()
	AudioEngine.PlayUISound("btn_show");
	local value = not GameLogic.options:GetViewBobbing();
	GameLogic.options:SetViewBobbing(value);
	-- if(page) then
		-- page:SetValue("btn_ViewBobbing", GetCheckBoxText(value));
	-- end
	SystemSettingsPage.ChangeButtonValue("btn_ViewBobbing",value)
end

function SystemSettingsPage.OnChangeStereoMode()
	AudioEngine.PlayUISound("btn_show");
	local mode = not GameLogic.options:IsStereoMode()
	--SystemSettingsPage.ChangeStereoValue("stereomode",mode) --disabled since a messagebox will popup for confirmation
	local att = ParaEngine.GetAttributeObject();
	local screen_resolution = att:GetField("ScreenResolution", {800, 600});
	local monitor_width, monitor_height = SystemSettingsPage.GetMonitorResolution();
	local new_width = nil;
	local new_height = nil;
	if mode == true or mode == "true" then
		if screen_resolution[1]*2 > monitor_width then
			new_width = monitor_width;
			new_height = monitor_width*9/16/2;
		else
			new_width = screen_resolution[1]*2;
			new_height = screen_resolution[2];
		end
	else
		new_width = screen_resolution[1]/2;
		new_height = screen_resolution[2];
		local min_x,min_y = string.match(standard_resolution_list[1].value or "", "(%d+)%D+(%d+)");
		if min_x and min_y then
			min_x = tonumber(min_x);
			min_y = tonumber(min_y);
			if new_width < min_x or new_height < min_y then
				new_width = min_x;
				new_height = min_y;
			end
		else
			LOG.std(nil, "error", "cellfy", "first resolution item invalid, please check again");
		end
	end
	_guihelper.MessageBox("您的显示设备即将改变:如果您的显卡不支持, 需要您重新登录。是否继续?", function (res)
		if(res and res == _guihelper.DialogResult.Yes) then
			att:SetField("ScreenResolution", {new_width, new_height});
			ParaEngine.GetAttributeObject():CallField("UpdateScreenMode");
			GameLogic.options:EnableStereoMode(mode);
			SystemSettingsPage.ClosePage();
		else
			SystemSettingsPage:RefreshPage()
		end
	end, _guihelper.MessageBoxButtons.YesNo);
end

function SystemSettingsPage.OnChangeStereoEyeDist(value)
	AudioEngine.PlayUISound("btn_scroll");
	value = tonumber(value);
	if(value) then
		GameLogic.options:SetStereoEyeSeparationDist(value);
	end
end

function SystemSettingsPage.OnClickBlockPlayer()
	if SystemSettingsPage.block_type then
		SystemSettingsPage.block_type = false
	else
		SystemSettingsPage.block_type = true
	end
	SystemSettingsPage.ChangeButtonValue("btn_BlockPlayer",SystemSettingsPage.block_type)
end
function SystemSettingsPage.OnClickBlockNPC()
	if SystemSettingsPage.NPC_type then
		SystemSettingsPage.NPC_type = false
	else
		SystemSettingsPage.NPC_type = true
	end
	SystemSettingsPage.ChangeButtonValue("btn_BlockNPC",SystemSettingsPage.NPC_type)
end
	
function SystemSettingsPage.ClosePage()
	if(page) then
		page:CloseWindow();
		page = nil;
	end
	UIManager.destroyUI("SystemSettingsPage");
end

function SystemSettingsPage.GetMaxGraphicsMem()
	local att = ParaEngine.GetAttributeObject();
	local Is64BitsSystem = att:GetField("Is64BitsSystem", false);
	if(Is64BitsSystem) then
		return 2048;
	else
		return 768;
	end
end
function SystemSettingsPage.OnAutoSave()
	if SystemSettingsPage.isAutoSave then
		SystemSettingsPage.isAutoSave = false
		_guihelper.MessageBox("关闭自动保存，如发生意外退出等情况将丢失本次游戏进度，系统无法为您找回。")
	else
		SystemSettingsPage.isAutoSave = true
	end	
	SystemSettingsPage.ChangeButtonValue("btn_AutoSave",SystemSettingsPage.isAutoSave)
	UserDatabase.setAttribute("AutoSave",SystemSettingsPage.isAutoSave,"local");
	ModuleManager.handleEvent("InitTimer")
end

function SystemSettingsPage:IsDayNightOn()
	return not SystemSettingsPage.inf_time_per_day;
end

function SystemSettingsPage.OnOffDayNight()
	AudioEngine.PlayUISound("btn_show");
	SystemSettingsPage.inf_time_per_day = not SystemSettingsPage.inf_time_per_day;
	page:Refresh(0);
	SystemSettingsPage.RefreshDayNightState();
end
function SystemSettingsPage.RefreshDayNightState()
	local value = SystemSettingsPage.last_dayLength or 60;

	if(SystemSettingsPage.inf_time_per_day) then
		local day_length = 10000000;
		SystemSettingsPage.SetDayLength(day_length);	
	else
		SystemSettingsPage.SetDayLength(value);
	end

	page:SetValue("dayNightTimeSlider",value);

	local old_time = ParaScene.GetTimeOfDaySTD();
	local mcTimeSliderValue = (old_time/2 + 0.5) * 1000;
	page:SetValue("mcTimeSlider",mcTimeSliderValue);
end

function SystemSettingsPage.SetDayLength(value)
	local day_length = tonumber(value) or 60;
	local old_time = ParaScene.GetTimeOfDaySTD();
	ParaScene.GetAttributeObjectSunLight():SetField("DayLength", day_length);
	ParaScene.SetTimeOfDaySTD(old_time);
	if( day_length > 0 and day_length < 100) then
		page:SetValue("dayNightTimeLabel",day_length);
		SystemSettingsPage.last_dayLength = day_length;
	end
end
function SystemSettingsPage.OnOneDayTimeSliderChanged(value)
	if(not SystemSettingsPage.inf_time_per_day) then
		SystemSettingsPage.SetDayLength(value)
	end
end
function SystemSettingsPage.ChangeSkyBox()
        local index = SystemSettingsPage.skySelectIndex or 1
        local Config = commonlib.gettable("Mod.Seer.Config");
        local envconfig = Config.PlanetEnvironment
        local skybox = envconfig.skybox:get(index)
        CommandManager:RunCommand("/sky -clear");
        CommandManager:RunCommand("sky", skybox.path);
        if skybox.fog_colour then
            CommandManager:RunCommand("/fog -color "..skybox.fog_colour);
        end
end