--[[
    Title: SeerGUIChat
    Author(s): Devil
    Date: 2016/04/29
    Desc: GUIChat extension. 
    A Injector class.
    Injection Target: MyCompany.Aries.Game.GUI.GUIChat
    use the lib:
    -------------------------------------------------------
	NPL.load("(gl)script/apps/Aries/Creator/Game/GUI/GUIChat.lua");
    NPL.load("(gl)script/Seer/Injector/SeerGUIChat.lua");
	local GUIChat = commonlib.gettable("MyCompany.Aries.Game.GUI.GUIChat");
    local SeerGUIChat = commonlib.gettable("Mod.Seer.Injector.SeerGUIChat");
    Inject(SeerGUIChat, GUIChat);
    -------------------------------------------------------
]]
NPL.load("(gl)script/apps/Aries/Creator/Game/GUI/GUIChat.lua");
NPL.load("(gl)script/ide/TooltipHelper.lua");
NPL.load("(gl)script/Seer/NetWork/YcProfile.lua");
NPL.load("(gl)script/Seer/Utility/ChatCoder.lua");
NPL.load("(gl)script/Seer/Game/ModuleManager.lua");
NPL.load("(gl)script/Seer/Utility/ChatAPI.lua");
local ChatAPI=commonlib.gettable("MyCompany.Aries.ChatSystem.API");
local ModuleManager = commonlib.gettable("Mod.Seer.Game.ModuleManager");
local ChatCoder=commonlib.gettable("Seer.Utility.ChatCoder");
local YcProfile = commonlib.gettable("Mod.Seer.Network.YcProfile");
local ChatMessage = commonlib.gettable("MyCompany.Aries.Game.Network.ChatMessage");
local ChatChannel = commonlib.gettable("MyCompany.Aries.ChatSystem.ChatChannel");
local BroadcastHelper = commonlib.gettable("CommonCtrl.BroadcastHelper");
local SeerGUIChat = commonlib.gettable("Mod.Seer.Injector.SeerGUIChat");
local GamingRoomInfo = commonlib.gettable("Mod.Seer.Game.MultiPlayer.GamingRoomInfo");

-- @param chatMsg: should be a ChatMessage class object or just string.
function SeerGUIChat:PrintChatMessage(chatMsg,userID,needLinkNickName)
	if(type(chatMsg) == "string") then
		chatMsg = ChatMessage:new():Init(chatMsg);
	end
	if(chatMsg) then
		-- TODO: print with more styles
		local text = chatMsg:ToString();
    local decoded=ChatCoder.decode(text);
    if decoded then
      text=decoded.mText;
      if decoded.mFromUserID then
        if self:getBulletScreenEnable() or not ModuleManager.checkModule("BigWorld") then
          text=decoded.mFromUserNickName..":"..text;
        end
        NPL.load("(gl)script/Seer/Settings.lua");
        local Settings = commonlib.gettable("Mod.Seer.Settings");
        local name = Settings.GetPlayerNetNID(decoded.mFromUserID);
        headon_speech.Speak(name, decoded.mText, 5);
        ChatAPI.onChat({NickName = decoded.mFromUserNickName,Message = decoded.mText, ID = decoded.mFromUserID});
      end
    end
    BroadcastHelper.PushLabel({id="GUIChat"..tostring(self:GetCycledId()), label = text, max_duration=4000, color = "0 255 0", scaling=1.1, bold=true, shadow=true,},nil,true);
    ChatChannel.AppendChat({ChannelIndex=ChatChannel.EnumChannels.NearBy, from=nil, words=chatMsg:ToString()});
	end
end
function SeerGUIChat:changeBulletScreenEnable()
	BroadcastHelper.enableBulletScreen(not BroadcastHelper.getBulletScreenEnable());
end
function SeerGUIChat:getBulletScreenEnable()
	return BroadcastHelper.getBulletScreenEnable();
end