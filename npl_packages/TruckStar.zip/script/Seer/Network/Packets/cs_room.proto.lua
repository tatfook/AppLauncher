﻿NPL.load("(gl)script/Seer/pb/cs_room_pb.lua");


NPL.load("(gl)script/Seer/Network/Packets/PacketPbHelper.lua");
local PacketPbHelper = commonlib.gettable("Mod.Seer.Network.Packets.PacketPbHelper");
local PacketPb = commonlib.gettable("Mod.Seer.Network.Packets.PacketPb");
NPL.load("(gl)script/Seer/Game/ModuleManager.lua");
local ModuleManager = commonlib.gettable("Mod.Seer.Game.ModuleManager")

NPL.load("(gl)script/Seer/Game/UI/InviteReminderManger.lua");
local InviteReminderManger = commonlib.gettable("Mod.Seer.Game.UI.InviteReminderManger");

NPL.load("(gl)script/Seer/Settings.lua");
local Settings = commonlib.gettable("Mod.Seer.Settings");

NPL.load("(gl)script/Seer/Game/MultiPlayer/GamingRoomInfo.lua");
local GamingRoomInfo = commonlib.gettable("Mod.Seer.Game.MultiPlayer.GamingRoomInfo");

NPL.load("(gl)script/Seer/Game/UI/UIManager.lua");
local UIManager= commonlib.gettable("Mod.Seer.Game.UI.UIManager");

local YcProfile = commonlib.gettable("Mod.Seer.Network.YcProfile");

function PacketPbHelper.sendCSCreateRoomReq(id,roomname, resourceid, max, password,limits,billboard, callback, errcallback)
	PacketPbHelper.send("CSCreateRoomReq", {room_id = id, max_mem_num = max, pass_word = password, room_name = roomname, resource_id = resourceid,limits = limits,description=billboard}, callback, errcallback);
end

function PacketPbHelper.sendCSUserJoinRoomReq(id, pwd, callback, errCallback)
	PacketPbHelper.send("CSUserJoinRoomReq", {room_id = id, pass_word = pwd},callback,errCallback);
end

function PacketPbHelper.sendCSUserToServerCommand(id,callback)
	PacketPbHelper.send("CSUserToServerCommand", {global_craft_uid = id}, callback);
end

function PacketPbHelper.sendCSMainToServerCommand(id, data, callback)
	PacketPbHelper.send("CSMainToServerCommand", {global_craft_uid = id, type = 0,msg = data, uids = {}}, callback);
end


function PacketPbHelper.sendCSUserExitRoomReq(id,callback)
	PacketPbHelper.send("CSUserExitRoomReq", {room_id = id},callback);
end


function PacketPbHelper.sendToPlayer(userid, planetid, data)
	PacketPbHelper.send("CSMainToServerCommand", 
		{
			global_craft_uid = planetid, 
			type = cs_room_pb.CSMainToServerCommand.INCLUDE,
			msg = commonlib.serialize(data), 
			uids = {userid}
		});
end

function PacketPbHelper.sendCSGetRoomlistReq(callback)
	PacketPbHelper.send("CSGetRoomlistReq",{},callback);
end

function PacketPbHelper.sendCSGetRoomlistByIDReq(resourceid,callback)
	PacketPbHelper.send("CSGetRoomlistByIDReq",{resource_id = resourceid},callback);
end
function PacketPbHelper.sendCSSearchRoomReq(mode,searchuid,roomname,callback)
	PacketPbHelper.send("CSSearchRoomReq",{mode = mode,search_uid = searchuid,room_name = roomname},callback);
end

PacketPbHelper.registerFunc("CSServerDownExitRoomNtf", 
function (h,b)
	_guihelper.MessageBox("服务器状态异常")
	if (not ModuleManager.checkModule("Saver")) then

		local delay_timer
		delay_timer = commonlib.Timer:new({callbackFunc = function(timer)
		-- ModuleManager.startModule("Online")
			_guihelper.CloseMessageBox()
			if delay_timer then
				delay_timer:Change()
			end
			delay_timer = nil
			ModuleManager.startModule("BigWorldPlay")
			end})
		delay_timer:Change(2000,0)

	end
end)

PacketPbHelper.registerFunc("CSRoomOwnerExitNtf", 
function (h,b)
	_guihelper.MessageBox("与主机断开连接")
	local delay_timer
	delay_timer = commonlib.Timer:new({callbackFunc = function(timer)
	-- ModuleManager.startModule("Online")
		_guihelper.CloseMessageBox()
		if delay_timer then
			delay_timer:Change()
		end
		delay_timer = nil
		ModuleManager.startModule("BigWorldPlay")
		end})
	delay_timer:Change(2000,0)
end)


function PacketPbHelper.sendCSGetRoomMemInfoReq(roomid,callback)
	PacketPbHelper.send("CSGetRoomMemInfoReq",{room_id = roomid},callback);
end

--邀请
function PacketPbHelper.sendCSInviteUserReq(roomid,inv_uid,callback,errcallback)
	PacketPbHelper.send("CSInviteUserReq",{room_id = roomid,inv_uid = inv_uid},callback,errcallback);
end

--踢人
function PacketPbHelper.sendCSKickUserOutReq(roomid,uid,callback,errcallback)
	PacketPbHelper.send("CSKickUserOutReq",{room_id = roomid,uid = uid},callback,errcallback);
end

function PacketPbHelper.sendCSCreateRoomComplateReq(roomid)
	PacketPbHelper.send("CSCreateRoomComplateReq",{room_id = roomid});
end

function PacketPbHelper.sendCSSetDefaultLimitsReq(roomid,limits,callback,errcallback)
	PacketPbHelper.send("CSSetDefaultLimitsReq",{room_id = roomid,pairs=limits},callback,errcallback);
end
--被邀请加入房间推送
PacketPbHelper.registerFunc("CSInviteUserNtf", 
	function (h,b)
	if YcProfile.GetBlacksInfoById(b.inviter_uid) then
		return
	end
	-- if ModuleManager.checkModule("MultiPlayerServer") then
	-- 	return
	-- end
	-- local ui_main = UIManager.getUI("UIMain")
	-- UIManager.createUI("FriendInviteReminder",ui_main,nil,b)
	InviteReminderManger.AddReminderMsg(b)
end)


PacketPbHelper.registerFunc("CSKickUserOutNtf", 
	function ()
		_guihelper.MessageBox("你已经被房主踢出房间")
		GamingRoomInfo.removeAllPlayers()
		local delay_timer
		delay_timer = commonlib.Timer:new({callbackFunc = function(timer)
		-- ModuleManager.startModule("Online")
			_guihelper.CloseMessageBox()
			if delay_timer then
				delay_timer:Change()
			end
			delay_timer = nil
			ModuleManager.startModule("BigWorldPlay")
			end})
		delay_timer:Change(2000,0)
	end)


PacketPbHelper.registerFunc("CSKickUserOutToMemNtf", 
	function (h,b)
		local text = "玩家\""..b.nick.."\"已被房主踢出房间"
		local Desktop = commonlib.gettable("MyCompany.Aries.Creator.Game.Desktop");
		Desktop.GetChatGUI():PrintChatMessage(text);
		GamingRoomInfo.removePlayer(b.uid)
	end)



function PacketPbHelper.sendCSSetMemLimitsReq(uid, roomid, pairs)
	PacketPbHelper.send("CSSetMemLimitsReq", {mem_uid = uid, room_id = roomid, pairs = pairs},function()end);
end

PacketPbHelper.registerFunc("CSSetMemLimitsNtf",
function (h,b)
	NPL.load("(gl)script/Seer/Network/bit.lua");
	local bit= commonlib.gettable("YcAPI.bit");

	--update info
	local player = GamingRoomInfo.getPlayer(b.mem_uid) 
	if player and b.pairs then
		local limits = player.states:getData();
		for k,v in ipairs(b.pairs) do 
			limits[v.idx + 1] = v.value;
		end

		--nessesary
		local UIManager = commonlib.gettable("Mod.Seer.Game.UI.UIManager");
    	RoomPermissionPage = UIManager.getUI("RoomPermissionPage");
    	if RoomPermissionPage then
    		RoomPermissionPage:RefreshInfo()
    	end
		GamingRoomInfo.updatePlayerLimits(b.mem_uid, limits);
	end

end)

PacketPbHelper.registerFunc("CSMemRelationUpdateNtf",
	function (h,b)
		GamingRoomInfo.updatePlayerRelation(b.mem_uid, b.relation);
	end)

PacketPbHelper.registerFunc("CSSetDefaultLimitsNtf",
  function (h,b)
	GamingRoomInfo.setRoomInfoOfLimits(b);
  end)