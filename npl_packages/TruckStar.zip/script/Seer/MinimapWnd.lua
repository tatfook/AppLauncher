--[[
Title: minimap UI window
Author(s): LiXizhi
Date: 2015/5/6
Desc: 
use the lib:
------------------------------------------------------------
NPL.load("(gl)script/Seer/MinimapWnd.lua");
local MinimapWnd = commonlib.gettable("Mod.Seer.UI.MinimapWnd");
MinimapWnd:Show();
-------------------------------------------------------
]]
NPL.load("(gl)script/ide/timer.lua");

NPL.load("(gl)script/ide/System/Windows/Window.lua");
NPL.load("(gl)script/Seer/MinimapSurface.lua");
local MinimapSurface = commonlib.gettable("Mod.Seer.UI.MinimapSurface");
local Window = commonlib.gettable("System.Windows.Window");
local MinimapWnd = commonlib.inherit(commonlib.gettable("Mod.Seer.Game.UI.UIBase"),commonlib.gettable("Mod.Seer.UI.MinimapWnd"));
NPL.load("(gl)script/Seer/Game/UI/UIManager.lua");
local UIManager= commonlib.gettable("Mod.Seer.Game.UI.UIManager");

UIManager.registerUI("MinimapWnd",MinimapWnd,"script/Seer/MinimapWnd.html")
local refresh_timer = nil;

function MinimapWnd:create(layout, name, zorder)
	self.name = name;
	zorder = zorder + 1;
	self.zorder= zorder;

	local window =  Window:new();
	window:EnableSelfPaint(true);
	window:SetAutoClearBackground(false);
	self.window = window;


	local params = {
			url = layout,
			name = name, 
			zorder = zorder,

			alignment="_rt", left=-178, top=30, width = 178, height = 196,
		};

	window:Show(params);

	echo("create UI " .. name);

	self:onCreate(self.userdata);
end


function MinimapWnd:onDestroy()
	ParaUI.Destroy(self.name);
end


function MinimapWnd:Show(bShow)
	if(not self.window) then
		local window = Window:new();
		window:EnableSelfPaint(true);
		window:SetAutoClearBackground(false);
		self.window = window;
	end
	
	self.window:Show({
		name="MinimapWnd", 
		url="script/Seer/MinimapWnd.html",
		zorder = 3,
		alignment="_rt", left=-178, top=30, width = 178, height = 196,
	});


	-- if(not refresh_timer) then
	-- 	echo("Test_ refresh avatar timer init");
	-- 	refresh_timer = commonlib.Timer:new({callbackFunc = function(timer)
	-- 		echo("Test_ refresh avatar timer started");
	-- 		local avatar = ParaUI.GetUIObject("MinimapSurface_avatar");
	-- 		  local name = UIAnimManager.GetPathStringFromUIObject(avatar);
	-- 		  echo("Test_ avatar name : "..name); 
	-- 		if(avatar) then
	-- 			echo("Test_ avatar not nil");
	-- 		end
	--  		local animationTime = 1000;
	-- 		local avatarBtn = UIDirectAnimBlock:new();
	-- 		avatarBtn:SetUIObject(avatar);
	-- 		avatarBtn:SetTime(animationTime);
	-- 		avatarBtn:SetRotationRange(100, 200);
	-- 		avatarBtn:SetApplyAnim(true); 
	-- 		UIAnimManager.PlayDirectUIAnimation(avatarBtn);
	-- 	end})
	-- end

	-- refresh_timer:Change(5000,nil);

end

function MinimapWnd:ClosePage()
	if(self.window) then
		ParaUI.Destroy("MinimapWnd");
	end
end