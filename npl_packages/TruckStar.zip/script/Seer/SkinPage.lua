--[[
    Title: Skin Page
    Author(s): WangXiXi
    Date: 2015/6/17
    Desc: 
    Use Lib:
    -------------------------------------------------------
    NPL.load("(gl)script/Seer/SkinPage.lua");
    local SkinPage = commonlib.gettable("Mod.Seer.UI.SkinPage");
    SkinPage.ShowPage();
    -------------------------------------------------------
]]

NPL.load("(gl)script/apps/Aries/Creator/Game/game_logic.lua");
NPL.load("(gl)script/apps/Aries/Creator/Game/Entity/EntityManager.lua");
NPL.load("(gl)script/Seer/NetWork/YcProfile.lua");
NPL.load("(gl)script/Seer/Network/Packets/PacketPbHelper.lua");
NPL.load("(gl)script/Seer/Game/Asset/AssetAPI.lua");
NPL.load("(gl)script/Seer/Game/Avatar/AvatarAPI.lua");
NPL.load("(gl)script/ide/math/vector2d.lua");
NPL.load("(gl)script/ide/mathlib.lua");
NPL.load("(gl)script/Seer/Game/Asset/AssetEnum.lua");
NPL.load("(gl)script/Seer/Config/Config.lua");
local Config = commonlib.gettable("Mod.Seer.Config");
local AssetEnum=commonlib.gettable("Seer.Game.Asset.Enum");
local mathlib = commonlib.gettable("mathlib");
local vector2d = commonlib.gettable("mathlib.vector2d");
local AvatarAPI=commonlib.gettable("Seer.Game.Avatar.API");
local AssetAPI=commonlib.gettable("Seer.Game.Asset.API");
local GameLogic = commonlib.gettable("MyCompany.Aries.Game.GameLogic")
local EntityManager = commonlib.gettable("MyCompany.Aries.Game.EntityManager");
local pe_gridview = commonlib.gettable("Map3DSystem.mcml_controls.pe_gridview");
local YcProfile = commonlib.gettable("Mod.Seer.Network.YcProfile");
local PacketPbHelper = commonlib.gettable("Mod.Seer.Network.Packets.PacketPbHelper");
local CharacterAssetsReader = commonlib.gettable("Mod.Seer.Config.CharacterAssetsReader");
local UIManager = commonlib.gettable("Mod.Seer.Game.UI.UIManager");
local UIBase = commonlib.gettable("Mod.Seer.Game.UI.UIBase");
local SkinPage = commonlib.inherit(UIBase,commonlib.gettable("Mod.Seer.UI.SkinPage"));
UIManager.registerUI("SkinPage", SkinPage,"script/Seer/SkinPage.html",{});

local colorTb = {[0] = "0", [1] = "1", [2] = "2", [3] = "3", [4] = "4", [5] = "5", [6] = "6", [7] = "7", [8] = "8", [9] = "9", [10] = "A", [11] = "B",[12] = "C", [13] = "D", [14] = "E", [15] = "F"}

local function _mapAvatarTypeToType1(avatarType)
  if avatarType=="Head" then
    return "hair";
  elseif avatarType=="Body" then
    return "top";
  elseif avatarType=="Leg" then
    return "bottoms";
  elseif avatarType=="Hand" then
    return "gloves";
  elseif avatarType=="Foot" then
    return "shoes";
  elseif avatarType=="Attachment" then
    return "jewelry";
  elseif avatarType=="Eye" or avatarType=="Mouth" then
    return "face";
  else
    echo("devilwalk------------------------------error:SkinPage.lua:_mapAvatarTypeToType1:avatarType:"..avatarType);
  end
end

local function _mapAvatarTypeToType2(avatarType)
  if avatarType=="Eye" then
    return "eye";
  elseif avatarType=="Mouth" then
    return "mouse";
  end
end

local function _mapAttachmentToType2(attachment)
  if attachment=="Boost" then
    return "up";
  elseif attachment=="Head" then
    return "head";
  elseif attachment=="Back" then
    return "down";
  else
    echo("devilwalk------------------------------error:SkinPage.lua:_mapAttachmentToType2:attachment:"..attachment);
  end
end

local function _mapAvatarSexToGender(sex)
  if sex=="Male" then
    return "male";
  elseif sex=="Female" then
    return "female";
  end
end

local function _getPaletteRGB(posX,posY)
  local pos=vector2d:new(posX,posY);
  local middle=vector2d:new(0.5,0.5);
  local half=0.5;
  local offset_y=half/2;
  local offset_x=math.sqrt(3)*offset_y;
  local red=vector2d:new(middle[1]-offset_x,middle[2]-offset_y);
  local green=vector2d:new(middle[1],middle[2]+half);
  local blue=vector2d:new(middle[1]+offset_x,middle[2]-offset_y);
  local hsv_base_axis=vector2d:new(1,0);
  local length_to_middle=(pos-middle):length();
  if length_to_middle<=half then
    local h=math.acos(mathlib.clamp(hsv_base_axis:dot((pos-middle):normalize()),-1,1))*180/3.1415926;
    if (posX>=middle[1] and posY<=middle[2]) or (posX<=middle[1] and posY<=middle[2]) then
      h=360-h;
    end
    local s=length_to_middle/half;
    local v=1;
    if 0==s then
      return 1,1,1;
    else
      h=h/60;
      local hi=math.floor(h);
      local f=h-hi;
      local p=v*(1-s);
      local q=v*(1-f*s);
      local t=v*(1-(1-f)*s);
      if hi==0 then
        return (v),(t),(p);
			elseif hi==1 then
        return (q),(v),(p);
			elseif hi==2 then
        return (p),(v),(t);
			elseif hi==3 then
        return (p),(q),(v);
			elseif hi==4 then
        return (t),(p),(v);
			elseif hi==5 then
        return (v),(p),(q);
			end
    end
  end
end

function SkinPage:onCreate(entity)
    ---------------------------------------测试用！！！！！！！！！！！！！！！！！！！！！！！！
    --[[self.items ={
                    [1] = {
                            ["type"] = "avartar";
                            ["type1"] = "hair";
                            ["time"] = 10;
                            ["name"] = "光头1";
                            ["gender"] = "male";
                            ["price"] = {[1] = 55};
                            ["option"] = {[1] = "7天"};
                            ["icon"] = "gameassets/icons/emojis/standard/18.png";
                            ["colorLimit"] = 5;
                            ["color"] = {};
                          };
                    [2] = {
                            ["type"] = "avartar";
                            ["type1"] = "hair";
                            ["time"] = -1;
                            ["name"] = "光头2";
                            ["gender"] = "female";
                            ["price"] = {[1] = 111, [2] = 555};
                            ["option"] = {[1] = "7天", [2] = "永久"};
                            ["icon"] = "gameassets/icons/emojis/standard/17.png";
                            ["colorLimit"] = 4;
                            ["color"] = {};
                          };                                
                }--]]
    ---------------------------------------测试用！！！！！！！！！！！！！！！！！！！！！！！！
    local functionBarUI = UIManager.getUI("FunctionBar")
    if functionBarUI then
        functionBarUI:EventOpenUI({name="skin"})
    end
    self.selectedItem = {}
    self.wearingItem = {}
    self.balance = nil
    self.selectedLable = "all"
    

    
    self:initAvatar()
end

function SkinPage:initAvatar()
    self.item_color_tb = {}
    self:getOwnItems(nil,true)
    --echo("devilwalk----------------------------------------debug:SkinPage.lua:SkinPage:initAvatar:self.wearingItem:");
    --echo(self.wearingItem);
    local pe_mc_player = self.page:GetNode("MyPlayer_SkinPage");
    pe_mc_player.mAvatarComponentHandles={};
    for key,value in pairs(self.wearingItem) do
        pe_mc_player.mAvatarComponentHandles[#pe_mc_player.mAvatarComponentHandles+1]=AvatarAPI.getComponentHandleByItemID(tonumber(value.mItemInfo.ID));
    end
    pe_mc_player.mSkinColour=AvatarAPI.getAvatarSkinColour();
    AssetAPI.getOwnItemHandles(AssetEnum.EItemType.Avatar,
    function(handles)
      --echo("devilwalk----------------------------------------debug:SkinPage.lua:SkinPage:initAvatar:handles:");
      --echo(handles);
        AssetAPI.getItemsAttributes(handles,
            function (attributes)
              --echo("devilwalk----------------------------------------debug:SkinPage.lua:SkinPage:initAvatar:attributes:");
              --echo(attributes);
                for i=1,#handles do
                    local item_handle=handles[i];
                    local avatar_component_handle = nil
                    for j=1,#pe_mc_player.mAvatarComponentHandles do
                        local handle=pe_mc_player.mAvatarComponentHandles[j];
                        if AssetAPI.getItemTableInfo(item_handle).ID==AvatarAPI.getComponentTableInfo(handle).ItemID then
                            avatar_component_handle=handle;
                            break;
                        end
                    end

                    local item_attributes=attributes[i];
                    local colours;
                    for key,value in pairs(item_attributes) do
                      colours=colours or {};
                        if type(key)==type(AssetEnum.EItemAttribute.Colour1) and key>=AssetEnum.EItemAttribute.Colour1 and key<=AssetEnum.EItemAttribute.Colour6 then
                            colours[key]=AvatarAPI.unpackColourValue(value);
                        end
                    end
                    if avatar_component_handle then
                        pe_mc_player.mAvatarComponentColor[avatar_component_handle]=colours;
                    else
                        self.item_color_tb[AssetAPI.getItemTableInfo(item_handle).ID] = colours
                    end
                end
            end);
        end);
end

function SkinPage:getOwnItems(callbackFunc, isInit)
    local selectedItemID_Temp = nil
    if self.selectedItem[self.selectedLable] then
        selectedItemID_Temp = self.selectedItem[self.selectedLable].mItemInfo.ID
    end
    local wearingItemID_Temp = {}
    if self.wearingItem then
        for k,v in pairs(self.wearingItem) do
            wearingItemID_Temp[#wearingItemID_Temp+1] = v.mItemInfo.ID
        end
    end
    self.wearingItem = {}
    AssetAPI.getOwnMoney(function (_,money,_)
        self.balance = money
    end,
    function ()
        
    end)
    AssetAPI.getOwnItemHandles(AssetEnum.EItemType.Avatar,
      function(handles)
        local items={};
        if handles then
          for i=1,#handles do
            local handle=handles[i];
            local item_info=AssetAPI.getItemTableInfo(handle);
            local item_in_avatarsxml=AvatarAPI.getAvatarTableByItemID(item_info.ID);
            local item={};
            item.type="avartar";
            item.type1=_mapAvatarTypeToType1(item_in_avatarsxml.Type);
            if item_in_avatarsxml.Attachment then
              item.type2=_mapAttachmentToType2(item_in_avatarsxml.Attachment);
              item.type3=item_in_avatarsxml.Slot;
            else
              item.type2=_mapAvatarTypeToType2(item_in_avatarsxml.Type);
            end
            item.time=AssetAPI.getItemExpire(handle);
            item.name=item_in_avatarsxml.Name;
            item.gender=_mapAvatarSexToGender(item_in_avatarsxml.Sex);
            item.icon=item_in_avatarsxml.Icon;
            if item_in_avatarsxml.mColorIndices then
              item.colorLimit=#item_in_avatarsxml.mColorIndices;
            else
              item.colorLimit=0;
            end
            item.color={};
            item.mItemInfo=commonlib.clone(item_info);
            items[#items+1]=item;
            --刷新完后重新选择
            if selectedItemID_Temp then
                if item.mItemInfo.ID == selectedItemID_Temp then
                    self.selectedItem[self.selectedLable] = item
                end
            else

            end
            --刷新完重新穿上

            for i=1,#wearingItemID_Temp do
                if item.mItemInfo.ID == wearingItemID_Temp[i] then
                    self.wearingItem[item.type1..(item.type2 or "")..(item.type3 or "")]=item
                end
            end
          end
        end
        
        self.items=items;
        
        
        local avatar_component_handles=AvatarAPI.getAvatarComponentHandles();
        --echo("devilwalk-------------------------------debug:SkinPage.lua:SkinPage:onCreate:avatar_component_handles:");
        --echo(avatar_component_handles);
        if avatar_component_handles then
          for i=1,#avatar_component_handles do
            local avatar_component_handle=avatar_component_handles[i];
            for j=1,#self.items do
              local item=self.items[j];
              if avatar_component_handle==AvatarAPI.getComponentHandleByItemID(tonumber(item.mItemInfo.ID)) then
                if isInit then
                    self.wearingItem[item.type1..(item.type2 or "")..(item.type3 or "")]=item;
                    break;
                end
              end
            end
          end
        end
        if next(self.items) then
            --获取续费价格
            local items=Config.StoreSellItems.StoreSellItem;
            for i=1,#self.items do
                for j=1,items:size() do
                    local item=items:get(j);
                    if item.ItemID == self.items[i].mItemInfo.ID then
                        self.items[i].mStoreSellItems = self.items[i].mStoreSellItems or {}
                        self.items[i].mStoreSellItems[#self.items[i].mStoreSellItems+1] = {ID = item.ID, StoreItemID = item.StoreItemID}
                        self.items[i].price=self.items[i].price or {};
                        self.items[i].price[#self.items[i].price+1]=tonumber(item.Price or 0);
                        self.items[i].option=self.items[i].option or {};
                        local second = tonumber(item.ExpiredTime)
                        local ExpiredTime = nil
                        if second then
                            if second/60/60/24 >= 1 then
                                ExpiredTime = math.floor(second/60/60/24).."天"
                            else
                                ExpiredTime = math.floor(second/60/60).."小时"
                            end
                        end
                        self.items[i].option[#self.items[i].option+1]=ExpiredTime or "永久";
                    end
                end
            end

            self:autoRefreshPage("stop")
            self:autoRefreshPage()
        else
            self:autoRefreshPage("stop")
        end
        self:refreshAvatar();
        if callbackFunc then
            callbackFunc()
        end
        self:refresh();
      end,
      function()
      end);
end

function SkinPage:onDestroy()
    local functionBarUI = UIManager.getUI("FunctionBar")
    if functionBarUI then
        functionBarUI:EventCloseUI({name="skin"})
    end
    self:closeOtherUi()
    
    self:autoRefreshPage("stop")
end



function SkinPage:closePage()
    
    local AvatarItemColorPage = UIManager.getUI("AvatarItemColorPage")
    if AvatarItemColorPage then
        _guihelper.MessageBox("正在调整肤色/物品颜色，是否继续保存？",
        function(res)
            if res == _guihelper.DialogResult.OK then
                AvatarItemColorPage:OnCancel()
                AvatarItemColorPage:close()
                self:close()
            end
        end,
        _guihelper.MessageBoxButtons.OKCancel);
        return
    end
    self:close()
end


function SkinPage:handleKeyEvent(event)
    local dik_key = event.keyname;
	if (dik_key == "DIK_ESCAPE") then
		self:close();
		event:accept();
	end
	return true;
end

function SkinPage:getSelectedLable()
    return self.selectedLable
end

function SkinPage:getSelectedLableIndex()
    if self.selectedLable then
        local index = {["none"] = 0, ["all"] = 1, ["hair"] = 2, ["face"] = 3, ["top"] = 4, ["bottoms"] = 5, ["shoes"] = 6, ["gloves"] = 7, ["jewelry"] = 8}
        return index[self.selectedLable]
    else
        return -1
    end
end

function SkinPage:getItems(index)
    if self.items then
        self.items_show = {}
        if self.selectedLable == "all" then
            self.items_show = self.items
        else
            for i=1,#self.items do
                -- if self.items[i].type1 == self.selectedLable then
                if self.selectedLable2 == self.selectedLable or not self.selectedLable2 then
                    if self.items[i].type1 == self.selectedLable then
                        table.insert(self.items_show, self.items[i])
                    end
                elseif self.items[i].type2 == self.selectedLable2 then
                    table.insert(self.items_show, self.items[i])
                end
            end
        end
        if(index == nil) then
            return #self.items_show;
        else
            return self.items_show[index];
        end
    end
end

-- 点击后脱掉身上所有配件
function SkinPage:OnReset()
    self.wearingItem = {}
    self:refreshAvatar()
end

-- 调整肤色
function SkinPage:OnSetSkinColor()
        local pe_mc_player = self.page:GetNode("MyPlayer_SkinPage");
    local skinColor = pe_mc_player.mSkinColour
    self:closeOtherUi()    
    UIManager.createUI("AvatarItemColorPage",nil,nil,{skinColor = skinColor,fromUI = "SkinPage"})
end

-- 保存形象
function SkinPage:OnSaveAvatar()
        local pe_mc_player = self.page:GetNode("MyPlayer_SkinPage");
  local handles={};
  for key,value in pairs(self.wearingItem) do
    local item=value;
    handles[#handles+1]=AvatarAPI.getComponentHandleByItemID(item.mItemInfo.ID);
  end
  handles=AvatarAPI.completeAvatarComponentHandles(handles,YcProfile.GetMyGender());
  local avatar_component_colours={};
  for i=1,#handles do
    local avatar_component_handle=handles[i];
    avatar_component_colours[avatar_component_handle]=pe_mc_player.mAvatarComponentColor[avatar_component_handle];
  end
  --[[echo("devilwalk-------------------------debug:SkinPage.lua:SkinPage:OnSaveAvatar:handles");
  echo(handles)
  echo("devilwalk-------------------------debug:SkinPage.lua:SkinPage:OnSaveAvatar:pe_mc_player.mSkinColour");
  echo(pe_mc_player.mSkinColour)
  echo("devilwalk-------------------------debug:SkinPage.lua:SkinPage:OnSaveAvatar:avatar_component_colours");
  echo(avatar_component_colours)]]
  AvatarAPI.setAvatarAttributes(handles,pe_mc_player.mSkinColour,avatar_component_colours,
    function ()
      self:closePage();
    end);
end

-- 切换标签
function SkinPage:OnSelectLable(lableName)
    if lableName ~= self.selectedLable then
        self.selectedLable = lableName
        if self.selectedLable then
            self.selectedItem[self.selectedLable] = nil
        end
        self:refresh()
    end
    self.selectedLable2 = nil
    self:refresh()
end

function SkinPage:isLableSelected(lableName)
    if self.selectedLable then
        return self.selectedLable == lableName
    end
end

-- 切换2级标签
function SkinPage:OnSelectLable2(lableName)
    if lableName ~= self.selectedLable2 then
        self.selectedLable2 = lableName
        self:refresh()
    else
        self.selectedLable2 = nil
        self:refresh()
    end
end

function SkinPage:getSelectedLable2()
    return self.selectedLable2 
end


function SkinPage:isItemSelected(index)
    local item = self.items_show[index]
    if self.selectedItem then
        return self.selectedItem[self.selectedLable] == item
    end
end

function SkinPage:getItemName(index)
    return self.items_show[index].name
end

function SkinPage:getSelectedItemName()
    return self.selectedItem[self.selectedLable].name
end

function SkinPage:unSelect()
    self.selectedItem[self.selectedLable] = nil
end

function SkinPage:getSelectedItem()
    return self.selectedItem[self.selectedLable]
end


function SkinPage:getItemTime(index)
    local string = "剩余"
    if self.items_show[index].time < 0 then
        string = "永久"
    elseif self.items_show[index].time == 0 then
        string = "已过期"    
    elseif self.items_show[index].time > 24*60*60 then
        string = string..(math.floor(self.items_show[index].time/24/60/60)+1).."天"
    elseif self.items_show[index].time > 60*60 then 
        string = string..math.floor(self.items_show[index].time/60/60).."小时"
    elseif self.items_show[index].time < 60 then
        string = "不足1分钟"
    else
        string = string..math.floor(self.items_show[index].time/60).."分钟"
    end
    return string
end


function SkinPage:canRenewal()
    return self.selectedItem[self.selectedLable].time >= 0
end

function SkinPage:canChangeColor()
    local item = self.selectedItem[self.selectedLable]
    return self.wearingItem[item.type1..(item.type2 or "")..(item.type3 or "")] == item and item.colorLimit > 0
end

function SkinPage:getItemGender(index)
    return self.items_show[index].gender
end

function SkinPage:getItemIcon(index)
    if self.items then
        return self.items_show[index].icon
    end
end

function SkinPage:OnSelectItem(index)
    local item = self.items_show[index]
    if self.selectedItem[self.selectedLable] ~= item then   
        local AvatarItemColorPage = UIManager.getUI("AvatarItemColorPage")
        if AvatarItemColorPage then
            _guihelper.MessageBox("请先保存或关闭当前正在修改的配色")
            return
        end
        self.selectedItem[self.selectedLable] = item
    end
    if self.wearingItem[item.type1..(item.type2 or "")..(item.type3 or "")] == item then
        -- 脱
        if(mouse_button == "right") then
            self.wearingItem[item.type1..(item.type2 or "")..(item.type3 or "")] = nil
        end
        --
    else
        -- 穿/更换
        self.wearingItem[item.type1..(item.type2 or "")..(item.type3 or "")] = item
        if not item.color or not next(item.color) then
            self:refreshAvatar()
            local pe_mc_player = self.page:GetNode("MyPlayer_SkinPage");
            local avatar_component_handle=AvatarAPI.getComponentHandleByItemID(tonumber(item.mItemInfo.ID));
            pe_mc_player.mAvatarComponentColor[avatar_component_handle]=self.item_color_tb[item.mItemInfo.ID]
            return 
        else
                        
        end
    end



    self:refreshAvatar()
    
    
end

function SkinPage:dressUpSelectedItem()
    local item = self.selectedItem[self.selectedLable]
    if self.wearingItem[item.type1..(item.type2 or "")..(item.type3 or "")] == item then
        -- 脱
        self.wearingItem[item.type1..(item.type2 or "")..(item.type3 or "")] = nil
        local AvatarItemColorPage = UIManager.getUI("AvatarItemColorPage")
        if AvatarItemColorPage then
            AvatarItemColorPage:OnCancel()
        end
    else
        -- 穿/更换
        self.wearingItem[item.type1..(item.type2 or "")..(item.type3 or "")] = item
    end
    self:refreshAvatar()
end

-- 续费按钮
function SkinPage:OnRenewal()
    local item = self.selectedItem[self.selectedLable]
    if item then
        self:closeOtherUi()
        UIManager.createUI("AvatarItemRenewalPage",nil,nil,{item = item, fromUI = "SkinPage", balance = self.balance})
    end
end

-- 详情按钮
function SkinPage:OnDetail()
    local item = self.selectedItem[self.selectedLable]
    if item then
        self:closeOtherUi()
        UIManager.createUI("AvatarItemInfoPage",nil,nil,{item = item, fromUI = "SkinPage", balance = self.balance, canRenewal = self:canRenewal(), })
    end
end

-- 换色按钮
function SkinPage:OnSetItemColor()
    local item = self.selectedItem[self.selectedLable]
    if item then
        self:closeOtherUi()    
        UIManager.createUI("AvatarItemColorPage",nil,nil,{item = item, fromUI = "SkinPage"})
    end
end

function SkinPage:closeOtherUi()
    local AvatarItemColorPage = UIManager.getUI("AvatarItemColorPage")
    if AvatarItemColorPage then
        AvatarItemColorPage:close()
    end
    local AvatarItemInfoPage = UIManager.getUI("AvatarItemInfoPage")
    if AvatarItemInfoPage then
        AvatarItemInfoPage:close()
    end
    local AvatarItemRenewalPage = UIManager.getUI("AvatarItemRenewalPage")
    if AvatarItemRenewalPage then
        AvatarItemRenewalPage:close()
    end
    local ShopCheckOutPage = UIManager.getUI("ShopCheckOutPage")
    if ShopCheckOutPage then
        ShopCheckOutPage:close()
    end
end

-- 是否穿在身上
function SkinPage:isWearing(index)
    if self.wearingItem then
        local item = self.items_show[index]
        if self.wearingItem[item.type1..(item.type2 or "")..(item.type3 or "")] == item then
            return true
        else
            return false
        end
    end
end



-- 选中物品是否穿在身上
function SkinPage:isSelectedItemWearing()
    local item = self.selectedItem[self.selectedLable]
    if self.wearingItem[item.type1..(item.type2 or "")..(item.type3 or "")] == item then
        return true
    else
        return false
    end
end



function SkinPage:OnResetColor(page)
    if self.isChangingSkin then
        local pe_mc_player = self.page:GetNode("MyPlayer_SkinPage");
        pe_mc_player.mSkinColour = nil
    end
end

function SkinPage:IsChangingSkin()
    return self.isChangingSkin
end
    
function SkinPage:isSelectedColor(index)
    return self.selectedColor == tonumber(index)
end

function SkinPage:getCurrentItemColorLimit()
    if self.isChangingSkin then
        return 1
    else
        return self.selectedItem[self.selectedLable].colorLimit
    end
end

function SkinPage:getItemColor()
    if self.isChangingSkin then
        return self.skincolor
    else
        local item = self.selectedItem[self.selectedLable]
        return item.color[self.selectedColor]
    end
end

function SkinPage:autoRefreshPage(stop)
    local refreshTime = 60  --单位：秒
    local timer = commonlib.Timer:new({callbackFunc = function(timer)
        self:getOwnItems()
        if not next(self.items) then
            timer:Change()
        else
            for i = 1, #self.items do
                if self.items[i].time > 0 and self.items[i].time < refreshTime then
                    refreshTime = items[i].time
                end
            end
            timer:Change(refreshTime*1000)
        end      
        
    end});

    if stop then
        timer:Change()
    end
end


function SkinPage:refreshAvatar()
  local pe_mc_player = self.page:GetNode("MyPlayer_SkinPage");
  pe_mc_player.mAvatarComponentHandles={};
  for key,value in pairs(self.wearingItem) do
    echo(AvatarAPI.getComponentHandleByItemID(tonumber(value.mItemInfo.ID)))
    pe_mc_player.mAvatarComponentHandles[#pe_mc_player.mAvatarComponentHandles+1]=AvatarAPI.getComponentHandleByItemID(tonumber(value.mItemInfo.ID));
  end
  self:refresh()
end
