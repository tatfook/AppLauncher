﻿--[[
Title: SavingWorld  Page
Author(s): Ted
Date: 2015/6/25
Desc: 
Use Lib:
-------------------------------------------------------
NPL.load("(gl)script/Seer/SavingWorldPage.lua");
local SavingWorldPage = commonlib.gettable("Mod.Seer.SavingWorldPage");
-- SavingWorldPage.ShowPage(callback)
-------------------------------------------------------
]]

local GameLogic = commonlib.gettable("MyCompany.Aries.Game.GameLogic");
local UIManager = commonlib.gettable("Mod.Seer.Game.UI.UIManager");
local UIBase = commonlib.gettable("Mod.Seer.Game.UI.UIBase");
local SavingWorldPage = commonlib.inherit(UIBase,commonlib.gettable("Mod.Seer.SavingWorldPage"));

NPL.load("(gl)script/seer/Utility/CommonUtility.lua");
local CommonUtility = commonlib.gettable("Mod.Seer.Utility.CommonUtility");
if CommonUtility:IsMobilePlatform() then
	UIManager.registerUI("SavingWorldPage", SavingWorldPage,"script/Seer/SavingWorldPage.html",
	{
	});
else
	UIManager.registerUI("SavingWorldPage", SavingWorldPage,"script/Seer/SavingWorldPage.PC.html",
	{
	});
end

local saving_text = [[  正在保存世界... 
					<br />
                    请不要强制关闭游戏]];
local saved_text = [[保存完毕!]];

SavingWorldPage.content = nil;
function SavingWorldPage:onCreate(params)
	self.content =  saving_text;
	self:refresh()
end

function SavingWorldPage:handleKeyEvent(event)
  event.accpet();
  return true;
end