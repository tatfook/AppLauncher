NPL.load("(gl)script/Seer/Network/Packets/PacketPbHelper.lua");
NPL.load("(gl)script/Seer/pb/cs_resource_platform_pb.lua");

local PacketPbHelper = commonlib.gettable("Mod.Seer.Network.Packets.PacketPbHelper");
local PacketPb = commonlib.gettable("Mod.Seer.Network.Packets.PacketPb");

function PacketPbHelper.sendCSGetRpStorageInfoReq(callback)
    PacketPbHelper.send("CSGetRpStorageInfoReq", 
    {}, callback);
end

-- 获取下载token
function PacketPbHelper.sendCSGetResDownloadTokenReq(items, callback)
    PacketPbHelper.send("CSGetResDownloadTokenReq", 
    {items = items}, callback);
end

-- 获取上传token
function PacketPbHelper.sendCSGetResUploadTokenReq(files, callback)
    PacketPbHelper.send("CSGetResUploadTokenReq", 
    files, callback);
end

-- 排行
function PacketPbHelper.sendCSGetResRankingReq(type, attrid, start, number, callback)
    PacketPbHelper.send("CSGetResRankingReq", 
    {res_type = type,attribute_id = attrid, start = start, number = number}, callback);
end

-- 获取资源列表
function PacketPbHelper.sendCSGetResListReq(type, callback)
    PacketPbHelper.send("CSGetResListReq", 
    {type = type}, callback);
end

function PacketPbHelper.sendCSCollectResListReq(callback)
    PacketPbHelper.send("CSCollectResListReq", {}, callback)
end


local enum_attrs = {};
for k, v in ipairs(cs_resource_platform_pb.CSRESOURCEID.values) do
    enum_attrs[#enum_attrs + 1] = v.number;
end
function PacketPbHelper.sendCSGetResourceAttributeReq(ids,attrs, callback)
    PacketPbHelper.send("CSGetResourceAttributeReq", {res_ids = ids, attribute_ids = attrs or enum_attrs}, callback);
end

function PacketPbHelper.sendCSDeleteResReq(id, type, callback)
    PacketPbHelper.send("CSDeleteResReq", {res_id = id, res_type = type}, callback);
end

function PacketPbHelper.sendCSGetResGradeReq(id, callback)
    PacketPbHelper.send("CSGetResGradeReq", {res_ids = {id}}, callback);
end

function PacketPbHelper.sendCSSetResGradeReq(id, val, callback)
    PacketPbHelper.send("CSSetResGradeReq", {res_id = id, grade = val}, callback);
end

function PacketPbHelper.sendCSCollectResReq(id, op, callback)
    PacketPbHelper.send("CSCollectResReq", {res_id = id, op = op}, callback);
end