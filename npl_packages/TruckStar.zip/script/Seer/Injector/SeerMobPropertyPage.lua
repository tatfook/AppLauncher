--[[
    Title: SeerMobPropertyPage
    Author(s): Devil
    Date: 2016/06/28
    Desc: MobPropertyPage extension. 
    A Injector class.
    Injection Target: MyCompany.Aries.Game.GUI.MobPropertyPage
    use the lib:
    -------------------------------------------------------
    NPL.load("(gl)script/apps/Aries/Creator/Game/GUI/MobPropertyPage.lua");
    NPL.load("(gl)script/Seer/Injector/SeerMobPropertyPage.lua");
    local MobPropertyPage = commonlib.gettable("MyCompany.Aries.Game.GUI.MobPropertyPage");
    local SeerMobPropertyPage = commonlib.gettable("Mod.Seer.Injector.SeerMobPropertyPage");
    Inject(SeerMobPropertyPage, MobPropertyPage);
    -------------------------------------------------------
]]
NPL.load("(gl)script/apps/Aries/Creator/Game/Items/ItemClient.lua");
NPL.load("(gl)script/apps/Aries/Creator/Game/Entity/PlayerAssetFile.lua");
NPL.load("(gl)script/apps/Aries/Creator/Game/Common/CharGeosets.lua");
NPL.load("(gl)script/apps/Aries/Creator/Game/Entity/PlayerSkins.lua");
NPL.load("(gl)script/apps/Aries/Creator/Game/Areas/SkinPage.lua");
NPL.load("(gl)script/apps/Aries/Creator/Game/Common/Files.lua");
local Files = commonlib.gettable("MyCompany.Aries.Game.Common.Files");
local SkinPage = commonlib.gettable("MyCompany.Aries.Creator.Game.Desktop.SkinPage");
local PlayerSkins = commonlib.gettable("MyCompany.Aries.Game.EntityManager.PlayerSkins");
local CharGeosets = commonlib.gettable("MyCompany.Aries.Game.Common.CharGeosets");
local PlayerAssetFile = commonlib.gettable("MyCompany.Aries.Game.EntityManager.PlayerAssetFile")
local ItemClient = commonlib.gettable("MyCompany.Aries.Game.Items.ItemClient");
local GameLogic = commonlib.gettable("MyCompany.Aries.Game.GameLogic")
local block_types = commonlib.gettable("MyCompany.Aries.Game.block_types")
local EntityManager = commonlib.gettable("MyCompany.Aries.Game.EntityManager");

local MobPropertyPage = commonlib.gettable("MyCompany.Aries.Game.GUI.MobPropertyPage");
local SeerMobPropertyPage = commonlib.gettable("Mod.Seer.Injector.SeerMobPropertyPage");

function SeerMobPropertyPage.OnClickOK()
	local page = document:GetPageCtrl();
	local name = page:GetValue("name");
	name = string.gsub(name,"%s","");
	local name_len = ParaMisc.GetUnicodeCharNum(name);
	if(name_len > 16)then
		_guihelper.MessageBox(L"名字不能超过16个字, 请重新输入");
		return
	end
  NPL.load("(gl)script/Seer/Utility/SensitiveWordManager.lua");
  local SensitiveWordManager = commonlib.gettable("Mod.Seer.Utility.SensitiveWordManager");
  name=SensitiveWordManager.process(name);

	local entity = MobPropertyPage.GetEntity();
	local obj = entity:GetInnerObject();
	
	
	if(obj and obj:IsCharacter()) then
		entity:SetDisplayName(name);
		entity:SetName(name);

		local bShowHeadonName = page:GetValue("showHeadonName", false);
		entity:ShowHeadOnDisplay(bShowHeadonName);

		local canRandomWalk = page:GetValue("canRandomWalk", true);
		entity:SetCanRandomMove(canRandomWalk);

		MobPropertyPage.UpdateAssetFile(entity, obj, page:GetValue("assetfile"));
	end

	page:CloseWindow();
end
