--[[
    Title: CharacterAssetsReader
    Author(s): Cellfy
    Date: Mar 31, 2016
    Desc: Interface to visit CharacterAssets.xml
    Usage:
    ------------------------------------------------------------
    NPL.load("(gl)script/Seer/Config/CharacterAssetsReader.lua");
    local CharacterAssetsReader = commonlib.gettable("Mod.Seer.Config.CharacterAssetsReader");
    ------------------------------------------------------------
]]

local CharacterAssetsReader = commonlib.gettable("Mod.Seer.Config.CharacterAssetsReader");

local AllLists = {};
local CharacterAssetList = {};
local MaleCharacterAssetList = {};
local FemaleCharacterAssetList = {};
local TotalCount = 0;

function CharacterAssetsReader.Load()
    Mod.Seer.Config.loadConfig("script/Seer/Config/CharacterAssets.xml");

    AllLists = {};
    CharacterAssetList = {};
    MaleCharacterAssetList = {};
    FemaleCharacterAssetList = {};

    local Config = commonlib.gettable("Mod.Seer.Config");
    local AssetsConfig = Config.CharacterAssets;
    local Characters = AssetsConfig.Character;
    if type(Characters)=="table" and Characters:size()>0 then
        CharacterAssetList = Characters;
        TotalCount = CharacterAssetList:size();
        for i,v in ipairs(CharacterAssetList._VEC) do
            if v.gender == "male" then
                table.insert(MaleCharacterAssetList, v);
            elseif v.gender == "female" then
                table.insert(FemaleCharacterAssetList, v);
            end
        end
        AllLists.all = CharacterAssetList._VEC;
        AllLists.male = MaleCharacterAssetList;
        AllLists.female = FemaleCharacterAssetList;
    else
        LOG.std(nil, "error", "cellfy", "CharacterAssets.xml parse error");
    end
end

--@param list_type: should be one of "male", "female", "all"
function CharacterAssetsReader.GetAssetInfoList(list_type)
    return AllLists[list_type] or CharacterAssetList._VEC;
end

function CharacterAssetsReader.GetAssetInfoByID(asset_id)
    return CharacterAssetList:find(asset_id);
end

function CharacterAssetsReader.GetAssetInfoByIndex(asset_index, list_type)
    local assetList = CharacterAssetsReader.GetAssetInfoList(list_type);
    return assetList[asset_index];
end

function CharacterAssetsReader.GetAssetCount(list_type)
    local assetList = CharacterAssetsReader.GetAssetInfoList(list_type);
    return #assetList;
end

function CharacterAssetsReader.AssetIDtoIndex(asset_id, list_type)
    local assetList = CharacterAssetsReader.GetAssetInfoList(list_type);
    asset_id = tostring(asset_id);
    for i,v in ipairs(assetList) do
        if v.id == asset_id then
            return i;
        end
    end
    return nil;
end

function CharacterAssetsReader.IndexToAssetID(asset_index, list_type)
    local assetInfo = CharacterAssetsReader.GetAssetInfoByIndex(asset_index, list_type);
    if assetInfo then
        return tonumber(assetInfo.id);
    else
        return nil;
    end
end

function CharacterAssetsReader.GetDefaultAssetID()
    local default_asset_id = nil;
    for i,v in ipairs(CharacterAssetList._VEC) do
        if v.default and v.default == "true" then
            default_asset_id = v.id;
            break;
        end
    end
    if not default_asset_id then
        if TotalCount>0 then
            default_asset_id = CharacterAssetList:get(1).id;
        end
    end
    return default_asset_id;
end

function CharacterAssetsReader.GetDefaultAssetInfo()
    local default_asset_id = CharacterAssetsReader.GetDefaultAssetID();
    if default_asset_id then
        return CharacterAssetsReader.GetAssetInfoByID(default_asset_id);
    end
end

function CharacterAssetsReader.GetDefaultModel()
    local default_asset_info = CharacterAssetsReader.GetDefaultAssetInfo();
    if default_asset_info then
        return default_asset_info.model;
    end
end
