--[[
NPL.load("(gl)script/Seer/Network/Connection.lua");
local Connection = commonlib.gettable("Mod.Seer.Network.Connection");
]]

local Connection = commonlib.inherit(nil, commonlib.gettable("Mod.Seer.Network.Connection"));


function Connection:init(nid, handler)
	self.nid = nid;
	self.handler = handler;
	self.connected = false;
	return self;
end

function Connection:connect(msg)
	if self:trySend(msg ) then
		return;
	end

	local intervals = {100, 300,500, 1000, 1000, 1000, 1000}; -- intervals to try
	local try_count = 0;
		
	local mytimer = commonlib.Timer:new({callbackFunc = function(timer)
		commonlib.log("try to connect " .. tostring(try_count + 1).. " count\n");
		try_count = try_count + 1;
		if not self:trySend( msg)  then
			if(intervals[try_count]) then
				timer:Change(intervals[try_count], nil);
			else
				-- timed out. 
				self:onError("ConnectionNotEstablished");
				LOG.std(nil, "warn", "Connection", "unable to send to %s.", self.nid);
			end	
		else
			-- connected 
			self.connected = true;
		end
	end})
	mytimer:Change(10, nil);
end

function Connection:disconnect(reason)
	NPL.reject({["nid"]=self.nid, ["reason"]=reason});
	self.connected = false;
	self.nid = nil;
end

function Connection:send(msg)
	if self.connected then 
		if self:trySend(msg) then 
			return true;
		else
			self:onError(string.format("unable to send to %s", self.nid));
		end
	else
		self:connect(msg);
	end
end

function Connection:trySend(msg)
	local address = string.format("(gl)%s:remote file", self.nid);
	return NPL.activate(address, msg) == 0 ;
end


function Connection:isConnected()
	return self.connected;
end

function Connection:onReceive(msg)
	self.handler:handleMsg(msg);
end

function Connection:onError(reason)
	if self.handler and self.handleErrorMessage then 
		self:handleErrorMessage(reason, nid);
	end
end