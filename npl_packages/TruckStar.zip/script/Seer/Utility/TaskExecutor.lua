--[[
	local TaskExecutor = NPL.load("(gl)script/Seer/Utility/TaskExecutor.lua");
]]

local TaskExecutor =  commonlib.inherit(nil, NPL.export());

function TaskExecutor:ctor()
	self.tasks = {}
	self.lock = false;
	self.index = 1;
end

function TaskExecutor:schedule(callback)
	local key = next(self.tasks);
	if key then
		local task = self.tasks[key];
		self.tasks[key] = nil;
		task.callback = callback;
		self.lock = task;
		task:execute();
	elseif callback then
		self.lock = false;
		callback();
	end
end


local Task = 
{
	id = nil,
	func = nil,
	executor = nil,
	execute = function (self)
		if not self.func(self) then
			return false;
		end

		self:done();
	end,

	done = function (self)
		if self.executor.lock ~= self then
			return
		end
		self.executor:schedule(self.callback);
	end,

	new = function(self, id, func, exe)
		local task = commonlib.copy(self);
		task.id = id;
		task.func = func;
		task.executor = exe;
		return task;
	end
}


function TaskExecutor:addTask(func, userdata)
	local task = Task:new( index, func, self);
	self.tasks[self.index] = task;
	self.index = self.index + 1;
	task.userdata = userdata;
	return task;
end

function TaskExecutor:execute(callback)
	if self.lock then
		error("TaskExecutor is already running!!")
		return
	end
	self.lock = true;
	self:schedule(callback);
end

function TaskExecutor:clear()
	self.tasks = {};
	self.lock = false;
end

function TaskExecutor:isRunning()
	return self.lock ~= nil and self.lock ~= false;
end

function TaskExecutor:current()
	if self.lock and type(self.lock) == "table" then 
		return self.lock
	end;
end