--[[
    Title: SeerFilters
    Author(s): Cellfy
    Date: Mar 4, 2016
    Desc: All filter functions for Seer Mod
    Usage:
    ------------------------------------------------------------
    NPL.load("(gl)script/Seer/Framework/SeerFilters.lua");
    local SeerFilters = commonlib.gettable("Mod.Seer.Framework.SeerFilters");
    ------------------------------------------------------------
]]

--echo("----------------------------------Seer Filters loaded here----------------------------------");
local SeerFilters = commonlib.gettable("Mod.Seer.Framework.SeerFilters");
NPL.load("(gl)script/Seer/Game/ModuleManager.lua");
local ModuleManager = commonlib.gettable("Mod.Seer.Game.ModuleManager");
NPL.load("(gl)script/Seer/Utility/CommonUtility.lua");
local CommonUtility = commonlib.gettable("Mod.Seer.Utility.CommonUtility");
NPL.load("(gl)script/Seer/Config/Config.lua");
local Config = commonlib.gettable("Mod.Seer.Config");
NPL.load("(gl)script/Seer/Game/MultiPlayer/GamingRoomInfo.lua");
local GamingRoomInfo = commonlib.gettable("Mod.Seer.Game.MultiPlayer.GamingRoomInfo");
local block_types = commonlib.gettable("MyCompany.Aries.Game.block_types");

--@param bContinue : useless, just ignore it
--@param region_x : x coordinate of the region just saved
--@param region_y : y coordinate of the region just saved
--@param region_type : type of the region file just saved, could be one of "raw"/"region.xml"
function SeerFilters.OnSaveBlockRegion(bContinue, region_x, region_y, region_type)
    LOG.std(nil, "debug", "cellfy", "SeerFilters.OnSaveRegionCallback");

    if region_x and region_y and region_type then
        echo(region_x);
        echo(region_y);
        echo(region_type);

        local planetMgr = commonlib.gettable("Mod.Seer.Game.World.PlanetManager");
        local planet =planetMgr.getCurrentPlanet()
        if (planet) then
            planet:refreshLocalFile("blockWorld.lastsave/"..region_x.."_"..region_y.."."..region_type)
        end
    end
end


--This filter is a little bit special. It's not not registered directly, but embeded in GameLogic.OnBeforeLoadBlockRegion.
--The reason is mainly that the return value is vital, so multipy filters on the same hook may conflict with each other.
--@param bContinue
--@param region_x : x coordinate of the region just saved
--@param region_y : y coordinate of the region just saved
--@return true: continue loading local file; false: stop loading local file
function SeerFilters.OnBeforeLoadBlockRegion(bContinue, region_x, region_y)
    LOG.std(nil, "debug", "cellfy", "SeerFilters:OnBeforeLoadBlockRegion");

    echo(bContinue);
    echo(region_x);
    echo(region_y);


    local GameLogic = commonlib.gettable("MyCompany.Aries.Game.GameLogic");

    local planetMgr = commonlib.gettable("Mod.Seer.Game.World.PlanetManager");
    local planet = planetMgr.getCurrentPlanet()
    if (not planet) then
        return true
    end
    local blockName = "blockWorld.lastsave/"..msg.x.."_"..msg.y..".raw"
    local fileExist = ParaIO.DoesFileExist(planet:getFolderDir() .. blockName, false);
    if (not fileExist and not planet:isFileExisted(blockName)) then
        return true
    end

    if planet:checkFile(blockName) then
        return true
    else
        echo("log current files")
        for k, v in pairs(planet.files) do
            echo(k)
        end
        _guihelper.MessageBox("检测到本地数据异常，星球将在5s内自动关闭！")
        local closeTimer =  commonlib.Timer:new({callbackFunc =
                                function(timer)
                                    _guihelper.CloseMessageBox();
                                    ModuleManager.startModule("BigWorldPlay");
                                end})
        closeTimer:Change(5000,nil);
        return false;
    end
end

-- hooked at the end of block:OnBlockAdded and block:OnBlockLoaded, after adding or loading a entity block
-- @param block_data contents of the added or loaded block
-- @param x x coord of the block
-- @param y y coord of the block
-- @param z z coord of the block
-- @return nil
function SeerFilters.BlockEntityBaseOnBlockAddedOrLoaded(block_data, x, y, z)
    local entity = block_data:GetBlockEntity(x,y,z)
    if(entity) then
        local obj = entity:GetInnerObject();
        if obj then
            local current_type = block_types.get(block_data.id);
            if current_type.customModel then
                local custom_tex = current_type.texture;
                obj:SetReplaceableTexture(2, ParaAsset.LoadTexture("", custom_tex, 1) );
            end
        end
    else
        LOG.std(nil, "debug", "paperstar", "error occured in SeerFilters.BlockEntityBaseOnBlockAddedOrLoaded, can not find an entity within this BlockEntityBase %s", block_data.id);
    end
end

-- hooked at the end of ItemClient.AddItem, after adding a new item type
-- @param block_id id of the block type
-- @param item xml node of the block type
-- @return nil
function SeerFilters.ItemClientNewItemTypeAdded(block_id, item)
    if item.name=="player" then
        --item.filename = "Seer/model/characters/girlA.fbx";
        --Cellfy: use the first entry in CharacterAssets.xml as the default character model
        local defaultModel = Mod.Seer.Config.CharacterAssetsReader.GetDefaultModel();
        if defaultModel then
            item.filename = defaultModel;
        else
            LOG.std(nil, "error", "cellfy", "No default charactermodel found, please check character asset config file");
        end
    end
end

-- hooked at the end of CreatorAPISandbox.InstallClasses(env), after all internal classes installed
-- @param APIs a table you can insert anything you'd like to be exposed to sandbox env
-- @return nil
function SeerFilters.RegisterClassesIntoSandboxAPI(APIs)
    LOG.std(nil, "debug", "cellfy", "Registering Seer APIs into sandbox");

    NPL.load("(gl)script/Seer/Game/SandboxAPI/SandboxAPI_Functions.lua");
    NPL.load("(gl)script/Seer/Game/SandboxAPI/SandboxAPI_Classes.lua");

    local SandboxAPI_Functions = commonlib.gettable("Mod.Seer.Game.SandboxAPI.SandboxAPI_Functions");
    local SandboxAPI_Classes = commonlib.gettable("Mod.Seer.Game.SandboxAPI.SandboxAPI_Classes");

    --echo("----------------------------------function part----------------------------------");
    for k,v in pairs(SandboxAPI_Functions) do
        LOG.std(nil, "debug", "cellfy", "sandbox api function: %s registered", k);
        APIs[k] = v;
    end

    --echo("----------------------------------classes part----------------------------------");
    local classesToRegister = SandboxAPI_Classes.GetAllClasses();
    for k,v in pairs(classesToRegister) do
        LOG.std(nil, "debug", "cellfy", "sandbox api class: %s registered", k);
        APIs[k] = v;
    end
end

function SeerFilters.CharacterAssetSync_Host_All(entityPlayerMP)
    if entityPlayerMP then
        NPL.load("(gl)script/Seer/Game/MultiPlayer/GamingRoomInfo.lua");
        NPL.load("(gl)script/Seer/NetWork/YcProfile.lua");
        local GamingRoomInfo = commonlib.gettable("Mod.Seer.Game.MultiPlayer.GamingRoomInfo");
        local YcProfile = commonlib.gettable("Mod.Seer.Network.YcProfile");

        if entityPlayerMP.username == "admin" then
            --rename it to my user name
            entityPlayerMP.username = tostring(YcProfile.GetUID());
            local myNickName = YcProfile.GetMyNickname();
            if myNickName then
                entityPlayerMP.nickname = myNickName;
                entityPlayerMP:UpdateDisplayName(myNickName.."(房主)");
            end
            local myAssetID = YcProfile.GetMyCharacterAssetID();
            if myAssetID then
                entityPlayerMP:SetCharacterAsset(myAssetID);
            end
            GamingRoomInfo.PlayerInfoMapAddItem(entityPlayerMP.username, myAssetID, myNickName, true);

            ModuleManager.handleEvent("EventHostPlayerCreated");
        else
            local asset_id = GamingRoomInfo.PlayerInfoMapGetAssetID(entityPlayerMP.username);
            if asset_id then
                entityPlayerMP:SetCharacterAsset(asset_id);
            end
            local nick_name = GamingRoomInfo.PlayerInfoMapGetNickname(entityPlayerMP.username);
            if nick_name then
                entityPlayerMP.nickname = nick_name;
                entityPlayerMP:UpdateDisplayName(nick_name);
            end
        end
        GamingRoomInfo.updatePlayerEntity(tonumber(entityPlayerMP.username), entityPlayerMP);
        
    end
end

function SeerFilters.CharacterAssetSync_Client_Self(entityPlayerMP)
    NPL.load("(gl)script/Seer/NetWork/YcProfile.lua");
    local YcProfile = commonlib.gettable("Mod.Seer.Network.YcProfile");

    if entityPlayerMP then
        local myAssetID = YcProfile.GetMyCharacterAssetID();
        entityPlayerMP:SetCharacterAsset(myAssetID);
        --rename it to my user name
        local myNickName = YcProfile.GetMyNickname();
        if myNickName then
            entityPlayerMP.nickname = myNickName;
            entityPlayerMP:UpdateDisplayName(myNickName);
        end
        GamingRoomInfo.updatePlayerEntity(tonumber(entityPlayerMP.username), entityPlayerMP);
        ModuleManager.handleEvent("EventClientPlayerCreated")
    end
end

function SeerFilters.CharacterAssetSync_Client_Other(entityPlayerMP)
    if entityPlayerMP then
        if entityPlayerMP.asset_id then
            entityPlayerMP:SetCharacterAsset(entityPlayerMP.asset_id);
        end
        if entityPlayerMP.nickname then
            local nickName = entityPlayerMP.nickname;
            if entityPlayerMP.ishost then
                nickName = nickName.." (房主)";
            end
            entityPlayerMP:UpdateDisplayName(nickName);
        end

        GamingRoomInfo.updatePlayerEntity(tonumber(entityPlayerMP.username), entityPlayerMP);
        
    end
end

--Cellfy: this packet is send from client side
function SeerFilters.Packet_PacketLoginClient_Inited(packet)
    NPL.load("(gl)script/Seer/NetWork/YcProfile.lua");
    local YcProfile = commonlib.gettable("Mod.Seer.Network.YcProfile");

    packet.asset_id = YcProfile.GetMyCharacterAssetID();
    packet.nick_name = YcProfile.GetMyNickname();
end

--Cellfy: this packet is send from host side
function SeerFilters.Packet_PacketEntityPlayerSpawn_Inited(packet)


    local player_info = GamingRoomInfo.PlayerInfoMapGetInfo(packet.name);
    if player_info then
        packet.asset_id = player_info.AssetID;
        packet.nick_name = player_info.NickName;
        packet.is_host = player_info.IsHost;
    end
end

function SeerFilters.MPHostSide_ClientLoginReceived(nethandler, packet)
    NPL.load("(gl)script/Seer/Game/MultiPlayer/GamingRoomInfo.lua");
    local GamingRoomInfo = commonlib.gettable("Mod.Seer.Game.MultiPlayer.GamingRoomInfo");

    GamingRoomInfo.PlayerInfoMapAddItem(packet.username, packet.asset_id, packet.nick_name);

    local PacketSyncResourceTable = commonlib.gettable("Mod.Seer.Network.PacketsExt.PacketSyncResourceTable");
    nethandler:SendPacketToPlayer(PacketSyncResourceTable:new():Init());
end

function SeerFilters.MPEntityActionStateUpdated(entityPlayerMP)
    if entityPlayerMP then
        local newAssetID = entityPlayerMP:GetAssetID();
        if newAssetID and newAssetID~=entityPlayerMP.AssetID then
            NPL.load("(gl)script/Seer/Game/MultiPlayer/GamingRoomInfo.lua");
            local GamingRoomInfo = commonlib.gettable("Mod.Seer.Game.MultiPlayer.GamingRoomInfo");

            entityPlayerMP:SetCharacterAsset(newAssetID);
            GamingRoomInfo.updatePlayerAsset(entityPlayerMP.username, newAssetID);

            if GamingRoomInfo.IsPlayerInfoMapValid() then
                --i'm the host player, i should update the skin map
                GamingRoomInfo.PlayerInfoMapUpdateAssetID(entityPlayerMP.username, newAssetID);
            end
        end
    end
end

--this filter will be executed when CreateRolePage is shown, and everytime that page got refreshed
function SeerFilters.MCML_pe_mc_player_RenderCallbackUpdatePreviewInfo(obj_params)
    NPL.load("(gl)script/Seer/CreateRolePage.lua");
    local CreateRolePage = commonlib.gettable("MyCompany.Aries.Game.MainLogin.CreateRolePage");
    if CreateRolePage.IsOnScreen() then
        CreateRolePage.UpdatePreviewInfo(obj_params);
    end
end

function SeerFilters.register_item()
	NPL.load("(gl)script/Seer/Game/Items/Skill/ItemSkill.lua");
	NPL.load("(gl)script/Seer/Game/Items/Skill/ItemSpeedUp.lua");
	NPL.load("(gl)script/Seer/Game/Items/Skill/ItemCreateBlocks.lua");
end


local additional_prop = 
{
    {"skillid", converter = tonumber},
    {"power", converter = tonumber },
}

function SeerFilters.block_types_convert_attribute(attr)
    for k,v in ipairs(additional_prop) do
        if v.converter then
            attr[v[1]] = v.converter(attr[v[1]])
        end
    end
end

function SeerFilters.block_types_apply_property(ApplyProperty)
    for k,v in ipairs(additional_prop) do
	    ApplyProperty(v[1]);
    end
end

function SeerFilters.register_command()
	local whitelist = Config.CommandList.white:get(1);

	if not CommonUtility:IsDevVersion() or Config.CommandList.debug == "true" then
		local Commands = commonlib.gettable("MyCompany.Aries.Game.Commands");
		for k,v in pairs(Commands) do
			if not whitelist[k] then
				Commands[k] = nil;
			end 
		end
	end

	--yoocraft command list
	NPL.load("(gl)script/Seer/Command/CommandYooCraft.lua");
end

GameLogic.GetFilters():add_filter("OnSaveBlockRegion", SeerFilters.OnSaveBlockRegion);
GameLogic.GetFilters():add_filter("item_client_new_item_type_added", SeerFilters.ItemClientNewItemTypeAdded);
GameLogic.GetFilters():add_filter("register_classes_into_sandbox_api", SeerFilters.RegisterClassesIntoSandboxAPI);
GameLogic.GetFilters():add_filter("packet_login_client_inited", SeerFilters.Packet_PacketLoginClient_Inited);
GameLogic.GetFilters():add_filter("packet_entity_player_spawn_inited", SeerFilters.Packet_PacketEntityPlayerSpawn_Inited);
GameLogic.GetFilters():add_filter("host_side_client_login_received", SeerFilters.MPHostSide_ClientLoginReceived);
GameLogic.GetFilters():add_filter("host_side_player_created", SeerFilters.CharacterAssetSync_Host_All);
GameLogic.GetFilters():add_filter("client_side_player_self_created", SeerFilters.CharacterAssetSync_Client_Self);
GameLogic.GetFilters():add_filter("client_side_player_other_created", SeerFilters.CharacterAssetSync_Client_Other);
GameLogic.GetFilters():add_filter("entity_player_mp_entity_action_state_updated", SeerFilters.MPEntityActionStateUpdated);
GameLogic.GetFilters():add_filter("entity_player_mp_other_entity_action_state_updated", SeerFilters.MPEntityActionStateUpdated);
GameLogic.GetFilters():add_filter("entity_player_mp_client_entity_action_state_updated", SeerFilters.MPEntityActionStateUpdated);
GameLogic.GetFilters():add_filter("pe_mc_player_render_callback_obj_params_created", SeerFilters.MCML_pe_mc_player_RenderCallbackUpdatePreviewInfo);
GameLogic.GetFilters():add_filter("register_item", SeerFilters.register_item);
GameLogic.GetFilters():add_filter("block_types_convert_attribute", SeerFilters.block_types_convert_attribute);
GameLogic.GetFilters():add_filter("block_types_apply_property", SeerFilters.block_types_apply_property);
GameLogic.GetFilters():add_filter("register_command", SeerFilters.register_command);
GameLogic.GetFilters():add_filter("block_entity_base_on_block_added", SeerFilters.BlockEntityBaseOnBlockAddedOrLoaded);
GameLogic.GetFilters():add_filter("block_entity_base_on_block_loaded", SeerFilters.BlockEntityBaseOnBlockAddedOrLoaded);
