--[[
NPL.load("(gl)script/Seer/Utility/StringTools.lua");
local StringTools = commonlib.gettable("Mod.Seer.Utility.StringTools");
]]

NPL.load("(gl)script/Seer/Utility/IOUtility.lua");
local IOUtility = commonlib.gettable("Mod.Seer.Utility.IOUtility");

local StringTools = commonlib.gettable("Mod.Seer.Utility.StringTools");

function StringTools.Valid(str_in)
    if type(str_in)=="string" and string.len(str_in)>0 then
        return true;
    else
        return false;
    end
end

function StringTools.split(str, delimiter)
	if str==nil or str=='' or delimiter==nil then
		return nil
	end
    local result = {}
    for match in (str..delimiter):gmatch("(.-)"..delimiter) do
        table.insert(result, match)
    end
    return result
end


function StringTools.StripFilename(filename)
    return IOUtility.StripFilename(filename);
end  

function StringTools.StripFilepath(filename)  
    return IOUtility.StripFilepath(filename);
end 
