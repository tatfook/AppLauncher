--[[
    Title: SeerItemSlab
    Author(s): Devil
    Date: 2016/08/8
    Desc: ItemSlab extension. 
    A Injector class.
    Injection Target: MyCompany.Aries.Game.Items.ItemSlab
    use the lib:
    -------------------------------------------------------
    NPL.load("(gl)script/apps/Aries/Creator/Game/Items/ItemSlab.lua");
    NPL.load("(gl)script/Seer/Injector/SeerItemSlab.lua");
    local ItemSlab = commonlib.gettable("MyCompany.Aries.Game.Items.ItemSlab");
    local SeerItemSlab = commonlib.gettable("Mod.Seer.Injector.SeerItemSlab");
    Inject(SeerItemSlab, ItemSlab);
    -------------------------------------------------------
]]
NPL.load("(gl)script/apps/Aries/Creator/Game/Items/ItemSlab.lua");
local Player = commonlib.gettable("MyCompany.Aries.Player");
local EntityManager = commonlib.gettable("MyCompany.Aries.Game.EntityManager");
local BlockEngine = commonlib.gettable("MyCompany.Aries.Game.BlockEngine")
local TaskManager = commonlib.gettable("MyCompany.Aries.Game.TaskManager")
local block_types = commonlib.gettable("MyCompany.Aries.Game.block_types")
local GameLogic = commonlib.gettable("MyCompany.Aries.Game.GameLogic")
local SeerItemSlab = commonlib.gettable("Mod.Seer.Injector.SeerItemSlab");

local block_id_map;

local function GetBoxBlockBySlabID(slab_id)
  if block_types.get(slab_id).full_block_id then
    return tonumber(block_types.get(slab_id).full_block_id);
  else
    return nil;
  end
end
-- Right clicking in 3d world with the block in hand will trigger this function. 
-- Alias: OnUseItem;
-- @param itemStack: can be nil
-- @param entityPlayer: can be nil
-- @return isUsed: isUsed is true if something happens.
function SeerItemSlab:TryCreate(itemStack, entityPlayer, x,y,z, side, data, side_region)
	if (itemStack and itemStack.count == 0) then
		return;
	elseif (entityPlayer and not entityPlayer:CanPlayerEdit(x,y,z, data, itemStack)) then
		return;
	elseif (self:CanPlaceOnSide(x,y,z,side, data, side_region, entityPlayer, itemStack)) then
		local x_, y_, z_ = BlockEngine:GetBlockIndexBySide(x,y,z,BlockEngine:GetOppositeSide(side));
		local last_block_id = BlockEngine:GetBlockId(x_, y_, z_);
		local block_id = self.block_id;
		local isReplacing;
		if(last_block_id == block_id) then
			local last_block_data = ParaTerrain.GetBlockUserDataByIdx(x_, y_, z_);
			
			if(last_block_data == 0) then
				if(side == 5 or data == 1) then
					-- replace last block id
					if(BlockEngine:SetBlock(x_, y_, z_, GetBoxBlockBySlabID(last_block_id) or block_id, 0, 3)) then
						isReplacing = true;
					end
				end
			else
				if(side == 4 or data == 0) then
					-- replace last block id
					if(BlockEngine:SetBlock(x_, y_, z_, GetBoxBlockBySlabID(last_block_id) or block_id, 0, 3)) then
						isReplacing = true;
					end
				end	
			end	
		end
		if(isReplacing) then
			local block_template = block_types.get(block_id);
			if(block_template) then
				block_template:play_create_sound();

				block_template:OnBlockPlacedBy(x,y,z, entityPlayer);
				if(itemStack) then
					itemStack.count = itemStack.count - 1;
				end
				return true;
			end
		else
			local block_id = self.block_id;
			local block_template = block_types.get(block_id);

			if(block_template) then
				data = data or block_template:GetMetaDataFromEnv(x, y, z, side, side_region);

				if(BlockEngine:SetBlock(x, y, z, block_id, data, 3)) then
					block_template:play_create_sound();

					block_template:OnBlockPlacedBy(x,y,z, entityPlayer);
					if(itemStack) then
						itemStack.count = itemStack.count - 1;
					end
				end
				return true;
			end
		end
	end
end