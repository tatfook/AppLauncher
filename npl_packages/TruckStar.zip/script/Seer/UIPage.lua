--[[
Title: Seer Mod UI Page
Author(s): ZhouXing
Date: 2015/6/19
Desc: Seer Mod UI Page
use the lib:
------------------------------------------------------------
NPL.load("(gl)script/Seer/UIPage.lua");
local UIPage = commonlib.gettable("Mod.Seer.UI.Page");
------------------------------------------------------------
]]
NPL.load("(gl)script/Seer/EscFramePage.lua");

NPL.load("(gl)script/Seer/FriendPage.lua");
NPL.load("(gl)script/Seer/FriendChat.lua");
NPL.load("(gl)script/Seer/FriendSuspension.lua");

NPL.load("(gl)script/Seer/SelectBlocksScale.lua");
NPL.load("(gl)script/apps/Aries/Creator/Game/Tasks/SelectBlocksTask.lua");


local UIPage = commonlib.gettable("Mod.Seer.UI.Page");

UIPage.showEscFramePage = false;

function UIPage.ShowEscFramePage()
	NPL.load("(gl)script/Seer/Settings.lua");
	local Settings = commonlib.gettable("Mod.Seer.Settings");

	if(UIPage.showEscFramePage == false) then
		UIPage.showEscFramePage = true;
	else
		UIPage.showEscFramePage = false;
	end
	bShow = commonlib.gettable("Mod.Seer.UI.EscFramePage").ShowPage();
	return bShow;
end

function UIPage.CloseSelectBlocksPage()
	local SelectBlocksTask = commonlib.gettable("MyCompany.Aries.Game.Tasks.SelectBlocks");
	local SelectBlocksScale = commonlib.gettable("Mod.Seer.UI.SelectBlocksScale");
	if(SelectBlocksTask.page) then
		echo("Select blocks page");
		SelectBlocksTask.CancelSelection()
	end
	if(SelectBlocksScale.page) then
		SelectBlocksScale.ClosePage();
	end
end

function UIPage.ShowGoalTracker()
	NPL.load("(gl)script/Seer/GoalTracker.lua");
	local GoalTracker = commonlib.gettable("Mod.UI.GoalTracker");
	GoalTracker.ShowPage();
end

function UIPage.EscCloseOtherPage()
	NPL.load("(gl)script/Seer/CreatorDesktop.lua");
    local CreatorDesktop = commonlib.gettable("Mod.Seer.UI.CreatorDesktop");
	if(CreatorDesktop.IsExpanded) then
	    CreatorDesktop.ShowPage(false);
	end

	local FriendPage = commonlib.gettable("Mod.Seer.UI.FriendPage");
	if (FriendPage.page) then
		FriendPage.ClosePage();
	end

	NPL.load("(gl)script/Seer/CommandHelpPage.lua");
        Mod.Chat.CommandHelpPage.ClosePage();

	NPL.load("(gl)script/Seer/BuilderFramePage.lua");
	Mod.Seer.UI.BuilderFramePage.ClosePage();

	NPL.load("(gl)script/Seer/QuickEdit.lua");
	Mod.Seer.UI.QuickEdit.ClosePage();

	NPL.load("(gl)script/Seer/HelpPage.lua");
	Mod.Tasks.HelpPage.ClosePage();

	NPL.load("(gl)script/Seer/Minimap.lua");
	Mod.Seer.UI.Minimap.OnClose();

	NPL.load("(gl)script/Seer/EnvFramePage.lua");
	Mod.UI.EnvFramePage.ClosePage()

	NPL.load("(gl)script/Seer/SkinPage.lua");
	Mod.Seer.UI.SkinPage.ClosePage();

	NPL.load("(gl)script/Seer/SystemSettingsPage.lua");
	Mod.Seer.UI.SystemSettingsPage.ClosePage();

	NPL.load("(gl)script/Seer/RoomPermissionPage.lua");
	Mod.Seer.RoomPermissionPage.OnClose()

	NPL.load("(gl)script/Seer/RoomInvitePage.lua");
	Mod.Seer.RoomInvitePage.OnClose()

	NPL.load("(gl)script/Seer/QuickSelectBar.lua");
	Mod.Seer.UI.Minimap.CloseEnvAndMapPage()

	NPL.load("(gl)script/Seer/ChatWindow.lua");
	MyCompany.Aries.ChatSystem.ChatWindow.ClosePage();

	NPL.load("(gl)script/Seer/FriendInfoPage.lua");
	Mod.Seer.UI.FriendInfoPage.ClosePage();

	NPL.load("(gl)script/Seer/RoomInfoPage.lua");
	Mod.Seer.RoomInfoPage.OnClosePage()

	Mod.Seer.UI.Page.CloseSelectBlocksPage();
end
