
--[[
call:
NPL.load("(gl)script/Seer/Network/Packets/PacketPbHelper.lua");
local PacketPbHelper = commonlib.gettable("Mod.Seer.Network.Packets.PacketPbHelper");

]]

NPL.load("(gl)script/Seer/pb/cs_basic_pb.lua");

NPL.load("(gl)script/Seer/Game/ModuleManager.lua");
local ModuleManager = commonlib.gettable("Mod.Seer.Game.ModuleManager");

NPL.load("(gl)script/Seer/Network/Packets/PacketPbHelper.lua");
local PacketPbHelper = commonlib.gettable("Mod.Seer.Network.Packets.PacketPbHelper");

function PacketPbHelper.sendCSPingReq(callback)
	PacketPbHelper.send("CSPingReq",{},callback);
end

function PacketPbHelper.sendCSLogin(userid, zone, callback,errcallback)
	PacketPbHelper.send("CSLoginReq", {uid = userid, channel=0, zone_id=zone},callback,errcallback);
end

--[[
//客户端登陆相关协议
--]]	
function PacketPbHelper.sendCSLoginAuthDataReq(userID, password, clientIP, verifyCode, verifySession, callback)
	local msg = 
	{
		user_id = userID,
		passwd = password,
		client_ip = clientIP,
		verify_code = verifyCode,
		verify_session = verifySession,
	};
	PacketPbHelper.send("CSLoginAuthDataReq", msg,callback);
end

--[[
//客户端请求刷新验证码
--]]	
function PacketPbHelper.sendCSRefreshVerifyCodeReq(userid, clientip,callback)
	PacketPbHelper.send("CSRefreshVerifyCodeReq", {user_id = userid, client_ip = clientip},callback);
end
--[[
//CSCheckSession
--]]	
function PacketPbHelper.sendCSCheckSessionReq(userid, sessionid, clientip,callback)
	PacketPbHelper.send("CSCheckSessionReq", {user_id = userid, session = sessionid, client_ip = clientip},callback);
end
--[[
//创建角色
--]]
function PacketPbHelper.sendCSCrtRoleReq(name, skin, gender,callback)
	PacketPbHelper.send("CSCrtRoleReq", {nick = name, skin_id = skin, gender= gender},callback);
end
--[[
//检查昵称是否重复
--]]	
function PacketPbHelper.sendCSCheckNickReq(name,callback)
	PacketPbHelper.send("CSCheckNickReq", {nick = name},callback);
end

--跨服踢人，通知消息
PacketPbHelper.registerFunc("CSKickUserNotify", 
function (h,b)
	_guihelper.MessageBox("已被强制下线")
	ModuleManager.startModule("Login");

end)

--喊话
PacketPbHelper.registerFunc("CSPushMessageNotify", 
function (h,b)
	if b and b.msg then
	    NPL.load("(gl)script/Seer/Game/UI/BMessageBox.lua");
	    local BMessageBox = commonlib.gettable("Mod.Seer.Game.UI.BMessageBox")
	    BMessageBox.ShowPage(b.msg)
	end
end)


-- keepwork 方式登录
function PacketPbHelper.sendCSLoginByCodeReq(code, callback)
	PacketPbHelper.send("CSLoginByCodeReq", {code = code}, callback)
end

