--[[
Title: CreateRoleConfirmPage.html code-behind script
Author(s): WangXiXi
Date: 2015/7/14
Desc: Create new world based on predefined template and open existing world. 
use the lib:
-------------------------------------------------------
NPL.load("(gl)script/Seer/CreateRoleConfirmPage.lua");
local CreateRoleConfirmPage = commonlib.gettable("MyCompany.Aries.Game.MainLogin.CreateRoleConfirmPage")
CreateRoleConfirmPage.ShowPage()
-------------------------------------------------------
]]
NPL.load("(gl)script/apps/Aries/Creator/WorldCommon.lua");

NPL.load("(gl)script/Seer/Settings.lua");
local Settings = commonlib.gettable("Mod.Seer.Settings");

local CreateRoleConfirmPage = commonlib.gettable("MyCompany.Aries.Game.MainLogin.CreateRoleConfirmPage")

CreateRoleConfirmPage.inited = false;

-- init function. page script fresh is set to false.
function CreateRoleConfirmPage.OnInit()

	if(not CreateRoleConfirmPage.inited) then
		CreateRoleConfirmPage.inited = true;
	end	
end

-- show page
function CreateRoleConfirmPage.ShowPage(bShow)
	System.App.Commands.Call("File.MCMLWindowFrame", {
		url = "script/Seer/CreateRoleConfirmPage.html", 
		name = "CreateRoleConfirmPage", 
		isShowTitleBar = false,
		DestroyOnClose = true, -- prevent many ViewProfile pages staying in memory
		style = CommonCtrl.WindowFrame.ContainerStyle,
		zorder = 0,
		allowDrag = false,
		bShow = bShow,
		directPosition = true,
			align = "_fi",
			x = 0,
			y = 0,
			width = 0,
			height = 0,
		cancelShowAnimation = true,
	});

end