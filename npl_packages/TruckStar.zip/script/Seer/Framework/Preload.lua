--[[
	NPL.load("(gl)script/Seer/Framework/Preload.lua");
    local Preload = commonlib.gettable("Mod.Seer.Framework.Preload");
]]

local Preload = commonlib.gettable("Mod.Seer.Framework.Preload");
local Config = commonlib.gettable("Mod.Seer.Config")

local TaskExecutor = NPL.load("(gl)script/Seer/Utility/TaskExecutor.lua");


local taskexecutor = TaskExecutor:new();

--Texture
local function loadTexture(grp, res)
	local asset  = ParaAsset.LoadTexture("",res.path,1);
	if (asset:IsValid()) then
		asset:LoadAsset()
		echo("preload: "..res.path)
		return asset
	end
end

local function unloadTexture(res)
	local asset = res.file;
	asset:UnloadAsset()
end



-----------
local function loadSingle(grp,res)
	if (res.type == "texture") then
		return loadTexture(grp, res);
	end
	return false;
end

local function unloadSingle(res)
	if (res.type == "texture") then
		unloadTexture(res)
	end
end

function Preload.load(grpname)
	local group = Config.Preload.Group:find(grpname);
	if not group then
		return
	end

	local resources = group.Resource;
	if not resources then
		return
	end
	

	local count = resources:size()
	
	for i = 1 , count do
		local res = resources:get(i);
		taskexecutor:addTask(function (t)
			local asset = loadSingle(grpname, res);
			if (not asset) then
				echo(string.format("failed to load resource %s in group ", res.path, grpname))
				t:done();
				return;
			end

			local timer;
			timer = commonlib.Timer:new({callbackFunc = function ()
				if asset:IsLoaded() then
					timer:Change();
					t:done();
				end
			end})
			timer:Change(10,10);
		end)
	end

	taskexecutor:execute(function ()echo("resources are loaded")end)
end

function Preload.unload(grpname)

end



