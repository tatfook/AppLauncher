﻿

NPL.load("(gl)script/Seer/pb/error_code_pb.lua");
NPL.load("(gl)script/Seer/Network/Packets/PacketPbHelper.lua");
local PacketPbHelper = commonlib.gettable("Mod.Seer.Network.Packets.PacketPbHelper");

NPL.load("(gl)script/Seer/Game/ModuleManager.lua");
local ModuleManager = commonlib.gettable("Mod.Seer.Game.ModuleManager");

PacketPbHelper.registerFunc("ErrorCode", 
function (header, body)
	if (header.errcode == error_code_pb.ONLINE_ERROR_LOGIN_REPEAT) then
		_guihelper.MessageBox("  用户重复登陆");
		ModuleManager.startModule("Login");
	elseif (header.errcode == error_code_pb.ONLINE_ERROR_FORCE_OFFLINE) then
		_guihelper.MessageBox("  用户重复登陆");
		ModuleManager.startModule("Login");
	else
	end
	print("error: protocol errorcode:".. header.errcode);

end);

