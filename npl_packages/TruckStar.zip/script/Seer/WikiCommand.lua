﻿--[[
Title: WikiCommand Page
Author(s): WuZhao
Date: 2015/7/20
Desc: 
Use Lib:
-------------------------------------------------------
NPL.load("(gl)script/Seer/WikiCommand.lua");
local WikiCommand = commonlib.gettable("Mod.Seer.UI.WikiCommand");
WikiCommand.ShowPage();
-------------------------------------------------------
]]

local WikiCommand = commonlib.gettable("Mod.Seer.UI.WikiCommand");

WikiCommand.page = nil;

function WikiCommand.ShowPage()
	local params = {
			url = "script/Seer/WikiCommand.html", 
			name = "WikiCommand.ShowPage", 
			isShowTitleBar = false,
			DestroyOnClose = true,
			bToggleShowHide=true, 
			style = CommonCtrl.WindowFrame.ContainerStyle,
			allowDrag = false,
			enable_esc_key = true,
			--bShow = FriendSuspension.IsExpanded,
			click_through = false, 
			zorder = 2,
			app_key = MyCompany.Aries.Creator.Game.Desktop.App.app_key, 
			directPosition = true,
				align = "_fi",
				x = 0,
				y = 0,
				width = 0,
				height = 0,
		};	
	--params.bShow = FriendSuspension.IsExpanded;

	System.App.Commands.Call("File.MCMLWindowFrame", params);

end

function WikiCommand.OnInit()
	WikiCommand.page = document:GetPageCtrl();

end

function WikiCommand.ClosePage()
	WikiCommand.page:CloseWindow();
end

function WikiCommand.OnClick(name,mcmlNode)
	if(name=="advance") then
        ClosePage();
	--
    elseif(name=="command") then
        ClosePage();
        
    end
end