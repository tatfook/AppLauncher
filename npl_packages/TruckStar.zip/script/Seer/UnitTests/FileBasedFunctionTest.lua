--is prime
return function (num)
    for i = 2, num - 1 do
        if num % i == 0 then
            return false;
        end
    end
    return true;
end