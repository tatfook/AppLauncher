NPL.load("(gl)script/Seer/UIPage.lua");
NPL.load("(gl)script/Seer/Settings.lua");
NPL.load("(gl)script/Seer/Utility/CommonUtility.lua");
local CommonUtility = commonlib.gettable("Mod.Seer.Utility.CommonUtility");
local Settings = commonlib.gettable("Mod.Seer.Settings");
local UIManager = commonlib.gettable("Mod.Seer.Game.UI.UIManager");
local UIBase = commonlib.gettable("Mod.Seer.Game.UI.UIBase");
local RoomBillboardPage = commonlib.inherit(UIBase,commonlib.gettable("Mod.Seer.RoomBillboardPage"));
UIManager.registerUI("RoomBillboardPage", RoomBillboardPage,"script/Seer/RoomBillboardPage.html",
{
});
local callback
function RoomBillboardPage:onCreate(info)
  callback = info.callback
  local text= info.text
  self.craftid=info.id;
  if self.craftid then
    local file_path=Settings.GetLocalPlanetFolder(self.craftid).."billboard.txt";
    local file_handle=io.open(file_path,"r");
    if file_handle then
      text=file_handle:read("*a");
      file_handle:close();
    end
  end
  self.page:GetNode("text"):GetControl():SetText(text);
end
function RoomBillboardPage:onOK()
  local text=self.page:GetValue("text","");
  if CommonUtility.getChineseCharacterCount(text)+CommonUtility.getNotChineseCharacterCount(text) > 64 then
    _guihelper.MessageBox("字数超过64个限制!");
    return;
  end
  if callback then
    callback(text)
  else
    local file_path=Settings.GetLocalPlanetFolder(self.craftid).."billboard.txt";
    local file_handle=io.open(file_path,"w");
    file_handle:write(text);
    file_handle:close();
  end
  self:close();
end