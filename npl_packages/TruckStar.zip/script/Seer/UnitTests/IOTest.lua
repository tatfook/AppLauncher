--[[
    Title: Unit test for IO interfaces
    Author(s): Cellfy
    Date Created: November 9, 2016
    Date Updated: November 9, 2016
    Desc: 
    Usage:
    ------------------------------------------------------------
    NPL.load("(gl)script/Seer/UnitTests/IOTest.lua");
    local IOTest = commonlib.gettable("Mod.Seer.UnitTests.IOTest");
    ------------------------------------------------------------
]]

NPL.load("(gl)script/Seer/Utility/IOUtility.lua");

local IOTest = commonlib.gettable("Mod.Seer.UnitTests.IOTest");

function IOTest.TestRead()
    local file = ParaIO.open("worlds/1.xml", "r");
    local content = file:GetText();
    echo("----------------------------------read test----------------------------------");
    echo(type(content))
    echo(content);
    print(content);
    file:close();
    echo("----------------------------------read test end----------------------------------");

    echo("----------------------------------io read test----------------------------------");
    local iofile = io.open("worlds/1.xml", "rb");
    local iocontent = iofile:read("*all");
    echo(type(iocontent))
    echo(iocontent);
    --print(iocontent);
    file:close();
    echo("----------------------------------io read test end----------------------------------");
end

function IOTest.TestHash()
    NPL.load("(gl)script/Seer/Utility/qiniuHash.lua");
    local QiniuHash = commonlib.gettable("Mod.Seer.Utility.QiniuHash");
    echo("----------------------------------lua io----------------------------------");
    local iofile = io.open("worlds/1.xml", "rb");
    local iocontent = iofile:read("*all");
    echo(iocontent);
    QiniuHash.hash(iofile);
    iofile:close();

    echo("----------------------------------paraio----------------------------------");
    --local fullPath = ParaIO.GetWritablePath().."worlds/1.xml";
    local fullPath = "worlds/1.xml";
    echo(fullPath);
    local file = ParaIO.open(fullPath, "r");
    local content = file:GetText(0, -1);
    echo(content);
    QiniuHash.hashpara(file);
    file:close();
end

function IOTest.TestWrite()
    
end
