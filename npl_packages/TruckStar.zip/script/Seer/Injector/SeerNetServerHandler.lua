--[[
    Title: SeerNetServerHandler
    Author(s): Devil
    Date: 2016/05/04
    Desc: NetServerHandler extension. 
    A Injector class.
    Injection Target: MyCompany.Aries.Game.Network.NetServerHandler
    use the lib:
    -------------------------------------------------------
	NPL.load("(gl)script/apps/Aries/Creator/Game/Network/NetServerHandler.lua");
    NPL.load("(gl)script/Seer/Injector/SeerNetServerHandler.lua");
	local NetServerHandler = commonlib.gettable("MyCompany.Aries.Game.Network.NetServerHandler");
    local SeerNetServerHandler = commonlib.gettable("Mod.Seer.Injector.SeerNetServerHandler");
    Inject(SeerNetServerHandler, NetServerHandler);
    -------------------------------------------------------
]]
NPL.load("(gl)script/apps/Aries/Creator/Game/Entity/NetServerHandler.lua");
NPL.load("(gl)script/ide/math/bit.lua");
NPL.load("(gl)script/apps/Aries/Creator/Game/Commands/CommandManager.lua");
NPL.load("(gl)script/Seer/Game/MultiPlayer/GamingRoomInfo.lua");
local GamingRoomInfo = commonlib.gettable("Mod.Seer.Game.MultiPlayer.GamingRoomInfo");
local CommandManager = commonlib.gettable("MyCompany.Aries.Game.CommandManager");
local Packets = commonlib.gettable("MyCompany.Aries.Game.Network.Packets");
local BlockEngine = commonlib.gettable("MyCompany.Aries.Game.BlockEngine")
local block_types = commonlib.gettable("MyCompany.Aries.Game.block_types")
local GameLogic = commonlib.gettable("MyCompany.Aries.Game.GameLogic")
local EntityManager = commonlib.gettable("MyCompany.Aries.Game.EntityManager");
local Desktop = commonlib.gettable("MyCompany.Aries.Creator.Game.Desktop");
local SeerNetServerHandler = commonlib.gettable("Mod.Seer.Injector.SeerNetServerHandler")

function SeerNetServerHandler:handleChat(packet_Chat)
    LOG.std(nil, "debug", "NetServerHandler.handleChat", "%s says: %s", GamingRoomInfo.PlayerInfoMapGetNickname(self.playerEntity:GetUserName()), packet_Chat.text);
	--packet_Chat.text = GamingRoomInfo.PlayerInfoMapGetNickname(self.playerEntity:GetUserName())..": "..packet_Chat.text;
	local chat_msg = packet_Chat:ToChatMessage();

	Desktop.GetChatGUI():PrintChatMessage(chat_msg, tonumber(string.match(self.playerEntity.name, "__MP__(.*)")));
	self:GetServerManager():SendChatMsg(chat_msg);
end

function SeerNetServerHandler:handlePlayerPositionReq(packet_player_position_req)
    if packet_player_position_req.user_id then
        NPL.load("(gl)script/apps/Aries/Creator/Game/Network/ServerManager.lua");
	local ServerManager = commonlib.gettable("MyCompany.Aries.Game.Network.ServerManager");
        local player = nil;
	for i=1, ServerManager.GetSingleton().playerEntityList:size() do
            if ServerManager.GetSingleton().playerEntityList:get(i):GetUserName()==packet_player_position_req.user_id then
                player=ServerManager.GetSingleton().playerEntityList:get(i);
                local bx, by, bz = player:GetBlockPos();
                local Packets = commonlib.gettable("Mod.Seer.Network.PacketsExt");
                self:SendPacketToPlayer(Packets.PacketPlayerPosition:new():InitAsRsp(packet_player_position_req, bx, by, bz));
                break;
            end
	end
    end
end
