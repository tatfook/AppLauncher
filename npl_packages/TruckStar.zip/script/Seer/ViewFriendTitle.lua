
--[[
NPL.load("(gl)script/Seer/ViewFriendTitle.lua");
local ViewFriendTitle = commonlib.gettable("Mod.Seer.ViewFriendTitle")
--]]

NPL.load("(gl)script/Seer/NetWork/YcProfile.lua");
local YcProfile = commonlib.gettable("Mod.Seer.Network.YcProfile");

NPL.load("(gl)script/Seer/Settings.lua");
local Settings = commonlib.gettable("Mod.Seer.Settings");

NPL.load("(gl)script/Seer/Network/Packets/PacketPbHelper.lua");
local PacketPbHelper = commonlib.gettable("Mod.Seer.Network.Packets.PacketPbHelper");

NPL.load("(gl)script/apps/Aries/Creator/Game/Entity/PlayerSkins.lua");
local PlayerSkins = commonlib.gettable("MyCompany.Aries.Game.EntityManager.PlayerSkins")

NPL.load("(gl)script/Seer/FriendInfoPage.lua");
local FriendInfoPage = commonlib.gettable("Mod.Seer.UI.FriendInfoPage");

local Config = commonlib.gettable("Mod.Seer.Config");

local configPlanet;

local UIManager = commonlib.gettable("Mod.Seer.Game.UI.UIManager");

local UIBase = commonlib.gettable("Mod.Seer.Game.UI.UIBase");
local ViewFriendTitle = commonlib.inherit(UIBase,commonlib.gettable("Mod.Seer.ViewFriendTitle"));
UIManager.registerUI("ViewFriendTitle", ViewFriendTitle,"script/Seer/ViewFriendTitle.html",
{
	align = "_lt",
	x = 0,
	y = 0,
	width = 834,
	height = 244,
});
ViewFriendTitle.favorCount = 0
ViewFriendTitle.isFavor = false
ViewFriendTitle.storageInfo = {}
function ViewFriendTitle:onCreate()
	configPlanet = Config.PlanetTemplate.Planet;
	PacketPbHelper.sendCSGetFriendDetailReq(
		YcProfile.viewUid,function(head,msg)
			YcProfile.SetUserInfo(uid, msg.friend_info);
			self.friendInfo = msg.friend_info
			self:RefreshPage()
		end)
	self.storageInfo = YcProfile.viewStorageInfo

	echo("test====self.storageInfo")
	echotable(self.storageInfo)

	self.favorCount = self:SetFavorCount()

	self.isFavor = false

	PacketPbHelper.sendCSIsReviewCraftReq(YcProfile.viewUid,self.storageInfo.id,base_define_pb.REVIEW_TYPE_FAVOR,
		function (head,body)
			if body then
				self.isFavor = body.is_reviewed
				self:RefreshPage();
			end
		end)
end
function ViewFriendTitle:RefreshPage()
	self:refresh(0)
	self:RefreshHeadIcon()
end

function ViewFriendTitle:RefreshHeadIcon()
	 local control = self.page:FindControl("craftinfo")
	 if control then
		 local icon = self:GetHeadIcon()
		 control.background = icon..";0 0 128 128"
	 end
end
-- function ViewFriendTitle.ShowPage()
-- 	if YcProfile.uid ==nil or  YcProfile.viewStorageInfo == nil or next(YcProfile.viewStorageInfo) == nil then
-- 		return
-- 	end
-- 	System.App.Commands.Call("File.MCMLWindowFrame", {
-- 	url = "script/Seer/ViewFriendTitle.html",
-- 	name = "ViewFriendTitle",
-- 	isShowTitleBar = false,
-- 	DestroyOnClose = true, -- prevent many ViewProfile pages staying in memory
-- 	style = CommonCtrl.WindowFrame.ContainerStyle,
-- 	zorder = 1,
-- 	allowDrag = false,
-- 	enable_esc_key = false,
-- 	bShow = bShow,
-- 	directPosition = true,
-- 		align = "_lt",
-- 		x = 300,
-- 		y = 0,
-- 		width = 270,
-- 		height = 60,
-- 	cancelShowAnimation = true,
-- 	});
-- end


function ViewFriendTitle:GetHeadIcon()
	if self.friendInfo then
		local avatar_id = self.friendInfo.avatar_id;
		if avatar_id then
			echo(avatar_id)
			local avatar_filename = YcProfile.GetCharacterHeadIconById(avatar_id)
			echo(avatar_filename)
			return avatar_filename;
		end
	end
	return ""
end



function ViewFriendTitle:GetFriendName()
	if self.friendInfo then
		return self.friendInfo.nick_name.."("..self.friendInfo.user_id..")"
	end
	return ""
end

function ViewFriendTitle:GetCraftName()
	local id =  self.storageInfo.resourceid
	if configPlanet and id then
		-- return configPlanet:find(id).name
		return self.storageInfo.name
	end
	return ""
end

function ViewFriendTitle:GetCraftCreateTime()
	-- local time = self.storageInfo.createTime
	-- if time then
	-- 	local timeTable = os.date("*t",time)
	-- 	return timeTable.year.."-"..timeTable.month.."-"..timeTable.day
	-- end
	-- return ""

	local time = self.storageInfo.duration
	if(time) then
		time = tonumber(time) or 0;
		local hours = math.floor(time/3600);
		local minute = math.floor(time%3600/60);
		return string.format("%02d:%02d",hours,minute);
	end
	return "00:00"


end
function ViewFriendTitle:GetFavorCount()
	return self.favorCount
end
function ViewFriendTitle:SetFavorCount()
	local reviewList = self.storageInfo.reviewCount
	if reviewList and next(reviewList) then
		for i,v in pairs(reviewList) do
			if v.review_type and v.review_type == base_define_pb.REVIEW_TYPE_FAVOR then
				return v.count
			end
		end
	else
		return 0
	end
end

function ViewFriendTitle:SetYcprofileFriendInfo()
	local reviewList = self.storageInfo.reviewCount
	if reviewList and next(reviewList) then
		local isExistFavor = false
		for i,v in pairs(reviewList) do
			if v.review_type and v.review_type == base_define_pb.REVIEW_TYPE_FAVOR then
				v.count = self.favorCount
				isExistFavor = true
				break
			end
		end
		if isExistFavor == false then
			local temp = {}
			temp.review_type = base_define_pb.REVIEW_TYPE_FAVOR
			temp.count = self.favorCount
			self.storageInfo.reviewCount[#self.storageInfo.reviewCount+1] = temp
		end
	else
		self.storageInfo.reviewCount = {}
		local temp = {}
		temp.review_type = base_define_pb.REVIEW_TYPE_FAVOR
		temp.count = self.favorCount
		self.storageInfo.reviewCount[1] = temp
	end
	local ui = UIManager.getUI("FriendInfoPage")
	if ui then
		ui:SetNewFavorCount(YcProfile.viewUid,self.storageInfo.id,self.storageInfo.reviewCount)
	end
end
function ViewFriendTitle:OnFavorCancelBtn()
	Statistics.SendKeyValue("Social.Like", "Visit")
	if self.isFavorBtn == true then
		return
	else
		self.isFavorBtn = true
	end

	PacketPbHelper.sendCSReviewCraftReq(YcProfile.viewUid,self.storageInfo.id,base_define_pb.REVIEW_TYPE_FAVOR,base_define_pb.OP_REVIEW_CANCLE,
		function (head,body)
	    	self.favorCount = self.favorCount -1
			self.isFavor = false
	    	self:SetYcprofileFriendInfo()
			self:RefreshPage();
			self.isFavorBtn = false
		end,
		function (header)
			self.isFavorBtn = false
		end)
end

function ViewFriendTitle:OnFavorBtn()
	Statistics.SendKeyValue("Social.Like", "Visit")
	if self.isFavorBtn == true then
		return
	else
		self.isFavorBtn = true
	end
	PacketPbHelper.sendCSReviewCraftReq(YcProfile.viewUid,self.storageInfo.id,base_define_pb.REVIEW_TYPE_FAVOR,base_define_pb.OP_REVIEW_BUILD,
	function (head,body)
		self.favorCount = self.favorCount + 1
		self.isFavor = true
		self:SetYcprofileFriendInfo()
		self:RefreshPage()
		self.isFavorBtn = false
	end,
	function (header)
		self.isFavorBtn = false
	end)
end
function ViewFriendTitle:CraftInfo()
	-- FriendInfoPage.ShowPage(YcProfile.viewUid);
	UIManager.createUI("FriendInfoPage",self,nil,YcProfile.viewUid)
end

function ViewFriendTitle:QuitCraftToBigworld()
	NPL.load("(gl)script/Seer/Game/ModuleManager.lua");
	local ModuleManager = commonlib.gettable("Mod.Seer.Game.ModuleManager");
	local Settings = commonlib.gettable("Mod.Seer.Settings");
	ModuleManager.startModule("BigWorldPlay");
end
