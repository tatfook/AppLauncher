--[[
	商店通讯协议
--]]
NPL.load("(gl)script/Seer/pb/cs_shop_pb.lua");
NPL.load("(gl)script/Seer/Network/Packets/PacketPbHelper.lua");
local PacketPbHelper = commonlib.gettable("Mod.Seer.Network.Packets.PacketPbHelper");

--[[
//进入商店
--]]
function PacketPbHelper.sendCSEnterShopReq(shopId, callback,errcallback)
	PacketPbHelper.send("CSEnterShopReq", {shop_id = shopId, },callback,errcallback)
end

--购买物品
function PacketPbHelper.sendCSBuyItemReq(shopId,itemId,number, callback,errcallback)
	PacketPbHelper.send("CSBuyItemReq", {shop_id = shopId,item_id = itemId,number= number },callback,errcallback)
end


function PacketPbHelper.sendCSObtainAllItemsReq(callback,errcallback)
	PacketPbHelper.send("CSObtainAllItemsReq", {},callback,errcallback)
end
