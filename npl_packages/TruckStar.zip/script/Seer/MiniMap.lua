--[[
Title: Mini Map Page
Author(s): WuZhao
Date: 2008/6/22
Desc:
use the lib:
------------------------------------------------------------
NPL.load("(gl)script/Seer/Minimap.lua");
local Minimap = commonlib.gettable("Mod.Seer.UI.Minimap");
Minimap.Show();
-------------------------------------------------------
]]

local AudioEngine = commonlib.gettable("AudioEngine");
NPL.load("(gl)script/Seer/MinimapWnd.lua");
NPL.load("(gl)script/Seer/MinimapSurface.lua");
local MinimapSurface = commonlib.gettable("Mod.Seer.UI.MinimapSurface");
NPL.load("(gl)script/Seer/Game/UI/UIManager.lua");
local UIManager= commonlib.gettable("Mod.Seer.Game.UI.UIManager");
-- create class
local Minimap = commonlib.inherit(commonlib.gettable("Mod.Seer.Game.UI.UIBase"),commonlib.gettable("Mod.Seer.UI.Minimap"));

UIManager.registerUI("Minimap",Minimap,"script/Seer/Minimap.html",
{
		align = "_rt",
		x = -230,
		y = 0,
		width = 230,
		height = 266,
    zorder = 0
})


-- 0   ,  1  minimap opened,  2  envframepage opend ,
Minimap.pageStatus = 0;

function Minimap:ctor()
	self.location = "";
end

function Minimap:onCreate()

	local functionBarUI = UIManager.getUI("FunctionBar")
	if functionBarUI then
		functionBarUI:EventOpenUI({name="minimap"})
	end

	UIManager.createUI("MinimapWnd",self);
	local ui = UIManager.getUI("RoomMemBar")
	if ui then
		ui:RefreshInfo()
	end

	if not Statistics.TempStatus.MiniMapOpened then
		Statistics.TempStatus.MiniMapOpened = true;
		Statistics.SendKey("Environment.MiniMap.FirstOpen");
	end
end

function Minimap:onDestroy()
	if self.surface then
		self.surface:Close()
	end
	local ui = UIManager.getUI("RoomMemBar")
	if ui then
		ui:RefreshInfo()
	end

	local functionBarUI = UIManager.getUI("FunctionBar")
	if functionBarUI then
		functionBarUI:EventCloseUI({name="minimap"})
	end
end

function Minimap:getLocation()
	return self.location;
end

function Minimap:setLocation(x,y,z)
	self.location = string.format("X:%d Z:%d Y: %d",x, y, z)
end

-- toggle show/hide mini map window
-- @param x,y: position at which to display the window. If nil, the center of screen is used. 
function Minimap.Show(bShow, x, y)


	if(bShow) then
		NPL.load("(gl)script/ide/timer.lua");
		Minimap.timer = commonlib.Timer:new({callbackFunc = function(timer)
				NPL.load("(gl)script/Seer/MinimapWnd.lua");
				local MinimapWnd = commonlib.gettable("Mod.Seer.UI.MinimapWnd");
				MinimapWnd:Show();
				end})
		Minimap.timer:Change(100, nil);
		
	else
		if(Minimap.timer) then
			Minimap.timer:Change();
		end
		NPL.load("(gl)script/Seer/MinimapWnd.lua");
		local MinimapWnd = commonlib.gettable("Mod.Seer.UI.MinimapWnd");
		MinimapWnd:ClosePage();
		if(Minimap.surface) then
			Minimap.surface:Close();
		end
	end

	if(Minimap.page) then
		Minimap.page:Refresh(0);
	end

	NPL.load("(gl)script/Seer/Settings.lua");
	local Settings = commonlib.gettable("Mod.Seer.Settings");

	-- NPL.load("(gl)script/Seer/Game/Guide/GuideMask.lua");
	-- local GuideMask = commonlib.gettable("Mod.Seer.Game.Guide.GuideMask");
	-- GuideMask.guide("Map");
end

-- open using external system web browser, such as ie


--function Minimap.RefreshAvatar()
--
	--Minimap.page:Refresh(0);
--
--end

function Minimap:ShowEnvFramePage()
	local parent = self.parent

	UIManager.createUI("EnvFramePage", parent);

	AudioEngine.PlayUISound("btn_show");

	self:close();

end

function Minimap:enableEnvPage( value)
	self.enableEnv = value;
	self:refresh();
end

function Minimap:handleKeyEvent(event)
    local dik_key = event.keyname;
	if (dik_key == "DIK_ESCAPE") then
		self:close();
		event:accept();
	end

	--catch all
	return true;
end
