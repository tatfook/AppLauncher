--[[
    Title: SeerNetClientHandler
    Author(s): Cellfy
    Date Created: Jul 10, 2016
    Date Updated: Jul 10, 2016
    Desc: EntityMob extension. 
    A Injector class.
    Injection Target: MyCompany.Aries.Game.Network.NetClientHandler
    use the lib:
    -------------------------------------------------------
    NPL.load("(gl)script/apps/Aries/Creator/Game/Network/NetClientHandler.lua");
    NPL.load("(gl)script/Seer/Injector/SeerNetClientHandler.lua");
    local NetClientHandler = commonlib.gettable("MyCompany.Aries.Game.Network.NetClientHandler");
    local SeerNetClientHandler = commonlib.gettable("Mod.Seer.Injector.SeerNetClientHandler");
    Inject(SeerNetClientHandler, NetClientHandler);
    -------------------------------------------------------
]]

local SeerNetClientHandler = commonlib.gettable("Mod.Seer.Injector.SeerNetClientHandler");
local ResourceTable = NPL.load("script/Seer/Game/Resource/ResourceTable.lua");

function SeerNetClientHandler:handlePlayerPosition(packet_player_position)
    --cellfy: this is just an example function, if everything is done in user callback, this function isn't necessarily needed to be explicitly written, just make it nil
    echo("----------------------------------nothing to do, all things done in user callback----------------------------------");
end

function SeerNetClientHandler:handleEntityMetadata(packet_EntityMetadata)
    local entity = self:GetEntityByID(packet_EntityMetadata.entityId);

		if (entity and packet_EntityMetadata:GetMetadata()) then
			local watcher = entity:GetDataWatcher();
			if(watcher) then
				watcher:UpdateWatchedObjectsFromList(packet_EntityMetadata:GetMetadata());
			end
		end
end

function SeerNetClientHandler:handleSyncResourceTable(packet)
    echo("ResourceTable receive res from server")
    for k,v in pairs(packet.resources) do
        ResourceTable.add(v, k);
    end
end