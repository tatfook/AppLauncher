--[[
desc:protcol file, wrap game.proto
use the lib:
-------------------------------------------
NPL.load("(gl)script/Seer/Network/Packets/game.proto.lua");
-------------------------------------------
]]

NPL.load("(gl)script/Seer/pb/game_pb.lua");
NPL.load("(gl)script/Seer/Network/Packets/PacketPbHelper.lua");
local PacketPbHelper = commonlib.gettable("Mod.Seer.Network.Packets.PacketPbHelper");
local YcProfile = commonlib.gettable("Mod.Seer.Network.YcProfile");
local UIManager = commonlib.gettable("Mod.Seer.Game.UI.UIManager");

NPL.load("(gl)script/Seer/Game/Friend/FriendManager.lua");
local FriendManager = commonlib.gettable("Mod.Seer.Game.Friend.FriendManager");


local GameLogic = commonlib.gettable("MyCompany.Aries.Game.GameLogic")

function PacketPbHelper.sendCSAvatarLoginWorldReq(worldid, callback)
	local msg = {};
	msg.world_id = worldid;
	PacketPbHelper.send("CSAvatarLoginWorldReq", msg, callback);
end


function PacketPbHelper.sendCSAvatarLogoutWorldReq(worldid)
	local msg = {};
	msg.world_id = worldid;
	PacketPbHelper.send("CSAvatarLogoutWorldReq", msg);
end


function PacketPbHelper.sendCSAvatarChat(worldid, userid, chatdata)
	local msg = {};
	msg.world_id = worldid;
	msg.user_id = userid;
	msg.chatdata = chatdata;
	PacketPbHelper.send("CSAvatarChat", msg);
end

function PacketPbHelper.sendCSAvatarPosition(worldid, userid,x,y,z,facing,pitch,animid, row, col)
	local msg = {};
	msg.world_id = worldid;
	msg.user_id = userid;
	msg.x = x;
	msg.y = y;
	msg.z = z;
	msg.facing= facing;
	msg.pitch = pitch;
	msg.anim_id= animid;
	msg.row = row
	msg.col= col
	PacketPbHelper.send("CSAvatarPosition", msg);
end

PacketPbHelper.registerFunc("CSChatMsgDataNtf", 
function (header, body)
	local uid = body.from_user_id;

	if(not YcProfile.GetFriendInfo(uid) and not YcProfile.GetBlacksInfoById(uid)) then -- get info and append to chat
		PacketPbHelper.sendCSGetFriendDetailReq(
			uid,
			function(h, msg)	
			if(msg.friend_info) then
				YcProfile.SetUserInfo(uid, msg.friend_info);
				YcProfile.AddStrangerInfo(uid, msg.friend_info);

				-- NPL.load("(gl)script/Seer/FriendChat.lua");
				-- local FriendChat = commonlib.gettable("Mod.Seer.UI.FriendChat");
				-- FriendChat.OnReceiveMessage(body.from_user_id, body.msg_data);

				-- NPL.load("(gl)script/Seer/FriendPage.lua");
				-- local FriendPage = commonlib.gettable("Mod.Seer.UI.FriendPage");
				-- FriendPage.SetUnreadMsg(body.from_user_id);

				FriendManager.SetUnreadMsgUser(body.from_user_id)
				FriendManager.OnReceiveMessage(body.from_user_id,body.msg_data)
			end
		end)
	else -- directly append to chat
		-- NPL.load("(gl)script/Seer/FriendChat.lua");
		-- local FriendChat = commonlib.gettable("Mod.Seer.UI.FriendChat");
		-- FriendChat.OnReceiveMessage(body.from_user_id, body.msg_data);

		-- NPL.load("(gl)script/Seer/FriendPage.lua");
		-- local FriendPage = commonlib.gettable("Mod.Seer.UI.FriendPage");
		-- FriendPage.SetUnreadMsg(body.from_user_id);


		FriendManager.SetUnreadMsgUser(body.from_user_id)
		FriendManager.OnReceiveMessage(body.from_user_id,body.msg_data)
	end
end);

PacketPbHelper.registerFunc("CSUserOnlineNtf", 
function (header, body)
	YcProfile.SetUserInfo(body.user_info.user_id, body.user_info);
	YcProfile.AddFriendInfo(body.user_info.user_id, body.user_info);

	local friend_ui = UIManager.getUI("FriendPage")
	if friend_ui then
		friend_ui:RefreshPage()
	end
	local friend_chat_ui = UIManager.getUI("FriendChat")
	if friend_chat_ui then
		friend_chat_ui:RefreshInfo(body.user_info)
	end
	local friendAndChat_ui = UIManager.getUI("FriendAndChatPage")
	if friendAndChat_ui then
		friendAndChat_ui:RefreshFriendData()
	end
	local friend_info_ui = UIManager.getUI("FriendInfoPage")
	if friend_info_ui then
		friend_info_ui:RefreshPage()
	end
	local ui_main = UIManager.getUI("UIMain")
	UIManager.createUI("FriendReminder",ui_main,nil,body.user_info)
end);

PacketPbHelper.registerFunc("CSUserOfflineNtf", 
function (header, body)
	YcProfile.SetUserInfo(body.user_info.user_id, body.user_info);
	YcProfile.AddFriendInfo(body.user_info.user_id, body.user_info);
	local friend_ui = UIManager.getUI("FriendPage")
	if friend_ui then
		friend_ui:RefreshPage()
	end
	local friend_chat_ui = UIManager.getUI("FriendChat")
	if friend_chat_ui then
		friend_chat_ui:RefreshInfo(body.user_info)
	end
end);

PacketPbHelper.registerFunc("CSAvatarChat", 
function (header, body)
	local chatmsg = body.chatdata;
	local chat_name_msg = chatmsg;
	MyCompany.Aries.Creator.Game.Desktop.GetChatGUI():PrintChatMessage(chat_name_msg,body.user_id,true);
end);

PacketPbHelper.registerFunc("CSUserChangeStatusNtf", 
function (header, body)
	YcProfile.SetUserInfo(body.user_info.user_id, body.user_info);
	YcProfile.AddFriendInfo(body.user_info.user_id, body.user_info);

	local friend_ui = UIManager.getUI("FriendPage")
	if friend_ui then
		friend_ui:RefreshPage()
	end
	local friend_chat_ui = UIManager.getUI("FriendChat")
	if friend_chat_ui then
		friend_chat_ui:RefreshInfo(body.user_info)
	end
	local friendAndChat_ui = UIManager.getUI("FriendAndChatPage")
	if friendAndChat_ui then
		friendAndChat_ui:RefreshFriendData()
	end
end);
