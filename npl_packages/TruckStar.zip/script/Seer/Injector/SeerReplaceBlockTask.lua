--[[
    Title: SeerReplaceBlockTask
    Author(s): Devil
    Date: 2016/11/04
    Desc: ReplaceBlockTask extension. 
    A Injector class.
    Injection Target: Mod.Seer.Injector.SeerReplaceBlockTask
    use the lib:
    -------------------------------------------------------
    NPL.load("(gl)script/apps/Aries/Creator/Game/Tasks/ReplaceBlockTask.lua");
    NPL.load("(gl)script/Seer/Injector/SeerReplaceBlockTask.lua");
    local ReplaceBlockTask = commonlib.gettable("MyCompany.Aries.Game.Tasks.ReplaceBlock");
    local SeerReplaceBlockTask = commonlib.gettable("Mod.Seer.Injector.SeerReplaceBlockTask");
    Inject(SeerReplaceBlockTask, ReplaceBlockTask);
    -------------------------------------------------------
]]
NPL.load("(gl)script/apps/Aries/Creator/Game/Tasks/ReplaceBlockTask.lua");
local UndoManager = commonlib.gettable("MyCompany.Aries.Game.UndoManager");
local GameLogic = commonlib.gettable("MyCompany.Aries.Game.GameLogic")
local BlockEngine = commonlib.gettable("MyCompany.Aries.Game.BlockEngine")
local TaskManager = commonlib.gettable("MyCompany.Aries.Game.TaskManager")
local block_types = commonlib.gettable("MyCompany.Aries.Game.block_types")
local SeerReplaceBlockTask = commonlib.gettable("Mod.Seer.Injector.SeerReplaceBlockTask");

function SeerReplaceBlockTask:ReplaceBlock(x, y, z)
	local from_id, from_data, from_entity_data = BlockEngine:GetBlockFull(x,y,z)
	if(not self.from_id) then
		if(from_id ~= self.to_id or (self.to_data or 0) ~= from_data) then
			BlockEngine:SetBlock(x,y,z, self.to_id, from_data, 3);
			if(GameLogic.GameMode:CanAddToHistory()) then
				self.history[#(self.history)+1] = {x,y,z, from_id, from_data, from_entity_data};
			end
		end
	elseif( from_id == self.from_id and from_data == self.from_data) then
		local idx = BlockEngine:GetSparseIndex(x,y,z);
		if(not self.replaced_map[idx]) then
			self.replaced_map[idx] = true;
			self.new_blocks[#(self.new_blocks)+1] = {x,y,z};
			BlockEngine:SetBlock(x,y,z, self.to_id, from_data, 3);
			if(GameLogic.GameMode:CanAddToHistory()) then
				self.history[#(self.history)+1] = {x,y,z, from_id, from_data, from_entity_data};
			end
		end
	end
end
