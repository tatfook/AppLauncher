local UrlFileTransfer = NPL.export();
local TaskExecutor = NPL.load("script/Seer/Utility/TaskExecutor.lua")
NPL.load("(gl)script/ide/Json.lua");
local Json = commonlib.Json;

local queues = {}

local function getQueue(name)
    queues[name] = queues[name] or TaskExecutor:new();
    return queues[name];
end

function UrlFileTransfer.download(url, path, callback,progress, queue)
    queue = queue or "downloadGeneral"
    local task = getQueue(queue)

    task:addTask(function (t)
        LOG.std(nil, "debug", "UrlFileTransfer", "download file %s from [%s] in {%s}",path, url, queue);
        NPL.AsyncDownload(url, path, string.format("__downloadTask(%q)", queue), "transferTask");
    end, {callback, path,progress})

    if not task:isRunning() then 
        task:execute(function() end);
    end
end

function UrlFileTransfer.upload(url, path, data, key, token, callback, queue)
    if not data and not ParaIO.DoesFileExist(path) then 
        LOG.std(nil, "error", "UrlFileTransfer.upload", "cannot find file %s",path);
        return;
    end
    
    queue = queue or "uploadGeneral"
    local task = getQueue(queue)

    task:addTask(function (t)
        LOG.std(nil, "debug", "UrlFileTransfer", "upload file %q to [%s] in {%s}",path, url, queue);
       
        if not data then 
            local file = ParaIO.open(path , "r");
            data = file:ReadBytes(file:GetFileSize(), nil);
            file:close();
        end
        
        NPL.AppendURLRequest(
            url, 
            string.format("__uploadTask(%q)", queue),
            {
                key = key,
                token = token,
                file = 
                {
                    file = path:match(".*[/\\]+(.+)$") or path,
                    data = data,
                    type = "application/octet-stream",
                }
            },
            "r");

    end, {callback, path})

    if not task:isRunning() then 
        task:execute(function() end);
    end
end

function UrlFileTransfer.terminateQueue(queue)
    local task = getQueue(queue);
    task:clear();
end



function __downloadTask(queue)
    local task = getQueue(queue);
    local t = task:current();
    if t then 
        local cb = t.userdata[1];
        local path = t.userdata[2];
        local prog = t.userdata[3];
        if prog then 
            echo("error..", prog)
            prog(path, msg.PercentDone , msg.totalFileSize);
        end
        if msg.DownloadState == "complete"  then
            if cb then 
                cb(path);
            end

            t:done();
        elseif msg.DownloadState == "terminated" then
            if cb then 
                cb(path, "error")
            end
            t:done();
            LOG.std(nil, "error", "UrlFileTransfer", "failed to download file %s",path);
            echotable(msg);
        end
    end
end

function __uploadTask(queue)
    local task = getQueue(queue);
    local t = task:current();
    if t then 
        local cb = t.userdata[1];
        local path = t.userdata[2];

        if msg.code == 0 then
            if cb then 
                cb( path );
            end
            t:done();
        else
            if cb then 
                cb( path, msg);
            end
            t:done();
            LOG.std(nil, "error", "UrlFileTransfer", "failed to upload file %s",path);
            echotable(msg);
        end
        
    end
end