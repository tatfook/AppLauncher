--[[
NPL.load("(gl)script/Seer/EscFrameManager.lua");
local EscFrameManager = commonlib.gettable("Mod.Seer.EscFrameManager");
--]]

NPL.load("(gl)script/Seer/Game/ModuleManager.lua");
local ModuleManager = commonlib.gettable("Mod.Seer.Game.ModuleManager");
NPL.load("(gl)script/Seer/SavingWorldPage.lua");
local SavingWorldPage = commonlib.gettable("Mod.Seer.UI.SavingWorldPage");
local planetMgr = commonlib.gettable("Mod.Seer.Game.World.PlanetManager");
local GameLogic = commonlib.gettable("MyCompany.Aries.Game.GameLogic");
local UserDatabase = commonlib.gettable("Mod.Seer.Utility.UserDatabase");

local EscFrameManager = commonlib.gettable("Mod.Seer.EscFrameManager");
local UIManager = commonlib.gettable("Mod.Seer.Game.UI.UIManager");


function EscFrameManager.LeavePlanet(saving, target)
	target = target or {"BigWorldPlay"}
	local function DoLeavePlaner(saving)
		local planet = planetMgr.getCurrentPlanet();
		if (planet and planet:isUploading()) then
			_guihelper.MessageBox("正在上传，无法保存，一会儿再试")
			return;
		end
	    if not saving  then
			ModuleManager.startModule(target[1], target[2]);
	        return;
	    end
		local function OnSavingWorldPage()
	    	local uiMain = UIManager.getUI("UIMain")
			GameLogic.QuickSave(
				function (err)
					if (not err) then
						ModuleManager.startModule(target[1], target[2]);
					else
						_guihelper.MessageBox("网络异常,上传失败！", 
							function(res) 
								if(res and res == _guihelper.DialogResult.OK) then 
									ModuleManager.startModule(target[1], target[2]);
								end
							end, _guihelper.MessageBoxButtons.OK);
					end
				end
			)
			UIManager.createUI("SavingWorldPage",uiMain);
	    end
		local isAutoSave= EscFrameManager.CheckIsAutoSave();
		if not isAutoSave then
			_guihelper.MessageBox("你未开启自动保存，退出游戏前是否进行保存?", function(res)
				if(res and res == _guihelper.DialogResult.Yes) then
					_guihelper.CloseMessageBox(true); -- fast close without animation
					OnSavingWorldPage()
				else
					ModuleManager.startModule(target[1], target[2]);
				end
			end, _guihelper.MessageBoxButtons.YesNo);
		else
			OnSavingWorldPage()
		end
	end


    _guihelper.MessageBox(L"是否真的要退出该星球？", function(res)
        if(res and res == _guihelper.DialogResult.Yes) then
        	DoLeavePlaner(saving)
        end
    end, _guihelper.MessageBoxButtons.YesNo);

end
function EscFrameManager.OnSaveWorld()
    AudioEngine.PlayUISound("btn_show");
    GameLogic.QuickSave();
	ModuleManager.handleEvent("ResetTimer")
end
function EscFrameManager.CheckIsAutoSave()
	return UserDatabase.getAttribute("AutoSave",true);
end

function EscFrameManager.OnExitGame()
    _guihelper.MessageBox(L"是否真的要退出本游戏？", function(res)
        if(res and res == _guihelper.DialogResult.Yes) then
            local Desktop = commonlib.gettable("MyCompany.Aries.Creator.Game.Desktop");
            Desktop.ForceExit();
        end
    end, _guihelper.MessageBoxButtons.YesNo);
end
