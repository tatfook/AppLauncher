--[[
    Title: SeerEntityPlayer
    Author(s): Cellfy
    Date: 2016/04/10
    Desc: EntityPlayer extension. 
    A Injector class.
    Injection Target: MyCompany.Aries.Game.EntityManager.EntityPlayer
    use the lib:
    -------------------------------------------------------
    NPL.load("(gl)script/apps/Aries/Creator/Game/Entity/EntityPlayer.lua");
    NPL.load("(gl)script/Seer/Injector/SeerEntityPlayer.lua");
    local EntityPlayer = commonlib.gettable("MyCompany.Aries.Game.EntityManager.EntityPlayer")
    local SeerEntityPlayer = commonlib.gettable("Mod.Seer.Injector.SeerEntityPlayer");
    Inject(SeerEntityPlayer, EntityPlayer);
    -------------------------------------------------------
]]

--EntityPlayer.dataWatcher field convension:
--1: AnimID
--2: SkinID
--3: CharacterAssetID (Add by Mod-Seer, Cellfy)

NPL.load("(gl)script/Seer/Utility/StringTools.lua");
NPL.load("(gl)script/Seer/Game/MultiPlayer/GamingRoomInfo.lua");
NPL.load("(gl)script/Seer/Utility/GlobalMessageDispatcher.lua");
local GlobalMessageDispatcher=commonlib.gettable("Mod.Seer.Utility.GlobalMessageDispatcher");

local StringTools = commonlib.gettable("Mod.Seer.Utility.StringTools");
local GamingRoomInfo = commonlib.gettable("Mod.Seer.Game.MultiPlayer.GamingRoomInfo");

local SeerEntityPlayer = commonlib.gettable("Mod.Seer.Injector.SeerEntityPlayer");

function SeerEntityPlayer:ctor()
  self:Original_ctor();
  GlobalMessageDispatcher.getMessageSource():notify(GlobalMessageDispatcher.getMessage_EntityPlayerConstruction(),self);
end

function SeerEntityPlayer:SetCharacterAsset(asset_id, bBroadCast)
    asset_id = tonumber(asset_id);
    if asset_id then
        local ItemReader = commonlib.gettable("Mod.Seer.Config.ItemReader");
        local assetInfo = ItemReader.GetAssetInfoByID(asset_id);
        if assetInfo then
            self:SetMainAssetPath(assetInfo.model);
            self.AssetID = asset_id;
            if StringTools.Valid(assetInfo.texture) then
                self:SetSkin(assetInfo.texture, bBroadCast);  --ignore skin_id if broadcast, it goes through asset management pipeline
            else
                self:SetSkin(nil, bBroadCast);
            end
            --GamingRoomInfo update
            if bBroadCast then
                if GamingRoomInfo.IsPlayerInfoMapValid() then
                    --i'm the host player, i should update the skin map
                    GamingRoomInfo.PlayerInfoMapUpdateAssetID(self.username, asset_id);
                end
                local dataWatcher = self:GetDataWatcher();
                if not self.dataFieldAssetID then
                    self.dataFieldAssetID = dataWatcher:AddField(nil, nil);
                end
                dataWatcher:SetField(self.dataFieldAssetID, asset_id);
            end
        end
    end
end

function SeerEntityPlayer:GetAssetID()
    local dataWatcher = self:GetDataWatcher();
    if not self.dataFieldAssetID then
        self.dataFieldAssetID = dataWatcher:AddField(nil, nil);
    end
    return dataWatcher:GetField(self.dataFieldAssetID, nil);
end