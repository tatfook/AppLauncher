--[[
    Title: SensitiveWordManager
    Author(s): Devil, Issac
    Date: 2016/05/27
    Desc: Seer Sensitive Word Manager
    use the lib:
    ------------------------------------------------------------
    NPL.load("(gl)script/Seer/Utility/SensitiveWordManager.lua");
    local SensitiveWordManager = commonlib.gettable("Mod.Seer.Utility.SensitiveWordManager");
    -------------------------------------------------------
]]
local function _isEnglishChar(word)
  return string.len(word)==1 and string.byte(word,1)<=string.byte("z",1) and string.byte(word,1)>=string.byte("A",1);
end
local function _isMatch(word1,word2)
  if _isEnglishChar(word1) and _isEnglishChar(word2) then
    return string.lower(word1)==string.lower(word2);
  else
    return word1==word2;
  end
end
----------------------------------------------------String word---------------------------------------
local function _getString_StringWord(stringWord)
  local ret=string.sub(stringWord.mText,stringWord.mStart,stringWord.mEnd);
  return ret;
end

local function _createStringWord(text,charStart,charEnd)
  local ret={mText=text,mStart=charStart,mEnd=charEnd};
  return ret;
end

local function _getStringWordList(text)
	local ret={};
    local char_index=1;
    while char_index<=#text do
      local current_bytes=string.byte(text,char_index);
      local byte_count=1;
      if current_bytes>0 and current_bytes<=127 then
        byte_count = 1;
      elseif current_bytes>=192 and current_bytes< 223 then
        byte_count = 2;
      elseif current_bytes>=224 and current_bytes< 239 then
        byte_count = 3;
      elseif current_bytes>=240 and current_bytes<=247 then
        byte_count = 4;
      end
      ret[#ret+1]=_createStringWord(text,char_index,char_index+byte_count-1);
      char_index=char_index+byte_count;
      --echo("devilwalk-------------------------_getStringWordList:StringWord:");
      --echo(ret[#ret]);
    end
	return ret;
end

------------------------------------------------------------------------------------------------------

local SensitiveWordManager = commonlib.gettable("Mod.Seer.Utility.SensitiveWordManager");
local lWordGroup_list=nil;
local function _loadWordGroupList()
  if lWordGroup_list then
    return;
  end
  lWordGroup_list={};
  local file=ParaIO.open("config/SensitiveWord.txt","r");
  if file then
    local text=file:readline();
    while text do
      local word_group=_getStringWordList(text);
      lWordGroup_list[#lWordGroup_list+1]=word_group;
      text=file:readline();
    end
    ParaIO.CloseFile();
  else
    LOG.std(nil, "error", "SensitiveWordManager", "Can not load the file");
  end
end

local function _getWordGroups(word)
  --echo("devilwalk-------------------------_getWordGroups:word:"..word);
  local word_groups={};
  for word_group_index=1,#lWordGroup_list do
    local word_group=lWordGroup_list[word_group_index];
    --首字匹配
    local first_word_1=_getString_StringWord(word_group[1]);
    local first_word_2=word;
    if _isMatch(first_word_1,first_word_2) then
      word_groups[#word_groups+1]=word_group;
      --echo("devilwalk-------------------------_getWordGroups:word_group:");
      --echo(word_group);
    end
  end
  return word_groups;
end

local function _testWordGroup(wordGroup,stringWordList,stringWordListStart)
  --echo("devilwalk--------------------------_testWordGroup:wordGroup:");
  --echo(wordGroup);
  --echo("devilwalk--------------------------_testWordGroup:#wordGroup:"..tostring(#wordGroup));
  --echo("devilwalk--------------------------_testWordGroup:#stringWordList-stringWordListStart+1:"..tostring(#stringWordList-stringWordListStart+1));
  if #wordGroup<=#stringWordList-stringWordListStart+1 then
    for word_index=1,#wordGroup do
      local word_1=_getString_StringWord(wordGroup[word_index]);
      local word_2=_getString_StringWord(stringWordList[stringWordListStart+word_index-1]);
      --echo("devilwalk--------------------------_testWordGroup:wordGroup");
      --echo(wordGroup);
      if not _isMatch(word_1,word_2) then
        --echo("devilwalk--------------------------_testWordGroup:Word1:"..word_1);
        --echo("devilwalk--------------------------_testWordGroup:Word2:"..word_2);
        return false;
      end
      --echo("devilwalk--------------------------_testWordGroup:Word:"..word_1);
    end
    return true;
  end
  return false;
end

local function _check(text)
  local ret={};
  local string_word_list=_getStringWordList(text);
  for string_word_index=1,#string_word_list do
    local string_word=string_word_list[string_word_index];
    local word_groups=_getWordGroups(_getString_StringWord(string_word));
    for word_group_index=1,#word_groups do
      local word_group=word_groups[word_group_index];
      if _testWordGroup(word_group,string_word_list,string_word_index) then
        ret[#ret+1]={string_word.mStart,string_word.mStart+string.len(word_group[1].mText)-1};
        string_word_index=string_word_index+#word_group-1;
        --echo("devilwalk--------------------------------------SensitiveWordManager._check:");
        --echo(ret[#ret]);
        break;
      end
    end
  end
  return ret;
end

function SensitiveWordManager.process(text)
  local ret=text;
  _loadWordGroupList();
  local sensitive_word_index_list=_check(text);
  for i=1,#sensitive_word_index_list do
    local word_index=sensitive_word_index_list[i];
    local star_add="";
    for j=1,word_index[2]-word_index[1]+1 do
      star_add=star_add.."*";
    end
    ret=string.sub(ret,1,word_index[1]-1)..star_add..string.sub(ret,word_index[2]+1);
  end
  --[[for word_group_index=1,#lWordGroup_list do
    while true do
      local word_group=lWordGroup_list[word_group_index];
      local temp=string.gsub(ret,word_group,"***");
      if temp==ret then
        break;
      else
        ret=temp;
      end
    end
  end]]
  --echo("devilwalk--------------------------------------SensitiveWordManager.process:"..ret);
  return ret;
end