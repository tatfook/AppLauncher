--[[
    Title: shell_loop_build_pkg
    Author(s): Cellfy
    Date: 2016/05/08
    Desc: standalone seer pkg builder script
    use the lib:
    -------------------------------------------------------
    In shell script:
    ./ParaEngineServer 'bootstrapper="script/Seer/installer/shell_loop_build_pkg.lua"'
    -------------------------------------------------------
]]
NPL.load("(gl)script/ide/commonlib.lua"); 

local function activate()
    print("Making PKGs ...");
    
    NPL.load("(gl)script/Seer/installer/BuildSeerPKG.lua");
    local BuildSeerPKG = commonlib.gettable("Mod.Seer.Installer.BuildSeerPKG");
    local target_id = ParaEngine.GetAppCommandLineByParam("build_target", nil);
    if type(target_id)=="string" and string.len(target_id)>0 then
        print("build target :");
        print(target_id);
    else
        print("target id not specified, please check again");
    end
    
    BuildSeerPKG.Init();
    if target_id == "all" then
        BuildSeerPKG.Compile();
        BuildSeerPKG.BuildAll();
    elseif target_id == "pc_all" then
        BuildSeerPKG.Compile();
        BuildSeerPKG.BuildPCAll();
    elseif target_id == "mobile_all" then
        BuildSeerPKG.Compile();
        BuildSeerPKG.BuildMobileAll();
    elseif target_id == "logic" then
        BuildSeerPKG.Compile();
        BuildSeerPKG.BuildPackageGroup("group_logic");
    elseif target_id == "settings" then
        BuildSeerPKG.RebuildSettings();
    elseif target_id == "re_settings" then
        BuildSeerPKG.RebuildSettings();
    elseif target_id == "basic" then
        BuildSeerPKG.BuildPackageGroup("group_basic");
    elseif target_id == "icons" then
        BuildSeerPKG.BuildPackageGroup("group_icons");
    elseif target_id == "models" then
        BuildSeerPKG.BuildPackageGroup("group_models");
    elseif target_id == "skyboxes" then
        BuildSeerPKG.BuildPackageGroup("group_skyboxes");
    elseif target_id == "textures" then
        BuildSeerPKG.BuildPackageGroup("group_textures");
    end
    
    ParaGlobal.ExitApp();
    
    print("Making PKGs Finished");
end

NPL.this(activate);
