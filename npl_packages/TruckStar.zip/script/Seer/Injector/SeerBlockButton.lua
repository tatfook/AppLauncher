--[[
    Title: SeerBlockButton
    Author(s): Devil
    Date: 2016/9/7
    Desc: BlockButton extension. 
    A Injector class.
    Injection Target: Mod.Seer.Injector.SeerBlockButton
    use the lib:
    -------------------------------------------------------
    NPL.load("(gl)script/apps/Aries/Creator/Game/blocks/BlockButton.lua");
    NPL.load("(gl)script/Seer/Injector/SeerBlockButton.lua");
    local BlockButton = commonlib.gettable("MyCompany.Aries.Game.blocks.BlockButton");
    local SeerBlockButton = commonlib.gettable("Mod.Seer.Injector.SeerBlockButton");
    Inject(SeerBlockButton, BlockButton);
    -------------------------------------------------------
]]
NPL.load("(gl)script/apps/Aries/Creator/Game/blocks/BlockButton.lua");
local ItemClient = commonlib.gettable("MyCompany.Aries.Game.Items.ItemClient");
local BlockEngine = commonlib.gettable("MyCompany.Aries.Game.BlockEngine")
local TaskManager = commonlib.gettable("MyCompany.Aries.Game.TaskManager")
local block_types = commonlib.gettable("MyCompany.Aries.Game.block_types")
local GameLogic = commonlib.gettable("MyCompany.Aries.Game.GameLogic")
local EntityManager = commonlib.gettable("MyCompany.Aries.Game.EntityManager");
local BlockButton = commonlib.gettable("MyCompany.Aries.Game.blocks.BlockButton");
local SeerBlockButton = commonlib.gettable("Mod.Seer.Injector.SeerBlockButton");
-- goto pressed state and then schedule tickUpdate to go off again after some ticks
function SeerBlockButton:OnActivated(x, y, z, entity)
	local data = ParaTerrain.GetBlockUserDataByIdx(x, y, z);
	if(data >=8) then
		return true;
	else
		if(entity) then
			EntityManager.SetLastTriggerEntity(entity,x,y,z);
		end
		BlockEngine:SetBlockData(x,y,z, data+8);
		self:NotifyNeighborBlocksByDir(x, y, z, data);
		GameLogic.GetSim():ScheduleBlockUpdate(x, y, z, self.id, self:tickRate());

		-- do neuron activation
		BlockButton._super.OnActivated(self, x, y, z);
		return true;
	end
end
