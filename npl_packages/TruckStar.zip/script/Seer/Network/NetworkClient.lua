﻿--[[
NPL.load("(gl)script/Seer/Network/NetworkClient.lua");
local NetworkClient = commonlib.gettable("Mod.Seer.Network.NetworkClient");
]]

local NetworkClient = commonlib.gettable("Mod.Seer.Network.NetworkClient");

NPL.load("(gl)script/Seer/Network/Packets/PacketPb.lua");
NPL.load("(gl)script/Seer/Config/Config.lua");
local Config = commonlib.gettable("Mod.Seer.Config");

local PacketPb = commonlib.gettable("Mod.Seer.Network.Packets.PacketPb");
local PacketPbHelper = commonlib.gettable("Mod.Seer.Network.Packets.PacketPbHelper");

--connection
local cons = {}

NPL.load("(gl)script/Seer/Network/Connection.lua");
local Connection = commonlib.gettable("Mod.Seer.Network.Connection");


--receive handler
local NetHandler = commonlib.inherit(nil, commonlib.gettable("Mod.Seer.Network.NetHandler"));

local isStarted = false;
function NetworkClient.start(ip, port)
	echo({ip,port})
	isStarted = true;
	if not (ip and port) then
		local client = Config.NetworkConfigReader.CurrentListen();
		ip = client.ip;
		port = client.port;
	end
	-- setting to 0.0.0.0 is allow to listen all local ips
	-- it will not listen any ports if port is "0"(just be a client)
	NPL.StartNetServer(ip, port)
	-- set receiving entry ( entry: activate() )
	NPL.AddPublicFile("script/Seer/Network/NetworkClient.lua", 201);
end

function NetworkClient.stop()
	isStarted = false;
	NPL.StopNetServer();
end

function NetworkClient.connect(ip, port, errCallback)
	if (not isStarted) then
		NetworkClient.start()
	end

	local nid = string.format("%s%s", ip, port);
	if cons[nid] then 
		return nid;
	end

	local params = {host = tostring(ip), port = tostring(port), nid = nid};
	NPL.AddNPLRuntimeAddress(params);
	local handler = NetHandler:new()

	cons[nid] = Connection:new():init(nid, handler);
	handler.errCallback = errCallback;
	--cons[nid]:connect()
	return nid;
end

--@param reason: reason for shutting down the connection: 10001: abandon on general purpose
--                                                        10002: not used yet
function NetworkClient.isReasonKnown(reason)
	return (reason>10000 and reason<10002);
end

--@param reason: same with NetworkClient.isReasonKnown
function NetworkClient.disconnect(nid, reason)
	local con = cons[nid];
	
	if (con and con:isConnected()) then
		con:disconnect(reason);
	end
	cons[nid] = nil
end

function NetworkClient.send(nid, packet)
	local con = cons[nid];
	-- if (not con or not con:isConnected()) then
	-- 	commonlib.log("error: connection "..nid.." is not existed or closed when sending\n")
	-- 	return false;
	-- end
	local msg = packet:WritePacket();
	msg.id = packet.id;
	return con:send(msg)
end


function NetHandler:handleMsg(msg)
	local pb = PacketPb:new();
	pb:unserialize(msg);

	PacketPbHelper.process(pb.headerRaw, pb.bodyRaw);

end

function NetHandler:handleErrorMessage(err,nid)
	local reason = err:match("OnConnectionLost with reason = (%d+)");
	if not reason then
		commonlib.log("error: "..err.."\n")
		reason = -1;
	end
	if self.errCallback then
		self.errCallback(tonumber(reason));
	end

	NetworkClient.disconnect(nid)
end

-- incoming msg entry
local function activate()
	local msg = msg;
	local id = msg.nid or msg.tid;
	if(id) then
		local connection = cons[id];
		if(connection) then
			connection:onReceive(msg);
		-- elseif(msg.tid) then
		-- 	Connection:new():init(msg.tid, NetHandler:new(), 
		-- 										"script/Seer/Network/NetworkClient.lua");
		end
	end
end
NPL.this(activate);
