--[[
    Title: SeerServerManager
    Author(s): Devil
    Date: 2016/05/19
    Desc: ServerManager extension. 
    A Injector class.
    Injection Target: MyCompany.Aries.Game.Network.ServerManager
    use the lib:
    -------------------------------------------------------
    NPL.load("(gl)script/apps/Aries/Creator/Game/Network/ServerManager.lua");
    NPL.load("(gl)script/Seer/Injector/SeerServerManager.lua");
    local ServerManager = commonlib.gettable("MyCompany.Aries.Game.Network.ServerManager");
    local SeerServerManager = commonlib.gettable("Mod.Seer.Injector.SeerServerManager");
    Inject(SeerServerManager, ServerManager);
    -------------------------------------------------------
]]
NPL.load("(gl)script/apps/Aries/Creator/Game/Network/ServerManager.lua");
NPL.load("(gl)script/Seer/Utility/ChatCoder.lua");
local ChatCoder=commonlib.gettable("Seer.Utility.ChatCoder");
local WorldCommon = commonlib.gettable("MyCompany.Aries.Creator.WorldCommon")
local ChatMessage = commonlib.gettable("MyCompany.Aries.Game.Network.ChatMessage");
local GameMode = commonlib.gettable("MyCompany.Aries.Game.GameLogic.GameMode");
local WorldServer = commonlib.gettable("MyCompany.Aries.Game.Network.WorldServer");
local Packets = commonlib.gettable("MyCompany.Aries.Game.Network.Packets");
local NetServerHandler = commonlib.gettable("MyCompany.Aries.Game.Network.NetServerHandler");
local BanList = commonlib.gettable("MyCompany.Aries.Game.Network.BanList");
local ServerListener = commonlib.gettable("MyCompany.Aries.Game.Network.ServerListener");
local BlockEngine = commonlib.gettable("MyCompany.Aries.Game.BlockEngine")
local block_types = commonlib.gettable("MyCompany.Aries.Game.block_types")
local GameLogic = commonlib.gettable("MyCompany.Aries.Game.GameLogic")
local EntityManager = commonlib.gettable("MyCompany.Aries.Game.EntityManager");
local Desktop = commonlib.gettable("MyCompany.Aries.Creator.Game.Desktop");
local SeerServerManager = commonlib.gettable("Mod.Seer.Injector.SeerServerManager");
-- initialize connection and handler for the given player. 
function SeerServerManager:InitializeConnectionToPlayer(playerConnection, entityMP)
	
	-- TODO: send messages to client for login.
	local worldserver = self:GetWorldServerForDimension(entityMP.dimension);

	local player_data = self:ReadPlayerDataFromFile(entityMP);
	entityMP:SetWorld(worldserver);
	local ip_address = playerConnection:GetIPAddress();
       
	LOG.std(nil, "info", "SeerServerManager", "%s [%s] logged in with entity id %d at (%d, %d, %d)", entityMP:GetUserName(), ip_address, entityMP.entityId, entityMP.x, entityMP.y, entityMP.z);
	
	local born_x, born_y, born_z = worldserver:GetSpawnPoint();
	local net_handler = NetServerHandler:new():Init(playerConnection, entityMP, self);
       
	net_handler:SendPacketToPlayer(Packets.PacketLogin:new():Init(entityMP.entityId, worldserver:GetWorldInfo():GetTerrainType(), self:GetMaxPlayers()));
	net_handler:SendPacketToPlayer(Packets.PacketSpawnPosition:new():Init(born_x, born_y, born_z));
	self:SendChatMsg(ChatMessage:new():Init(ChatCoder.encode2(string.format("玩家\"%s\"加入房间",entityMP:GetDisplayName()),"系统")));
  Desktop.GetChatGUI():PrintChatMessage(ChatMessage:new():Init(ChatCoder.encode2(string.format("玩家\"%s\"加入房间",entityMP:GetDisplayName()),"系统")));
	self:PlayerLoggedIn(entityMP);
	net_handler:SetPlayerLocation(entityMP.x, entityMP.y, entityMP.z, entityMP.facing, entityMP.rotationPitch);
	net_handler:SendPacketToPlayer(Packets.PacketUpdateTime:new():Init(worldserver:GetTotalWorldTime(), worldserver:GetWorldTime()));
       
	if (worldserver:GetWorldInfo():GetTexturePack() ~= "") then
		entityMP:RequestTexturePackLoad(worldserver:GetWorldInfo():GetTexturePack());
	end
       
	if (player_data and player_data.attr and player_data.attr.isRiding) then
		-- TODO: create and mount on the entity. 
	end
end