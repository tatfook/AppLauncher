NPL.load("(gl)script/Seer/UIPage.lua");

NPL.load("(gl)script/Seer/Network/bit.lua");
NPL.load("(gl)script/Seer/Settings.lua");
local Settings = commonlib.gettable("Mod.Seer.Settings");
local bit= commonlib.gettable("YcAPI.bit");

-- local RoomAccessPage = commonlib.gettable("Mod.Seer.RoomAccessPage")
NPL.load("(gl)script/Seer/Game/MultiPlayer/RoomPermission.lua");
local RoomPermission = commonlib.gettable("Mod.Seer.Game.MultiPlayer.RoomPermission");

NPL.load("(gl)script/Seer/Utility/CommonUtility.lua");
local CommonUtility = commonlib.gettable("Mod.Seer.Utility.CommonUtility");

NPL.load("(gl)script/Seer/Utility/StringTools.lua");
local StringTools = commonlib.gettable("Mod.Seer.Utility.StringTools");

local UserDatabase = commonlib.gettable("Mod.Seer.Utility.UserDatabase");

local page;

local minMem = 2
local maxMem = 16

local UIManager = commonlib.gettable("Mod.Seer.Game.UI.UIManager");
local UIBase = commonlib.gettable("Mod.Seer.Game.UI.UIBase");
local RoomAccessPage = commonlib.inherit(UIBase,commonlib.gettable("Mod.Seer.RoomAccessPage"));

if CommonUtility:IsMobilePlatform() then
	UIManager.registerUI("RoomAccessPage", RoomAccessPage,"script/Seer/RoomAccessPage.html",
	{
	});
else
	UIManager.registerUI("RoomAccessPage", RoomAccessPage,"script/Seer/RoomAccessPage.PC.html",
	{
	});
end

local lroomAccessList = {}
local lstates = nil
RoomAccessPage.craftid = 0;
function RoomAccessPage:onCreate(info)
	page = self.page
	self.craftid = info.id
	self.callback = info.callback

	lroomAccessList.maxOnlineNum = 4;
	lroomAccessList.roomPwd = "";
	lroomAccessList.states = nil;

	local accessTable = UserDatabase.getAttribute("Room.".. self.craftid)
	if accessTable and next(accessTable) then
		commonlib.partialcopy(lroomAccessList, accessTable);
	end
	if lroomAccessList.states and lroomAccessList.states.state then
		lroomAccessList.states.state = nil
	end
	if lroomAccessList.states then
		lstates = RoomPermission:new():init(lroomAccessList.states)
	else
		lstates = RoomPermission:new()

		--默认权限添加，参数在RoomPermission.xml表
		--eg,添加编辑权限
		-- lstates:add("edit")
		--eg,删除编辑权限
		-- lstates:remove("edit")
		 -- lstates:remove("NoWaterBlock")
		 -- lstates:remove("NoGreenWaterBlock")
		 -- lstates:remove("NoLavaBlock")
		 -- lstates:remove("NoTeleportBlock")
		 -- lstates:remove("NoBombBlock")
	end
	self:refresh(0)
	if self.craftid then
		local file_path=Settings.GetLocalPlanetFolder(self.craftid).."billboard.txt";
		local file_handle=ParaIO.open(file_path,"r");
		if file_handle then
			text=file_handle:GetText(0,-1);
			file_handle:close();
			if self.page:GetNode("billboard_text") then
				self.page:GetNode("billboard_text"):GetControl():SetText(text);
			end
		else
    		ParaIO.CreateDirectory(Settings.GetLocalPlanetFolder(self.craftid));
		end
	end
	if CommonUtility:IsMobilePlatform() then
		page:SetValue("online_slider", (lroomAccessList.maxOnlineNum - minMem) * 562 / (maxMem - minMem));
	else
		page:SetValue("online_slider", (lroomAccessList.maxOnlineNum - minMem) * 115 / (maxMem - minMem));
	end
	self:RefreshSlider()

	-- NPL.load("(gl)script/Seer/Game/Guide/GuideMask.lua");
	-- local GuideMask = commonlib.gettable("Mod.Seer.Game.Guide.GuideMask");
	-- GuideMask.guide("EnterPlanet")
end

function RoomAccessPage:OnChangeSilder()
    local value = page:GetValue("online_slider");
    if CommonUtility:IsMobilePlatform() then
		lroomAccessList.maxOnlineNum = math.floor(minMem + (maxMem - minMem) * value/562);
	else
		lroomAccessList.maxOnlineNum = math.floor(minMem + (maxMem - minMem) * value/115);
	end
	self:RefreshSlider()
end
function RoomAccessPage:RefreshSlider()
	local value = page:GetValue("online_slider");
	local mask = page:FindUIControl("slider_mask");
	local maskLeft =  value;
	if CommonUtility:IsMobilePlatform() then
		-- page:SetValue("online_slider", (lroomAccessList.maxOnlineNum - minMem) * 562 / (maxMem - minMem));
		mask.x = maskLeft+50;
		mask.width = 562 - maskLeft;
		page:SetValue("online_num", lroomAccessList.maxOnlineNum);
	else
		mask.width = value;
		page:SetValue("online_num", lroomAccessList.maxOnlineNum);
	end
end
function RoomAccessPage:GetRoompwd()
	return lroomAccessList.roomPwd
end
function RoomAccessPage:OnChangePwd()
	lroomAccessList.roomPwd = page:GetValue("room_pwd");
end
function RoomAccessPage:OnEditAccess()
	local callback = function (list)
		lstates = RoomPermission:new():init(list.states)
		lroomAccessList = list
	end
	lroomAccessList.states = lstates:getData()
	UIManager.createUI("RoomBlockAccessPage",self,nil,{accessInfo = lroomAccessList,callback=callback});
end
function RoomAccessPage:OnCancel()
	self:close()
end
function RoomAccessPage:OnConfirm()
	lroomAccessList.states = lstates:getData()
	UserDatabase.setAttribute("Room.".. self.craftid, 
		{maxOnlineNum = lroomAccessList.maxOnlineNum,
		 states = lstates:getData()},"pack")

	local text=self.page:GetValue("billboard_text","");
	if CommonUtility.getChineseCharacterCount(text)+CommonUtility.getNotChineseCharacterCount(text) > 70 then
		_guihelper.MessageBox("公告字数超过限制!");
		return;
	end
	if StringTools.Valid(text) then
		local file_path=Settings.GetLocalPlanetFolder(self.craftid).."billboard.txt";
		local file_handle=ParaIO.open(file_path,"w");
		if file_handle then
			file_handle:WriteString(text);
			file_handle:close();
		end
	end
	--添加统计项
	Statistics.SendKey("OnlineRoomOption.CreateRoom")
	if lstates:has("edit") then
		Statistics.SendKey("OnlineRoomOption.AllowEditing")
	if lstates:has("useTools") then
		Statistics.SendKeyValue("OnlineRoomOption.Tools","Anyone")
	elseif lstates:has("useToolsFriends",true) then
		Statistics.SendKeyValue("OnlineRoomOption.Tools","Friends")
	else
		Statistics.SendKeyValue("OnlineRoomOption.Tools","Self")
	end
	end
	if lstates:has("teleport") then
		Statistics.SendKey("OnlineRoomOption.FlyingForbidden")
	end
	Statistics.SendKeyValue("OnlineRoomOption.RoomMaxMem",lroomAccessList.maxOnlineNum)
	if self.callback then
		self.callback({maxOnlineNum = lroomAccessList.maxOnlineNum,roomPwd = lroomAccessList.roomPwd,states = lroomAccessList.states ,billboard=text})
	end
	self:close()
end


function RoomAccessPage:CheckOpenFly()
	if lstates and lstates:has("toggleFly") then
		return true
	end
	return false
end
function RoomAccessPage:OnOpenFly()
	if self:CheckOpenFly() then
		lstates:remove("toggleFly")
	else
		lstates:add("toggleFly")
	end
end
function RoomAccessPage:CheckOpenTeleport()
	if lstates and lstates:has("teleport") then
		return true
	end
	return false
end
function RoomAccessPage:OnOpenTeleport()
	if self:CheckOpenTeleport() then
		lstates:remove("teleport")
	else
		lstates:add("teleport")
	end
end
function RoomAccessPage:CheckOpenEdit()
	if lstates and lstates:has("edit") then
		return true
	end
	return false
end
function RoomAccessPage:OnOpenEdit()
	if self:CheckOpenEdit() then
		lstates:remove("edit")
		-- self:OnCloseBlock()
	else
		lstates:add("edit")
	end
end
function RoomAccessPage:OnCloseBlock()
    self.page:SetUIValue("tools", false);
	lstates:remove("useTools")
end
function RoomAccessPage:CheckOpenTools()
	if lstates and lstates:has("useTools") then
		return true
	end
	return false
end
function RoomAccessPage:OnOpenTools()
	-- if not self:CheckOpenEdit() then
	-- 	_guihelper.MessageBox("需要先开启建造权限!")
 --        self.page:SetUIValue("tools", false);
	-- 	return
	-- end
	if self:CheckOpenTools() then
		lstates:remove("useTools")
		lstates:remove("useToolsFriends")
	else
		lstates:add("useTools")
		lstates:remove("useToolsFriends")
	end
end
