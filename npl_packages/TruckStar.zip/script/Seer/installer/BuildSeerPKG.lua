--[[
    Title: BuildSeerPKG
    Author(s): Cellfy
    Date: 2016/05/08
    Desc: standalone seer pkg builder script
    use the lib:
    -------------------------------------------------------
    NPL.load("(gl)script/Seer/installer/BuildSeerPKG.lua");
    local BuildSeerPKG = commonlib.gettable("Mod.Seer.Installer.BuildSeerPKG");
    BuildSeerPkg.Init();
    BuildSeerPKG.BuildAll();
    -------------------------------------------------------
]]

--NPL.load("(gl)script/Seer/Headers.lua");

NPL.load("(gl)script/installer/BuildParaWorld.lua");
-- 
local BuildParaWorld = commonlib.gettable("commonlib.BuildParaWorld");
local BuildSeerPKG = commonlib.gettable("Mod.Seer.Installer.BuildSeerPKG");

local package_list = {
    ["group_logic"] = {
        "seer_scripts_all",
    },
    ["group_settings"] = {
        "seer_settings",
    },
    ["group_basic"] = {
        "seer_basic",
        "seer_configs",
        "seer_audios",
    },
    ["group_icons"] = {
        "seer_icons_blocks",
        "seer_icons_emojis_standard",
        "seer_icons_heads",
        "seer_icons_planets",
        "seer_icons_shop_categories",
        "seer_icons_shop_items",
        "seer_icons_skills",
        "seer_icons_skyboxes",
    },
    ["group_models"] = {
        "seer_models_blocks",
        "seer_models_characters",
        "seer_models_entities",
        "seer_models_furnitures",
    },
    ["group_skyboxes"] = {
        "seer_skyboxes",
    },
    ["group_textures"] = {
        "seer_textures_blocks",
        "seer_textures_characters",
        "seer_textures_guides",
        "seer_textures_skins",
        "seer_textures_etc",
        "seer_textures_ui_01_basic",
        "seer_textures_ui_02_login",
        "seer_textures_ui_03_planet",
        "seer_textures_ui_04_friend",
        "seer_textures_ui_05_comment",
        "seer_textures_ui_06_shop",
        "seer_textures_ui_07_wiki",
        "seer_textures_ui_08_access",
        "seer_textures_ui_09_bag",
        "seer_textures_ui_10_selectbar",
        "seer_textures_ui_11_esc",
        "seer_textures_ui_12_guide",
        "seer_textures_ui_13_help",
        "seer_textures_ui_14_others",
        "seer_textures_ui_15_messagebox",
        "seer_textures_ui_16_minimap",
        "seer_textures_ui_17_ranklist",
        "seer_textures_ui_18_quickedit",
        "seer_textures_ui_19_multiplayer",
        "seer_textures_ui_20_serverhall",
        "seer_textures_ui_21_visit",
        "seer_textures_ui_22_welcome",
        "seer_textures_ui_23_offline",
        "seer_textures_ui_24_mail",
    },
    ["group_pc"] = {
        "seer_pc_configs",
        "seer_pc_audios",
        "seer_pc_fonts",
        "seer_pc_icons",
        "seer_pc_models",
        "seer_pc_skyboxes",
        "seer_pc_textures_blocks",
        "seer_pc_textures_others",
    },
    ["group_mobile"] = {
        "seer_mobile_configs",
        "seer_mobile_audios",
        "seer_mobile_fonts",
        "seer_mobile_icons",
        "seer_mobile_models",
        "seer_mobile_skyboxes",
        "seer_mobile_textures_blocks",
        "seer_mobile_textures_others",
    },
}
BuildSeerPKG.Inited = false;

function BuildSeerPKG.Init()
    if not BuildSeerPKG.Inited then
        BuildParaWorld.AddBuildProfile("seer_etc", {src="installer/main_seerA.zip", dest="installer/main_seerA.pkg", txtPathList={"packages/redist/main_seer_etc_script-1.0.txt",} });
        BuildParaWorld.AddBuildProfile("seer_logic", {src="installer/main_seerB.zip", dest="installer/main_seerB.pkg", txtPathList={"packages/redist/main_seer_logic_script-1.0.txt",} });
        BuildParaWorld.AddBuildProfile("seer_settings", {src="installer/main_seerC.zip", dest="installer/main_seerC.pkg", txtPathList={"packages/redist/main_seer_settings_script-1.0.txt",} });
        BuildParaWorld.AddBuildProfile("seer_mobile", {src="installer/main_seerMobile.zip", dest="installer/main_seerMobile.pkg", txtPathList={"packages/redist/main_seer_mobile_script-1.0.txt",} });

        BuildParaWorld.AddBuildProfile("seer_scripts_all", {src="installer/main_seer_scripts_all.zip", dest="installer/main_seer_scripts_all.pkg", txtPathList={"packages/redist/main_seer_scripts_all.txt",} });
        BuildParaWorld.AddBuildProfile("seer_settings", {src="installer/main_seer_settings.zip", dest="installer/main_seer_settings.pkg", txtPathList={"packages/redist/main_seer_settings.txt",} });
        BuildParaWorld.AddBuildProfile("seer_basic", {src="installer/main_seer_basic.zip", dest="installer/main_seer_basic.pkg", txtPathList={"packages/redist/main_seer_basic.txt",} });
        BuildParaWorld.AddBuildProfile("seer_configs", {src="installer/main_seer_configs.zip", dest="installer/main_seer_configs.pkg", txtPathList={"packages/redist/main_seer_configs.txt",} });
        BuildParaWorld.AddBuildProfile("seer_audios", {src="installer/main_seer_audios.zip", dest="installer/main_seer_audios.pkg", txtPathList={"packages/redist/main_seer_audios.txt",} });
        BuildParaWorld.AddBuildProfile("seer_icons_blocks", {src="installer/main_seer_icons_blocks.zip", dest="installer/main_seer_icons_blocks.pkg", txtPathList={"packages/redist/main_seer_icons_blocks.txt",} });
        BuildParaWorld.AddBuildProfile("seer_icons_emojis_standard", {src="installer/main_seer_icons_emojis_standard.zip", dest="installer/main_seer_icons_emojis_standard.pkg", txtPathList={"packages/redist/main_seer_icons_emojis_standard.txt",} });
        BuildParaWorld.AddBuildProfile("seer_icons_heads", {src="installer/main_seer_icons_heads.zip", dest="installer/main_seer_icons_heads.pkg", txtPathList={"packages/redist/main_seer_icons_heads.txt",} });
        BuildParaWorld.AddBuildProfile("seer_icons_planets", {src="installer/main_seer_icons_planets.zip", dest="installer/main_seer_icons_planets.pkg", txtPathList={"packages/redist/main_seer_icons_planets.txt",} });
        BuildParaWorld.AddBuildProfile("seer_icons_shop_categories", {src="installer/main_seer_icons_shop_categories.zip", dest="installer/main_seer_icons_shop_categories.pkg", txtPathList={"packages/redist/main_seer_icons_shop_categories.txt",} });
        BuildParaWorld.AddBuildProfile("seer_icons_shop_items", {src="installer/main_seer_icons_shop_items.zip", dest="installer/main_seer_icons_shop_items.pkg", txtPathList={"packages/redist/main_seer_icons_shop_items.txt",} });
        BuildParaWorld.AddBuildProfile("seer_icons_skills", {src="installer/main_seer_icons_skills.zip", dest="installer/main_seer_icons_skills.pkg", txtPathList={"packages/redist/main_seer_icons_skills.txt",} });
        BuildParaWorld.AddBuildProfile("seer_icons_skyboxes", {src="installer/main_seer_icons_skyboxes.zip", dest="installer/main_seer_icons_skyboxes.pkg", txtPathList={"packages/redist/main_seer_icons_skyboxes.txt",} });
        BuildParaWorld.AddBuildProfile("seer_models_blocks", {src="installer/main_seer_models_blocks.zip", dest="installer/main_seer_models_blocks.pkg", txtPathList={"packages/redist/main_seer_models_blocks.txt",} });
        BuildParaWorld.AddBuildProfile("seer_models_characters", {src="installer/main_seer_models_characters.zip", dest="installer/main_seer_models_characters.pkg", txtPathList={"packages/redist/main_seer_models_characters.txt",} });
        BuildParaWorld.AddBuildProfile("seer_models_entities", {src="installer/main_seer_models_entities.zip", dest="installer/main_seer_models_entities.pkg", txtPathList={"packages/redist/main_seer_models_entities.txt",} });
        BuildParaWorld.AddBuildProfile("seer_models_furnitures", {src="installer/main_seer_models_furnitures.zip", dest="installer/main_seer_models_furnitures.pkg", txtPathList={"packages/redist/main_seer_models_furnitures.txt",} });
        BuildParaWorld.AddBuildProfile("seer_skyboxes", {src="installer/main_seer_skyboxes.zip", dest="installer/main_seer_skyboxes.pkg", txtPathList={"packages/redist/main_seer_skyboxes.txt",} });
        BuildParaWorld.AddBuildProfile("seer_textures_blocks", {src="installer/main_seer_textures_blocks.zip", dest="installer/main_seer_textures_blocks.pkg", txtPathList={"packages/redist/main_seer_textures_blocks.txt",} });
        BuildParaWorld.AddBuildProfile("seer_textures_characters", {src="installer/main_seer_textures_characters.zip", dest="installer/main_seer_textures_characters.pkg", txtPathList={"packages/redist/main_seer_textures_characters.txt",} });
        BuildParaWorld.AddBuildProfile("seer_textures_guides", {src="installer/main_seer_textures_guides.zip", dest="installer/main_seer_textures_guides.pkg", txtPathList={"packages/redist/main_seer_textures_guides.txt",} });
        BuildParaWorld.AddBuildProfile("seer_textures_skins", {src="installer/main_seer_textures_skins.zip", dest="installer/main_seer_textures_skins.pkg", txtPathList={"packages/redist/main_seer_textures_skins.txt",} });
        BuildParaWorld.AddBuildProfile("seer_textures_etc", {src="installer/main_seer_textures_etc.zip", dest="installer/main_seer_textures_etc.pkg", txtPathList={"packages/redist/main_seer_textures_etc.txt",} });
        BuildParaWorld.AddBuildProfile("seer_textures_ui_01_basic", {src="installer/main_seer_textures_ui_01_basic.zip", dest="installer/main_seer_textures_ui_01_basic.pkg", txtPathList={"packages/redist/main_seer_textures_ui_01_basic.txt",} });
        BuildParaWorld.AddBuildProfile("seer_textures_ui_02_login", {src="installer/main_seer_textures_ui_02_login.zip", dest="installer/main_seer_textures_ui_02_login.pkg", txtPathList={"packages/redist/main_seer_textures_ui_02_login.txt",} });
        BuildParaWorld.AddBuildProfile("seer_textures_ui_03_planet", {src="installer/main_seer_textures_ui_03_planet.zip", dest="installer/main_seer_textures_ui_03_planet.pkg", txtPathList={"packages/redist/main_seer_textures_ui_03_planet.txt",} });
        BuildParaWorld.AddBuildProfile("seer_textures_ui_04_friend", {src="installer/main_seer_textures_ui_04_friend.zip", dest="installer/main_seer_textures_ui_04_friend.pkg", txtPathList={"packages/redist/main_seer_textures_ui_04_friend.txt",} });
        BuildParaWorld.AddBuildProfile("seer_textures_ui_05_comment", {src="installer/main_seer_textures_ui_05_comment.zip", dest="installer/main_seer_textures_ui_05_comment.pkg", txtPathList={"packages/redist/main_seer_textures_ui_05_comment.txt",} });
        BuildParaWorld.AddBuildProfile("seer_textures_ui_06_shop", {src="installer/main_seer_textures_ui_06_shop.zip", dest="installer/main_seer_textures_ui_06_shop.pkg", txtPathList={"packages/redist/main_seer_textures_ui_06_shop.txt",} });
        BuildParaWorld.AddBuildProfile("seer_textures_ui_07_wiki", {src="installer/main_seer_textures_ui_07_wiki.zip", dest="installer/main_seer_textures_ui_07_wiki.pkg", txtPathList={"packages/redist/main_seer_textures_ui_07_wiki.txt",} });
        BuildParaWorld.AddBuildProfile("seer_textures_ui_08_access", {src="installer/main_seer_textures_ui_08_access.zip", dest="installer/main_seer_textures_ui_08_access.pkg", txtPathList={"packages/redist/main_seer_textures_ui_08_access.txt",} });
        BuildParaWorld.AddBuildProfile("seer_textures_ui_09_bag", {src="installer/main_seer_textures_ui_09_bag.zip", dest="installer/main_seer_textures_ui_09_bag.pkg", txtPathList={"packages/redist/main_seer_textures_ui_09_bag.txt",} });
        BuildParaWorld.AddBuildProfile("seer_textures_ui_10_selectbar", {src="installer/main_seer_textures_ui_10_selectbar.zip", dest="installer/main_seer_textures_ui_10_selectbar.pkg", txtPathList={"packages/redist/main_seer_textures_ui_10_selectbar.txt",} });
        BuildParaWorld.AddBuildProfile("seer_textures_ui_11_esc", {src="installer/main_seer_textures_ui_11_esc.zip", dest="installer/main_seer_textures_ui_11_esc.pkg", txtPathList={"packages/redist/main_seer_textures_ui_11_esc.txt",} });
        BuildParaWorld.AddBuildProfile("seer_textures_ui_12_guide", {src="installer/main_seer_textures_ui_12_guide.zip", dest="installer/main_seer_textures_ui_12_guide.pkg", txtPathList={"packages/redist/main_seer_textures_ui_12_guide.txt",} });
        BuildParaWorld.AddBuildProfile("seer_textures_ui_13_help", {src="installer/main_seer_textures_ui_13_help.zip", dest="installer/main_seer_textures_ui_13_help.pkg", txtPathList={"packages/redist/main_seer_textures_ui_13_help.txt",} });
        BuildParaWorld.AddBuildProfile("seer_textures_ui_14_others", {src="installer/main_seer_textures_ui_14_others.zip", dest="installer/main_seer_textures_ui_14_others.pkg", txtPathList={"packages/redist/main_seer_textures_ui_14_others.txt",} });
        BuildParaWorld.AddBuildProfile("seer_textures_ui_15_messagebox", {src="installer/main_seer_textures_ui_15_messagebox.zip", dest="installer/main_seer_textures_ui_15_messagebox.pkg", txtPathList={"packages/redist/main_seer_textures_ui_15_messagebox.txt",} });
        BuildParaWorld.AddBuildProfile("seer_textures_ui_16_minimap", {src="installer/main_seer_textures_ui_16_minimap.zip", dest="installer/main_seer_textures_ui_16_minimap.pkg", txtPathList={"packages/redist/main_seer_textures_ui_16_minimap.txt",} });
        BuildParaWorld.AddBuildProfile("seer_textures_ui_17_ranklist", {src="installer/main_seer_textures_ui_17_ranklist.zip", dest="installer/main_seer_textures_ui_17_ranklist.pkg", txtPathList={"packages/redist/main_seer_textures_ui_17_ranklist.txt",} });
        BuildParaWorld.AddBuildProfile("seer_textures_ui_18_quickedit", {src="installer/main_seer_textures_ui_18_quickedit.zip", dest="installer/main_seer_textures_ui_18_quickedit.pkg", txtPathList={"packages/redist/main_seer_textures_ui_18_quickedit.txt",} });
        BuildParaWorld.AddBuildProfile("seer_textures_ui_19_multiplayer", {src="installer/main_seer_textures_ui_19_multiplayer.zip", dest="installer/main_seer_textures_ui_19_multiplayer.pkg", txtPathList={"packages/redist/main_seer_textures_ui_19_multiplayer.txt",} });
        BuildParaWorld.AddBuildProfile("seer_textures_ui_20_serverhall", {src="installer/main_seer_textures_ui_20_serverhall.zip", dest="installer/main_seer_textures_ui_20_serverhall.pkg", txtPathList={"packages/redist/main_seer_textures_ui_20_serverhall.txt",} });
        BuildParaWorld.AddBuildProfile("seer_textures_ui_21_visit", {src="installer/main_seer_textures_ui_21_visit.zip", dest="installer/main_seer_textures_ui_21_visit.pkg", txtPathList={"packages/redist/main_seer_textures_ui_21_visit.txt",} });
        BuildParaWorld.AddBuildProfile("seer_textures_ui_22_welcome", {src="installer/main_seer_textures_ui_22_welcome.zip", dest="installer/main_seer_textures_ui_22_welcome.pkg", txtPathList={"packages/redist/main_seer_textures_ui_22_welcome.txt",} });
        BuildParaWorld.AddBuildProfile("seer_textures_ui_23_offline", {src="installer/main_seer_textures_ui_23_offline.zip", dest="installer/main_seer_textures_ui_23_offline.pkg", txtPathList={"packages/redist/main_seer_textures_ui_23_offline.txt",} });
        BuildParaWorld.AddBuildProfile("seer_textures_ui_24_mail", {src="installer/main_seer_textures_ui_24_mail.zip", dest="installer/main_seer_textures_ui_24_mail.pkg", txtPathList={"packages/redist/main_seer_textures_ui_24_mail.txt",} });

        BuildParaWorld.AddBuildProfile("seer_pc_configs", {src="installer/main_seer_pc_configs.zip", dest="installer/main_seer_pc_configs.pkg", txtPathList={"packages/redist/main_seer_pc_configs.txt",} });
        BuildParaWorld.AddBuildProfile("seer_pc_audios", {src="installer/main_seer_pc_audios.zip", dest="installer/main_seer_pc_audios.pkg", txtPathList={"packages/redist/main_seer_pc_audios.txt",} });
        BuildParaWorld.AddBuildProfile("seer_pc_fonts", {src="installer/main_seer_pc_fonts.zip", dest="installer/main_seer_pc_fonts.pkg", txtPathList={"packages/redist/main_seer_pc_fonts.txt",} });
        BuildParaWorld.AddBuildProfile("seer_pc_icons", {src="installer/main_seer_pc_icons.zip", dest="installer/main_seer_pc_icons.pkg", txtPathList={"packages/redist/main_seer_pc_icons.txt",} });
        BuildParaWorld.AddBuildProfile("seer_pc_models", {src="installer/main_seer_pc_models.zip", dest="installer/main_seer_pc_models.pkg", txtPathList={"packages/redist/main_seer_pc_models.txt",} });
        BuildParaWorld.AddBuildProfile("seer_pc_skyboxes", {src="installer/main_seer_pc_skyboxes.zip", dest="installer/main_seer_pc_skyboxes.pkg", txtPathList={"packages/redist/main_seer_pc_skyboxes.txt",} });
        BuildParaWorld.AddBuildProfile("seer_pc_textures_blocks", {src="installer/main_seer_pc_textures_blocks.zip", dest="installer/main_seer_pc_textures_blocks.pkg", txtPathList={"packages/redist/main_seer_pc_textures_blocks.txt",} });
        BuildParaWorld.AddBuildProfile("seer_pc_textures_others", {src="installer/main_seer_pc_textures_others.zip", dest="installer/main_seer_pc_textures_others.pkg", txtPathList={"packages/redist/main_seer_pc_textures_others.txt",} });

        BuildParaWorld.AddBuildProfile("seer_mobile_configs", {src="installer/main_seer_mobile_configs.zip", dest="installer/main_seer_mobile_configs.pkg", txtPathList={"packages/redist/main_seer_mobile_configs.txt",} });
        BuildParaWorld.AddBuildProfile("seer_mobile_audios", {src="installer/main_seer_mobile_audios.zip", dest="installer/main_seer_mobile_audios.pkg", txtPathList={"packages/redist/main_seer_mobile_audios.txt",} });
        BuildParaWorld.AddBuildProfile("seer_mobile_fonts", {src="installer/main_seer_mobile_fonts.zip", dest="installer/main_seer_mobile_fonts.pkg", txtPathList={"packages/redist/main_seer_mobile_fonts.txt",} });
        BuildParaWorld.AddBuildProfile("seer_mobile_icons", {src="installer/main_seer_mobile_icons.zip", dest="installer/main_seer_mobile_icons.pkg", txtPathList={"packages/redist/main_seer_mobile_icons.txt",} });
        BuildParaWorld.AddBuildProfile("seer_mobile_models", {src="installer/main_seer_mobile_models.zip", dest="installer/main_seer_mobile_models.pkg", txtPathList={"packages/redist/main_seer_mobile_models.txt",} });
        BuildParaWorld.AddBuildProfile("seer_mobile_skyboxes", {src="installer/main_seer_mobile_skyboxes.zip", dest="installer/main_seer_mobile_skyboxes.pkg", txtPathList={"packages/redist/main_seer_mobile_skyboxes.txt",} });
        BuildParaWorld.AddBuildProfile("seer_mobile_textures_blocks", {src="installer/main_seer_mobile_textures_blocks.zip", dest="installer/main_seer_mobile_textures_blocks.pkg", txtPathList={"packages/redist/main_seer_mobile_textures_blocks.txt",} });
        BuildParaWorld.AddBuildProfile("seer_mobile_textures_others", {src="installer/main_seer_mobile_textures_others.zip", dest="installer/main_seer_mobile_textures_others.pkg", txtPathList={"packages/redist/main_seer_mobile_textures_others.txt",} });

        BuildSeerPKG.Inited = true;
    end
end

function BuildSeerPKG.BuildPackageGroup(package_group_name)
    if package_group_name and package_list[package_group_name] then
        BuildParaWorld.MakeZipPackage(package_list[package_group_name]);
        BuildParaWorld.EncryptZipFiles(package_list[package_group_name]);
    end
end

function BuildSeerPKG.BuildGeneral()
    BuildSeerPKG.BuildPackageGroup("group_logic");
    BuildSeerPKG.BuildPackageGroup("group_settings");
    BuildSeerPKG.BuildPackageGroup("group_basic");
    BuildSeerPKG.BuildPackageGroup("group_icons");
    BuildSeerPKG.BuildPackageGroup("group_models");
    BuildSeerPKG.BuildPackageGroup("group_skyboxes");
    BuildSeerPKG.BuildPackageGroup("group_textures");
    echo("All general pkgs finished");
end

function BuildSeerPKG.BuildPCSpecific()
    BuildSeerPKG.BuildPackageGroup("group_pc");
    echo("All pc-specific pkgs finished");
end

function BuildSeerPKG.BuildMobileSpecific()
    BuildSeerPKG.BuildPackageGroup("group_mobile");
    echo("All mobile-specific pkgs finished");
end

function BuildSeerPKG.BuildPCAll()
    BuildSeerPKG.BuildGeneral();
    BuildSeerPKG.BuildPCSpecific();
end

function BuildSeerPKG.BuildMobileAll()
    BuildSeerPKG.BuildGeneral();
    BuildSeerPKG.BuildMobileSpecific();
end

function BuildSeerPKG.BuildAll()
    BuildSeerPKG.BuildGeneral();
    BuildSeerPKG.BuildPCSpecific();
    BuildSeerPKG.BuildMobileSpecific();    
end

--cellfy: not tested
function BuildSeerPKG.BuildSingle(pkg_id)
    local id_found = false;
    for _i,current_group in pairs(package_list) do
        for _j,current_id in pairs(current_group) do
            if current_id == pkg_id then
                id_found = true;
                break;
            end
        end
        if id_found then
            break;
        end
    end
    if id_found then
        local pkg_collection={pkg_id};
        BuildParaWorld.MakeZipPackage(pkg_collection);
        BuildParaWorld.EncryptZipFiles(pkg_collection);
        echo("Single pkg: "..pkg_id.." build finished");
    else
        echo("invalid pkg id: "..pkg_id);
    end
end

function BuildSeerPKG.Compile()
    local error_count = BuildParaWorld.CompileNPLFiles();
    echo("Compiled with error count:");
    echo(error_count);
end

function BuildSeerPKG.BuildETC()
    BuildParaWorld.MakeZipPackage({"seer_etc"})
    BuildParaWorld.EncryptZipFiles({"seer_etc"})
    echo("pkg etc finished");
end

function BuildSeerPKG.BuildLogic()
    BuildParaWorld.MakeZipPackage({"seer_logic"})
    BuildParaWorld.EncryptZipFiles({"seer_logic"})
    echo("pkg logic finished");
end

function BuildSeerPKG.BuildSettings()
    BuildParaWorld.MakeZipPackage({"seer_settings"})
    BuildParaWorld.EncryptZipFiles({"seer_settings"})
    echo("pkg settings finished");
end

function BuildSeerPKG.RebuildSettings()
    local error_count = NPL.CompileFiles("script/Seer/Settings.lua");
    BuildSeerPKG.BuildPackageGroup("group_settings");
end

function BuildSeerPKG.BuildPCAll_Old()
    BuildSeerPKG.BuildETC();
    BuildSeerPKG.BuildLogic();
    BuildSeerPKG.BuildSettings();
    echo("All pkgs finished");
end

function BuildSeerPKG.BuildMobile()
    BuildParaWorld.MakeZipPackage({"seer_mobile"})
    BuildParaWorld.EncryptZipFiles({"seer_mobile"})
    echo("pkg mobile finished");
end
