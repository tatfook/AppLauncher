--[[
Title: CreateOfficialWorld.html code-behind script
Author(s): ZhouXing
Date: 2015/6/9
Desc: Create new world based on predefined template and open existing world. 
use the lib:
-------------------------------------------------------
NPL.load("(gl)script/Seer/CreateOfficialWorld.lua");
local CreateOfficialWorld = commonlib.gettable("Mod.Seer.World.CreateOfficialWorld");
-------------------------------------------------------
]]

NPL.load("(gl)script/apps/Aries/Game/MainLogin/CreateNewWorld.lua");
NPL.load("(gl)script/ide/AudioEngine/AudioEngine.lua");
local AudioEngine = commonlib.gettable("AudioEngine");
local WorldCommon = commonlib.gettable("MyCompany.Aries.Creator.WorldCommon");
local CreateNewWorld = commonlib.gettable("MyCompany.Aries.Game.MainLogin.CreateNewWorld");

local CreateOfficialWorld = commonlib.gettable("Mod.Seer.World.CreateOfficialWorld");

function CreateOfficialWorld.Create()
	local world_name = CreateNewWorld.page:GetValue("new_world_name");
	local world_type = CreateNewWorld.page:GetValue("new_world_type");

	local params = {
		worldname = commonlib.Encoding.Utf8ToDefault(world_name),
		title = world_name,
		creationfolder = CreateNewWorld.GetWorldFolder(),
		parentworld = "worlds/Templates/Empty/flatsandland",
		world_generator = string.format("SeerOfficial_%s", world_type),
		seed = string.format("%s_%s_%s", world_generator, world_name, ParaGlobal.timeGetTime()),
		inherit_scene = true,
		inherit_char = true,
	}
	LOG.std(nil, "info", "CreateOfficialWorld.Create", params);

	local worldpath, error_msg = CreateNewWorld.CreateWorld(params);
	if(not worldpath) then
		if(error_msg) then
			_guihelper.MessageBox(error_msg);
		else
			AudioEngine.PlayUISound("btn_warn");
			_guihelper.MessageBox("δ֪���󣬴�������ʧ�ܣ�");
		end
	else
		CreateNewWorld.page:CloseWindow();
		WorldCommon.OpenWorld(worldpath, true);
	end
end
