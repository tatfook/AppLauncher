NPL.load("(gl)script/Seer/Network/PacketsExt/SeerPacketBase.lua");
local PacketSyncResourceTable = commonlib.inherit(commonlib.gettable("Mod.Seer.Network.PacketsExt.SeerPacketBase"), commonlib.gettable("Mod.Seer.Network.PacketsExt.PacketSyncResourceTable"));
local ResourceTable = NPL.load("script/Seer/Game/Resource/ResourceTable.lua");

function PacketSyncResourceTable:ctor()
end


function PacketSyncResourceTable:Init(res)
    PacketSyncResourceTable._super.Init(self);
    if res then 
        self.resources = {[res._idx] = res};
    else
        self.resources = ResourceTable.getAll();
    end
    return self;
end

function PacketSyncResourceTable:ProcessPacket(net_handler)
    PacketSyncResourceTable._super.ProcessPacket(self, net_handler);
    if(net_handler.handleSyncResourceTable) then
        net_handler:handleSyncResourceTable(self);
    end
end

function PacketSyncResourceTable:requestAdd(res, callback)
    PacketSyncResourceTable._super.InitAsReq(self, callback);
    self.resource = res;    
    return self;
end

function PacketSyncResourceTable:responseAdd(packet, index)
    PacketSyncResourceTable._super.InitAsRsp(self, packet);
    self.index = index;
    return self;
end

