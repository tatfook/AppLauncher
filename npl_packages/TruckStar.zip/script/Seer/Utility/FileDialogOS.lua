local FileDialogOS = NPL.export()
NPL.load("(gl)script/Seer/Utility/CommonUtility.lua");
local CommonUtility = commonlib.gettable("Mod.Seer.Utility.CommonUtility");
local Async = commonlib.gettable("Mod.Seer.Utility.Async");

function FileDialogOS.open(filter, initialdir, callback)
    FileDialogOS.select(filter, nil, initialdir, false, callback);
end

function FileDialogOS.save(filter, initialdir, callback)
    FileDialogOS.select(filter, nil, initialdir, true, callback);
end

local function GetFilterString(filters)
	if(filters) then
		local filterText = "";
		for _, filter in ipairs(filters) do
			if(filter[1] and filter[2]) then
				local text = format("%s\0%s\0", commonlib.Encoding.Utf8ToDefault(filter[1]), filter[2]);
				filterText = filterText..text;
			end
		end
		if(filterText~="") then
			return filterText;
		end
	end
end
-- filter : {"All Files (*.*)", "*.*"}
function FileDialogOS.select(filter,title,initialdir,save, callback)
    if CommonUtility:GetPlatform() == CommonUtility.PC then
        local input = 
        {
            filter = GetFilterString(filter),
            title = title,
            initialdir = initialdir,
            save = save,
        }
        local future = Async.call("return   function (input) if ParaGlobal.OpenFileDialog(input) then return input.filename; end; end ",input);
        future:get(callback);
    end
end