--[[
    Title: SeerEntityPlayerMP
    Author(s): Devil
    Date: 2016/05/04
    Desc: EntityPlayerMP extension. 
    A Injector class.
    Injection Target: MyCompany.Aries.Game.EntityManager.EntityPlayerMP
    use the lib:
    -------------------------------------------------------
	NPL.load("(gl)script/apps/Aries/Creator/Game/Entity/EntityPlayerMP.lua");
    NPL.load("(gl)script/Seer/Injector/SeerEntityPlayerMP.lua");
	local EntityPlayerMP = commonlib.gettable("MyCompany.Aries.Game.EntityManager.EntityPlayerMP")
    local SeerEntityPlayerMP = commonlib.gettable("Mod.Seer.Injector.SeerEntityPlayerMP");
    Inject(SeerEntityPlayerMP, EntityPlayerMP);
    -------------------------------------------------------
]]
NPL.load("(gl)script/apps/Aries/Creator/Game/Entity/EntityPlayerMP.lua");
NPL.load("(gl)script/Seer/Game/MultiPlayer/GamingRoomInfo.lua");
local GamingRoomInfo = commonlib.gettable("Mod.Seer.Game.MultiPlayer.GamingRoomInfo");
local Packets = commonlib.gettable("MyCompany.Aries.Game.Network.Packets");
local TableCodec = commonlib.gettable("commonlib.TableCodec");
local BlockEngine = commonlib.gettable("MyCompany.Aries.Game.BlockEngine")
local block_types = commonlib.gettable("MyCompany.Aries.Game.block_types")
local GameLogic = commonlib.gettable("MyCompany.Aries.Game.GameLogic")
local EntityManager = commonlib.gettable("MyCompany.Aries.Game.EntityManager");
local PlayerSkins = commonlib.gettable("MyCompany.Aries.Game.EntityManager.PlayerSkins")
local ChunkLocation = commonlib.gettable("MyCompany.Aries.Game.Common.ChunkLocation");
local Desktop = commonlib.gettable("MyCompany.Aries.Creator.Game.Desktop");
local SeerEntityPlayerMP = commonlib.gettable("Mod.Seer.Injector.SeerEntityPlayerMP");
-- this is message from administrator:
-- @param chatmsg: ChatMessage or string. 
function SeerEntityPlayerMP:SendChatMsg(chatmsg, chatdata)
	local packet_Chat = Packets.PacketChat:new():Init(chatmsg, chatdata)
	--packet_Chat.text = GamingRoomInfo.PlayerInfoMapGetNickname(self:GetUserName())..": "..packet_Chat.text;
	chat_msg = packet_Chat:ToChatMessage();
	Desktop.GetChatGUI():PrintChatMessage(chat_msg);
	self.worldObj:GetServerManager():SendChatMsg(chat_msg);
	return true;
end
