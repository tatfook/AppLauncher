--[[
    Title: SeerGameDesktop
    Author(s): Cellfy
    Date Created: 19 Jan 2017
    Date Updated: 19 Jan 2017
    Desc: 
    Usage:
    ------------------------------------------------------------
    NPL.load("(gl)script/apps/Aries/Creator/Game/GameDesktop.lua");
    NPL.load("(gl)script/Seer/Injector/SeerGameDesktop.lua");
    local GameDesktop = commonlib.gettable("MyCompany.Aries.Creator.Game.Desktop");
    local SeerGameDesktop = commonlib.gettable("Mod.Seer.Injector.SeerGameDesktop");
    Inject(SeerGameDesktop, GameDesktop);
    ------------------------------------------------------------
]]
local SeerGameDesktop = commonlib.gettable("Mod.Seer.Injector.SeerGameDesktop");

-- override Desktop.ForceExit
function SeerGameDesktop.ForceExit(bRestart)
    --TODO: iOS doesn't allow apps to exit by itself. We only have pc and android now, so force-exiting is ok.
    LOG.std(nil, "debug", "truckstar", "SeerGameDesktop.ForceExit: about to exit");
    ParaEngine.GetAttributeObject():SetField("IsWindowClosingAllowed", true);
    if(bRestart) then
        Game.Exit();
        System.App.Commands.Call("Profile.Aries.Restart", {method="soft"});
    else
        Game.Exit();
        ParaGlobal.ExitApp();
    end
end
