--[[
    Title: SeerShapeAABB
    Author(s): Devil
    Date: 2016/10/13
    Desc: ShapeAABB extension. 
    A Injector class.
    Injection Target: mathlib.ShapeAABB
    use the lib:
    -------------------------------------------------------
    NPL.load("(gl)script/ide/math/ShapeAABB.lua");
    NPL.load("(gl)script/Seer/Injector/SeerShapeAABB.lua");
    local ShapeAABB = commonlib.gettable("mathlib.ShapeAABB");
    local SeerShapeAABB = commonlib.gettable("Mod.Seer.Injector.SeerShapeAABB");
    Inject(SeerShapeAABB, ShapeAABB);
    -------------------------------------------------------
]]
NPL.load("(gl)script/ide/math/ShapeAABB.lua");
local SeerShapeAABB = commonlib.gettable("Mod.Seer.Injector.SeerShapeAABB");
function SeerShapeAABB:intersectPoint(x,y,z)
  local T = {self.mCenter[1] - x,self.mCenter[2] - y,self.mCenter[3] - z};
  return ((math.abs(T[1]) <= self.mExtents[1])
		and (math.abs(T[2]) <= self.mExtents[2])
		and (math.abs(T[3]) <= self.mExtents[3]));
end