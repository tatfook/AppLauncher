NPL.load("(gl)script/Seer/pb/cs_custom_pb.lua");

local PacketPbHelper = commonlib.gettable("Mod.Seer.Network.Packets.PacketPbHelper");
local PacketPb = commonlib.gettable("Mod.Seer.Network.Packets.PacketPb");


function PacketPbHelper.sendCSGetCustomDataReq(keys, uid)
	PacketPbHelper.send("CSGetCustomDataReq", {keys = keys, uid = uid});
end

function PacketPbHelper.sendCSGetAllCustomDataReq(uid)
	PacketPbHelper.send("CSGetAllCustomDataReq", {uid = uid});
end

-- data: { {key, value}, {key, value}, ... }
function PacketPbHelper.sendCSUpdateCustomDataReq(data)
	PacketPbHelper.send("CSUpdateCustomDataReq", {pairs = data});
end

function PacketPbHelper.sendCSDeleteCustomDataReq(keys)
	PacketPbHelper.send("CSDeleteCustomDataReq", {keys = keys});
end


