--[[
    Title: SeerBlockTemplateTask
    Author(s): Devil
    Date: 2016/08/10
    Desc: BlockTemplateTask extension. 
    A Injector class.
    Injection Target: Mod.Seer.Injector.SeerBlockTemplateTask
    use the lib:
    -------------------------------------------------------
    NPL.load("(gl)script/apps/Aries/Creator/Game/Tasks/BlockTemplateTask.lua");
    NPL.load("(gl)script/Seer/Injector/SeerBlockTemplateTask.lua");
    local BlockTemplate = commonlib.gettable("MyCompany.Aries.Game.Tasks.BlockTemplate");
    local SeerBlockTemplateTask = commonlib.gettable("Mod.Seer.Injector.SeerBlockTemplateTask");
    Inject(SeerBlockTemplateTask, BlockTemplate);
    -------------------------------------------------------
]]
NPL.load("(gl)script/apps/Aries/Creator/Game/Tasks/BlockTemplateTask.lua");
local FastRandom = commonlib.gettable("MyCompany.Aries.Game.Common.CustomGenerator.FastRandom");
local UndoManager = commonlib.gettable("MyCompany.Aries.Game.UndoManager");
local GameLogic = commonlib.gettable("MyCompany.Aries.Game.GameLogic")
local BlockEngine = commonlib.gettable("MyCompany.Aries.Game.BlockEngine")
local TaskManager = commonlib.gettable("MyCompany.Aries.Game.TaskManager")
local block_types = commonlib.gettable("MyCompany.Aries.Game.block_types")
local SeerBlockTemplateTask = commonlib.gettable("Mod.Seer.Injector.SeerBlockTemplateTask");

-- Save to template. if no 
-- self.params: root level attributes
-- self.filename: 
-- self.blocks: if nil, the current selection is used. 
function SeerBlockTemplateTask:SaveTemplate()
	local filename = self.filename;
	ParaIO.CreateDirectory(filename);
	local file = ParaIO.open(filename, "w");
	if(file:IsValid()) then 
		self.params = self.params or {};
		self.params.auto_scale = self.auto_scale;
		local o = {name="pe:blocktemplate", attr = self.params};

		if(not self.blocks) then
			NPL.load("(gl)script/apps/Aries/Creator/Game/Tasks/SelectBlocksTask.lua");
			local select_task = MyCompany.Aries.Game.Tasks.SelectBlocks.GetCurrentInstance();
			if(select_task) then
				local pivot = select_task:GetPivotPoint();
				-- local block_pivot = BlockEngine:GetBlock(pivot[1],pivot[2],pivot[3]);
				-- if(block_pivot and block_pivot.id == block_types.names.Command_Block) then
				-- 	-- TODO: use the displayed pivot point if it is on a command block. 
				-- end
				self.blocks = select_task:GetCopyOfBlocks(pivot);
			else
				return;
			end
		end
    --找到blocks中坐标最小值,最大值
    local aabb_min={100000000,100000000,100000000};
    local aabb_max={-100000000,-100000000,-100000000};
    for i=1,#self.blocks do
      local block_info=self.blocks[i];
      aabb_min[1]=math.min(aabb_min[1],block_info[1]);
      aabb_min[2]=math.min(aabb_min[2],block_info[2]);
      aabb_min[3]=math.min(aabb_min[3],block_info[3]);
      aabb_max[1]=math.max(aabb_max[1],block_info[1]);
      aabb_max[2]=math.max(aabb_max[2],block_info[2]);
      aabb_max[3]=math.max(aabb_max[3],block_info[3]);
    end
    --转换blocks坐标为相对blocks中最小坐标的坐标
    for i=1,#self.blocks do
      self.blocks[i][1]=self.blocks[i][1]-aabb_min[1];
      self.blocks[i][2]=self.blocks[i][2]-aabb_min[2];
      self.blocks[i][3]=self.blocks[i][3]-aabb_min[3];
    end
    aabb_max[1]=aabb_max[1]-aabb_min[1]+1;
    aabb_max[2]=aabb_max[2]-aabb_min[2]+1;
    aabb_max[3]=aabb_max[3]-aabb_min[3]+1;
    local empty_blocks={};
    local i=1;
    for j=1,#self.blocks do
      if self.blocks[i] and self.blocks[i][4]==545 then
        empty_blocks[#empty_blocks+1]=self.blocks[i];
        table.remove(self.blocks,i);
      else
        i=i+1;
      end
    end
		o[1] = {name="pe:blocks", [1]=commonlib.serialize_compact(self.blocks),}
    --保存empty blocks
    o[2]={name="pe:empty_blocks",[1]=commonlib.serialize_compact(empty_blocks)};
    --保存aabb
    o[3]={name="pe:aabb",[1]=commonlib.serialize_compact(aabb_max)};
		file:WriteString(commonlib.Lua2XmlString(o, true));
		file:close();
		
		if(filename:match("%.bmax$")) then
			-- refresh it if it is a bmax model.
			ParaAsset.LoadParaX("", filename):UnloadAsset();
		end
		return true;
	end
end
