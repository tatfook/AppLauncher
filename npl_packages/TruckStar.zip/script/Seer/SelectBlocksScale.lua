--[[
Title: selected blocks scale page
Author(s): WuZhao
Date: 2013/8/24
Desc: selected blocks scale page
use the lib:
------------------------------------------------------------
NPL.load("(gl)script/Seer/SelectBlocksScale.lua");
local SelectBlocksScale = commonlib.gettable("Mod.Seer.UI.SelectBlocksScale");
SelectBlocksScale.ShowPage({x=10, y=0, z=10, facing=90}, function(trans)
	_guihelper.MessageBox(trans)
end)
-------------------------------------------------------
]]
local SelectBlocksScale = commonlib.gettable("Mod.Seer.UI.SelectBlocksScale");
NPL.load("(gl)script/ide/math/ShapeAABB.lua");
local ShapeAABB = commonlib.gettable("mathlib.ShapeAABB");
NPL.load("(gl)script/ide/math/vector.lua");
local vector3d = commonlib.gettable("mathlib.vector3d");
NPL.load("(gl)script/ide/AudioEngine/AudioEngine.lua");
local AudioEngine = commonlib.gettable("AudioEngine");
local EntityManager = commonlib.gettable("MyCompany.Aries.Game.EntityManager");

local groupindex_hint = 6; 

------------------------
-- page function 
------------------------
local page;

local pagetype;

local settings = {};

local axis_map = {"x", "y", "z"};
local axis_idx = 1;
local axis_xyz = "x";

local transform = {};
local temp_transform = {};
local old_transform = {};
-- @param trans: {x, y, z, rot_y, blocks, method}
-- @param callbackFunc: function(trans, result) end, where result is "ok" if user clicked ok. 
function SelectBlocksScale.ShowPage(blocks, trans, callbackFunc)
	SelectBlocksScale.result = nil;
	SelectBlocksScale.blocks = blocks;
	temp_transform.x, temp_transform.y, temp_transform.z = 0, 0, 0; 
	local pivot_x,pivot_y,pivot_z = EntityManager.GetPlayer():GetBlockPos();
	settings.pivot_x, settings.pivot_y, settings.pivot_z = pivot_x, pivot_y, pivot_z;
	SelectBlocksScale.pivot_x = pivot_x;
	SelectBlocksScale.pivot_y = pivot_y;
	SelectBlocksScale.pivot_z = pivot_z;
	settings.xyz = "x";
	settings.method = "clone"
	settings.pagetype= SelectBlocksScale.pagetype;

	
	SelectBlocksScale.UpdateHintLocation();

	if(page) then
		page:CloseWindow();
	end
	SelectBlocksScale.callbackFunc = callbackFunc;
	
	SelectBlocksScale.result = nil;
	SelectBlocksScale.blocks = blocks;
	transform = trans or {};

	old_transform = commonlib.clone(trans);
	
	local x, y, width, height = 230, 160, 310, 340;
	local align = "_lt";
	
	local params = {
			url = "script/Seer/SelectBlocksScale.html", 
			name = "SelectBlocksScale.ShowPage", 
			app_key = MyCompany.Aries.Creator.Game.Desktop.App.app_key, 
			isShowTitleBar = false, 
			DestroyOnClose = true, -- prevent many ViewProfile pages staying in memory
			style = CommonCtrl.WindowFrame.ContainerStyle,
			enable_esc_key = true,
			zorder = 2,
			allowDrag = true,
			-- click_through = false,
			directPosition = true,
				align = align,
				x = x,
				y = y,
				width = width,
				height = height,
		};
	System.App.Commands.Call("File.MCMLWindowFrame", params);
	params._page.OnClose = function()
		ParaTerrain.DeselectAllBlock(groupindex_hint);
		if(SelectBlocksScale.callbackFunc) then
			SelectBlocksScale.callbackFunc(transform, settings, SelectBlocksScale.result);
		end
		page = nil;
	end
	SelectBlocksScale.UpdateHintLocation();
end


function SelectBlocksScale.GetNumberValue(name, default_value)
	value = page:GetValue(name, 1);
	return tonumber(value) or default_value or 0;
end

function SelectBlocksScale.SetNumberValue(name, value)
	if(page) then
		page:SetValue(name, tostring(value));
	end
end


function SelectBlocksScale.ChangeCoordinate(name,mcmlNode)
	AudioEngine.PlayUISound("btn_show");
	local value;
	if(name == "btn_sub_x" or name == "btn_add_x") then
		--value = SelectBlocksScale.GetNumberValue("text_pos_x", 0);
		value = temp_transform.x or 0;
		if(name == "btn_add_x") then
			value = value + 1;
		elseif(name == "btn_sub_x") then
			value = value - 1;
		end
		page:SetValue("text_pos_x",value);
		temp_transform.x = value;
		SelectBlocksScale.UpdateHintLocation();
	elseif(name == "btn_sub_y" or name == "btn_add_y") then
		--value = SelectBlocksScale.GetNumberValue("text_pos_y", 0);
		value = temp_transform.y or 0;
		if(name == "btn_add_y") then
			value = value + 1;
		elseif(name == "btn_sub_y") then
			value = value - 1;
		end
		page:SetValue("text_pos_y",value);
		temp_transform.y = value;
		SelectBlocksScale.UpdateHintLocation();	
	elseif(name == "btn_sub_z" or name == "btn_add_z") then
		--value = SelectBlocksScale.GetNumberValue("text_pos_z", 0);
		value = temp_transform.z or 0;
		if(name == "btn_add_z") then
			value = value + 1;
		elseif(name == "btn_sub_z") then
			value = value - 1;
		end
		page:SetValue("text_pos_z",value);
		temp_transform.z = value;
		SelectBlocksScale.UpdateHintLocation();
	elseif(name == "text_pos_x" or name == "text_pos_y" or name == "text_pos_z") then
		if(name == "text_pos_x") then
			value = SelectBlocksScale.GetNumberValue("text_pos_x", 0);
			temp_transform.x = value;
		elseif(name == "text_pos_y") then
			value = SelectBlocksScale.GetNumberValue("text_pos_y", 0);
			temp_transform.y = value;
		elseif(name == "text_pos_z") then
			value = SelectBlocksScale.GetNumberValue("text_pos_z", 0);
			temp_transform.z = value;
		end
		SelectBlocksScale.UpdateHintLocation();	
	elseif(name == "btn_rotate_right" or name == "btn_rotate_left") then
		value = temp_transform.rotate or 0;
		if(name == "btn_rotate_right") then
			value = value + 1;
		elseif(name == "btn_rotate_left") then
			value = value - 1;
		end
		value = value%4;
		temp_transform.rotate = value;
		SelectBlocksScale.UpdateHintLocation();
	elseif(name == "btn_sub_scaling" or name == "btn_add_scaling") then
		if(name == "btn_add_scaling") then
			value = "2,2,2";
		elseif(name == "btn_sub_scaling") then
			value = "0.5,0.5,0.5";
		end
		page:SetValue("text_scaling",value);
	elseif(name == "btn_sub_scaling_x" or name == "btn_add_scaling_x") then
		value = SelectBlocksScale.GetNumberValue("label_scaling_x", 1);
		if(name == "btn_add_scaling_x") then 
			value = value + 0.1;
		elseif(name == "btn_sub_scaling_x") then
			value = value - 0.1;
		end
		if(value > 2) then 
			value = 2;
		end
		if(value < 0.5) then
			value = 0.5;
		end
		
		page:SetValue("label_scaling_x",value);
		page:Refresh(0);
		temp_transform.scalingX = value;
		SelectBlocksScale.UpdateHintLocation();	
	elseif(name == "btn_sub_scaling_y" or name == "btn_add_scaling_y") then
		value = SelectBlocksScale.GetNumberValue("label_scaling_y", 1);
		if(name == "btn_add_scaling_y") then 
			value = value + 0.1;
		elseif(name == "btn_sub_scaling_y") then
			value = value - 0.1;
		end
		if(value > 2) then 
			value = 2;
		end
		if(value < 0.5) then
			value = 0.5;
		end
		
		page:SetValue("label_scaling_y",value);
		page:Refresh(0);
		temp_transform.scalingY = value;
		SelectBlocksScale.UpdateHintLocation();	
	elseif(name == "btn_sub_scaling_z" or name == "btn_add_scaling_z") then
		value = SelectBlocksScale.GetNumberValue("label_scaling_z", 1);
		if(name == "btn_add_scaling_z") then 
			value = value + 0.1;
		elseif(name == "btn_sub_scaling_z") then
			value = value - 0.1;
		end
		if(value > 2) then 
			value = 2;
		end
		if(value < 0.5) then
			value = 0.5;
		end		

		page:SetValue("label_scaling_z",value);
		page:Refresh(0);
		temp_transform.scalingZ = value;
		SelectBlocksScale.UpdateHintLocation();	
	end
end

function SelectBlocksScale.ClosePage()
	if(page) then
		page:CloseWindow();
	end
end

function SelectBlocksScale.GetTransformedPoint(src_x, src_y, src_z, dx, dy, dz, rad_y, cx, cy, cz)
	local sin_t, cos_t = math.floor(math.sin(math.rad(rad_y))+0.5), math.floor(math.cos(math.rad(rad_y))+0.5);
	local x, y = src_x - cx, src_z - cz;
	local des_x = x*cos_t - y*sin_t + cx;
	local des_z = x*sin_t + y*cos_t + cz;

	return des_x + dx, src_y + dy, des_z + dz;

	--return src_x+dx, src_y+dy,src_z+dz;
end

function SelectBlocksScale.GetScaledBlocks(blocks, aabb, scalingX, scalingY, scalingZ)
	local final_blocks = {};
	scalingX = scalingX or 1;
	scalingY = scalingY or 1;
	scalingZ = scalingZ or 1;
	local scaling = math.min(scalingX, scalingY, scalingZ);
	if((scalingX~=1 or scalingY~=1 or scalingZ~=1) and aabb) then
		-- scaling is at the min of the aabb. 
		local pivot_x, pivot_y, pivot_z = aabb:GetMinValues();
		local extend_x, extend_y, entend_z = aabb:GetExtendValues();
		pivot_x, pivot_y, pivot_z = math.floor(pivot_x+0.5), math.floor(pivot_y+0.5), math.floor(pivot_z+0.5)
		-- offseting the final center, so that it is repostioned to the bottom center. 
		local bottomCenter_x, bottomCenter_y, bottomCenter_z = aabb:GetBottomPosition();
		local offset_x = pivot_x - math.floor((bottomCenter_x-pivot_x)*scalingX+0.5 - extend_x);
		local offset_y = pivot_y - 0;
		local offset_z = pivot_z - math.floor((bottomCenter_z-pivot_z)*scalingZ+0.5 - entend_z);

		local k = 0;
		for i = 1, #(blocks) do
			local b = blocks[i];
			local dx, dy, dz = b[1] - pivot_x, b[2] - pivot_y, b[3] - pivot_z;

			if(scaling<1) then
				-- min-point-filtering
				k = k + 1;
				final_blocks[k] = {
					math.floor(dx*scalingX + 0.499) + offset_x,
					math.floor(dy*scalingY + 0.499) + offset_y,
					math.floor(dz*scalingZ + 0.499) + offset_z,
					b[4],b[5],b[6],
				};
			else
				-- max-point-filtering
				for x = if_else(dx==0, 0, math.floor((dx)*scalingX)), math.floor((dx+1)*scalingX)-1 do
					for y = if_else(dy==0, 0, math.floor((dy)*scalingY)), math.floor((dy+1)*scalingY)-1  do
						for z = if_else(dz==0, 0, math.floor((dz)*scalingZ)), math.floor((dz+1)*scalingZ)-1  do
							k = k + 1;
							final_blocks[k] = {
								x + offset_x,
								y + offset_y,
								z + offset_z,
								b[4],b[5],b[6],
							};
						end
					end
				end
			end
		end
	else
		final_blocks = commonlib.clone(blocks);
	end
	return final_blocks;
end

function SelectBlocksScale.GetMirrorPoint(src_x, src_y, src_z, pivot_x, pivot_y,pivot_z, mirror_axis)
	if(mirror_axis == "x") then
		return pivot_x*2 - src_x, src_y, src_z;
	elseif(mirror_axis == "y") then
		return src_x, pivot_y*2 - src_y, src_z;
	else -- if(mirror_axis == "z") then
		return src_x, src_y, pivot_z*2 - src_z;
	end
end

-- public function
function SelectBlocksScale.UpdateHintLocation(blocks, dx,dy,dz)
	ParaTerrain.DeselectAllBlock(groupindex_hint);	
	blocks = blocks or SelectBlocksScale.blocks;
	for i = 1, #blocks do
		local b = blocks[i];
	end
	if(blocks) then
		local temp_blocks = commonlib.clone(blocks);

		if(SelectBlocksScale.pagetype == "mirror") then
			ParaTerrain.DeselectAllBlock(groupindex_hint);	

			local GetMirrorPoint = SelectBlocksScale.GetMirrorPoint;
			pivot_x, pivot_y,pivot_z = SelectBlocksScale.pivot_x, SelectBlocksScale.pivot_y, SelectBlocksScale.pivot_z;
			mirror_axis = mirror_axis or settings.xyz;

			SelectBlocksScale.blocks = blocks;
			SelectBlocksScale.pivot_x = pivot_x;
			SelectBlocksScale.pivot_y = pivot_y;
			SelectBlocksScale.pivot_z = pivot_z;
			settings.xyz = mirror_axis;
			settings.pivot_x, settings.pivot_y, settings.pivot_z = pivot_x, pivot_y, pivot_z;

			--temp_blocks = final_blocks;
--
			--if(#final_blocks == 0) then
				--temp_blocks = blocks;
			--end
			for i = 1, #temp_blocks do
				local b = temp_blocks[i];
				local x,y,z = GetMirrorPoint(b[1], b[2], b[3], pivot_x, pivot_y,pivot_z, mirror_axis);
				--ParaTerrain.SelectBlock(x,y,z, true, groupindex_hint);
				b[1], b[2], b[3] = x, y, z;
			end

		end


		if(dx) then
			temp_transform.x, temp_transform.y, temp_transform.z = dx, dy, dz;
		else
			transform.x, transform.y, transform.z = temp_transform.x or 0, temp_transform.y or 0, temp_transform.z or 0;
			dx, dy, dz = transform.x, transform.y, transform.z;
		end
		local rad_y = (temp_transform.rotate or 0) * 90;
		--NPL.load("(gl)script/apps/Aries/Creator/Game/Tasks/TransformBlocksTask.lua");
		local aabb = ShapeAABB:new();
		aabb:SetPointAABB(vector3d:new({temp_blocks[1][1],temp_blocks[1][2],temp_blocks[1][3]}));
		for i = 2, #temp_blocks do
			local b = temp_blocks[i];
			aabb:Extend(vector3d:new({b[1], b[2], b[3]}));
		end

		local center = aabb:GetCenter();
		cx, cy, cz = math.floor(center[1]), math.floor(center[2]), math.floor(center[3]);		
		
		final_blocks = {};

		if(dx~=0 or dy~=0 or dz~=0 or #temp_blocks>1) then
			local GetTransformedPoint = SelectBlocksScale.GetTransformedPoint;
			local k = 0;
			for i = 1, #temp_blocks do
				local b = temp_blocks[i];
				local x,y,z = GetTransformedPoint(b[1], b[2], b[3], dx, dy, dz, rad_y, cx, cy, cz);
				k = k + 1;
				final_blocks[k] = {
					x,y,z,b[4],b[5],b[6],
				};
				--ParaTerrain.SelectBlock(x,y,z, true, groupindex_hint);
			end
		end

		if(#final_blocks >= 1) then 
			aabb = ShapeAABB:new();
			aabb:SetPointAABB(vector3d:new({final_blocks[1][1],final_blocks[1][2],final_blocks[1][3]}));
			for i = 2, #final_blocks do
				local b = final_blocks[i];
				aabb:Extend(vector3d:new({b[1], b[2], b[3]}));
			end
		end				

		scalingX, scalingY, scalingZ = temp_transform.scalingX or 1, temp_transform.scalingY or 1, temp_transform.scalingZ or 1
		final_blocks = SelectBlocksScale.GetScaledBlocks(final_blocks, aabb, scalingX, scalingY, scalingZ);

		if(dx~=0 or dy~=0 or dz~=0 or #final_blocks>0) then
			for i = 1, #final_blocks do
				local b = final_blocks[i];
				local x,y,z = b[1], b[2], b[3];
				ParaTerrain.SelectBlock(x,y,z, true, groupindex_hint);
			end
		end		
	end
end

function SelectBlocksScale.OnUIValueChanged()
	SelectBlocksScale.UpdateHintLocation();
end

function SelectBlocksScale.TransformSelection()
	transform.x = temp_transform.x or 0;
	transform.y = temp_transform.y or 0;
	transform.z = temp_transform.z or 0;
	transform.facing = (temp_transform.rotate or 0)* 90 or 0;
	transform.method = page:GetUIValue("method");
	--local scaling = page:GetValue("text_scaling", "1,1,1");
	local scaling = ""..page:GetValue("label_scaling_x", "1")..","..page:GetValue("label_scaling_y", "1")..","..page:GetValue("label_scaling_z", "1")..",";
	if(scaling) then
		NPL.load("(gl)script/apps/Aries/Creator/Game/Commands/CmdParser.lua");
		local CmdParser = commonlib.gettable("MyCompany.Aries.Game.CmdParser");
		local scalings = CmdParser.ParseNumberList(scaling);
		if(scalings and #scalings>=1) then
			transform.scalingX, transform.scalingY, transform.scalingZ = scalings[1], scalings[2] or scalings[1], scalings[3] or scalings[1];
		end
	end

	if((transform.x~=0 or transform.y~=0 or transform.z~=0) or 
	    (transform.facing ~= 0) or
		(transform.scalingX~=1 or transform.scalingY~=1 or transform.scalingZ~=1) ) or
		(SelectBlocksScale.pagetype and SelectBlocksScale.pagetype == "mirror") then
		SelectBlocksScale.result = "ok";
		if(page) then
			page:CloseWindow();
		end
	end
end

function SelectBlocksScale.OnClickReset()
	transform = old_transform;
	if(page) then
		page:Refresh(0.01);
	end
end

function SelectBlocksScale.OnInit()
	page = document:GetPageCtrl();
	
	temp_transform = transform or {0, 0, 0};

	page:SetValue("text_pos_x", transform.x or 0);
	page:SetValue("text_pos_y", transform.y or 0);
	page:SetValue("text_pos_z", transform.z or 0);
	page:SetValue("facing", transform.facing or 0);
	page:SetValue("method", if_else(not transform.method or transform.method=="move" or transform.method == "no_clone", "no_clone", "clone"));
end

function SelectBlocksScale.OnChangeAxisX()
	local axis_x = page:GetNode("axis_x");
	local axis_y = page:GetNode("axis_y");
	local axis_z = page:GetNode("axis_z");

	axis_x:SetAttribute("visible", "true");
	axis_y:SetAttribute("visible", "false");
	axis_z:SetAttribute("visible", "false");

	page:Refresh(0);

	axis_xyz = "x";
	mirror_axis = axis_xyz;
	SelectBlocksScale.UpdateHintLocation(nil, nil, nil, nil, axis_xyz);
end

function SelectBlocksScale.OnChangeAxisY()
	local axis_x = page:GetNode("axis_x");
	local axis_y = page:GetNode("axis_y");
	local axis_z = page:GetNode("axis_z");

	axis_x:SetAttribute("visible", "false");
	axis_y:SetAttribute("visible", "true");
	axis_z:SetAttribute("visible", "false");

	page:Refresh(0);

	axis_xyz = "y";
	mirror_axis = axis_xyz;
	SelectBlocksScale.UpdateHintLocation(nil, nil, nil, nil, axis_xyz);
end

function SelectBlocksScale.OnChangeAxisZ()
	local axis_x = page:GetNode("axis_x");
	local axis_y = page:GetNode("axis_y");
	local axis_z = page:GetNode("axis_z");

	axis_x:SetAttribute("visible", "false");
	axis_y:SetAttribute("visible", "false");
	axis_z:SetAttribute("visible", "true");
	
	page:Refresh(0);

	axis_xyz = "z";
	mirror_axis = axis_xyz;
	SelectBlocksScale.UpdateHintLocation(nil, nil, nil, nil, axis_xyz);
end