--[[
    Title: Quick SelectBar
    Author(s): WangXiXi
    Date: 2015/5/18
    Desc: Quick SelectBar
    use the lib:
    ------------------------------------------------------------
    NPL.load("(gl)script/Seer/QuickMotionBar.lua");
    local QuickMotionBar = commonlib.gettable("Mod.Seer.UI.QuickMotionBar");
    -------------------------------------------------------
]]
NPL.load("(gl)script/apps/Aries/Creator/Game/GameRules/GameMode.lua");
local gameMode = commonlib.gettable("MyCompany.Aries.Game.GameLogic.GameMode");

NPL.load("(gl)script/ide/AudioEngine/AudioEngine.lua");
local AudioEngine = commonlib.gettable("AudioEngine");

NPL.load("(gl)script/apps/Aries/Creator/Game/Tasks/UndoManager.lua");
local undoManager = commonlib.gettable("MyCompany.Aries.Game.UndoManager");

local CommandManager = commonlib.gettable("MyCompany.Aries.Game.CommandManager");
local GameLogic = commonlib.gettable("MyCompany.Aries.Game.GameLogic")

NPL.load("(gl)script/Seer/Utility/GlobalMessageDispatcher.lua");
local GlobalMessageDispatcher=commonlib.gettable("Mod.Seer.Utility.GlobalMessageDispatcher");

NPL.load("(gl)script/Seer/Game/Friend/FriendManager.lua");
local FriendManager = commonlib.gettable("Mod.Seer.Game.Friend.FriendManager");

-- local QuickMotionBar = commonlib.gettable("Mod.Seer.UI.QuickMotionBar");


local UIManager = commonlib.gettable("Mod.Seer.Game.UI.UIManager");

local UIBase = commonlib.gettable("Mod.Seer.Game.UI.UIBase");
local QuickMotionBar = commonlib.inherit(UIBase,commonlib.gettable("Mod.Seer.UI.QuickMotionBar"));


NPL.load("(gl)script/seer/Utility/CommonUtility.lua");
local CommonUtility = commonlib.gettable("Mod.Seer.Utility.CommonUtility");

if CommonUtility:IsMobilePlatform() then

UIManager.registerUI("QuickMotionBar", QuickMotionBar,"script/Seer/QuickMotionBar.html",
{
  directPosition = true,
    align = "_ctb",
    x = 0,
    y = 0,
    width = 1080,
    height = 130,
});

else

UIManager.registerUI("QuickMotionBar", QuickMotionBar,"script/Seer/QuickMotionBar.PC.html",
{
  directPosition = true,
    align = "_ctb",
    x = 0,
    y = -5,
    width = 650,
    height = 80,
});

end



-- function QuickMotionBar.ShowPage()
--   local params = {
--         url = "script/Seer/QuickMotionBar.html",
--         name = "QuickMotionBar.ShowPage",
--         isShowTitleBar = false,
--         DestroyOnClose = true,
--         bToggleShowHide=true,
--         style = CommonCtrl.WindowFrame.ContainerStyle,
--         allowDrag = false,
--         enable_esc_key = false,
--         cancelShowAnimation = true,
--         click_through = false,
--         directPosition = true,
--           align = "_ctb",
--           x = 0,
--           y = 0,
--           width = 660,
--           height = 50,
--       };
--   System.App.Commands.Call("File.MCMLWindowFrame", params);
--   if lOpenFriendButtonTimer then
--     lOpenFriendButtonTimer:Change();
--     lOpenFriendButtonTimer=nil;
--   end
--   _onMessage_UnreadMessageEnableChange();
-- end


QuickMotionBar.curExp = 0
QuickMotionBar.maxExp = 100
QuickMotionBar.progress_bar_width = 358

QuickMotionBar.custombtn_nodes = {
    {},{},{},{},{},{},{},{},{}
}
QuickMotionBar.motionIndex = 1;

QuickMotionBar.minimap_display = false


local lOpenFriendButtonTimer=nil;

QuickMotionBar.blockWidth = 0;

function QuickMotionBar:onCreate()
    GameLogic.events:AddEventListener("EvnetMotionIndexChanged", QuickMotionBar.EvnetMotionIndexChanged, self, "quickMotionBar");

    if lOpenFriendButtonTimer then
        lOpenFriendButtonTimer:Change();
        lOpenFriendButtonTimer=nil;
    end

    local gridview = self.page:GetNode("quickMotionBar");
    if gridview then
        QuickMotionBar.blockWidth = gridview:GetInt("DefaultNodeWidth", 0);
    end

    self:refresh(0)
end
function QuickMotionBar.EvnetMotionIndexChanged(event)
    local ui = UIManager.getUI("QuickMotionBar")
    if ui then
        ui:OnMotionIndexChanged(event)
    end
end
function QuickMotionBar:OnMotionIndexChanged(event)
    if (self.page) then
        local ctl = self.page:FindControl("handtool_highlight_bg")
        if ctl then
            ctl.x = (GameLogic.GetPlayerController():GetHandToolIndex()-1) * QuickMotionBar.blockWidth;
        end
    end
end

function QuickMotionBar:ds_CustomBtn(index)
    if(not index) then
        return #(self.custombtn_nodes);
    else
        return self.custombtn_nodes[index];
    end
end

function QuickMotionBar:OnClickMotionButton(name, mcmlNode)
    local buttonIndex = string.match(name, "^Motion(%d+)");
    buttonIndex = tonumber(buttonIndex)
    if buttonIndex < 1 or buttonIndex > #self.custombtn_nodes then
        return
    end
    self.motionIndex = buttonIndex
    local animLUT = {
        "35","32","31","79","34","78","72","75","100",
    }
    if buttonIndex then
        CommandManager:RunCommand("anim", animLUT[buttonIndex]);
        if(self.page) then
            local ctl = self.page:FindControl("handtool_highlight_bg");
            if(ctl) then
                ctl.x = (buttonIndex-1) * QuickMotionBar.blockWidth;
            end
        end
    end
end
function QuickMotionBar:OnClickItem(mcmlNode)
   -- _guihelper.MessageBox("Button "..mcmlNode.solt.slotIndex.." Clicked");
    --GameLogic.GetPlayerController():OnClickHandToolIndex(mcmlNode.solt.slotIndex)
end

function QuickMotionBar:OnProgressChanged()
    local IProgress = QuickMotionBar.IProgress;
    if(IProgress) then
        self.maxExp = IProgress:GetMaxValue();
        self.curExp = IProgress:GetValue();
        QuickMotionBar:UpdateExpUI();
    end
end

function QuickMotionBar:UpdateExpUI()
    local cur_value = self.curExp;
    local max_value = self.maxExp;
    cur_value = math.min(cur_value,max_value);
    local _bar = ParaUI.GetUIObject("mc_exp_bar");
    if(_bar:IsValid() == true) then
        local width = self.progress_bar_width;
        width = math.ceil( (cur_value / max_value) * width );
        width = math.max(8,width);
        _bar.width = width;
        _bar.tooltip = format("%d/%d", cur_value, max_value);
    end
end

function QuickMotionBar:OnClickAccelerateProgress()
    if(self.IProgress) then
        self.IProgress:GetEvents():DispatchEvent({type = "OnClickAccelerateProgress", });
    end
end

function QuickMotionBar:handleMouseEvent(event)
  local event_type = event:GetType();
    if (event_type == "mouseWheelEvent" ) then
    if (not event.ctrl_pressed) then
      local index = self.motionIndex - event.mouse_wheel
      self:OnClickMotionButton("Motion"..index);
      event.accepted = true;
    end
  end
end
function QuickMotionBar:handleKeyEvent(event)
	-- For Numeric key 1-9
    local key_index = event.keyname:match("^DIK_(%d)");
    if (key_index) and (key_index ~= "0") then
        self:OnClickMotionButton("Motion"..key_index);
        event:accept();
        return true;
    end
end
