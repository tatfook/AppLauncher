--[[
	NPL.load("(gl)script/Seer/Utility/BitState.lua");
	local BitState = commonlib.gettable("Mod.Seer.Utility.BitState");
]]

NPL.load("(gl)script/ide/math/bit.lua");
local bor = mathlib.bit.bor
local band = mathlib.bit.band;
local bxor = mathlib.bit.bxor;
local bnot = mathlib.bit.bnot
local rshift = mathlib.bit.rshift;
local lshift = mathlib.bit.lshift;
local modf = math.modf;

local BitState = commonlib.inherit(nil, commonlib.gettable("Mod.Seer.Utility.BitState"));

local test = false;
local MAX_SIZE = 16; 
local UNIT_SIZE = 16;
BitState.MAX_STATE = MAX_SIZE * UNIT_SIZE;

function BitState:ctor()
	self.state = {}
	for i = 1, MAX_SIZE do 
		self.state[i] = 0;
	end

end

local function get(state, index)
	if test then
		return state[index];
	else
		local chunk = modf(index / UNIT_SIZE) + 1;
		local shift = index % UNIT_SIZE;
		return band(1, rshift(state[chunk], shift)); 
	end
end


local function set(state, index,val)
	if test then
		state[index] = val;
	else
		local chunk = modf(index / UNIT_SIZE) + 1;
		local shift = index % UNIT_SIZE;
		state[chunk] = band(state[chunk], bnot(lshift(1, shift))) + lshift(val, shift);
		return chunk, shift;
	end
end

function BitState:hasState(index)
	return get(self.state,index) == 1;
end

function BitState:addState(index)
	return set(self.state, index, 1);
end

function BitState:removeState(index)
	return set(self.state, index, 0);
end

function BitState:getData()
	return commonlib.copy(self.state);
end

function BitState:setData(data)
	self.state = data;
	for i = 1, MAX_SIZE do
		self.state[i] = self.state[i] or 0;
	end
	return self;
end