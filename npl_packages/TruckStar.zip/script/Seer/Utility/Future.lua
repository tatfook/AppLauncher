--[[
	NPL.load("(gl)script/Seer/Utility/Future.lua");

    example: 
        local Async = commonlib.gettable("Mod.Seer.Utility.Async");
        -- call by file 
        local future = Async.call("script/func.lua", parameter1, parameter1 );
        -- call by string
        local future = Async.call("return function(output) echo(output) end", "hello world");

        -- one way to get returns ;
        if future:isReady() then 
            local result1, result2, result3 = future:get();
        end

        -- another way from callback
        future.get(function (result1, result2,result3)
            echo({result1, result2, result3})
        end)

        "script/func.lua":
            
            return function (p1, p2) return p1, p2, p1 .. p2; end

]]

local Future = commonlib.inherit(nil, commonlib.gettable("Mod.Seer.Utility.Future"));

local Async = commonlib.gettable("Mod.Seer.Utility.Async");

NPL.load("(gl)script/Seer/Utility/Thread.lua");
local ThreadPool = commonlib.gettable("Mod.Seer.Utility.ThreadPool");

Future.Waitting = 1;
Future.Ready = 2;

function Async.call(func, ...)
    local f = Future:new();
    ThreadPool.addTask(func, {...}, 
        function (type, data)
            if type == "setvalue" and data[1] == "_result"  then
                f.result = data[2];
                f.state = Future.Ready;
                f:get(f.callback);
            end
        end)

    return f;
end

function Future:ctor()
    self.state = Future.Waitting;
end

function Future:get(callback)

    self.callback = callback;
    if self.state == Future.Waitting then
        return;
    else
        local result = self.result
        if result == nil then
            if self.callback then
                self.callback();
            else
                return ;
            end
        else
            local index = #result + 1;
            local function get()
                index = index - 1;
                if index <= 0 then
                    return nil
                else
                    return result[index];
                end
            end

            local function parse(...)
                local val = get();
                if val ~= nil then
                    return parse(val, ...);
                else
                    return ...;
                end
            end

            if self.callback then
                self.callback(parse(get()));
            else
                return parse(get());
            end
        end
    end
end

function Future:isReady()
    return self.state == Future.Ready;
end
